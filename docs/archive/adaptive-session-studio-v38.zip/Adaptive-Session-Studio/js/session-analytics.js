// ── session-analytics.js ───────────────────────────────────────────────────
// Post-session analytics: collects time-in-block, loop count, total runtime,
// and FS output stats. Stores the last 10 summaries in localStorage.
// Displays a post-session modal after natural stop (not emergency stop).
//
// ROADMAP Phase 5.3 — Session Analytics

import { state, fmt, esc } from './state.js';
import { fsState } from './macros.js';

const STORAGE_KEY = 'ass-analytics-v1';
const MAX_STORED  = 10;

// ── Collection ──────────────────────────────────────────────────────────────
// Called by tickPlayback each frame to accumulate block-time counters.
// runtime.analytics is initialised by startPlayback.

export function initAnalytics(runtime) {
  runtime.analytics = {
    blockTime:   {},   // blockId → accumulated seconds
    sceneTime:   {},   // sceneId → accumulated seconds
    fsPosSamples:[],   // array of 0–100 position samples (downsampled)
    fsSampleTick: 0,   // counter for downsampling
    attentionLossEvents: 0,
    attentionLossTotalSec: 0,
    _attentionLostAt: null,
  };
}

// Call every tick. frameSec = seconds since last frame (approx 1/60).
export function tickAnalytics(runtime, frameSec) {
  const a = runtime.analytics;
  if (!a) return;

  // Accumulate time for the active block
  const bid = runtime.activeBlock?.id;
  if (bid) {
    a.blockTime[bid] = (a.blockTime[bid] ?? 0) + frameSec;
  }

  // Accumulate time for the active scene
  const sid = runtime.activeScene?.scene?.id;
  if (sid) {
    a.sceneTime[sid] = (a.sceneTime[sid] ?? 0) + frameSec;
  }

  // Downsample FS position: record one sample every ~30 frames (~0.5s)
  a.fsSampleTick++;
  if (a.fsSampleTick % 30 === 0) {
    a.fsPosSamples.push(Math.round(fsState.lastSentPos));
  }
}

// Attention-loss hooks (called by tracking.js automation)
export function notifyAttentionLost(runtime) {
  const a = runtime?.analytics;
  if (!a) return;
  a._attentionLostAt = performance.now();
  a.attentionLossEvents++;
}

export function notifyAttentionReturned(runtime) {
  const a = runtime?.analytics;
  if (!a || a._attentionLostAt === null) return;
  a.attentionLossTotalSec += (performance.now() - a._attentionLostAt) / 1000;
  a._attentionLostAt = null;
}

// ── Finalise & store ─────────────────────────────────────────────────────────
export function finaliseAnalytics(runtime) {
  if (!runtime?.analytics) return null;
  const { session } = state;
  const a = runtime.analytics;

  const totalSec = (performance.now() - runtime.startedAt - runtime.totalPausedMs) / 1000;
  // loopIndex is the current (0-based) loop, not the count of *completed* loops.
  // Use floor(totalSec / duration) so an in-progress loop is not counted as done.
  const loopsCompleted = Math.floor(totalSec / Math.max(1, session.duration));

  // If attention was still lost when the session ended, fold in the open interval now.
  if (a._attentionLostAt !== null) {
    a.attentionLossTotalSec += (performance.now() - a._attentionLostAt) / 1000;
    a._attentionLostAt = null;
  }

  // Block breakdown (only blocks with any time)
  const blockBreakdown = session.blocks
    .filter(b => a.blockTime[b.id] > 0)
    .map(b => ({ id: b.id, label: b.label, type: b.type, seconds: Math.round(a.blockTime[b.id] ?? 0) }))
    .sort((x, y) => y.seconds - x.seconds);

  // Scene breakdown (only scenes with any time)
  const sceneBreakdown = (session.scenes ?? [])
    .filter(s => a.sceneTime[s.id] > 0)
    .map(s => ({ id: s.id, name: s.name, color: s.color, seconds: Math.round(a.sceneTime[s.id] ?? 0) }))
    .sort((x, y) => y.seconds - x.seconds);

  // FS stats
  const samples = a.fsPosSamples;
  const fsAvg   = samples.length ? Math.round(samples.reduce((s, v) => s + v, 0) / samples.length) : null;
  const fsMax   = samples.length ? Math.max(...samples) : null;

  const summary = {
    timestamp:    Date.now(),
    sessionName:  session.name,
    totalSec:     Math.round(totalSec),
    loopsCompleted,
    blockBreakdown,
    sceneBreakdown,
    fsAvg,
    fsMax,
    attentionLossEvents:   a.attentionLossEvents,
    attentionLossTotalSec: Math.round(a.attentionLossTotalSec),
  };

  _store(summary);
  return summary;
}

function _store(summary) {
  try {
    const existing = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '[]');
    existing.unshift(summary);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(existing.slice(0, MAX_STORED)));
  } catch { /* storage full or unavailable — silently skip */ }
}

export function getStoredAnalytics() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '[]'); } catch { return []; }
}

// ── Post-session modal ───────────────────────────────────────────────────────
export function showPostSessionModal(summary) {
  if (!summary) return;

  const existing = document.getElementById('postSessionModal');
  if (existing) existing.remove();

  const overlay = document.createElement('div');
  overlay.id = 'postSessionModal';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-label', 'Session summary');
  overlay.style.cssText = `
    position:fixed;inset:0;z-index:9990;
    background:rgba(0,0,0,0.65);backdrop-filter:blur(4px);
    display:flex;align-items:center;justify-content:center;
    font-family:Inter,system-ui,sans-serif;`;
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

  // FS activity bar (visual summary of position over time)
  const barHtml = summary.fsAvg !== null
    ? `<div style="margin:10px 0 4px;font-size:10px;color:rgba(255,255,255,0.3);letter-spacing:.08em;text-transform:uppercase">FS Output</div>
       <div style="display:flex;gap:1px;height:28px;align-items:flex-end">
         ${_minibar(summary.fsAvg, summary.fsMax)}
       </div>
       <div style="display:flex;justify-content:space-between;font-size:10px;color:rgba(255,255,255,0.3);margin-top:3px">
         <span>Avg ${summary.fsAvg}%</span><span>Peak ${summary.fsMax}%</span>
       </div>`
    : '';

  // Block breakdown rows
  const blockRows = summary.blockBreakdown.slice(0, 6).map(b =>
    `<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:0.5px solid rgba(255,255,255,0.05);font-size:11px">
       <span style="color:var(--text2,#908e86)">${esc(b.label)}</span>
       <span style="color:var(--text,#d8d6ce)">${fmt(b.seconds)}</span>
     </div>`
  ).join('');

  // Scene breakdown rows (only if scenes were active)
  const sceneRows = (summary.sceneBreakdown ?? []).slice(0, 4).map(s =>
    `<div style="display:flex;align-items:center;gap:6px;padding:4px 0;border-bottom:0.5px solid rgba(255,255,255,0.05);font-size:11px">
       <div style="width:8px;height:8px;border-radius:50%;background:${s.color};flex-shrink:0"></div>
       <span style="flex:1;color:var(--text2,#908e86)">${esc(s.name)}</span>
       <span style="color:var(--text,#d8d6ce)">${fmt(s.seconds)}</span>
     </div>`
  ).join('');

  // Attention row (only if tracking was used)
  const attentionHtml = summary.attentionLossEvents > 0
    ? `<div style="margin-top:10px;font-size:11px;color:#f0a04a">
         ⚠ ${summary.attentionLossEvents} attention loss event${summary.attentionLossEvents > 1 ? 's' : ''}
         · ${fmt(summary.attentionLossTotalSec)} total
       </div>`
    : '';

  overlay.innerHTML = `
    <div id="postSessionModalInner" style="background:#16161c;border:0.5px solid rgba(255,255,255,0.12);
      border-radius:14px;padding:24px;max-width:420px;width:92vw;
      max-height:88vh;overflow-y:auto;position:relative">

      <div style="display:flex;align-items:baseline;justify-content:space-between;margin-bottom:18px">
        <div>
          <div style="font-family:Syne,system-ui,sans-serif;font-size:15px;font-weight:700;color:#f0f0e8;margin-bottom:3px">
            Session complete
          </div>
          <div style="font-size:11px;color:rgba(255,255,255,0.35)">${esc(summary.sessionName)}</div>
        </div>
        <button id="postSessionClose1" style="
          background:transparent;border:none;color:rgba(255,255,255,0.3);
          font-size:18px;cursor:pointer;padding:0;line-height:1">✕</button>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:14px">
        ${_statPill('Runtime', fmt(summary.totalSec))}
        ${_statPill('Loops', summary.loopsCompleted)}
        ${_statPill('Blocks', summary.blockBreakdown.length)}
      </div>

      ${barHtml}
      ${attentionHtml}

      ${sceneRows ? `
        <div style="margin-top:14px;font-size:10px;color:rgba(255,255,255,0.3);letter-spacing:.08em;text-transform:uppercase;margin-bottom:6px">Time per scene</div>
        ${sceneRows}` : ''}

      ${summary.blockBreakdown.length ? `
        <div style="margin-top:14px;font-size:10px;color:rgba(255,255,255,0.3);letter-spacing:.08em;text-transform:uppercase;margin-bottom:6px">Time per block</div>
        ${blockRows}` : ''}

      <button id="postSessionClose2" style="
        margin-top:18px;width:100%;padding:9px;border-radius:8px;
        border:0.5px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);
        color:#d8d6ce;font-family:inherit;font-size:12px;cursor:pointer">
        Close
      </button>
    </div>`;

  document.body.appendChild(overlay);

  const closeModal = () => overlay.remove();
  document.getElementById('postSessionClose1')?.addEventListener('click', closeModal);
  document.getElementById('postSessionClose2')?.addEventListener('click', closeModal);
}

function _statPill(label, value) {
  return `<div style="background:rgba(255,255,255,0.04);border:0.5px solid rgba(255,255,255,0.08);
    border-radius:8px;padding:10px;text-align:center">
    <div style="font-size:15px;font-weight:700;color:#f0f0e8;margin-bottom:3px">${value}</div>
    <div style="font-size:10px;color:rgba(255,255,255,0.3);text-transform:uppercase;letter-spacing:.07em">${label}</div>
  </div>`;
}

function _minibar(avg, max) {
  if (max === null || max === 0) return '<span style="color:rgba(255,255,255,0.2);font-size:10px">No FS data</span>';
  // Two bars: avg and peak
  const avgH  = Math.round((avg / 100) * 28);
  const maxH  = Math.round((max / 100) * 28);
  const color = avg > 70 ? '#e05050' : avg > 40 ? '#f0a04a' : '#5fa0dc';
  return `
    <div style="display:flex;gap:6px;align-items:flex-end;height:28px">
      <div style="width:32px;height:${avgH}px;background:${color};border-radius:3px 3px 0 0;opacity:0.7" title="Average"></div>
      <div style="width:32px;height:${maxH}px;background:${color};border-radius:3px 3px 0 0" title="Peak"></div>
    </div>`;
}
