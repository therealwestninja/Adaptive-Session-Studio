// ── tests/suggestions.test.js ─────────────────────────────────────────────
// Tests for analyzeSession() in suggestions.js
// These are purely logic tests — no DOM needed.

import { makeRunner } from './harness.js';
import { analyzeSession } from '../js/suggestions.js';
import { state } from '../js/state.js';
import { defaultSession, normalizeSession } from '../js/state.js';

export function runSuggestionsTests() {
  const R  = makeRunner('suggestions.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  function setup(patch = {}) {
    state.session = normalizeSession({ ...defaultSession(), ...patch });
    // Minimal viable session: one block, duration matches
    if (!patch.blocks) {
      state.session.blocks = [
        { id: 'b1', type: 'text', label: 'Hello', start: 0, duration: 10, content: 'Hi' }
      ];
    }
    if (!patch.duration) state.session.duration = 60;
    state.session.playlists.audio = [{ id: 'a1', name: 'bg.mp3', dataUrl: 'data:audio/mp3;base64,AA==', volume: 1, _muted: false }];
  }

  function ids(sugs) { return sugs.map(s => s.id); }

  // ── No blocks ──────────────────────────────────────────────────────────────
  t('no_blocks suggestion when session has no blocks', () => {
    state.session = normalizeSession({ duration: 60 });
    state.session.blocks = [];
    const sugs = analyzeSession();
    ok(ids(sugs).includes('no_blocks'), `got: ${ids(sugs).join(', ')}`);
  });

  // ── Block overflow ─────────────────────────────────────────────────────────
  t('blocks_overflow when block extends past duration', () => {
    setup({ duration: 30 });
    state.session.blocks = [
      { id: 'b1', type: 'text', label: 'Long', start: 20, duration: 20, content: 'Hi' }
    ];
    ok(ids(analyzeSession()).includes('blocks_overflow'));
  });

  t('no blocks_overflow when block fits exactly', () => {
    setup({ duration: 30 });
    state.session.blocks = [
      { id: 'b1', type: 'text', label: 'OK', start: 0, duration: 30, content: 'Hi' }
    ];
    ok(!ids(analyzeSession()).includes('blocks_overflow'));
  });

  // ── All good ───────────────────────────────────────────────────────────────
  t('all_good when session is clean', () => {
    setup();
    const sugs = analyzeSession();
    // May include no_background but not overflow/overlap/etc
    ok(!ids(sugs).some(id => ['blocks_overflow','text_blocks_overlap','no_blocks'].includes(id)));
  });

  // ── Text overlap ───────────────────────────────────────────────────────────
  t('text_blocks_overlap when two text blocks overlap', () => {
    setup();
    state.session.blocks = [
      { id: 'b1', type: 'text', label: 'A', start: 0,  duration: 20, content: 'A' },
      { id: 'b2', type: 'text', label: 'B', start: 10, duration: 20, content: 'B' },
    ];
    ok(ids(analyzeSession()).includes('text_blocks_overlap'));
  });

  t('no text_blocks_overlap when text blocks are sequential', () => {
    setup();
    state.session.blocks = [
      { id: 'b1', type: 'text', label: 'A', start: 0,  duration: 10, content: 'A' },
      { id: 'b2', type: 'text', label: 'B', start: 10, duration: 10, content: 'B' },
    ];
    ok(!ids(analyzeSession()).includes('text_blocks_overlap'));
  });

  t('no text_blocks_overlap for audio vs text overlap (only text vs text)', () => {
    setup();
    state.session.blocks = [
      { id: 'b1', type: 'audio', label: 'A', start: 0,  duration: 20, content: '' },
      { id: 'b2', type: 'text',  label: 'B', start: 5,  duration: 20, content: 'B' },
    ];
    ok(!ids(analyzeSession()).includes('text_blocks_overlap'));
  });

  // ── Many short loops ───────────────────────────────────────────────────────
  t('many_short_loops when loopCount > 10 and duration < 60', () => {
    setup({ duration: 30, loopMode: 'count', loopCount: 20 });
    ok(ids(analyzeSession()).includes('many_short_loops'));
  });

  t('no many_short_loops when duration >= 60', () => {
    setup({ duration: 60, loopMode: 'count', loopCount: 20 });
    ok(!ids(analyzeSession()).includes('many_short_loops'));
  });

  t('no many_short_loops when loopCount <= 10', () => {
    setup({ duration: 30, loopMode: 'count', loopCount: 5 });
    ok(!ids(analyzeSession()).includes('many_short_loops'));
  });

  // ── Rules without webcam ───────────────────────────────────────────────────
  t('rules_no_webcam when attention rules exist but tracking disabled', () => {
    setup();
    state.session.tracking.enabled = false;
    state.session.rules = [{
      id: 'r1', name: 'test', enabled: true,
      condition: { metric: 'attention', op: '<', value: 0.3 },
      durationSec: 3, cooldownSec: 30,
      action: { type: 'pause', param: null }
    }];
    ok(ids(analyzeSession()).includes('rules_no_webcam'));
  });

  t('no rules_no_webcam when tracking enabled', () => {
    setup();
    state.session.tracking.enabled = true;
    state.session.rules = [{
      id: 'r1', name: 'test', enabled: true,
      condition: { metric: 'attention', op: '<', value: 0.3 },
      durationSec: 3, cooldownSec: 30,
      action: { type: 'pause', param: null }
    }];
    ok(!ids(analyzeSession()).includes('rules_no_webcam'));
  });

  t('no rules_no_webcam when rule uses non-attention metric', () => {
    setup();
    state.session.tracking.enabled = false;
    state.session.rules = [{
      id: 'r1', name: 'test', enabled: true,
      condition: { metric: 'intensity', op: '>', value: 1.5 },
      durationSec: 3, cooldownSec: 30,
      action: { type: 'setSpeed', param: 0.5 }
    }];
    ok(!ids(analyzeSession()).includes('rules_no_webcam'));
  });

  // ── Pacing without webcam ──────────────────────────────────────────────────
  t('pacing_no_webcam when dynamic pacing on but tracking disabled', () => {
    setup();
    state.session.tracking.enabled = false;
    state.session.pacingSettings = { enabled: true, minSpeed: 0.5, maxSpeed: 2, smoothingSec: 4, curve: 'linear', lockDuringSec: 0 };
    ok(ids(analyzeSession()).includes('pacing_no_webcam'));
  });

  // ── Scene overflow ─────────────────────────────────────────────────────────
  t('scene_overflow when scene extends past session duration', () => {
    setup({ duration: 60 });
    state.session.scenes = [{ id: 's1', name: 'Late', start: 50, end: 80, color: '#5fa0dc', loopBehavior: 'once' }];
    ok(ids(analyzeSession()).includes('scene_overflow'));
  });

  t('no scene_overflow when scene fits within duration', () => {
    setup({ duration: 60 });
    state.session.scenes = [{ id: 's1', name: 'OK', start: 0, end: 60, color: '#5fa0dc', loopBehavior: 'once' }];
    ok(!ids(analyzeSession()).includes('scene_overflow'));
  });

  // ── analyzeSession always returns an array ─────────────────────────────────
  t('analyzeSession always returns an array', () => {
    setup();
    ok(Array.isArray(analyzeSession()));
  });

  t('each suggestion has id, severity, title, detail', () => {
    setup();
    const sugs = analyzeSession();
    ok(sugs.length > 0);
    for (const s of sugs) {
      ok(typeof s.id === 'string' && s.id.length > 0, `id missing on ${JSON.stringify(s)}`);
      ok(['warn','info','error'].includes(s.severity), `severity '${s.severity}' invalid`);
      ok(typeof s.title === 'string' && s.title.length > 0, `title missing`);
      ok(typeof s.detail === 'string', `detail missing`);
    }
  });

  // ── Large embedded media warning ───────────────────────────────────────────
  t('large_media info when audio total exceeds 50 MB', () => {
    setup();
    // ~51 MB in base64 characters (base64 length ≈ bytes / 0.75)
    const bigUrl = 'data:audio/mp3;base64,' + 'A'.repeat(Math.ceil(51_000_000 / 0.75));
    state.session.playlists.audio = [{ id: 'a1', name: 'big.mp3', dataUrl: bigUrl, volume: 1, _muted: false }];
    const sugs = analyzeSession();
    ok(ids(sugs).includes('large_media'), `expected large_media, got: ${ids(sugs).join(', ')}`);
  });

  t('no large_media when all media is under 50 MB', () => {
    setup();
    // 1 KB data URL — well under threshold
    const smallUrl = 'data:audio/mp3;base64,' + 'A'.repeat(1000);
    state.session.playlists.audio = [{ id: 'a1', name: 's.mp3', dataUrl: smallUrl, volume: 1, _muted: false }];
    ok(!ids(analyzeSession()).includes('large_media'));
  });

  t('large_media severity is warn when media exceeds 150 MB', () => {
    setup();
    const hugeUrl = 'data:audio/mp3;base64,' + 'A'.repeat(Math.ceil(200_000_000 / 0.75));
    state.session.playlists.audio = [{ id: 'a1', name: 'huge.mp3', dataUrl: hugeUrl, volume: 1, _muted: false }];
    const sugs = analyzeSession();
    const lg = sugs.find(s => s.id === 'large_media');
    ok(lg !== undefined, 'large_media should be present');
    ok(lg.severity === 'warn', `expected warn, got ${lg?.severity}`);
  });

  // ── Broken scene branch reference ──────────────────────────────────────────
  t('broken_branch when nextSceneId points to non-existent scene', () => {
    setup({ duration: 120 });
    state.session.scenes = [{
      id: 's1', name: 'Intro', start: 0, end: 60,
      loopBehavior: 'once', color: '#5fa0dc',
      nextSceneId: 'b_nonexistent_scene_id',
    }];
    ok(ids(analyzeSession()).includes('broken_branch'));
  });

  t('no broken_branch when nextSceneId points to an existing scene', () => {
    setup({ duration: 120 });
    state.session.scenes = [
      { id: 's1', name: 'Intro', start: 0,  end: 60, loopBehavior: 'once', color: '#5fa0dc', nextSceneId: 's2' },
      { id: 's2', name: 'Main',  start: 60, end: 120, loopBehavior: 'once', color: '#7dc87a', nextSceneId: null },
    ];
    ok(!ids(analyzeSession()).includes('broken_branch'));
  });

  t('no broken_branch when nextSceneId is null (default)', () => {
    setup({ duration: 60 });
    state.session.scenes = [
      { id: 's1', name: 'Only', start: 0, end: 60, loopBehavior: 'once', color: '#5fa0dc', nextSceneId: null }
    ];
    ok(!ids(analyzeSession()).includes('broken_branch'));
  });

  // ── Unlabeled blocks warning ───────────────────────────────────────────────
  t('unlabeled_blocks when 3+ blocks have generic labels', () => {
    setup();
    state.session.blocks = [
      { id: 'b1', type: 'text', label: 'Block 1', start: 0,  duration: 5,  content: 'A' },
      { id: 'b2', type: 'text', label: 'Block 2', start: 10, duration: 5,  content: 'B' },
      { id: 'b3', type: 'text', label: 'Block 3', start: 20, duration: 5,  content: 'C' },
    ];
    ok(ids(analyzeSession()).includes('unlabeled_blocks'));
  });

  t('no unlabeled_blocks when fewer than 3 blocks have generic labels', () => {
    setup();
    state.session.blocks = [
      { id: 'b1', type: 'text', label: 'Intro', start: 0, duration: 10, content: 'A' },
      { id: 'b2', type: 'text', label: 'Block 2', start: 15, duration: 5, content: 'B' },
    ];
    ok(!ids(analyzeSession()).includes('unlabeled_blocks'));
  });

  t('no unlabeled_blocks when all blocks have custom labels', () => {
    setup();
    state.session.blocks = [
      { id: 'b1', type: 'text', label: 'Intro',  start: 0,  duration: 10, content: 'A' },
      { id: 'b2', type: 'text', label: 'Middle', start: 15, duration: 10, content: 'B' },
      { id: 'b3', type: 'text', label: 'Outro',  start: 30, duration: 10, content: 'C' },
    ];
    ok(!ids(analyzeSession()).includes('unlabeled_blocks'));
  });

  return R.summary();
}
