// ── tests/user-profile.test.js ────────────────────────────────────────────
// Tests for user-profile.js: computeDifficultyLevel, getAdaptiveRampSuggestion,
// getStreakMilestone, rebuildProfile.

import { makeRunner } from './harness.js';
import {
  computeDifficultyLevel, getAdaptiveRampSuggestion,
  getStreakMilestone, defaultProfile,
} from '../js/user-profile.js';

export function runUserProfileTests() {
  const R  = makeRunner('user-profile.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // ── computeDifficultyLevel ────────────────────────────────────────────
  t('computeDifficultyLevel returns 1 for null profile', () => {
    eq(computeDifficultyLevel(null), 1);
  });
  t('computeDifficultyLevel returns 1 for new user (< 2 sessions)', () => {
    eq(computeDifficultyLevel({ ...defaultProfile(), sessionCount: 1 }), 1);
  });
  t('computeDifficultyLevel returns 1 for baseline user with no bonuses', () => {
    const p = { ...defaultProfile(), sessionCount: 5, streak: 0,
      avgAttentionStability: 0.5, intensityTrend: 'stable' };
    eq(computeDifficultyLevel(p), 1);
  });
  t('computeDifficultyLevel streak 7+ adds level', () => {
    const p = { ...defaultProfile(), sessionCount: 10, streak: 7,
      avgAttentionStability: 0, intensityTrend: 'stable' };
    ok(computeDifficultyLevel(p) >= 2, 'streak 7 should push level >= 2');
  });
  t('computeDifficultyLevel streak 30+ adds more level', () => {
    const p = { ...defaultProfile(), sessionCount: 30, streak: 30,
      avgAttentionStability: 0, intensityTrend: 'stable' };
    ok(computeDifficultyLevel(p) >= 3, 'streak 30 should push level >= 3');
  });
  t('computeDifficultyLevel high attention stability adds level', () => {
    const p = { ...defaultProfile(), sessionCount: 5, streak: 0,
      avgAttentionStability: 0.82, intensityTrend: 'stable' };
    ok(computeDifficultyLevel(p) >= 2);
  });
  t('computeDifficultyLevel very high stability adds more level', () => {
    const p = { ...defaultProfile(), sessionCount: 5, streak: 0,
      avgAttentionStability: 0.96, intensityTrend: 'stable' };
    ok(computeDifficultyLevel(p) >= 2);
  });
  t('computeDifficultyLevel rising intensity trend adds bonus', () => {
    const p = { ...defaultProfile(), sessionCount: 5, streak: 0,
      avgAttentionStability: 0, intensityTrend: 'rising' };
    ok(computeDifficultyLevel(p) >= 1);
  });
  t('computeDifficultyLevel caps at 5', () => {
    const p = { ...defaultProfile(), sessionCount: 100, streak: 100,
      avgAttentionStability: 0.99, intensityTrend: 'rising' };
    ok(computeDifficultyLevel(p) <= 5);
  });

  // ── getAdaptiveRampSuggestion ─────────────────────────────────────────
  t('getAdaptiveRampSuggestion returns a valid rampSettings object', () => {
    const s = getAdaptiveRampSuggestion();
    ok(typeof s.enabled === 'boolean');
    ok(typeof s.startVal === 'number');
    ok(typeof s.endVal === 'number');
    ok(['time','engagement','step','adaptive'].includes(s.mode));
    ok(['linear','exponential','sine'].includes(s.curve));
    ok(['max','add','replace'].includes(s.blendMode));
  });
  t('getAdaptiveRampSuggestion startVal is in 0-2 range', () => {
    const s = getAdaptiveRampSuggestion();
    ok(s.startVal >= 0 && s.startVal <= 2, `startVal ${s.startVal} out of range`);
  });
  t('getAdaptiveRampSuggestion endVal is in 0-2 range', () => {
    const s = getAdaptiveRampSuggestion();
    ok(s.endVal >= 0 && s.endVal <= 2, `endVal ${s.endVal} out of range`);
  });
  t('getAdaptiveRampSuggestion endVal >= startVal', () => {
    const s = getAdaptiveRampSuggestion();
    ok(s.endVal >= s.startVal, `endVal ${s.endVal} should be >= startVal ${s.startVal}`);
  });
  t('getAdaptiveRampSuggestion includes a _note string', () => {
    const s = getAdaptiveRampSuggestion();
    ok(typeof s._note === 'string' && s._note.length > 0);
  });

  // ── getStreakMilestone ────────────────────────────────────────────────
  t('getStreakMilestone returns null for streak 0', () => {
    eq(getStreakMilestone(0), null);
  });
  t('getStreakMilestone returns null for non-milestone streaks', () => {
    eq(getStreakMilestone(2), null);
    eq(getStreakMilestone(5), null);
    eq(getStreakMilestone(10), null);
  });
  t('getStreakMilestone returns message for streak 3', () => {
    const m = getStreakMilestone(3);
    ok(m !== null && typeof m.message === 'string');
    ok(m.message.includes('3'));
  });
  t('getStreakMilestone returns message for streak 7', () => {
    const m = getStreakMilestone(7);
    ok(m !== null && typeof m.message === 'string');
  });
  t('getStreakMilestone returns message for streak 30', () => {
    const m = getStreakMilestone(30);
    ok(m !== null);
  });
  t('getStreakMilestone returns message for streak 100', () => {
    ok(getStreakMilestone(100) !== null);
  });

  // ── defaultProfile ────────────────────────────────────────────────────
  t('defaultProfile returns valid shape', () => {
    const p = defaultProfile();
    eq(p.sessionCount, 0);
    eq(p.totalRuntimeSec, 0);
    eq(p.streak, 0);
    eq(p.intensityTrend, 'stable');
    eq(p.attentionTrend, 'stable');
  });

  return R.summary();
}
