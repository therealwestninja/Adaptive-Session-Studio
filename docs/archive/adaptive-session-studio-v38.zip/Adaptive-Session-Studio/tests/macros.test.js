// ── tests/macros.test.js ─────────────────────────────────────────────────
// Tests for macros.js: library CRUD, slot assignments, and removeMacro
// cleanup across blocks, rules, and triggers.

import { makeRunner } from './harness.js';
import {
  allMacros, getMacro, getSlotMacro, setSlotMacro,
  saveMacro, removeMacro, newMacro, macroDuration,
  BUILTIN_MACROS,
} from '../js/macros.js';
import { state, defaultSession, normalizeSession } from '../js/state.js';

export function runMacrosTests() {
  const R   = makeRunner('macros.js');
  const t   = R.test.bind(R);
  const eq  = R.assertEqual.bind(R);
  const ok  = R.assert.bind(R);
  const deep = R.assertDeep.bind(R);

  function reset() {
    state.session = normalizeSession(defaultSession());
    state.session.macroLibrary = [];
    state.session.macroSlots   = { 1:null, 2:null, 3:null, 4:null, 5:null };
    state.session.blocks       = [];
    state.session.rules        = [];
    state.session.triggers     = [];
  }

  // ── Built-in macro constants ───────────────────────────────────────────
  t('BUILTIN_MACROS is a non-empty array', () => {
    ok(Array.isArray(BUILTIN_MACROS) && BUILTIN_MACROS.length >= 5);
  });

  t('each built-in macro has id, name, builtin:true, and actions', () => {
    for (const m of BUILTIN_MACROS) {
      ok(typeof m.id === 'string' && m.id.length > 0, `builtin id missing`);
      ok(typeof m.name === 'string', `builtin name missing`);
      ok(m.builtin === true, `builtin flag missing on ${m.id}`);
      ok(Array.isArray(m.actions) && m.actions.length > 0, `actions missing on ${m.id}`);
    }
  });

  // ── allMacros / getMacro ──────────────────────────────────────────────
  t('allMacros includes built-ins when macroLibrary is empty', () => {
    reset();
    const all = allMacros();
    ok(all.length >= BUILTIN_MACROS.length);
    ok(all.some(m => m.builtin), 'should contain builtins');
  });

  t('getMacro returns a builtin by id', () => {
    reset();
    const m = getMacro(BUILTIN_MACROS[0].id);
    ok(m !== null);
    eq(m.id, BUILTIN_MACROS[0].id);
  });

  t('getMacro returns null for unknown id', () => {
    reset();
    eq(getMacro('nonexistent'), null);
  });

  // ── saveMacro ─────────────────────────────────────────────────────────
  t('saveMacro adds a new custom macro', () => {
    reset();
    const m = newMacro();
    saveMacro(m);
    eq(state.session.macroLibrary.length, 1);
    eq(state.session.macroLibrary[0].id, m.id);
  });

  t('saveMacro updates an existing macro by id', () => {
    reset();
    const m = newMacro();
    saveMacro(m);
    const updated = { ...m, name: 'Updated Name' };
    saveMacro(updated);
    eq(state.session.macroLibrary.length, 1, 'should not duplicate');
    eq(state.session.macroLibrary[0].name, 'Updated Name');
  });

  // ── macroDuration ─────────────────────────────────────────────────────
  t('macroDuration returns 0 for macro with no actions', () => {
    eq(macroDuration({ actions: [] }), 0);
  });

  t('macroDuration returns last at value', () => {
    eq(macroDuration({ actions: [{ at: 0, pos: 0 }, { at: 1500, pos: 100 }] }), 1500);
  });

  // ── getSlotMacro ─────────────────────────────────────────────────────
  t('getSlotMacro returns builtin default when slot is unassigned', () => {
    reset();
    const slot1 = getSlotMacro(1);
    ok(slot1 !== null, 'slot 1 should default to first builtin');
    eq(slot1.id, BUILTIN_MACROS[0].id);
  });

  t('getSlotMacro returns assigned macro when slot is set', () => {
    reset();
    const m = newMacro();
    saveMacro(m);
    setSlotMacro(1, m.id);
    eq(getSlotMacro(1)?.id, m.id);
  });

  t('getSlotMacro returns null when assigned macro has been deleted', () => {
    reset();
    const m = newMacro();
    saveMacro(m);
    setSlotMacro(1, m.id);
    removeMacro(m.id); // deletes the macro — slot entry cleared by removeMacro
    // Slot should now fall back to builtin (null slot → builtin default)
    const result = getSlotMacro(1);
    // removeMacro clears the slot, so slot[1] becomes null → returns builtin
    eq(result?.id, BUILTIN_MACROS[0].id);
  });

  // ── removeMacro — cleanup correctness ────────────────────────────────
  t('removeMacro removes macro from macroLibrary', () => {
    reset();
    const m = newMacro();
    saveMacro(m);
    eq(state.session.macroLibrary.length, 1);
    removeMacro(m.id);
    eq(state.session.macroLibrary.length, 0);
  });

  t('removeMacro clears slot assignment pointing at deleted macro', () => {
    reset();
    const m = newMacro();
    saveMacro(m);
    setSlotMacro(3, m.id);
    eq(state.session.macroSlots[3], m.id, 'sanity: slot 3 should be assigned');
    removeMacro(m.id);
    ok(
      state.session.macroSlots[3] === null || state.session.macroSlots[3] === undefined,
      `slot 3 should be cleared after deletions, got: ${state.session.macroSlots[3]}`
    );
  });

  t('removeMacro does not clear slots pointing at OTHER macros', () => {
    reset();
    const mA = { ...newMacro(), name: 'MacroA' };
    const mB = { ...newMacro(), name: 'MacroB' };
    saveMacro(mA); saveMacro(mB);
    setSlotMacro(1, mA.id);
    setSlotMacro(2, mB.id);
    removeMacro(mA.id);
    eq(state.session.macroSlots[2], mB.id, 'slot 2 should still point at MacroB');
  });

  t('removeMacro clears macroId on blocks that referenced the deleted macro', () => {
    reset();
    const m = newMacro();
    saveMacro(m);
    state.session.blocks = [
      { id: 'blk1', type: 'macro', macroId: m.id, macroSlot: null },
      { id: 'blk2', type: 'macro', macroId: 'other_id', macroSlot: null },
    ];
    removeMacro(m.id);
    eq(state.session.blocks[0].macroId, '', 'macroId should be cleared on blk1');
    eq(state.session.blocks[1].macroId, 'other_id', 'blk2 should be untouched');
  });

  t('removeMacro nulls action.param on rules that inject the deleted macro', () => {
    reset();
    const m = newMacro();
    saveMacro(m);
    state.session.rules = [
      { id: 'r1', action: { type: 'injectMacro', param: m.id } },
      { id: 'r2', action: { type: 'injectMacro', param: 'different_id' } },
      { id: 'r3', action: { type: 'pause', param: null } },
    ];
    removeMacro(m.id);
    eq(state.session.rules[0].action.param, null, 'r1 param should be nulled');
    eq(state.session.rules[1].action.param, 'different_id', 'r2 should be untouched');
    eq(state.session.rules[2].action.param, null, 'r3 was already null');
  });

  t('removeMacro nulls successAction and failureAction params on triggers', () => {
    reset();
    const m = newMacro();
    saveMacro(m);
    state.session.triggers = [
      { id: 't1', successAction: { type: 'injectMacro', param: m.id },
                  failureAction: { type: 'injectMacro', param: m.id } },
      { id: 't2', successAction: { type: 'pause', param: null },
                  failureAction: { type: 'injectMacro', param: 'other' } },
    ];
    removeMacro(m.id);
    eq(state.session.triggers[0].successAction.param, null, 't1 success should be nulled');
    eq(state.session.triggers[0].failureAction.param, null, 't1 failure should be nulled');
    eq(state.session.triggers[1].failureAction.param, 'other', 't2 failure should be untouched');
  });

  t('removeMacro is a no-op when id does not exist', () => {
    reset();
    const m = newMacro(); saveMacro(m);
    removeMacro('nonexistent');
    eq(state.session.macroLibrary.length, 1, 'library should be unchanged');
  });

  t('removeMacro cannot remove a builtin macro (builtins not in macroLibrary)', () => {
    reset();
    const builtinId = BUILTIN_MACROS[0].id;
    removeMacro(builtinId); // should be a no-op — builtins live outside macroLibrary
    const stillThere = getMacro(builtinId);
    ok(stillThere !== null, 'builtin should still be accessible after removeMacro call');
  });

  // ── setSlotMacro ──────────────────────────────────────────────────────
  t('setSlotMacro assigns a macro to a slot', () => {
    reset();
    const m = newMacro(); saveMacro(m);
    setSlotMacro(2, m.id);
    eq(state.session.macroSlots[2], m.id);
  });

  t('setSlotMacro accepts null to unassign a slot', () => {
    reset();
    const m = newMacro(); saveMacro(m);
    setSlotMacro(2, m.id);
    setSlotMacro(2, null);
    ok(
      state.session.macroSlots[2] === null || state.session.macroSlots[2] === undefined,
      'slot should be unassigned'
    );
  });

  return R.summary();
}
