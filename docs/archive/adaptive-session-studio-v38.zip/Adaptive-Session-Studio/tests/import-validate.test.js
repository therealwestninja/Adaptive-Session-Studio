// ── tests/import-validate.test.js ────────────────────────────────────────
// Tests for the import-validate.js security layer.
// Covers all validators: session, FunScript, macro, subtitle, media file.

import { makeRunner } from './harness.js';
import {
  LIMITS,
  validateImportedSession,
  validateFunScript,
  validateMacro,
  validateSubtitleText,
  validateMediaFile,
} from '../js/import-validate.js';

export function runImportValidateTests() {
  const R  = makeRunner('import-validate.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  function throws(fn, label) {
    try { fn(); ok(false, `${label}: expected throw but did not`); }
    catch { ok(true); }
  }
  function noThrow(fn, label) {
    try { fn(); ok(true); }
    catch (e) { ok(false, `${label}: unexpected throw: ${e.message}`); }
  }

  // ── LIMITS shape ───────────────────────────────────────────────────────
  t('LIMITS exports expected budget keys', () => {
    ok(typeof LIMITS.SESSION_JSON_BYTES === 'number');
    ok(typeof LIMITS.SINGLE_MEDIA_BYTES === 'number');
    ok(typeof LIMITS.FUNSCRIPT_ACTIONS  === 'number');
    ok(typeof LIMITS.MACRO_ACTIONS      === 'number');
    ok(typeof LIMITS.SUBTITLE_EVENTS    === 'number');
    ok(typeof LIMITS.BLOCKS             === 'number');
  });

  // ── validateImportedSession ────────────────────────────────────────────
  t('validateImportedSession accepts a minimal valid session object', () => {
    noThrow(() => validateImportedSession({ name: 'test' }), 'minimal session');
  });

  t('validateImportedSession rejects null', () => {
    throws(() => validateImportedSession(null), 'null');
  });

  t('validateImportedSession rejects an array', () => {
    throws(() => validateImportedSession([]), 'array root');
  });

  t('validateImportedSession rejects oversized JSON text', () => {
    throws(
      () => validateImportedSession({}, LIMITS.SESSION_JSON_BYTES + 1),
      'oversized text'
    );
  });

  t('validateImportedSession rejects too many blocks', () => {
    const raw = { blocks: Array.from({ length: LIMITS.BLOCKS + 1 }, () => ({})) };
    throws(() => validateImportedSession(raw), 'block count exceeded');
  });

  t('validateImportedSession accepts exactly max blocks', () => {
    const raw = { blocks: Array.from({ length: LIMITS.BLOCKS }, () => ({})) };
    noThrow(() => validateImportedSession(raw), 'exact block limit');
  });

  t('validateImportedSession rejects too many rules', () => {
    const raw = { rules: Array.from({ length: LIMITS.RULES + 1 }, () => ({})) };
    throws(() => validateImportedSession(raw), 'rule count exceeded');
  });

  t('validateImportedSession rejects too many scenes', () => {
    const raw = { scenes: Array.from({ length: LIMITS.SCENES + 1 }, () => ({})) };
    throws(() => validateImportedSession(raw), 'scene count exceeded');
  });

  t('validateImportedSession rejects too many triggers', () => {
    const raw = { triggers: Array.from({ length: LIMITS.TRIGGERS + 1 }, () => ({})) };
    throws(() => validateImportedSession(raw), 'trigger count exceeded');
  });

  t('validateImportedSession rejects oversized FunScript track action count', () => {
    const raw = {
      funscriptTracks: [{
        actions: Array.from({ length: LIMITS.FUNSCRIPT_ACTIONS + 1 }, (_, i) => ({ at: i, pos: 50 }))
      }]
    };
    throws(() => validateImportedSession(raw), 'funscript actions exceeded');
  });

  t('validateImportedSession rejects oversized subtitle event count', () => {
    const raw = {
      subtitleTracks: [{
        events: Array.from({ length: LIMITS.SUBTITLE_EVENTS + 1 }, () => ({}))
      }]
    };
    throws(() => validateImportedSession(raw), 'subtitle events exceeded');
  });

  t('validateImportedSession rejects oversized rawAss text', () => {
    const raw = {
      subtitleTracks: [{ rawAss: 'x'.repeat(LIMITS.SUBTITLE_BYTES + 1), events: [] }]
    };
    throws(() => validateImportedSession(raw), 'rawAss size exceeded');
  });

  t('validateImportedSession rejects oversized embedded audio data URL', () => {
    const raw = {
      playlists: {
        audio: [{ dataUrl: 'data:audio/mp3;base64,' + 'A'.repeat(LIMITS.TOTAL_MEDIA_BYTES + 1) }],
        video: []
      }
    };
    throws(() => validateImportedSession(raw), 'embedded audio media exceeded');
  });

  t('validateImportedSession rejects oversized block label string', () => {
    const raw = { blocks: [{ label: 'x'.repeat(LIMITS.STRING_LEN + 1), content: '' }] };
    throws(() => validateImportedSession(raw), 'block label too long');
  });

  t('validateImportedSession accepts session with no playlists key', () => {
    noThrow(() => validateImportedSession({ name: 'ok', blocks: [] }), 'no playlists key');
  });

  // ── validateFunScript ─────────────────────────────────────────────────
  t('validateFunScript accepts valid FunScript', () => {
    noThrow(() => validateFunScript({ version: 1, actions: [{ at: 0, pos: 0 }] }), 'valid FS');
  });

  t('validateFunScript rejects null', () => {
    throws(() => validateFunScript(null), 'null');
  });

  t('validateFunScript rejects missing actions array', () => {
    throws(() => validateFunScript({ version: 1 }), 'no actions');
  });

  t('validateFunScript rejects actions count exceeding limit', () => {
    const raw = { actions: Array.from({ length: LIMITS.FUNSCRIPT_ACTIONS + 1 }, () => ({})) };
    throws(() => validateFunScript(raw), 'action count exceeded');
  });

  t('validateFunScript accepts exactly max actions', () => {
    const raw = { actions: Array.from({ length: LIMITS.FUNSCRIPT_ACTIONS }, () => ({ at: 0, pos: 0 })) };
    noThrow(() => validateFunScript(raw), 'exact action limit');
  });

  // ── validateMacro ─────────────────────────────────────────────────────
  t('validateMacro accepts valid macro', () => {
    noThrow(() => validateMacro({ actions: [{ at: 0, pos: 0 }, { at: 500, pos: 100 }] }), 'valid macro');
  });

  t('validateMacro rejects empty actions array', () => {
    throws(() => validateMacro({ actions: [] }), 'empty actions');
  });

  t('validateMacro rejects missing actions', () => {
    throws(() => validateMacro({}), 'missing actions');
  });

  t('validateMacro rejects actions count exceeding limit', () => {
    const raw = { actions: Array.from({ length: LIMITS.MACRO_ACTIONS + 1 }, () => ({})) };
    throws(() => validateMacro(raw), 'macro action count exceeded');
  });

  t('validateMacro accepts exactly max actions', () => {
    const raw = { actions: Array.from({ length: LIMITS.MACRO_ACTIONS }, () => ({ at: 0, pos: 0 })) };
    noThrow(() => validateMacro(raw), 'exact macro action limit');
  });

  // ── validateSubtitleText ──────────────────────────────────────────────
  t('validateSubtitleText accepts normal subtitle text', () => {
    noThrow(() => validateSubtitleText('[Script Info]\nTitle: Test\n'), 'normal subtitle');
  });

  t('validateSubtitleText rejects non-string input', () => {
    throws(() => validateSubtitleText(123), 'non-string');
  });

  t('validateSubtitleText rejects oversized text', () => {
    throws(() => validateSubtitleText('x'.repeat(LIMITS.SUBTITLE_BYTES + 1)), 'oversized');
  });

  t('validateSubtitleText accepts exactly max bytes', () => {
    noThrow(() => validateSubtitleText('x'.repeat(LIMITS.SUBTITLE_BYTES)), 'exact limit');
  });

  // ── validateMediaFile ─────────────────────────────────────────────────
  t('validateMediaFile accepts a file within size limit', () => {
    const mockFile = { name: 'audio.mp3', size: 1_000_000 }; // 1 MB
    noThrow(() => validateMediaFile(mockFile, 'Audio'), 'small file');
  });

  t('validateMediaFile rejects a file over the size limit', () => {
    const mockFile = { name: 'huge.mp4', size: LIMITS.SINGLE_MEDIA_BYTES + 1 };
    throws(() => validateMediaFile(mockFile, 'Video'), 'oversized file');
  });

  t('validateMediaFile accepts exactly max size', () => {
    const mockFile = { name: 'max.mp3', size: LIMITS.SINGLE_MEDIA_BYTES };
    noThrow(() => validateMediaFile(mockFile, 'Audio'), 'exact limit');
  });

  t('validateMediaFile rejects null file', () => {
    throws(() => validateMediaFile(null), 'null file');
  });

  return R.summary();
}
