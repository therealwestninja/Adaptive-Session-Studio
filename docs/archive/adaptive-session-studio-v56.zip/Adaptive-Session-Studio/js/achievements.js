// ── achievements.js ────────────────────────────────────────────────────────
// Achievements, daily quests, and XP/level progression system.
//
// Design constraints: ALL achievements must be reachable in ≤90 days @ 10min/day
//   → max 90 sessions, max 90-day streak, max 900min / 15h runtime
//
// Difficulty flavour:
//   "Precision" achievements (low count, high quality) = harder but fewer sessions
//   "Volume" achievements (higher count, low quality required) = easier but more time
//
// Architecture:
//   • ACHIEVEMENTS — static catalogue of 52 permanent badges
//   • LEVEL_THRESHOLDS — XP required to reach each level (1–20)
//   • getDailyQuests(dateStr) — deterministic daily quest set (3 quests/day)
//   • checkAndAwardAchievements(profile, summary, session) → newly earned ids[]
//   • processSessionEnd(summary, session) — called from playback.js post-session
//   • XP awards happen inside processSessionEnd and are stored in the profile

import { state }         from './state.js';
import { notify }        from './notify.js';
import { idbGet, idbSet } from './idb-storage.js';

// ── XP / Level table ────────────────────────────────────────────────────────
export const LEVEL_NAMES = [
  '',             // 0 (unused)
  'Initiate',     // 1
  'Curious',      // 2
  'Attuned',      // 3
  'Focused',      // 4
  'Steady',       // 5
  'Devoted',      // 6
  'Controlled',   // 7
  'Refined',      // 8
  'Trained',      // 9
  'Practiced',    // 10
  'Disciplined',  // 11
  'Immersed',     // 12
  'Surrendered',  // 13
  'Shaped',       // 14
  'Conditioned',  // 15
  'Dedicated',    // 16
  'Elite',        // 17
  'Master',       // 18
  'Transcendent', // 19
  'Apex',         // 20
];

export const MAX_LEVEL = 20;

// Cumulative XP to reach level N
export const LEVEL_THRESHOLDS = [
  0,     // → L1
  50,    // → L2
  130,   // → L3
  250,   // → L4
  420,   // → L5
  650,   // → L6
  950,   // → L7
  1320,  // → L8
  1770,  // → L9
  2310,  // → L10
  2960,  // → L11
  3730,  // → L12
  4640,  // → L13
  5710,  // → L14
  6960,  // → L15
  8410,  // → L16
  10080, // → L17
  12000, // → L18
  14200, // → L19
  16700, // → L20
  999999,
];

export function xpForLevel(level) {
  return LEVEL_THRESHOLDS[Math.min(level, MAX_LEVEL)] ?? 999999;
}
export function levelFromXp(xp) {
  let level = 1;
  for (let i = 1; i <= MAX_LEVEL; i++) {
    if (xp >= LEVEL_THRESHOLDS[i]) level = i + 1;
    else break;
  }
  return Math.min(level, MAX_LEVEL);
}
export function xpToNextLevel(xp) {
  const level = levelFromXp(xp);
  if (level >= MAX_LEVEL) return 0;
  return LEVEL_THRESHOLDS[level] - xp;
}
export function levelProgressPct(xp) {
  const level = levelFromXp(xp);
  if (level >= MAX_LEVEL) return 100;
  const base = LEVEL_THRESHOLDS[level - 1];
  const next = LEVEL_THRESHOLDS[level];
  return Math.round(((xp - base) / (next - base)) * 100);
}

// ── Achievement catalogue — 52 badges ───────────────────────────────────────
// All achievable within 90 sessions / 90-day streak / 15h total runtime.
// "Precision" = fewer sessions needed, higher difficulty per session.
// "Volume"    = lower per-session difficulty, more sessions needed.
// secret:true = hidden name/desc until earned.
export const ACHIEVEMENTS = [

  // ─── FIRST STEPS ────────────────────────────────────────────────────────
  { id:'first_session',   icon:'🌱', name:'First Step',
    desc:'Complete your first session',
    xp:30, category:'consistency' },

  { id:'sessions_3',      icon:'🌿', name:'Getting Started',
    desc:'Complete 3 sessions',
    xp:20, category:'consistency' },

  // ─── STREAK — slow ramp, max at 90 ────────────────────────────────────
  { id:'streak_2',        icon:'✌️', name:'Back Again',
    desc:'Maintain a 2-day streak',
    xp:10, category:'consistency' },

  { id:'streak_3',        icon:'🔥', name:'On a Roll',
    desc:'Maintain a 3-day streak',
    xp:20, category:'consistency' },

  { id:'streak_5',        icon:'🔥', name:'Momentum',
    desc:'Maintain a 5-day streak',
    xp:30, category:'consistency' },

  { id:'streak_7',        icon:'🏆', name:'Week Strong',
    desc:'Maintain a 7-day streak',
    xp:50, category:'consistency' },

  { id:'streak_14',       icon:'⚡', name:'Fortnight',
    desc:'Maintain a 14-day streak',
    xp:80, category:'consistency' },

  { id:'streak_21',       icon:'🌙', name:'Three Weeks',
    desc:'Maintain a 21-day streak',
    xp:110, category:'consistency' },

  { id:'streak_30',       icon:'🌟', name:'Monthly Devotion',
    desc:'Maintain a 30-day streak',
    xp:150, category:'consistency' },

  { id:'streak_60',       icon:'💫', name:'Two Months',
    desc:'Maintain a 60-day streak',
    xp:250, category:'consistency' },

  { id:'streak_90',       icon:'💎', name:'Ninety Days',
    desc:'Maintain a 90-day streak',
    xp:400, category:'consistency', secret:true },

  // ─── SESSION COUNT — volume, achievable at ~1/day ─────────────────────
  { id:'sessions_5',      icon:'💪', name:'Committed',
    desc:'Complete 5 sessions',
    xp:25, category:'depth' },

  { id:'sessions_10',     icon:'🔑', name:'Double Digits',
    desc:'Complete 10 sessions',
    xp:40, category:'depth' },

  { id:'sessions_20',     icon:'📈', name:'Habit Forming',
    desc:'Complete 20 sessions',
    xp:70, category:'depth' },

  { id:'sessions_30',     icon:'🎯', name:'Practitioner',
    desc:'Complete 30 sessions',
    xp:100, category:'depth' },

  { id:'sessions_50',     icon:'🏅', name:'Dedicated',
    desc:'Complete 50 sessions',
    xp:180, category:'depth' },

  { id:'sessions_75',     icon:'🌟', name:'Virtuoso',
    desc:'Complete 75 sessions',
    xp:300, category:'depth', secret:true },

  // ─── RUNTIME — capped at 15h (900min = 54 000s) ───────────────────────
  { id:'runtime_15m',     icon:'⏱', name:'Warmed Up',
    desc:'Accumulate 15 minutes of session time',
    xp:10, category:'endurance' },

  { id:'runtime_1h',      icon:'🕐', name:'First Hour',
    desc:'Accumulate 1 hour of session time',
    xp:30, category:'endurance' },

  { id:'runtime_3h',      icon:'⌛', name:'Three Hours',
    desc:'Accumulate 3 hours of session time',
    xp:60, category:'endurance' },

  { id:'runtime_5h',      icon:'🏃', name:'Five Hours',
    desc:'Accumulate 5 hours of session time',
    xp:100, category:'endurance' },

  { id:'runtime_10h',     icon:'🕙', name:'Ten Hours',
    desc:'Accumulate 10 hours of session time',
    xp:200, category:'endurance' },

  { id:'runtime_15h',     icon:'👑', name:'Full Journey',
    desc:'Accumulate 15 hours of session time',
    xp:400, category:'endurance', secret:true },

  // ─── SESSION LENGTH — precision: need one long session ────────────────
  { id:'long_10m',        icon:'🕙', name:'Committed Block',
    desc:'Complete a single session of at least 10 minutes',
    xp:15, category:'endurance' },

  { id:'long_20m',        icon:'⏳', name:'Twenty Minutes',
    desc:'Complete a single session of at least 20 minutes',
    xp:25, category:'endurance' },

  { id:'long_30m',        icon:'🌊', name:'Half Hour',
    desc:'Complete a single session of at least 30 minutes',
    xp:40, category:'endurance' },

  { id:'long_45m',        icon:'🌊', name:'Deep Dive',
    desc:'Complete a single session of at least 45 minutes',
    xp:70, category:'endurance' },

  // ─── ATTENTION / FOCUS — precision tier (low count, high quality) ─────
  { id:'attention_first', icon:'👁', name:'Present',
    desc:'Complete a session with fewer than 3 attention losses',
    xp:20, category:'focus' },

  { id:'attention_80',    icon:'🎯', name:'Sharp Focus',
    desc:'Complete a session with 80%+ focused time',
    xp:35, category:'focus' },

  { id:'attention_90',    icon:'🧘', name:'Deep Presence',
    desc:'Complete a session with 90%+ focused time',
    xp:60, category:'focus' },

  { id:'perfect_5m',      icon:'✨', name:'Five Clean Minutes',
    desc:'Complete a 5-minute session with zero attention losses',
    xp:25, category:'focus' },

  { id:'perfect_attention', icon:'💎', name:'Full Presence',
    desc:'Complete a session (10min+) with zero attention losses',
    xp:60, category:'focus' },

  { id:'perfect_3x',      icon:'🌙', name:'Consistent Mind',
    desc:'Complete 3 sessions with zero attention losses',
    xp:100, category:'focus' },

  { id:'perfect_5x',      icon:'🔮', name:'Unshakeable',
    desc:'Complete 5 sessions with zero attention losses',
    xp:150, category:'focus', secret:true },

  { id:'focus_streak',    icon:'⚡', name:'Focus Streak',
    desc:'Maintain 80%+ attention for 3 sessions in a row',
    xp:80, category:'focus' },

  // ─── CRAFT — exploration achievements ─────────────────────────────────
  { id:'use_tts',         icon:'🎙', name:'Spoken Word',
    desc:'Complete a session containing TTS voice blocks',
    xp:20, category:'craft' },

  { id:'use_viz',         icon:'🌀', name:'Visual Depth',
    desc:'Complete a session with a visualization block',
    xp:20, category:'craft' },

  { id:'use_funscript',   icon:'🕹', name:'Haptic Aware',
    desc:'Complete a session with an active haptic track',
    xp:30, category:'craft' },

  { id:'use_audio',       icon:'🎵', name:'Soundscape',
    desc:'Complete a session with a background audio playlist',
    xp:20, category:'craft' },

  { id:'use_scenes_1',    icon:'🎬', name:'Scene Setter',
    desc:'Build a session with at least 1 scene',
    xp:20, category:'craft' },

  { id:'use_scenes_3',    icon:'🎭', name:'Arc Director',
    desc:'Build a session with 3 or more scenes',
    xp:40, category:'craft' },

  { id:'use_rules_1',     icon:'⚙', name:'Rule One',
    desc:'Build a session with at least 1 behavioral rule',
    xp:25, category:'craft' },

  { id:'use_rules_3',     icon:'🤖', name:'Adaptive Build',
    desc:'Build a session with 3 or more active rules',
    xp:50, category:'craft' },

  { id:'use_ramp',        icon:'📈', name:'Ramp Up',
    desc:'Complete a session with the intensity ramp enabled',
    xp:25, category:'craft' },

  { id:'use_pacing',      icon:'🎛', name:'Paced',
    desc:'Complete a session with dynamic speed pacing enabled',
    xp:25, category:'craft' },

  { id:'use_variables',   icon:'📊', name:'Dynamic Voice',
    desc:'Build a session using {{variables}} in content',
    xp:40, category:'craft' },

  { id:'modes_4',         icon:'🗺', name:'Mode Sampler',
    desc:'Try 4 different session modes',
    xp:50, category:'craft' },

  { id:'all_modes',       icon:'🎛', name:'Mode Explorer',
    desc:'Try all 8 session modes',
    xp:120, category:'craft' },

  { id:'all_packs',       icon:'📦', name:'Pack Explorer',
    desc:'Load all 6 content packs at least once',
    xp:80, category:'craft' },

  // ─── COMBOS — precision: require multiple features at once ───────────
  { id:'combo_haptic_viz', icon:'🌐', name:'Full Sensory',
    desc:'Complete a session with both haptic feedback and a visualization',
    xp:50, category:'craft' },

  { id:'combo_rules_scenes', icon:'🎬', name:'Directed',
    desc:'Complete a session using both scenes and rules',
    xp:60, category:'craft' },

  // ─── SPECIAL ──────────────────────────────────────────────────────────
  { id:'safe_stop',       icon:'🛑', name:'Safety First',
    desc:'Use the emergency stop',
    xp:10, category:'craft' },

  { id:'full_surrender',  icon:'🎗', name:'Full Surrender',
    desc:'Complete a session in Surrender mode',
    xp:60, category:'focus', secret:true },

  { id:'peak_intensity',  icon:'🔥', name:'Peak State',
    desc:'Complete a session that includes a Peak scene',
    xp:40, category:'focus', secret:true },
];

export const ACHIEVEMENT_MAP = Object.fromEntries(ACHIEVEMENTS.map(a => [a.id, a]));

// ── Daily quest pool ─────────────────────────────────────────────────────────
const QUEST_POOL = [
  {
    id:'q_complete_any',  icon:'✅', name:'Session Complete',
    desc:'Complete any session today',
    xp:20,
    condition:(s) => s.completionState === 'completed',
  },
  {
    id:'q_10min',  icon:'⏰', name:'Ten Minutes',
    desc:'Complete a session of at least 10 minutes',
    xp:20,
    condition:(s) => s.completionState === 'completed' && s.totalSec >= 600,
  },
  {
    id:'q_15min',  icon:'⏰', name:'Fifteen Minutes',
    desc:'Complete a session of at least 15 minutes',
    xp:25,
    condition:(s) => s.completionState === 'completed' && s.totalSec >= 900,
  },
  {
    id:'q_30min',  icon:'⌛', name:'Half Hour',
    desc:'Complete a session of at least 30 minutes',
    xp:40,
    condition:(s) => s.completionState === 'completed' && s.totalSec >= 1800,
  },
  {
    id:'q_no_loss',  icon:'👁', name:'Unbroken Focus',
    desc:'Complete a session with no attention losses',
    xp:35,
    condition:(s) => s.completionState === 'completed' && s.attentionLossEvents === 0,
  },
  {
    id:'q_high_focus', icon:'🎯', name:'Sharp Focus',
    desc:'Complete a session with fewer than 2 attention losses',
    xp:25,
    condition:(s) => s.completionState === 'completed' && (s.attentionLossEvents ?? 99) < 2,
  },
  {
    id:'q_use_scenes',  icon:'🎬', name:'Scene Session',
    desc:'Complete a session that has at least 2 scenes',
    xp:30,
    condition:(s, sess) => s.completionState === 'completed' && (sess?.scenes?.length ?? 0) >= 2,
  },
  {
    id:'q_use_haptic',  icon:'🕹', name:'Haptic Session',
    desc:'Complete a session with an active FunScript track',
    xp:35,
    condition:(s, sess) => s.completionState === 'completed' &&
      (sess?.funscriptTracks?.filter(t => !t._disabled).length ?? 0) > 0,
  },
  {
    id:'q_use_rules',  icon:'⚙', name:'Rule-Driven',
    desc:'Complete a session with at least one active rule',
    xp:30,
    condition:(s, sess) => s.completionState === 'completed' &&
      (sess?.rules?.filter(r => r.enabled).length ?? 0) >= 1,
  },
  {
    id:'q_tts',  icon:'🎙', name:'Spoken Word',
    desc:'Complete a session with TTS blocks',
    xp:25,
    condition:(s, sess) => s.completionState === 'completed' &&
      (sess?.blocks?.some(b => b.type === 'tts') ?? false),
  },
  {
    id:'q_viz',  icon:'🌀', name:'Visual Journey',
    desc:'Complete a session with a visualization block',
    xp:25,
    condition:(s, sess) => s.completionState === 'completed' &&
      (sess?.blocks?.some(b => b.type === 'viz') ?? false),
  },
  {
    id:'q_loops',  icon:'🔄', name:'Loop Session',
    desc:'Complete a session that loops at least twice',
    xp:35,
    condition:(s) => s.completionState === 'completed' && s.loopsCompleted >= 2,
  },
  {
    id:'q_streak_keep',  icon:'🔥', name:'Keep the Streak',
    desc:'Complete a session (protect your streak today)',
    xp:15,
    condition:(s) => s.completionState === 'completed',
  },
  {
    id:'q_ramp',  icon:'📈', name:'Ramped Up',
    desc:'Complete a session with the intensity ramp enabled',
    xp:30,
    condition:(s, sess) => s.completionState === 'completed' && sess?.rampSettings?.enabled === true,
  },
  {
    id:'q_pacing', icon:'🎛', name:'Paced Session',
    desc:'Complete a session with dynamic speed pacing',
    xp:30,
    condition:(s, sess) => s.completionState === 'completed' && sess?.pacingSettings?.enabled === true,
  },
];

// Deterministic daily quest selection — 3 quests per day
export function getDailyQuests(dateStr = _today()) {
  let seed = 0;
  for (let i = 0; i < dateStr.length; i++) seed = (seed * 31 + dateStr.charCodeAt(i)) >>> 0;

  const base   = QUEST_POOL.find(q => q.id === 'q_complete_any');
  const others = QUEST_POOL.filter(q => q.id !== 'q_complete_any');

  const picked = [];
  let pool = [...others];
  for (let i = 0; i < 2 && pool.length; i++) {
    const idx = (seed >>> 0) % pool.length;
    picked.push(pool[idx]);
    pool = pool.filter((_, j) => j !== idx);
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    seed = (seed ^ (seed >>> 13)) >>> 0;
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
  }

  return [base, ...picked].filter(Boolean);
}

function _today() {
  return new Date().toISOString().slice(0, 10);
}

// ── Core: check which achievements are newly earned ──────────────────────────
export function checkAndAwardAchievements(profile, summary, session) {
  const earned     = new Set(profile.achievements ?? []);
  const newlyEarned = [];

  function check(id, condition) {
    if (!earned.has(id) && condition) {
      earned.add(id);
      newlyEarned.push(id);
    }
  }

  const completed    = summary.completionState === 'completed';
  const totalSec     = profile.totalRuntimeSec ?? 0;
  const count        = profile.sessionCount    ?? 0;
  const streak       = profile.streak          ?? 0;
  const totalSessSec = summary.totalSec        ?? 0;
  const zeroLoss     = (summary.attentionLossEvents ?? 999) === 0;
  const fewLoss      = (summary.attentionLossEvents ?? 999) < 3;

  const hasFunscript  = (session?.funscriptTracks ?? []).some(t => !t._disabled);
  const hasViz        = (session?.blocks ?? []).some(b => b.type === 'viz');
  const hasTts        = (session?.blocks ?? []).some(b => b.type === 'tts');
  const hasAudio      = (session?.blocks ?? []).some(b => b.type === 'audio');
  const sceneCount    = (session?.scenes ?? []).length;
  const ruleCount     = (session?.rules ?? []).filter(r => r.enabled).length;
  const hasVars       = Object.keys(session?.variables ?? {}).length > 0;
  const hasRamp       = session?.rampSettings?.enabled === true;
  const hasPacing     = session?.pacingSettings?.enabled === true;

  // First steps
  check('first_session', count >= 1);
  check('sessions_3',    count >= 3);

  // Streaks (all ≤ 90)
  check('streak_2',  streak >= 2);
  check('streak_3',  streak >= 3);
  check('streak_5',  streak >= 5);
  check('streak_7',  streak >= 7);
  check('streak_14', streak >= 14);
  check('streak_21', streak >= 21);
  check('streak_30', streak >= 30);
  check('streak_60', streak >= 60);
  check('streak_90', streak >= 90);

  // Session counts (all ≤ 75)
  check('sessions_5',  count >= 5);
  check('sessions_10', count >= 10);
  check('sessions_20', count >= 20);
  check('sessions_30', count >= 30);
  check('sessions_50', count >= 50);
  check('sessions_75', count >= 75);

  // Runtime — max 54 000s (15h)
  check('runtime_15m', totalSec >= 900);
  check('runtime_1h',  totalSec >= 3_600);
  check('runtime_3h',  totalSec >= 10_800);
  check('runtime_5h',  totalSec >= 18_000);
  check('runtime_10h', totalSec >= 36_000);
  check('runtime_15h', totalSec >= 54_000);

  // Session length (single session)
  check('long_10m', completed && totalSessSec >= 600);
  check('long_20m', completed && totalSessSec >= 1_200);
  check('long_30m', completed && totalSessSec >= 1_800);
  check('long_45m', completed && totalSessSec >= 2_700);

  // Focus — precision tier
  check('attention_first',   completed && fewLoss && totalSessSec >= 60);
  check('attention_80', completed && totalSessSec > 0 && (() => {
    const pct = 1 - ((summary.attentionLossTotalSec ?? 0) / totalSessSec);
    return pct >= 0.80;
  })());
  check('attention_90', completed && totalSessSec > 0 && (() => {
    const pct = 1 - ((summary.attentionLossTotalSec ?? 0) / totalSessSec);
    return pct >= 0.90;
  })());
  check('perfect_5m',      completed && zeroLoss && totalSessSec >= 300);
  check('perfect_attention', completed && zeroLoss && totalSessSec >= 600);

  // perfect_3x / perfect_5x / focus_streak tracked via profile counters
  check('perfect_3x',   (profile.perfectSessions ?? 0) >= 3);
  check('perfect_5x',   (profile.perfectSessions ?? 0) >= 5);
  check('focus_streak', (profile.focusStreakCount ?? 0) >= 3);

  // Craft — exploration
  check('use_tts',      completed && hasTts);
  check('use_viz',      completed && hasViz);
  check('use_funscript', completed && hasFunscript);
  check('use_audio',    completed && hasAudio);
  check('use_scenes_1', sceneCount >= 1);
  check('use_scenes_3', sceneCount >= 3);
  check('use_rules_1',  ruleCount  >= 1);
  check('use_rules_3',  ruleCount  >= 3);
  check('use_ramp',     completed && hasRamp);
  check('use_pacing',   completed && hasPacing);
  check('use_variables', hasVars && completed);

  const modesUsed = new Set(profile.modesUsed ?? []);
  check('modes_4',   modesUsed.size >= 4);
  check('all_modes', modesUsed.size >= 8);

  // all_packs — awarded from content-packs.js when packsLoaded reaches 6
  // (not checked here; triggered directly in loadContentPack)

  // Combos
  check('combo_haptic_viz',    completed && hasFunscript && hasViz);
  check('combo_rules_scenes',  completed && ruleCount >= 1 && sceneCount >= 1);

  // Special / secret
  check('full_surrender', completed && session?.mode === 'surrender');
  check('peak_intensity', completed && (session?.scenes ?? []).some(s => s.stateType === 'peak'));
  // safe_stop awarded separately via awardEmergencyBadge()

  return { newlyEarned, updatedEarned: [...earned] };
}

// ── XP calculation per session ───────────────────────────────────────────────
export function calculateSessionXp(summary, session, profile) {
  if (!summary || summary.completionState === 'emergency') return 0;

  let xp = 0;

  // Base completion award
  xp += summary.completionState === 'completed' ? 20 : 8;

  // Time played (1 XP / minute, capped at 30 for 10min/day target)
  xp += Math.min(30, Math.floor((summary.totalSec ?? 0) / 60));

  // Streak bonus
  const streak = profile.streak ?? 0;
  if (streak >= 30) xp += 12;
  else if (streak >= 14) xp += 7;
  else if (streak >= 7)  xp += 4;
  else if (streak >= 3)  xp += 2;
  else if (streak >= 1)  xp += 1;

  // Focus bonus — scaled
  const lossEvents = summary.attentionLossEvents ?? 0;
  if (lossEvents === 0 && (summary.totalSec ?? 0) >= 300) xp += 10;
  else if (lossEvents <= 1) xp += 4;
  else if (lossEvents <= 2) xp += 2;

  // Feature usage bonuses
  if ((session?.funscriptTracks ?? []).some(t => !t._disabled)) xp += 5;
  if ((session?.blocks ?? []).some(b => b.type === 'viz'))       xp += 3;
  if ((session?.scenes ?? []).length >= 2)                       xp += 3;
  if ((session?.rules  ?? []).filter(r => r.enabled).length >= 1) xp += 3;
  if (session?.rampSettings?.enabled)                            xp += 2;
  if (session?.pacingSettings?.enabled)                          xp += 2;

  return xp;
}

// ── Quest progress check ─────────────────────────────────────────────────────
export function checkQuestProgress(summary, session, profile) {
  const today     = _today();
  const questDate = profile.questDate ?? '';
  const quests    = questDate === today
    ? (profile.quests ?? [])
    : getDailyQuests(today).map(q => ({ id: q.id, done: false }));

  const completed = [];
  const updatedQuests = quests.map(qState => {
    if (qState.done) return qState;
    const def = QUEST_POOL.find(q => q.id === qState.id);
    if (!def) return qState;
    const met = def.condition(summary, session, profile);
    if (met) completed.push(qState.id);
    return { ...qState, done: met ? true : qState.done };
  });

  return { completed, updatedQuests, questDate: today };
}

// ── Main integration: call from playback.js after session ends ────────────────
export async function processSessionEnd(summary, session) {
  if (!summary) return null;

  const { loadProfile, saveProfile, rebuildProfile } = await import('./user-profile.js');
  let profile = rebuildProfile();

  // Guard: don't double-award for the same session timestamp
  const LAST_KEY = 'achievements:lastProcessed';
  try {
    const last = await idbGet(LAST_KEY);
    if (last === summary.timestamp) return null;
    await idbSet(LAST_KEY, summary.timestamp);
  } catch {}

  // ── Award XP ──────────────────────────────────────────────────────────────
  const sessionXp = calculateSessionXp(summary, session, profile);
  const prevXp    = profile.xp ?? 0;
  const prevLevel = levelFromXp(prevXp);
  profile.xp      = prevXp + sessionXp;

  // ── Track per-session counters ─────────────────────────────────────────────
  if (session?.mode) {
    const modesUsed = new Set(profile.modesUsed ?? []);
    modesUsed.add(session.mode);
    profile.modesUsed = [...modesUsed];
  }

  const zeroLoss  = (summary.attentionLossEvents ?? 999) === 0;
  const totalSec  = summary.totalSec ?? 0;
  const highFocus = totalSec > 0 &&
    (1 - ((summary.attentionLossTotalSec ?? 0) / totalSec)) >= 0.80;

  if (summary.completionState === 'completed') {
    if (zeroLoss) profile.perfectSessions = (profile.perfectSessions ?? 0) + 1;
    else profile.perfectSessions = profile.perfectSessions ?? 0; // don't reset

    if (highFocus) {
      profile.focusStreakCount = (profile.focusStreakCount ?? 0) + 1;
    } else {
      profile.focusStreakCount = 0; // reset on break
    }

    // Legacy: highAttentionSessions (for backward compat)
    if (highFocus && totalSec >= 300) {
      profile.highAttentionSessions = (profile.highAttentionSessions ?? 0) + 1;
    }
  }

  // ── Check achievements ────────────────────────────────────────────────────
  const { newlyEarned, updatedEarned } = checkAndAwardAchievements(profile, summary, session);
  profile.achievements = updatedEarned;

  // ── Check quests ──────────────────────────────────────────────────────────
  const { completed: completedQuests, updatedQuests, questDate } =
    checkQuestProgress(summary, session, profile);
  profile.quests    = updatedQuests;
  profile.questDate = questDate;

  saveProfile(profile);

  // ── Quest and achievement XP ──────────────────────────────────────────────
  let questXp = 0;
  for (const qid of completedQuests) {
    const def = QUEST_POOL.find(q => q.id === qid);
    if (def) questXp += def.xp ?? 0;
  }
  let achXp = 0;
  for (const aid of newlyEarned) {
    const def = ACHIEVEMENT_MAP[aid];
    if (def) achXp += def.xp ?? 0;
  }
  if (questXp + achXp > 0) {
    profile.xp += questXp + achXp;
    saveProfile(profile);
  }

  const finalLevel = levelFromXp(profile.xp);

  // ── Notifications (gated by displayOptions) ───────────────────────────────
  setTimeout(() => {
    const disp = state.session?.displayOptions ?? {};
    const total = sessionXp + questXp + achXp;

    if (disp.toastXp !== false && total > 0) {
      notify.info(`+${total} XP`, 3000);
    }
    if (disp.toastLevelUp !== false && finalLevel > prevLevel) {
      notify.success(`⬆ Level ${finalLevel}: ${LEVEL_NAMES[finalLevel] ?? ''}`, 5000);
    }
    if (disp.toastAchievements !== false) {
      for (const aid of newlyEarned) {
        const a = ACHIEVEMENT_MAP[aid];
        if (a) notify.success(`🏅 ${a.icon} ${a.name}`, 5000);
      }
    }
    if (disp.toastQuests !== false) {
      for (const qid of completedQuests) {
        const q = QUEST_POOL.find(q => q.id === qid);
        if (q) notify.success(`${q.icon} Quest: ${q.name} (+${q.xp} XP)`, 4000);
      }
    }
  }, 1200);

  return {
    sessionXp, questXp, achXx: achXp,
    newlyEarned, completedQuests, newLevel: finalLevel, prevLevel,
    _achMap:   ACHIEVEMENT_MAP,
    _questMap: Object.fromEntries(QUEST_POOL.map(q => [q.id, q])),
  };
}

// ── Emergency stop badge ──────────────────────────────────────────────────────
export async function awardEmergencyBadge() {
  const { loadProfile, saveProfile } = await import('./user-profile.js');
  const profile = loadProfile();
  const earned  = new Set(profile.achievements ?? []);
  if (!earned.has('safe_stop')) {
    earned.add('safe_stop');
    profile.achievements = [...earned];
    profile.xp = (profile.xp ?? 0) + (ACHIEVEMENT_MAP['safe_stop']?.xp ?? 10);
    saveProfile(profile);
    if (state.session?.displayOptions?.toastAchievements !== false) {
      setTimeout(() => notify.info('🛑 Achievement: Safety First', 4000), 500);
    }
  }
}

export function getTodayQuestDefs() {
  return getDailyQuests(_today());
}
