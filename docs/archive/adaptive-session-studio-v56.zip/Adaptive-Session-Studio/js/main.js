// ── main.js ────────────────────────────────────────────────────────────────
// App entry point: event wiring, keyboard shortcuts, initialization.

import { state, persist, fmt, $id, uid, fileToDataUrl,
         normalizeBlock, normalizeSession, normalizeAudioTrack, normalizeVideoTrack, normalizeSubtitleTrack,
         defaultSession, applyCssVars, applyTheme, sessionReady } from './state.js';

// Wait for IndexedDB session load to complete before rendering.
// (top-level await is valid in ES modules — supported in all modern browsers)
await sessionReady;

import { startPlayback, stopPlayback, pausePlayback, resumePlayback,
         seekTo, skipBy, emergencyStop } from './playback.js';
import { refreshVolumes, crossfade, startSingleTrack, removeSingleTrack } from './audio-engine.js';
import { parseAss, updateSubtitleCue } from './subtitle.js';
import { importFunScriptFile, initTimeline, drawTimeline,
         connectDevice, disconnectDevice,
         selectAllPoints, transformPoints,
         getCurrentPosition, updatePositionIndicator,
         resetZoom } from './funscript.js';

// ── Cross-module imports (previously missing — caused ReferenceError at runtime) ──
import { renderSidebar, updateSidebarSelection, renderInspector,
         syncSettingsForms, syncSessionFromSettings, syncTransportControls,
         renderThemeGrid, saveCustomTheme, deleteCustomTheme } from './ui.js';
import { notify }                 from './notify.js';
import { history }                from './history.js';
import { renderMacroLibrary, initMacroLibraryEvents } from './macro-ui.js';
import { renderSensorBridgePanel } from './sensor-bridge.js';
import { initFullscreenHud, renderIdleScreen, showLiveControlToast } from './fullscreen-hud.js';
import { initLiveControl, setLiveIntensity, setLiveSpeed } from './live-control.js';
import { makeTrackingModule }     from './tracking.js';
import { detectCapabilities, applyCapabilityGates,
         warnMissingCapabilities, checkStorageBudget } from './capabilities.js';
import { validateImportedSession, validateSubtitleText, validateMediaFile } from './import-validate.js';
import { injectMacro, getSlotMacro, toggleFsPause } from './macros.js';
import { duplicateBlock, deleteBlock,
         registerBlockOpRenderers } from './block-ops.js';
import { skipToNextScene } from './scenes.js';
import { resetStateEngine } from './state-engine.js';
import { clearRuleState }   from './rules-engine.js';
import { clearProfile, saveProfile, loadProfile } from './user-profile.js';
import { clearStoredAnalytics } from './session-analytics.js';
import { clearMetricsHistory }  from './metrics-history.js';
import { idbDel }           from './idb-storage.js';

// Expose for inspector button handlers
window._funscriptModule = { connectDevice, disconnectDevice }; // kept for external tooling compat

// Register renderers for block-ops (avoids circular dep: block-ops ← ui.js)
// Must be called after ui.js module initialises — deferred one microtask.
Promise.resolve().then(() => registerBlockOpRenderers(renderSidebar, renderInspector));

// ── Transport controls ───────────────────────────────────────────────────────
$id('playBtn').addEventListener('click', () => {
  if (!state.runtime)            startPlayback();
  else if (state.runtime.paused) resumePlayback();
  else                           pausePlayback();
});
$id('stopBtn').addEventListener('click', stopPlayback);
$id('skipBackBtn').addEventListener('click',  () => skipBy(-10));
$id('skipFwdBtn').addEventListener('click',   () => skipBy(10));
$id('nextSceneBtn')?.addEventListener('click', skipToNextScene);

$id('loopToggle').addEventListener('click', () => {
  const modes = ['none', 'count', 'minutes', 'forever'];
  const idx = modes.indexOf(state.session.loopMode);
  state.session.loopMode = modes[(idx === -1 ? 0 : idx + 1) % modes.length];
  syncTransportControls();
  persist();
});

// ── Session name quick-edit (menubar center input) ────────────────────────────
// Initialise with the current session name immediately
const sni = $id('sessionNameInput');
if (sni) {
  sni.value = state.session.name ?? '';
  sni.addEventListener('input', () => {
    history.push();
    state.session.name = sni.value.trim() || 'session';
    // Keep the Settings dialog in sync if it's open
    const settingsInput = $id('s_sessionName');
    if (settingsInput) settingsInput.value = state.session.name;
    persist();
    renderIdleScreen();
  });
  // On blur: normalise empty value back to something sensible
  sni.addEventListener('blur', () => {
    if (!sni.value.trim()) {
      sni.value = state.session.name || 'session';
    }
  });
  // Select-all on focus so the user can immediately type a new name
  sni.addEventListener('focus', () => sni.select());
  // Enter key commits and blurs
  sni.addEventListener('keydown', e => { if (e.key === 'Enter') sni.blur(); });
}

const mvSlider = $id('masterVolumeSlider');
mvSlider.value = state.session.masterVolume;
mvSlider.addEventListener('input', e => {
  state.session.masterVolume = Number(e.target.value);
  if (state.runtime?.usingAudioEngine) refreshVolumes();
  else state.runtime?.backgroundAudio.forEach(a => a.volume = state.session.masterVolume * state.session.advanced.playlistAudioVolume);
  // Keep settings dialog in sync if open
  const sv = $id('s_masterVolume');
  if (sv) { sv.value = e.target.value; const sl = $id('s_masterVolumeVal'); if (sl) sl.textContent = `${Math.round(Number(e.target.value) * 100)}%`; }
  persist();
});

// Progress bar — click to seek (playing), shift+click to scrub-preview (stopped)
$id('progressBar').addEventListener('click', e => {
  const r = e.currentTarget.getBoundingClientRect();
  if (r.width <= 0) return;  // guard zero-width bar (hidden panel)
  const pct = (e.clientX - r.left) / r.width;
  if (state.runtime) {
    seekTo(pct);
  } else if (e.shiftKey) {
    // Scrub-preview: show position in HUD and subtitle without starting playback
    const previewSec = pct * state.session.duration;
    const fill  = $id('progressFill');  if (fill)  fill.style.width  = `${pct*100}%`;
    const thumb = $id('progressThumb'); if (thumb) thumb.style.left   = `${pct*100}%`;
    const cur   = $id('tCurrent');      if (cur)   cur.textContent   = fmt(previewSec);
    const hud   = $id('stageHud');      if (hud)   hud.textContent   = `Preview ${fmt(previewSec)}`;
    // Show subtitle cue at this position
    updateSubtitleCue(previewSec);
    // Show active block name
    const ab = state.session.blocks.find(b => previewSec >= b.start && previewSec < b.start + b.duration);
    const ot = $id('overlayText');
    if (ot && ab?.type === 'text') {
      ot.textContent = ab.content;
      ot.style.opacity = '0.45';
      ot.style.fontSize = `${(ab.fontSize || 1.2) * 2.2}rem`;
    }
    // Show which FunScript position would be at this time
    updatePositionIndicator(getCurrentPosition(previewSec));
    // Draw timeline playhead at scrub position
    drawTimeline(previewSec);
  }
});

$id('fullscreenBtn').addEventListener('click', () => {
  if (!document.fullscreenElement) $id('mainStage').requestFullscreen?.();
  else document.exitFullscreen?.();
});

// ── Session actions ──────────────────────────────────────────────────────────
$id('newSessionBtn').addEventListener('click', async () => {
  const ok = await notify.confirm('Start a new session? Unsaved changes will be lost.', { confirmLabel: 'New session', danger: true });
  if (!ok) return;
  history.clear();
  state.session = defaultSession();
  // Clear all sidebar selection so the inspector doesn't try to render stale state
  state.selectedBlockId = null;
  state.selectedSidebarType = null; state.selectedSidebarIdx = null; state.selectedSidebarId = null;
  stopPlayback({ silent: true }); resetZoom(); resetStateEngine(); clearRuleState(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms(); syncTransportControls();
  $id('tTotal').textContent = fmt(state.session.duration); persist();
});

$id('loadSampleBtn').addEventListener('click', () => {
  // Open Session inspector tab and scroll to content packs picker
  if (state.inspTab !== 'session') {
    state.inspTab = 'session';
    document.querySelectorAll('.insp-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === 'session'));
    renderInspector();
  }
  setTimeout(() => {
    document.getElementById('contentPacksPanel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 120);
  notify.info('Choose a session template below.', 3000);
});

$id('exportPackageBtn').addEventListener('click', () => {
  const json     = JSON.stringify(state.session, null, 2);
  const sizeMB   = (new Blob([json]).size / 1_000_000).toFixed(1);
  const safeName = (state.session.name || 'session')
    .replace(/[/\\:*?"<>|]/g, '_')   // strip path separators and shell-special chars
    .replace(/\s+/g, '_')             // spaces → underscores
    .slice(0, 80)                     // cap length
    .trim() || 'session';
  const filename = `${safeName}.assp`;
  const blob     = new Blob([json], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click(); URL.revokeObjectURL(a.href);
  if (Number(sizeMB) > 50) {
    notify.warn(`Exported as ${filename} (${sizeMB} MB) — large file. Consider removing unused media to reduce size.`);
  } else {
    notify.success(`Exported as ${filename} (${sizeMB} MB)`);
  }
});

$id('importPackageInput').addEventListener('change', async e => {
  const file = e.target.files?.[0]; if (!file) return;
  try {
    const text = await file.text();
    // Size-check the raw text BEFORE JSON.parse to avoid OOM on oversized files
    if (text.length > 20_000_000) {
      throw new Error(`Session file is too large (${(text.length / 1e6).toFixed(1)} MB). Max allowed: 20 MB.`);
    }
    let raw;
    try { raw = JSON.parse(text); } catch (pe) { throw new Error(`Not valid JSON: ${pe.message}`); }
    // Validate structure and budgets before mutating any state
    validateImportedSession(raw, text.length);
    history.clear();
    state.session = normalizeSession(raw);
    state.selectedBlockId = state.session.blocks[0]?.id || null;
    state.selectedSidebarType = null; state.selectedSidebarIdx = null; state.selectedSidebarId = null;
    stopPlayback({ silent: true }); resetZoom(); resetStateEngine(); clearRuleState(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms(); syncTransportControls(); persist();
    renderIdleScreen();
    notify.success(`Imported "${state.session.name}" (v${raw.packageVersion ?? '?'})`);
  } catch (err) {
    notify.error(`Import failed: ${err.message}`);
  }
  e.target.value = '';
});

// ── Media file inputs ────────────────────────────────────────────────────────
$id('addAudioInput').addEventListener('change', async e => {
  const files = [...e.target.files];
  let added = 0;
  for (const f of files) {
    try {
      validateMediaFile(f, 'Audio');
      state.session.playlists.audio.push(normalizeAudioTrack({ name: f.name, dataUrl: await fileToDataUrl(f), volume: 1, _muted: false }));
      added++;
    } catch (err) {
      notify.error(`Audio import failed for "${f.name}": ${err.message}`);
    }
  }
  if (added > 0) { persist(); renderSidebar(); notify.success(`Added ${added} audio track${added > 1 ? 's' : ''}.`); }
  e.target.value = '';
});

$id('addVideoInput').addEventListener('change', async e => {
  const files = [...e.target.files];
  let added = 0;
  for (const f of files) {
    try {
      validateMediaFile(f, f.type.startsWith('image/') ? 'Image' : 'Video');
      state.session.playlists.video.push(normalizeVideoTrack({ name: f.name, dataUrl: await fileToDataUrl(f), mediaKind: f.type.startsWith('image/') ? 'image' : 'video', mute: true, volume: 1 }));
      added++;
    } catch (err) {
      notify.error(`Video/image import failed for "${f.name}": ${err.message}`);
    }
  }
  if (added > 0) { persist(); renderSidebar(); notify.success(`Added ${added} video/image track${added > 1 ? 's' : ''}.`); }
  e.target.value = '';
});

$id('addAssInput').addEventListener('change', async e => {
  const file = e.target.files?.[0]; if (!file) return;
  try {
    validateMediaFile(file, 'Subtitle');   // size check before read
    const rawText = await file.text();
    validateSubtitleText(rawText);         // text-size check after read
    const parsed  = parseAss(rawText);
    if (!parsed.events?.length) {
      notify.warn(`"${file.name}" imported but has no cues — check the [Events] section.`);
    } else {
      notify.success(`Imported "${file.name}" — ${parsed.events.length} cues.`);
    }
    state.session.subtitleTracks.push(normalizeSubtitleTrack({ name: file.name, rawAss: rawText, styles: parsed.styles, events: parsed.events, _disabled: false }));
    persist(); renderSidebar();
  } catch (err) {
    notify.error(`Subtitle import failed for "${file.name}":\n${err.message}`);
  }
  e.target.value = '';
});

$id('addFunscriptInput').addEventListener('change', async e => {
  let imported = 0;
  for (const f of e.target.files) {
    try { await importFunScriptFile(f); imported++; }
    catch (err) { notify.error(`FunScript import failed for "${f.name}":\n${err.message}`); }
  }
  if (imported > 0) notify.success(`Imported ${imported} FunScript track${imported > 1 ? 's' : ''}.`);
  renderSidebar(); renderInspector(); drawTimeline();
  e.target.value = '';
});

// ── Block add buttons ────────────────────────────────────────────────────────
document.querySelectorAll('[data-add-block]').forEach(btn => {
  btn.addEventListener('click', () => {
    const type = btn.dataset.addBlock;
    const nextStart = state.session.blocks.length ? Math.max(...state.session.blocks.map(b => b.start + b.duration)) + 2 : 0;
    const block = normalizeBlock({ id: uid(), type, label: `New ${type}`, start: nextStart, duration: type === 'pause' ? 5 : 10 });
    state.session.blocks.push(block);
    state.selectedBlockId = block.id; state.selectedSidebarType = 'block';
    persist(); renderSidebar(); renderInspector();
  });
});

$id('sortBlocksBtn').addEventListener('click', () => {
  state.session.blocks.sort((a, b) => a.start - b.start); persist(); renderSidebar();
});

// ── Delegated events ─────────────────────────────────────────────────────────
document.addEventListener('click', e => {
  const itab = e.target.closest('.insp-tab');
  if (itab) {
    state.inspTab = itab.dataset.tab;
    document.querySelectorAll('.insp-tab').forEach(t => {
      t.classList.toggle('active', t === itab);
      t.setAttribute('aria-selected', t === itab ? 'true' : 'false');
    });
    renderInspector(); return;
  }

  const stab = e.target.closest('.settings-tab');
  if (stab) {
    state.settingsTab = stab.dataset.stab;
    document.querySelectorAll('.settings-tab').forEach(t => t.classList.toggle('active', t === stab));
    document.querySelectorAll('.settings-section').forEach(s => s.classList.toggle('active', s.dataset.section === state.settingsTab));
    if (state.settingsTab === 'macros')   renderMacroLibrary();
    if (state.settingsTab === 'advanced') {
      renderSensorBridgePanel('sensorBridgePanel');
      // Populate JSON preview with current session on every open so it's always fresh
      const jp = $id('s_jsonPreview');
      if (jp) jp.value = JSON.stringify(state.session, null, 2);
    }    return;
  }

  const tc = e.target.closest('[data-theme-key]');
  if (tc) { applyTheme(tc.dataset.themeKey); syncSettingsForms(); return; }

  const muteBtn = e.target.closest('[data-mute-kind]');
  if (muteBtn) {
    const kind    = muteBtn.dataset.muteKind;
    const trackId = muteBtn.dataset.trackId;
    const idx     = Number(muteBtn.dataset.muteIdx);
    history.push();
    if (kind === 'audio') {
      const t = trackId
        ? state.session.playlists.audio.find(a => a.id === trackId)
        : state.session.playlists.audio[idx];
      if (t) {
        t._muted = !t._muted;
        // Update audio engine live so mute takes effect immediately during playback.
        if (state.runtime?.usingAudioEngine) {
          const fadeSec = state.session.advanced.crossfadeSeconds ?? 0.6;
          if (t._muted) {
            // Muting: fade out existing node
            crossfade(t.id, null, fadeSec);
          } else {
            // Unmuting: if track never started (was muted at playback start),
            // create its node first, then crossfade handles the fade-in.
            startSingleTrack(t).then(() => crossfade(null, t.id, fadeSec));
          }
        } else if (state.runtime) {
          refreshVolumes();
        }
      }
    }
    if (kind === 'subtitle') {
      const t = trackId
        ? state.session.subtitleTracks.find(s => s.id === trackId)
        : state.session.subtitleTracks[idx];
      if (t) t._disabled = !t._disabled;
    }
    if (kind === 'funscript') {
      const t = trackId
        ? state.session.funscriptTracks.find(f => f.id === trackId)
        : state.session.funscriptTracks[idx];
      if (t) t._disabled = !t._disabled;
    }
    persist(); renderSidebar(); drawTimeline(); return;
  }

  const delBtn = e.target.closest('[data-del-kind]');
  if (delBtn) {
    const kind    = delBtn.dataset.delKind;
    const trackId = delBtn.dataset.trackId;
    const idx     = Number(delBtn.dataset.delIdx);
    history.push();

    // ── Live teardown: stop the deleted track's media immediately ──────────
    // Without this the track keeps playing even though state says it's gone.
    if (state.runtime) {
      if (kind === 'audio') {
        if (state.runtime.usingAudioEngine) {
          // Resolve the actual id (may have been passed by index, not id)
          const resolvedId = trackId || state.session.playlists.audio[idx]?.id;
          if (resolvedId) removeSingleTrack(resolvedId);
        } else {
          // Fallback HTMLAudioElement path — rebuild backgroundAudio from remaining tracks
          state.runtime.backgroundAudio.forEach(a => { try { a.pause(); a.src = ''; } catch {} });
          state.runtime.backgroundAudio = [];
        }
      }
      if (kind === 'video') {
        // Rebuild bgHost from the remaining video tracks (after state is updated below)
        // We schedule this after state mutation via queueMicrotask.
        queueMicrotask(() => {
          const bh = document.getElementById('bgHost');
          if (!bh || !state.runtime) return;
          // Stop all current video elements
          state.runtime.backgroundVideo.forEach(v => { try { v.pause?.(); v.src = ''; } catch {} });
          state.runtime.backgroundVideo = [];
          bh.innerHTML = '';
          // Re-add remaining tracks
          state.session.playlists.video.forEach(track => {
            const el = track.mediaKind === 'image'
              ? document.createElement('img')
              : document.createElement('video');
            el.src = track.dataUrl;
            if (el.tagName === 'VIDEO') {
              el.loop = true; el.autoplay = true; el.muted = !!track.mute; el.playsInline = true;
              el.volume = state.session.masterVolume * state.session.advanced.playlistVideoVolume * (track.volume ?? 1);
              el.play().catch(() => {});
            }
            bh.appendChild(el);
            state.runtime.backgroundVideo.push(el);
          });
        });
      }
    }

    if (kind === 'audio')    state.session.playlists.audio  = trackId
      ? state.session.playlists.audio.filter(t => t.id !== trackId)
      : (state.session.playlists.audio.splice(idx, 1), state.session.playlists.audio);
    if (kind === 'video')    state.session.playlists.video  = trackId
      ? state.session.playlists.video.filter(t => t.id !== trackId)
      : (state.session.playlists.video.splice(idx, 1), state.session.playlists.video);
    if (kind === 'subtitle') state.session.subtitleTracks = trackId
      ? state.session.subtitleTracks.filter(t => t.id !== trackId)
      : (state.session.subtitleTracks.splice(idx, 1), state.session.subtitleTracks);
    if (kind === 'funscript') {
      state.session.funscriptTracks = trackId
        ? state.session.funscriptTracks.filter(t => t.id !== trackId)
        : (state.session.funscriptTracks.splice(idx, 1), state.session.funscriptTracks);
      drawTimeline();
    }
    state.selectedSidebarType = null; state.selectedSidebarIdx = null; state.selectedSidebarId = null;
    persist(); renderSidebar(); renderInspector(); return;
  }

  const sbItem = e.target.closest('[data-sb-type]');
  if (sbItem && !e.target.closest('[data-mute-kind],[data-del-kind]')) {
    const type    = sbItem.dataset.sbType;
    const idx     = sbItem.dataset.sbIdx !== undefined ? Number(sbItem.dataset.sbIdx) : null;
    const bid     = sbItem.dataset.blockId;
    const trackId = sbItem.dataset.sbTrackId;
    state.selectedSidebarType = type;
    state.selectedSidebarIdx  = idx;
    state.selectedSidebarId   = trackId ?? null;
    if (type === 'block' && bid) {
      state.selectedBlockId = bid;
      state.inspTab = 'overlay';
      document.querySelectorAll('.insp-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === 'overlay'));
    }
    // For non-block sidebar types (tracks, scenes), also ensure the overlay tab is active
    if (type !== 'block') {
      state.inspTab = 'overlay';
      document.querySelectorAll('.insp-tab').forEach(t => {
        t.classList.toggle('active', t.dataset.tab === 'overlay');
        t.setAttribute('aria-selected', t.dataset.tab === 'overlay' ? 'true' : 'false');
      });
    }
    // Targeted class update — avoids full innerHTML rebuild just to flip .selected
    updateSidebarSelection();
    renderInspector();
    return;
  }
});

// ── Settings dialog ──────────────────────────────────────────────────────────
let _tracking = null;

function stopAndClearTracking() { _tracking?.stop(); _tracking = null; }

$id('settingsBtn').addEventListener('click', () => {
  stopAndClearTracking();
  syncSettingsForms(); renderMacroLibrary();
  $id('settingsDialog').showModal();
  // Re-activate whichever tab was open last time
  const lastTab = state.settingsTab ?? 'appearance';
  document.querySelectorAll('.settings-tab').forEach(t =>
    t.classList.toggle('active', t.dataset.stab === lastTab));
  document.querySelectorAll('.settings-section').forEach(s =>
    s.classList.toggle('active', s.dataset.section === lastTab));
  if (lastTab === 'macros')   renderMacroLibrary();
  if (lastTab === 'advanced') {
    renderSensorBridgePanel('sensorBridgePanel');
    const jp = $id('s_jsonPreview');
    if (jp) jp.value = JSON.stringify(state.session, null, 2);
  }
  syncSettingsForms();
  _tracking = makeTrackingModule();
});
const closeSettings = () => {
  syncSessionFromSettings();
  applyCssVars();
  syncTransportControls();
  renderIdleScreen();
  $id('settingsDialog').close();
};
$id('closeSettings').addEventListener('click', closeSettings);
$id('settingsDoneBtn').addEventListener('click', closeSettings);
// Release camera on any close, including ESC-dismissed dialog
$id('settingsDialog').addEventListener('close', stopAndClearTracking);
$id('settingsDialog').addEventListener('input', e => {
  // s_masterVolume is handled by its own dedicated listener below (transport sync).
  // s_jsonPreview is a readonly textarea — skip it to avoid re-serialising on every keystroke.
  if (e.target.id === 's_jsonPreview' || e.target.id === 's_masterVolume') return;
  // Live-update HUD hide-after label
  if (e.target.id === 's_hudHideAfter') {
    const lbl = $id('s_hudHideAfterVal');
    if (lbl) lbl.textContent = `${e.target.value}s`;
  }
  // Live-update rich idle screen when toggled
  if (e.target.id === 's_displayRichIdle') {
    if (e.target.checked) renderIdleScreen();
    else {
      const el = $id('idleHint');
      if (el) el.innerHTML = '<svg width="26" height="26" viewBox="0 0 26 26" fill="none"><circle cx="13" cy="13" r="12" stroke="currentColor" stroke-width="1" opacity=".25"/><path d="M11 8.5l7 4.5-7 4.5V8.5z" fill="currentColor" opacity=".3"/></svg><span>Space to play</span>';
    }
  }
  syncSessionFromSettings(); applyCssVars(); renderThemeGrid();
});

// Mode selector button in Display/HUD tab — opens Session inspector and scrolls to mode section
$id('s_openModeSelector')?.addEventListener('click', () => {
  $id('settingsDoneBtn')?.click(); // close settings first
  setTimeout(() => {
    // Switch to session inspector tab
    if (state.inspTab !== 'session') {
      state.inspTab = 'session';
      document.querySelectorAll('.insp-tab').forEach(t =>
        t.classList.toggle('active', t.dataset.tab === 'session'));
      renderInspector();
    }
    setTimeout(() => {
      $id('sessionModeSelector')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
  }, 80);
});
$id('saveCustomThemeBtn')?.addEventListener('click', saveCustomTheme);
$id('deleteCustomThemeBtn')?.addEventListener('click', deleteCustomTheme);

// ── System tab buttons ─────────────────────────────────────────────────────────
$id('restartOnboardingBtn')?.addEventListener('click', () => {
  localStorage.removeItem(ONBOARD_KEY);
  $id('settingsDialog').close();
  setTimeout(() => _showOnboardingModal(), 300);
});

$id('clearProfileSettingsBtn')?.addEventListener('click', async () => {
  const step1 = await notify.confirm(
    'Clear all profile data and session history?',
    { confirmLabel: 'Yes, clear it', danger: true }
  );
  if (!step1) return;
  const step2 = await notify.confirm(
    'Are you really, really sure? 😢\nThis permanently erases your streak, history, and profile. No undo.',
    { confirmLabel: 'Yes, delete everything', cancelLabel: 'No, keep it', danger: true }
  );
  if (!step2) return;
  clearProfile();
  await clearStoredAnalytics();
  await clearMetricsHistory();
  notify.success('Profile and history cleared.');
  // Re-render profile panel if open (async — fire-and-forget is fine here)
  import('./user-profile.js').then(async ({ renderProfilePanel }) => {
    await renderProfilePanel('profilePanelInspector');
    await renderProfilePanel('profilePanel');
  }).catch(() => {});
});

$id('resetAllSettingsBtn')?.addEventListener('click', async () => {
  const ok = await notify.confirm(
    'Reset all settings (appearance, playback, FunScript, safety, advanced) to their factory defaults?\n\nSession content and profile data are not affected.',
    { confirmLabel: 'Reset settings', danger: true }
  );
  if (!ok) return;
  // Replace session settings fields with fresh defaults while preserving content
  const fresh = defaultSession();
  // Selectively restore settings keys (not blocks/scenes/rules/playlists/tracks)
  const SETTINGS_KEYS = [
    'speechRate', 'masterVolume', 'backgroundColor', 'textColor', 'accentColor',
    'advanced', 'subtitleSettings', 'funscriptSettings', 'safetySettings',
    'trackingFsOptions', 'tracking', 'customThemes', 'rampSettings', 'pacingSettings',
  ];
  for (const key of SETTINGS_KEYS) {
    if (key in fresh) state.session[key] = fresh[key];
  }
  persist();
  syncSettingsForms();
  applyCssVars();
  notify.success('All settings restored to defaults.');
});
$id('startTrackingBtn').addEventListener('click', () => _tracking?.start());
$id('stopTrackingBtn').addEventListener('click',  () => _tracking?.stop());
$id('s_connectDevice')?.addEventListener('click', () => {
  const url = $id('s_deviceWsUrl')?.value?.trim()
    || state.session.advanced?.deviceWsUrl
    || 'ws://localhost:12345';
  connectDevice(url);
});
$id('s_disconnectDevice')?.addEventListener('click', disconnectDevice);

// ── FunScript timeline ───────────────────────────────────────────────────────
const fsCanvas = $id('fsCanvas');
if (fsCanvas) {
  initTimeline(fsCanvas);
  new ResizeObserver(() => {
    fsCanvas.width = fsCanvas.offsetWidth;
    const oc = document.getElementById('overviewCanvas');
    if (oc) oc.width = oc.offsetWidth;
    drawTimeline(state.runtime?.sessionTime ?? null);
  }).observe(fsCanvas.parentElement);
}
$id('fsEditToggle')?.addEventListener('click', () => {
  state.fsEditMode = !state.fsEditMode;
  const btn = $id('fsEditToggle'); btn.classList.toggle('active', state.fsEditMode); btn.textContent = state.fsEditMode ? '✎ Editing' : '✎ Edit';
  drawTimeline(state.runtime?.sessionTime ?? null);
  updateTransformBar();
});
$id('fsCollapseBtn')?.addEventListener('click', () => {
  const c = $id('fsCanvas'), collapsed = c.style.display === 'none';
  c.style.display = collapsed ? '' : 'none'; $id('fsCollapseBtn').textContent = collapsed ? '↑' : '↓';
});
$id('zoomResetBtn')?.addEventListener('click', () => {
  resetZoom();
  drawTimeline(state.runtime?.sessionTime ?? null);
});

// FunScript transform bar
function updateTransformBar() {
  const bar = $id('fsTransformBar');
  if (!bar) return;
  const show = state.fsEditMode;
  bar.style.display = show ? 'flex' : 'none';
  const count = $id('fs_selectionCount');
  if (count) count.textContent = state.selectedFsPoints.size ? `${state.selectedFsPoints.size} pts selected` : '';
}

$id('fs_applyTransform')?.addEventListener('click', () => {
  history.push();
  transformPoints({
    timeScale:  Number($id('fs_timeScale')?.value  ?? 1),
    posScale:   Number($id('fs_posScale')?.value   ?? 1),
    timeOffset: Number($id('fs_timeOffset')?.value ?? 0),
    posOffset:  Number($id('fs_posOffset')?.value  ?? 0),
  });
  updateTransformBar();
  notify.success('Transform applied.');
});
$id('fs_selectAll')?.addEventListener('click',   () => { selectAllPoints(); updateTransformBar(); });
$id('fs_clearSelect')?.addEventListener('click', () => {
  state.selectedFsPoints.clear(); state.selectedFsPoint = null;
  drawTimeline(state.runtime?.sessionTime ?? null); updateTransformBar();
});

// Update transform bar point count on canvas interaction
document.addEventListener('mouseup', () => {
  if (state.fsEditMode) updateTransformBar();
});

// ── Keyboard shortcuts (per README) ─────────────────────────────────────────
let _lastEscTime   = 0;
let _shiftAlone    = false; // true if Shift pressed without another key

document.addEventListener('keydown', e => {
  const inField = e.target.matches('input,textarea,select');

  // Escape blurs the active field (standard UX)
  if (e.key === 'Escape' && inField) {
    e.target.blur();
    return;
  }

  // Ctrl+, opens settings (common convention)
  if (e.key === ',' && e.ctrlKey && !inField) {
    e.preventDefault();
    $id('openSettingsBtn')?.click();
    return;
  }

  if (inField && e.key !== 'Escape' && !e.ctrlKey) return;

  // If any non-modifier key pressed while Shift held → not standalone
  if (e.shiftKey && e.key !== 'Shift') _shiftAlone = false;

  switch (e.key) {
    case 'Shift':
      _shiftAlone = true; // may be cleared by subsequent key
      break;

    case ' ':
      e.preventDefault();
      if (!state.runtime)            startPlayback();
      else if (state.runtime.paused) resumePlayback();
      else                           pausePlayback();
      break;

    // Arrow keys: L/R = ±10s, U/D = ±30s  (per README)
    case 'ArrowLeft':  e.preventDefault(); skipBy(-10); break;
    case 'ArrowRight': e.preventDefault(); skipBy(10);  break;
    case 'ArrowUp':    e.preventDefault(); skipBy(30);  break;
    case 'ArrowDown':  e.preventDefault(); skipBy(-30); break;

    // Graceful stop + exit fullscreen
    case 'Enter':
    case 'F12':
      e.preventDefault();
      stopPlayback();
      document.exitFullscreen?.().catch(() => {});
      break;

    // ESC: single = graceful stop, double within 1.2s = emergency stop
    case 'Escape': {
      const now = Date.now();
      if (now - _lastEscTime < 1200) {
        e.preventDefault(); emergencyStop(); _lastEscTime = 0;
      } else {
        _lastEscTime = now;
        stopPlayback();
        document.exitFullscreen?.().catch(() => {});
      }
      break;
    }

    // Macro injection slots 1–5 (per README)
    case '1': case '2': case '3': case '4': case '5': {
      if (inField) break;
      _shiftAlone = false;
      const macro = getSlotMacro(Number(e.key));
      if (macro) { e.preventDefault(); injectMacro(macro.id); }
      break;
    }

    // Editor shortcuts
    case 'd': case 'D':
      if (!inField && state.selectedBlockId) duplicateBlock(); break;
    case 'n': case 'N':
      if (!inField && state.session.scenes?.length) { e.preventDefault(); skipToNextScene(); }
      break;
    case 'f': case 'F':
      if (!inField) {
        if (!document.fullscreenElement) $id('mainStage').requestFullscreen?.();
        else document.exitFullscreen?.();
      }
      break;
    case 'e': case 'E':
      if (!inField) {
        state.fsEditMode = !state.fsEditMode;
        const btn = $id('fsEditToggle');
        btn?.classList.toggle('active', state.fsEditMode);
        if (btn) btn.textContent = state.fsEditMode ? '✎ Editing' : '✎ Edit';
        drawTimeline(state.runtime?.sessionTime ?? null);
      }
      break;
    // A = select all FunScript points (edit mode only)
    case 'a': case 'A':
      if (!inField && state.fsEditMode) { e.preventDefault(); selectAllPoints(); }
      break;
    case 'Delete': case 'Backspace':
      if (!inField && state.selectedBlockId) { e.preventDefault(); deleteBlock(); }
      break;
    case 's':
      if (e.ctrlKey) { e.preventDefault(); $id('exportPackageBtn').click(); }
      break;
    case '0':
      if (e.ctrlKey) { e.preventDefault(); resetZoom(); drawTimeline(state.runtime?.sessionTime ?? null); }
      break;

    // ── Phase 2 Live Override controls ──────────────────────────────────────
    // [ / ] → Intensity -10% / +10%   , / . → Speed -0.1× / +0.1×   r → Reset
    case '[': {
      if (inField) break;
      e.preventDefault();
      const cur = state.liveControl?.intensityScale ?? 1;
      setLiveIntensity(Math.max(0, +(cur - 0.1).toFixed(2)));
      const pct = Math.round((state.liveControl?.intensityScale ?? cur) * 100);
      showLiveControlToast(`Intensity ${pct}%`);
      break;
    }
    case ']': {
      if (inField) break;
      e.preventDefault();
      const cur = state.liveControl?.intensityScale ?? 1;
      setLiveIntensity(Math.min(2, +(cur + 0.1).toFixed(2)));
      const pct = Math.round((state.liveControl?.intensityScale ?? cur) * 100);
      showLiveControlToast(`Intensity ${pct}%`);
      break;
    }
    case ',': {
      if (inField) break;
      e.preventDefault();
      const cur = state.liveControl?.speedScale ?? 1;
      setLiveSpeed(Math.max(0.25, +(cur - 0.1).toFixed(2)));
      const spd = (state.liveControl?.speedScale ?? cur).toFixed(2);
      showLiveControlToast(`Speed ${spd}×`);
      break;
    }
    case '.': {
      if (inField) break;
      e.preventDefault();
      const cur = state.liveControl?.speedScale ?? 1;
      setLiveSpeed(Math.min(4, +(cur + 0.1).toFixed(2)));
      const spd = (state.liveControl?.speedScale ?? cur).toFixed(2);
      showLiveControlToast(`Speed ${spd}×`);
      break;
    }
    case 'r': case 'R': {
      if (inField || e.ctrlKey) break;
      e.preventDefault();
      if (state.liveControl) {
        state.liveControl.intensityScale = 1.0;
        state.liveControl.speedScale = 1.0;
        state.liveControl.randomness = 0.0;
        // Sync sliders if panel is visible
        const iSlider = $id('lc_intensity'); if (iSlider) iSlider.value = 1.0;
        const iLabel  = $id('lc_intensityVal'); if (iLabel) iLabel.textContent = '100%';
        const sSlider = $id('lc_speed'); if (sSlider) sSlider.value = 1.0;
        const sLabel  = $id('lc_speedVal'); if (sLabel) sLabel.textContent = '1.00×';
        const rSlider = $id('lc_random'); if (rSlider) rSlider.value = 0;
        const rLabel  = $id('lc_randomVal'); if (rLabel) rLabel.textContent = '0%';
        showLiveControlToast('Controls reset ↺');
      }
      break;
    }

    // Undo / Redo
    case 'z':
      if (e.ctrlKey && !e.shiftKey) { e.preventDefault(); history.undo(); }
      break;
    case 'Z':
    case 'y':
      if (e.ctrlKey) { e.preventDefault(); history.redo(); }
      break;
    case '?':
    case '/':
      if (!inField) { e.preventDefault(); toggleShortcutsOverlay(); }
      break;
  }
});

// Shift keyup: if no other key was pressed during hold → toggle FS pause
document.addEventListener('keyup', e => {
  if (e.key === 'Shift' && _shiftAlone) {
    _shiftAlone = false;
    if (state.runtime) toggleFsPause();
  }
});

// ── Keyboard shortcuts overlay (? key) ───────────────────────────────────────
function toggleShortcutsOverlay() {
  const existing = document.getElementById('shortcutsOverlay');
  if (existing) { existing.remove(); return; }

  const overlay = document.createElement('div');
  overlay.id = 'shortcutsOverlay';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-label', 'Keyboard shortcuts');
  overlay.style.cssText = `
    position:fixed;inset:0;z-index:9998;
    background:rgba(0,0,0,0.7);backdrop-filter:blur(4px);
    display:flex;align-items:center;justify-content:center;
    font-family:Inter,system-ui,sans-serif;`;
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

  const groups = [
    { title: 'Playback', rows: [
      ['Space',       'Play / Pause session'],
      ['Shift',       'Play / Pause FunScript only'],
      ['1 – 5',       'Inject macro from slot'],
      ['← →',         'Skip ±10 seconds'],
      ['↑ ↓',         'Skip ±30 seconds'],
      ['Enter / F12', 'Graceful stop + exit fullscreen'],
      ['ESC',         'Stop + exit fullscreen'],
      ['ESC × 2',     'Emergency stop'],
    ]},
    { title: 'Live Overrides', rows: [
      ['[ / ]',  'Intensity −10% / +10%'],
      [', / .',  'Speed −0.1× / +0.1×'],
      ['R',      'Reset intensity, speed & variation'],
      ['N',      'Jump to next scene'],
    ]},
    { title: 'Editor', rows: [
      ['F',         'Toggle fullscreen'],
      ['E',         'Toggle FunScript edit mode'],
      ['Scroll ↕',  'Zoom timeline in / out'],
      ['Ctrl+0',    'Reset timeline zoom'],
      ['D',         'Duplicate selected block'],
      ['Delete',    'Delete selected block'],
      ['Ctrl+Z',    'Undo'],
      ['Ctrl+Y',    'Redo'],
      ['Ctrl+S',    'Export session'],
      ['?',         'Show / hide this overlay'],
    ]},
  ];

  const card = document.createElement('div');
  card.style.cssText = `
    background:#16161c;border:0.5px solid rgba(255,255,255,0.12);
    border-radius:14px;padding:22px 24px;max-width:540px;width:92vw;
    max-height:88vh;overflow-y:auto;`;

  const heading = document.createElement('div');
  heading.style.cssText = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;';
  const headingTitle = document.createElement('h3');
  headingTitle.style.cssText = 'font-family:Syne,sans-serif;font-size:15px;font-weight:600;color:#e2e0d8;margin:0';
  headingTitle.textContent = 'Keyboard Shortcuts';
  const closeBtn = document.createElement('button');
  closeBtn.style.cssText = 'background:transparent;border:none;color:rgba(255,255,255,0.3);font-size:18px;cursor:pointer;line-height:1;padding:0;';
  closeBtn.textContent = '✕';
  closeBtn.addEventListener('click', () => overlay.remove());
  heading.appendChild(headingTitle);
  heading.appendChild(closeBtn);
  card.appendChild(heading);

  const grid = document.createElement('div');
  grid.style.cssText = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:0 20px;';

  for (const group of groups) {
    const col = document.createElement('div');
    const groupTitle = document.createElement('div');
    groupTitle.style.cssText = 'font-size:9.5px;font-weight:600;letter-spacing:.09em;text-transform:uppercase;color:rgba(255,255,255,0.25);margin-bottom:10px;';
    groupTitle.textContent = group.title;
    col.appendChild(groupTitle);

    for (const [key, desc] of group.rows) {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:baseline;gap:8px;margin-bottom:7px;';
      const kbd = document.createElement('kbd');
      kbd.style.cssText = 'background:#20202c;border:0.5px solid rgba(255,255,255,0.15);border-radius:4px;padding:2px 6px;font-size:10px;font-family:monospace;color:#f0a04a;white-space:nowrap;flex-shrink:0;';
      kbd.textContent = key;
      const label = document.createElement('span');
      label.style.cssText = 'font-size:11px;color:#908e86;';
      label.textContent = desc;
      row.appendChild(kbd); row.appendChild(label);
      col.appendChild(row);
    }
    grid.appendChild(col);
  }

  card.appendChild(grid);
  overlay.appendChild(card);
  document.body.appendChild(overlay);
  // Close on ESC (single press - not double)
  const handler = e => { if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', handler, true); } };
  document.addEventListener('keydown', handler, true);
}


// ── AudioContext resume (browser autoplay policy) ─────────────────────────────
// Browsers suspend AudioContext until a user gesture. This resumes it on the
// first click or keydown anywhere on the page.
let _audioCtxResumed = false;
function tryResumeAudio() {
  if (_audioCtxResumed) return;
  _audioCtxResumed = true;
  import('./audio-engine.js').then(({ resumeAudioEngine }) => resumeAudioEngine());
}
document.addEventListener('click',   tryResumeAudio, { once: true });
document.addEventListener('keydown',  tryResumeAudio, { once: true });

initMacroLibraryEvents();

// ── Live Control Panel ────────────────────────────────────────────────────────
initLiveControl();

// ── Fullscreen HUD ────────────────────────────────────────────────────────────
initFullscreenHud();
renderIdleScreen();

// Keep vizStageCanvas pixel-crisp on window resize during active viz playback
window.addEventListener('resize', () => {
  const vizStage = $id('vizStageCanvas');
  if (vizStage && vizStage.dataset.blockId && vizStage.style.display !== 'none') {
    vizStage.width  = vizStage.offsetWidth  * devicePixelRatio || vizStage.width;
    vizStage.height = vizStage.offsetHeight * devicePixelRatio || vizStage.height;
    // mountVizBlock will be called on the next RAF tick via playback — canvas clears automatically
  }
}, { passive: true });

// ── Undo / Redo ───────────────────────────────────────────────────────────────
history.onchange(() => {
  renderSidebar(); renderInspector(); syncSettingsForms(); syncTransportControls(); applyCssVars();
  $id('tTotal').textContent = fmt(state.session.duration);
});
$id('undoBtn')?.addEventListener('click', () => history.undo());
$id('redoBtn')?.addEventListener('click', () => history.redo());

// ── Capabilities ───────────────────────────────────────────────────────────────
detectCapabilities();
applyCapabilityGates();
// Defer capability warnings slightly so UI is fully painted first
setTimeout(warnMissingCapabilities, 1200);

// ── Settings JSON apply / format ────────────────────────────────────────────
$id('applyJsonBtn').addEventListener('click', () => {
  const raw = $id('s_jsonPreview').value;
  try {
    history.push();
    const parsed = JSON.parse(raw);
    // Route through the same validator as file import — no separate trust boundary.
    validateImportedSession(parsed, raw.length);
    state.session = normalizeSession(parsed);
    state.selectedBlockId = state.session.blocks[0]?.id || null;
    stopPlayback({ silent: true }); resetZoom(); resetStateEngine(); clearRuleState(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms(); syncTransportControls();
    notify.success('JSON applied.');
  } catch (err) {
    history.undo(); // roll back the push
    notify.error(`Apply failed: ${err.message}`);
  }
});
$id('formatJsonBtn').addEventListener('click', () => {
  try { $id('s_jsonPreview').value = JSON.stringify(JSON.parse($id('s_jsonPreview').value), null, 2); }
  catch (err) { notify.error(`Invalid JSON: ${err.message}`); }
});

// ── Slider live value labels ──────────────────────────────────────────────────
const sliderLabels = [
  ['s_speechRate',         's_speechRateVal',       v => v],
  ['s_masterVolume',       's_masterVolumeVal',      v => `${Math.round(v * 100)}%`],
  ['s_playlistAudioVolume','s_pavVal',               v => v],
  ['s_playlistVideoVolume','s_pvvVal',               v => v],
  ['s_fsSpeed',            's_fsSpeedVal',           v => `${v}×`],
  ['s_hudHideAfter',       's_hudHideAfterVal',      v => `${v}s`],
  ['s_safetyMaxInt',       's_safetyMaxIntVal',      v => `${Math.round(v * 100)}%`],
  ['s_safetyMaxSpd',       's_safetyMaxSpdVal',      v => `${parseFloat(v).toFixed(2)}×`],
  ['s_safetyWarn',         's_safetyWarnVal',        v => `${Math.round(v * 100)}%`],
  ['s_safetyReduceTarget', 's_safetyReduceTargetVal',v => `${Math.round(v * 100)}%`],
];
sliderLabels.forEach(([sliderId, labelId, fmtFn]) => {
  const slider = $id(sliderId), label = $id(labelId);
  if (!slider || !label) return;
  slider.addEventListener('input', () => {
    label.textContent = fmtFn(parseFloat(slider.value).toFixed(2).replace(/\.?0+$/, ''));
  });
});

// ── Bidirectional master volume sync (transport bar ↔ settings dialog) ───────
// The transport slider input handler already pushes to s_masterVolume (above).
// This adds the reverse: settings slider → transport bar + state, so either
// control is the canonical source.
$id('settingsDialog')?.addEventListener('input', e => {
  if (e.target.id !== 's_masterVolume') return;
  const val = Number(e.target.value);
  state.session.masterVolume = val;
  const t = $id('masterVolumeSlider');
  if (t) t.value = val;
  if (state.runtime?.usingAudioEngine) refreshVolumes();
  else state.runtime?.backgroundAudio.forEach(a =>
    a.volume = val * state.session.advanced.playlistAudioVolume);
  persist();
});

// Show/hide safety auto-reduce target row when checkbox toggles
$id('settingsDialog')?.addEventListener('change', e => {
  if (e.target.id === 's_safetyAutoReduce') {
    const row = $id('s_safetyReduceTargetRow');
    if (row) row.style.display = e.target.checked ? '' : 'none';
  }
});

// ── Storage budget check ──────────────────────────────────────────────────────
setTimeout(() => {
  const budget = checkStorageBudget();
  if (budget.warning) {
    notify.info(`localStorage is ${budget.percentUsed}% full — consider clearing browser data. Session data is safely stored in IndexedDB.`, 6000);
  }
}, 2000);

// ── Suggestions on startup (deferred so UI paints first) ─────────────────────
setTimeout(() => checkAndNotify(), 3000);

// ── First-run onboarding tutorial ────────────────────────────────────────────
// Shows once per installation. Dismissed permanently via localStorage.
const ONBOARD_KEY = 'ass-onboarded-v1';
if (!localStorage.getItem(ONBOARD_KEY)) {
  setTimeout(() => _showOnboardingModal(), 800);
}

// Allow profile panel to trigger onboarding restart
window.addEventListener('ass:restartOnboarding', () => {
  try { localStorage.removeItem(ONBOARD_KEY); } catch {}
  _showOnboardingModal();
});

function _showOnboardingModal() {
  const ov = document.createElement('div');
  ov.id = 'onboardingOverlay';
  ov.setAttribute('role', 'dialog');
  ov.setAttribute('aria-modal', 'true');
  ov.setAttribute('aria-label', 'Welcome to Adaptive Session Studio');
  ov.style.cssText = `position:fixed;inset:0;z-index:10001;background:rgba(0,0,0,0.75);
    backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;
    font-family:Inter,system-ui,sans-serif;`;

  const steps = [
    { icon:'🌀', title:'Start from a template',
      body:'Open the Session tab in the inspector and choose from pre-built templates: guided induction, behavioral conditioning, partner training, solo escalation, and grounding sessions. Each is a complete starting point you can customize.' },
    { icon:'🧩', title:'Blocks are your content',
      body:'Text overlays, spoken TTS, audio tracks, and silence blocks. Each has a start time and duration. Combine them to build any experience — use {{intensity}} or {{varName}} in text to make it responsive.' },
    { icon:'🎬', title:'Scenes shape the arc',
      body:'Scenes divide your session into phases. Assign a State Block type (🌊 Calm · 📈 Build · ⚡ Peak · 🌱 Recovery) and the intensity/pace profile adjusts automatically when the scene is entered.' },
    { icon:'⚙', title:'Rules adapt in real time',
      body:'Rules watch attention, engagement, and intensity and fire actions when conditions hold. Reward focus with higher intensity, pause on drift, jump to a different scene — or set a variable with setVar.' },
    { icon:'🎛', title:'Live controls for operators',
      body:'The Live Control panel adjusts intensity, speed, and variation in real time. [ / ] intensity, , / . speed, R to reset. In partner sessions the operator uses these to guide the experience manually.' },
  ];

  let step = 0;

  const card = document.createElement('div');
  card.style.cssText = `background:#16161c;border:0.5px solid rgba(255,255,255,0.12);
    border-radius:16px;padding:28px 28px 22px;max-width:420px;width:90vw;
    box-shadow:0 12px 50px rgba(0,0,0,0.7);`;

  function render() {
    const s = steps[step];
    card.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px">
        <div style="font-family:Syne,sans-serif;font-size:13px;font-weight:600;color:#e2e0d8;letter-spacing:.03em">
          Welcome to Adaptive Session Studio
        </div>
        <span style="font-size:11px;color:rgba(255,255,255,0.25)">${step+1} / ${steps.length}</span>
      </div>
      <div style="font-size:2.2rem;margin-bottom:12px;line-height:1">${s.icon}</div>
      <div style="font-size:15px;font-weight:600;color:#e2e0d8;margin-bottom:8px;font-family:Syne,sans-serif">${s.title}</div>
      <div style="font-size:12.5px;color:rgba(255,255,255,0.6);line-height:1.7;margin-bottom:24px">${s.body}</div>
      <div style="display:flex;gap:8px;justify-content:space-between;align-items:center">
        <button id="ob_skip" style="background:transparent;border:none;color:rgba(255,255,255,0.25);
          font-size:11px;cursor:pointer;padding:0;font-family:inherit">Skip tour</button>
        <div style="display:flex;gap:6px">
          ${step > 0 ? `<button id="ob_back" style="padding:7px 16px;border-radius:7px;
            border:0.5px solid rgba(255,255,255,0.12);background:transparent;
            color:rgba(255,255,255,0.5);font-size:12px;cursor:pointer;font-family:inherit">← Back</button>` : ''}
          <button id="ob_next" style="padding:7px 18px;border-radius:7px;
            border:0.5px solid rgba(127,176,255,0.35);background:rgba(127,176,255,0.1);
            color:#7fb0ff;font-size:12px;cursor:pointer;font-family:inherit;font-weight:500">
            ${step === steps.length - 1 ? 'Get started →' : 'Next →'}
          </button>
        </div>
      </div>`;

    card.querySelector('#ob_skip')?.addEventListener('click', dismiss);
    card.querySelector('#ob_back')?.addEventListener('click', () => { step--; render(); });
    card.querySelector('#ob_next')?.addEventListener('click', () => {
      if (step < steps.length - 1) { step++; render(); }
      else dismiss();
    });
  }

  function dismiss() {
    localStorage.setItem(ONBOARD_KEY, '1');
    ov.style.opacity = '0';
    ov.style.transition = 'opacity 0.25s';
    setTimeout(() => ov.remove(), 260);
  }

  ov.addEventListener('click', e => { if (e.target === ov) dismiss(); });
  // Escape key should also dismiss the onboarding overlay
  const _obEscHandler = e => {
    if (e.key === 'Escape') { dismiss(); document.removeEventListener('keydown', _obEscHandler, true); }
  };
  document.addEventListener('keydown', _obEscHandler, true);
  ov.appendChild(card);
  document.body.appendChild(ov);
  render();
}

// ── Safety banner dismiss ─────────────────────────────────────────────────────
// IMPORTANT: hide the banner, never remove() it — _showEmergencyBanner() in
// playback.js uses $id('safetyBanner') and will silently fail if the node is gone.
$id('safetyDismiss')?.addEventListener('click', () => {
  const banner = $id('safetyBanner');
  if (banner) banner.style.display = 'none';
});

// ── Init ──────────────────────────────────────────────────────────────────────
applyCssVars();
renderSidebar();
renderInspector();
syncTransportControls();
drawTimeline();
