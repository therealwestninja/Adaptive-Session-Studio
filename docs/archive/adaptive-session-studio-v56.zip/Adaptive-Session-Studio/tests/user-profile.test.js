// ── tests/user-profile.test.js ────────────────────────────────────────────
// Tests for user-profile.js: computeDifficultyLevel, getAdaptiveRampSuggestion,
// getStreakMilestone, rebuildProfile.

import { makeRunner } from './harness.js';
import {
  computeDifficultyLevel, getAdaptiveRampSuggestion,
  getStreakMilestone, getSessionCountMilestone, getRuntimeMilestone,
  defaultProfile, rebuildProfile, clearProfile,
} from '../js/user-profile.js';
import { _setAnalyticsCacheForTest, clearStoredAnalytics } from '../js/session-analytics.js';

export function runUserProfileTests() {
  const R  = makeRunner('user-profile.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // ── computeDifficultyLevel ────────────────────────────────────────────
  t('computeDifficultyLevel returns 1 for null profile', () => {
    eq(computeDifficultyLevel(null), 1);
  });
  t('computeDifficultyLevel returns 1 for new user (< 2 sessions)', () => {
    eq(computeDifficultyLevel({ ...defaultProfile(), sessionCount: 1 }), 1);
  });
  t('computeDifficultyLevel returns 1 for baseline user with no bonuses', () => {
    const p = { ...defaultProfile(), sessionCount: 5, streak: 0,
      avgAttentionStability: 0.5, intensityTrend: 'stable' };
    eq(computeDifficultyLevel(p), 1);
  });
  t('computeDifficultyLevel streak 7+ adds level', () => {
    const p = { ...defaultProfile(), sessionCount: 10, streak: 7,
      avgAttentionStability: 0, intensityTrend: 'stable' };
    ok(computeDifficultyLevel(p) >= 2, 'streak 7 should push level >= 2');
  });
  t('computeDifficultyLevel streak 30+ adds more level', () => {
    const p = { ...defaultProfile(), sessionCount: 30, streak: 30,
      avgAttentionStability: 0, intensityTrend: 'stable' };
    ok(computeDifficultyLevel(p) >= 3, 'streak 30 should push level >= 3');
  });
  t('computeDifficultyLevel high attention stability adds level', () => {
    const p = { ...defaultProfile(), sessionCount: 5, streak: 0,
      avgAttentionStability: 0.82, intensityTrend: 'stable' };
    ok(computeDifficultyLevel(p) >= 2);
  });
  t('computeDifficultyLevel very high stability adds more level', () => {
    const p = { ...defaultProfile(), sessionCount: 5, streak: 0,
      avgAttentionStability: 0.96, intensityTrend: 'stable' };
    ok(computeDifficultyLevel(p) >= 2);
  });
  t('computeDifficultyLevel rising intensity trend adds bonus', () => {
    const p = { ...defaultProfile(), sessionCount: 5, streak: 0,
      avgAttentionStability: 0, intensityTrend: 'rising' };
    ok(computeDifficultyLevel(p) >= 1);
  });
  t('computeDifficultyLevel caps at 5', () => {
    const p = { ...defaultProfile(), sessionCount: 100, streak: 100,
      avgAttentionStability: 0.99, intensityTrend: 'rising' };
    ok(computeDifficultyLevel(p) <= 5);
  });

  // ── getAdaptiveRampSuggestion ─────────────────────────────────────────
  t('getAdaptiveRampSuggestion returns a valid rampSettings object', () => {
    const s = getAdaptiveRampSuggestion();
    ok(typeof s.enabled === 'boolean');
    ok(typeof s.startVal === 'number');
    ok(typeof s.endVal === 'number');
    ok(['time','engagement','step','adaptive'].includes(s.mode));
    ok(['linear','exponential','sine'].includes(s.curve));
    ok(['max','add','replace'].includes(s.blendMode));
  });
  t('getAdaptiveRampSuggestion startVal is in 0-2 range', () => {
    const s = getAdaptiveRampSuggestion();
    ok(s.startVal >= 0 && s.startVal <= 2, `startVal ${s.startVal} out of range`);
  });
  t('getAdaptiveRampSuggestion endVal is in 0-2 range', () => {
    const s = getAdaptiveRampSuggestion();
    ok(s.endVal >= 0 && s.endVal <= 2, `endVal ${s.endVal} out of range`);
  });
  t('getAdaptiveRampSuggestion endVal >= startVal', () => {
    const s = getAdaptiveRampSuggestion();
    ok(s.endVal >= s.startVal, `endVal ${s.endVal} should be >= startVal ${s.startVal}`);
  });
  t('getAdaptiveRampSuggestion includes a _note string', () => {
    const s = getAdaptiveRampSuggestion();
    ok(typeof s._note === 'string' && s._note.length > 0);
  });

  // ── getStreakMilestone ────────────────────────────────────────────────
  t('getStreakMilestone returns null for streak 0', () => {
    eq(getStreakMilestone(0), null);
  });
  t('getStreakMilestone returns null for non-milestone streaks', () => {
    eq(getStreakMilestone(2), null);
    eq(getStreakMilestone(5), null);
    eq(getStreakMilestone(10), null);
  });
  t('getStreakMilestone returns message for streak 3', () => {
    const m = getStreakMilestone(3);
    ok(m !== null && typeof m.message === 'string');
    ok(m.message.includes('3'));
  });
  t('getStreakMilestone returns message for streak 7', () => {
    const m = getStreakMilestone(7);
    ok(m !== null && typeof m.message === 'string');
  });
  t('getStreakMilestone returns message for streak 30', () => {
    const m = getStreakMilestone(30);
    ok(m !== null);
  });
  t('getStreakMilestone returns message for streak 100', () => {
    ok(getStreakMilestone(100) !== null);
  });

  // ── getSessionCountMilestone ─────────────────────────────────────────
  t('getSessionCountMilestone returns null for count 0', () => {
    eq(getSessionCountMilestone(0), null);
  });
  t('getSessionCountMilestone returns message for count 1 (first session)', () => {
    ok(getSessionCountMilestone(1)?.message.includes('First'));
  });
  t('getSessionCountMilestone returns message for count 10', () => {
    ok(getSessionCountMilestone(10)?.message.includes('10'));
  });
  t('getSessionCountMilestone returns message for count 100', () => {
    ok(getSessionCountMilestone(100)?.message.includes('100'));
  });
  t('getSessionCountMilestone returns null for non-milestone count', () => {
    eq(getSessionCountMilestone(3),  null);
    eq(getSessionCountMilestone(99), null);
  });

  // ── getRuntimeMilestone ───────────────────────────────────────────────
  t('getRuntimeMilestone returns null before first hour', () => {
    eq(getRuntimeMilestone(1800), null);
  });
  t('getRuntimeMilestone triggers at exactly 1 hour', () => {
    ok(getRuntimeMilestone(3600) !== null);
    ok(getRuntimeMilestone(3600)?.message.toLowerCase().includes('hour'));
  });
  t('getRuntimeMilestone returns null between milestone windows', () => {
    eq(getRuntimeMilestone(7200), null); // 2 hours — not a milestone boundary
  });
  t('getRuntimeMilestone triggers at 10 hours', () => {
    ok(getRuntimeMilestone(36_000) !== null);
  });

  // ── defaultProfile ────────────────────────────────────────────────────
  t('defaultProfile returns valid shape', () => {
    const p = defaultProfile();
    eq(p.sessionCount, 0);
    eq(p.totalRuntimeSec, 0);
    eq(p.streak, 0);
    eq(p.intensityTrend, 'stable');
    eq(p.attentionTrend, 'stable');
  });
  t('defaultProfile includes primaryUse field defaulting to self', () => {
    eq(defaultProfile().primaryUse, 'self');
  });
  t('defaultProfile includes role field defaulting to primary', () => {
    eq(defaultProfile().role, 'primary');
  });
  t('defaultProfile includes displayName as empty string', () => {
    eq(defaultProfile().displayName, '');
  });
  t('defaultProfile includes avatarEmoji', () => {
    ok(typeof defaultProfile().avatarEmoji === 'string' && defaultProfile().avatarEmoji.length > 0);
  });

  // ── rebuildProfile ─────────────────────────────────────────────────────
  // rebuildProfile reads from getStoredAnalytics() which reads _analyticsCache.
  // We seed the cache directly to avoid IDB async complexity in tests.
  function seedAnalytics(entries) {
    _setAnalyticsCacheForTest(entries);
  }
  function cleanupAnalytics() {
    _setAnalyticsCacheForTest([]);
    clearProfile();
  }
  function makeSummary(overrides = {}) {
    return { timestamp: Date.now(), sessionName: 'Test', totalSec: 60,
      loopsCompleted: 1, blockBreakdown: [], sceneBreakdown: [],
      fsAvg: 50, fsMax: 90, attentionLossEvents: 0,
      attentionLossTotalSec: 0, ...overrides };
  }

  t('rebuildProfile returns defaultProfile when analytics is empty', () => {
    cleanupAnalytics(); seedAnalytics([]);
    const p = rebuildProfile();
    eq(p.sessionCount, 0); eq(p.totalRuntimeSec, 0);
    cleanupAnalytics();
  });

  t('rebuildProfile sessionCount equals history entry count', () => {
    cleanupAnalytics();
    seedAnalytics([makeSummary(), makeSummary(), makeSummary()]);
    eq(rebuildProfile().sessionCount, 3);
    cleanupAnalytics();
  });

  t('rebuildProfile totalRuntimeSec sums all sessions', () => {
    cleanupAnalytics();
    seedAnalytics([makeSummary({ totalSec: 60 }), makeSummary({ totalSec: 90 }),
                   makeSummary({ totalSec: 120 })]);
    eq(rebuildProfile().totalRuntimeSec, 270);
    cleanupAnalytics();
  });

  t('rebuildProfile preferredIntensityAvg is average of fsAvg', () => {
    cleanupAnalytics();
    seedAnalytics([makeSummary({ fsAvg: 40 }), makeSummary({ fsAvg: 60 })]);
    eq(rebuildProfile().preferredIntensityAvg, 50);
    cleanupAnalytics();
  });

  t('rebuildProfile ignores null fsAvg entries in average', () => {
    cleanupAnalytics();
    seedAnalytics([makeSummary({ fsAvg: null, fsMax: null }), makeSummary({ fsAvg: 70, fsMax: 90 })]);
    eq(rebuildProfile().preferredIntensityAvg, 70);
    cleanupAnalytics();
  });

  t('rebuildProfile streak = 1 for a single session today', () => {
    cleanupAnalytics();
    seedAnalytics([makeSummary({ timestamp: Date.now() })]);
    eq(rebuildProfile().streak, 1);
    cleanupAnalytics();
  });

  t('rebuildProfile streak = 0 when last session was 3+ days ago', () => {
    cleanupAnalytics();
    const threeDaysAgo = Date.now() - 3 * 24 * 60 * 60 * 1000;
    seedAnalytics([makeSummary({ timestamp: threeDaysAgo })]);
    eq(rebuildProfile().streak, 0);
    cleanupAnalytics();
  });

  t('rebuildProfile intensityTrend stable for identical sessions', () => {
    cleanupAnalytics();
    seedAnalytics(Array.from({ length: 8 }, () => makeSummary({ fsAvg: 50 })));
    eq(rebuildProfile().intensityTrend, 'stable');
    cleanupAnalytics();
  });

  t('rebuildProfile intensityTrend rising when recent sessions have higher fsAvg', () => {
    cleanupAnalytics();
    // history[0] = most recent; newer half is higher
    const newer = [80, 85, 80, 85].map(fsAvg => makeSummary({ fsAvg }));
    const older  = [20, 25, 20, 25].map(fsAvg => makeSummary({ fsAvg }));
    seedAnalytics([...newer, ...older]);
    eq(rebuildProfile().intensityTrend, 'rising');
    cleanupAnalytics();
  });

  t('rebuildProfile preserves primaryUse across rebuild', () => {
    cleanupAnalytics();
    // Simulate user having set primaryUse on their profile
    const p = defaultProfile();
    p.primaryUse = 'i-train-partner';
    saveProfile(p);
    seedAnalytics([makeSummary()]);
    const rebuilt = rebuildProfile();
    eq(rebuilt.primaryUse, 'i-train-partner', 'primaryUse must survive rebuildProfile');
    cleanupAnalytics();
  });

  t('rebuildProfile preserves role across rebuild', () => {
    cleanupAnalytics();
    const p = defaultProfile();
    p.role = 'operator';
    saveProfile(p);
    seedAnalytics([makeSummary()]);
    const rebuilt = rebuildProfile();
    eq(rebuilt.role, 'operator', 'role must survive rebuildProfile');
    cleanupAnalytics();
  });

  t('rebuildProfile preserves displayName and goals across rebuild', () => {
    cleanupAnalytics();
    const p = defaultProfile();
    p.displayName = 'Alex';
    p.goals = 'Weekly consistency';
    saveProfile(p);
    seedAnalytics([makeSummary()]);
    const rebuilt = rebuildProfile();
    eq(rebuilt.displayName, 'Alex');
    eq(rebuilt.goals, 'Weekly consistency');
    cleanupAnalytics();
  });

  // ── computeDifficultyLevel: boundary cases ────────────────────────────────
  t('computeDifficultyLevel caps at 5 for very high streak + attention', () => {
    const profile = { ...defaultProfile(),
      sessionCount: 100, streak: 100,
      avgAttentionStability: 1.0, intensityTrend: 'rising',
    };
    ok(computeDifficultyLevel(profile) <= 5, 'level should never exceed 5');
  });

  t('computeDifficultyLevel returns 1 for single session (not enough data)', () => {
    const profile = { ...defaultProfile(), sessionCount: 1 };
    eq(computeDifficultyLevel(profile), 1);
  });

  t('computeDifficultyLevel adds streak bonus at 7 days', () => {
    const base = { ...defaultProfile(), sessionCount: 5, streak: 6 };
    const with7 = { ...defaultProfile(), sessionCount: 5, streak: 7 };
    ok(computeDifficultyLevel(with7) > computeDifficultyLevel(base),
      '7-day streak should increase level');
  });

  t('computeDifficultyLevel adds streak bonus at 30 days', () => {
    const with7  = { ...defaultProfile(), sessionCount: 10, streak: 7 };
    const with30 = { ...defaultProfile(), sessionCount: 10, streak: 30 };
    ok(computeDifficultyLevel(with30) > computeDifficultyLevel(with7),
      '30-day streak should add additional level');
  });

  // ── getStreakMilestone: exact matches only ────────────────────────────────
  t('getStreakMilestone returns null for streak=0', () => {
    ok(getStreakMilestone(0) === null);
  });

  t('getStreakMilestone returns null for non-milestone day', () => {
    ok(getStreakMilestone(5) === null);
    ok(getStreakMilestone(8) === null);
  });

  t('getStreakMilestone returns message for exactly 3 days', () => {
    const m = getStreakMilestone(3);
    ok(m !== null);
    ok(typeof m.message === 'string' && m.message.length > 0);
  });

  t('getStreakMilestone returns message for exactly 100 days', () => {
    ok(getStreakMilestone(100) !== null);
  });

  // ── getRuntimeMilestone: window-based ────────────────────────────────────
  t('getRuntimeMilestone returns null before first hour', () => {
    ok(getRuntimeMilestone(3599) === null);
  });

  t('getRuntimeMilestone returns message within first hour window', () => {
    const m = getRuntimeMilestone(3600);
    ok(m !== null, 'should trigger at exactly 1 hour');
  });

  t('getRuntimeMilestone returns null between milestones', () => {
    // Between 1hr and 10hr — no milestone
    ok(getRuntimeMilestone(7200) === null);
  });

  // ── getSessionCountMilestone ──────────────────────────────────────────────
  t('getSessionCountMilestone returns null for count=0', () => {
    ok(getSessionCountMilestone(0) === null);
  });

  t('getSessionCountMilestone returns message for exactly 1', () => {
    ok(getSessionCountMilestone(1) !== null);
  });

  t('getSessionCountMilestone returns null for non-milestone count', () => {
    ok(getSessionCountMilestone(2) === null);
    ok(getSessionCountMilestone(7) === null);
  });


  // ── defaultProfile: new achievement/XP fields ─────────────────────────────
  t('defaultProfile has xp field starting at 0', () => {
    eq(defaultProfile().xp, 0);
  });

  t('defaultProfile has achievements as empty array', () => {
    const p = defaultProfile();
    ok(Array.isArray(p.achievements) && p.achievements.length === 0);
  });

  t('defaultProfile has modesUsed as empty array', () => {
    const p = defaultProfile();
    ok(Array.isArray(p.modesUsed) && p.modesUsed.length === 0);
  });

  t('defaultProfile has highAttentionSessions starting at 0', () => {
    eq(defaultProfile().highAttentionSessions, 0);
  });

  t('defaultProfile has quests as empty array', () => {
    ok(Array.isArray(defaultProfile().quests));
  });

  t('defaultProfile questDate is null', () => {
    ok(defaultProfile().questDate === null);
  });


  // ── defaultProfile: packsLoaded ───────────────────────────────────────────
  t('defaultProfile has packsLoaded as empty array', () => {
    const p = defaultProfile();
    ok(Array.isArray(p.packsLoaded) && p.packsLoaded.length === 0);
  });


  // ── defaultProfile: new precision-tracking fields ─────────────────────────
  t('defaultProfile has perfectSessions starting at 0', () => {
    eq(defaultProfile().perfectSessions, 0);
  });

  t('defaultProfile has focusStreakCount starting at 0', () => {
    eq(defaultProfile().focusStreakCount, 0);
  });


  return R.summary();
}
