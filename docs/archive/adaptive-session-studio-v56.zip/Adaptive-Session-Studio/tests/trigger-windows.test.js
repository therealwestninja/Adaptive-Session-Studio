// ── tests/trigger-windows.test.js ────────────────────────────────────────
// Tests for normalizeTrigger and trigger window CRUD in trigger-windows.js

import { makeRunner } from './harness.js';
import { normalizeTrigger, addTrigger, deleteTrigger, updateTrigger, toggleTrigger,
         clearWindowState } from '../js/trigger-windows.js';
import { state } from '../js/state.js';

export function runTriggerWindowTests() {
  const R  = makeRunner('trigger-windows.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // ── normalizeTrigger ──────────────────────────────────────────────────
  t('normalizeTrigger generates stable id', () => {
    ok(normalizeTrigger({}).id?.startsWith('b_'));
  });
  t('normalizeTrigger preserves existing id', () => {
    eq(normalizeTrigger({ id: 'tr-1' }).id, 'tr-1');
  });
  t('normalizeTrigger enabled defaults to true', () => {
    ok(normalizeTrigger({}).enabled === true);
  });
  t('normalizeTrigger enabled:false preserved', () => {
    ok(normalizeTrigger({ enabled: false }).enabled === false);
  });
  t('normalizeTrigger defaults atSec to 0', () => {
    eq(normalizeTrigger({}).atSec, 0);
  });
  t('normalizeTrigger clamps atSec to min 0', () => {
    eq(normalizeTrigger({ atSec: -10 }).atSec, 0);
  });
  t('normalizeTrigger defaults windowDurSec to 5', () => {
    eq(normalizeTrigger({}).windowDurSec, 5);
  });
  t('normalizeTrigger clamps windowDurSec to min 1', () => {
    eq(normalizeTrigger({ windowDurSec: 0 }).windowDurSec, 1);
  });
  t('normalizeTrigger defaults condition.metric to attention', () => {
    eq(normalizeTrigger({}).condition.metric, 'attention');
  });
  t('normalizeTrigger accepts all valid metrics', () => {
    const metrics = ['attention','intensity','speed','engagement','sessionTime','loopCount'];
    for (const m of metrics) {
      eq(normalizeTrigger({ condition: { metric: m } }).condition.metric, m);
    }
  });
  t('normalizeTrigger rejects invalid metric', () => {
    eq(normalizeTrigger({ condition: { metric: 'heartRate' } }).condition.metric, 'attention');
  });
  t('normalizeTrigger defaults condition.op to >=', () => {
    eq(normalizeTrigger({}).condition.op, '>=');
  });
  t('normalizeTrigger defaults condition.value to 0.7', () => {
    eq(normalizeTrigger({}).condition.value, 0.7);
  });
  t('normalizeTrigger defaults successAction.type to none', () => {
    eq(normalizeTrigger({}).successAction.type, 'none');
  });
  t('normalizeTrigger defaults failureAction.type to none', () => {
    eq(normalizeTrigger({}).failureAction.type, 'none');
  });
  t('normalizeTrigger accepts valid action types', () => {
    const types = ['none','pause','resume','stop','injectMacro','setIntensity','setSpeed','nextScene','gotoScene'];
    for (const type of types) {
      eq(normalizeTrigger({ successAction: { type } }).successAction.type, type);
    }
  });
  t('normalizeTrigger preserves string param for gotoScene', () => {
    const tr = normalizeTrigger({ successAction: { type: 'gotoScene', param: 'b_xyz' } });
    eq(tr.successAction.type, 'gotoScene');
    eq(tr.successAction.param, 'b_xyz', 'scene ID string must survive normalization');
  });
  t('normalizeTrigger rejects invalid action type → none', () => {
    eq(normalizeTrigger({ successAction: { type: 'explode' } }).successAction.type, 'none');
  });
  t('normalizeTrigger defaults cooldownSec to 60', () => {
    eq(normalizeTrigger({}).cooldownSec, 60);
  });
  t('normalizeTrigger clamps cooldownSec to min 0', () => {
    eq(normalizeTrigger({ cooldownSec: -5 }).cooldownSec, 0);
  });

  // ── CRUD ──────────────────────────────────────────────────────────────
  function resetTriggers() {
    state.session = { ...state.session, triggers: [] };
    clearWindowState();
  }

  t('addTrigger appends normalized trigger', () => {
    resetTriggers();
    addTrigger({ name: 'Test', atSec: 30 });
    eq(state.session.triggers.length, 1);
    ok(state.session.triggers[0].id?.startsWith('b_'));
    eq(state.session.triggers[0].atSec, 30);
  });
  t('deleteTrigger removes by id', () => {
    resetTriggers();
    addTrigger({ name: 'A' });
    addTrigger({ name: 'B' });
    const idToDel = state.session.triggers[0].id;
    deleteTrigger(idToDel);
    eq(state.session.triggers.length, 1);
    eq(state.session.triggers[0].name, 'B');
  });
  t('deleteTrigger no-op on unknown id', () => {
    resetTriggers();
    addTrigger({ name: 'A' });
    deleteTrigger('nonexistent');
    eq(state.session.triggers.length, 1);
  });
  t('updateTrigger patches name', () => {
    resetTriggers();
    addTrigger({ name: 'Original' });
    const id = state.session.triggers[0].id;
    updateTrigger(id, { name: 'Updated' });
    eq(state.session.triggers[0].name, 'Updated');
  });
  t('updateTrigger patches condition.value', () => {
    resetTriggers();
    addTrigger({ condition: { value: 0.5 } });
    const id = state.session.triggers[0].id;
    updateTrigger(id, { condition: { value: 0.9 } });
    eq(state.session.triggers[0].condition.value, 0.9);
  });
  t('updateTrigger patches successAction type', () => {
    resetTriggers();
    addTrigger({});
    const id = state.session.triggers[0].id;
    updateTrigger(id, { successAction: { type: 'pause' } });
    eq(state.session.triggers[0].successAction.type, 'pause');
  });
  t('toggleTrigger flips enabled', () => {
    resetTriggers();
    addTrigger({ enabled: true });
    const id = state.session.triggers[0].id;
    toggleTrigger(id);
    ok(state.session.triggers[0].enabled === false);
    toggleTrigger(id);
    ok(state.session.triggers[0].enabled === true);
  });

  // ── setVar action support ─────────────────────────────────────────────────
  t('normalizeTrigger accepts setVar as successAction type', () => {
    const tr = normalizeTrigger({ successAction: { type: 'setVar', param: 'score=10' } });
    eq(tr.successAction.type,  'setVar');
    eq(tr.successAction.param, 'score=10');
  });

  t('normalizeTrigger accepts setVar as failureAction type', () => {
    const tr = normalizeTrigger({ failureAction: { type: 'setVar', param: 'level=0' } });
    eq(tr.failureAction.type,  'setVar');
    eq(tr.failureAction.param, 'level=0');
  });

  t('normalizeTrigger preserves string param for setVar through round-trip', () => {
    const tr = normalizeTrigger(normalizeTrigger({ successAction: { type: 'setVar', param: 'x=hello world' } }));
    eq(tr.successAction.param, 'x=hello world');
  });

  // ── normalizeTrigger completeness ─────────────────────────────────────────
  t('normalizeTrigger defaults atSec to 0', () => {
    const t = normalizeTrigger({});
    ok(typeof t.atSec === 'number' && t.atSec >= 0);
  });

  t('normalizeTrigger defaults windowDurSec to a positive number', () => {
    const t = normalizeTrigger({});
    ok(typeof t.windowDurSec === 'number' && t.windowDurSec > 0);
  });

  t('normalizeTrigger defaults cooldownSec to a non-negative number', () => {
    const t = normalizeTrigger({});
    ok(typeof t.cooldownSec === 'number' && t.cooldownSec >= 0);
  });

  t('normalizeTrigger preserves atSec value', () => {
    const t = normalizeTrigger({ atSec: 30 });
    eq(t.atSec, 30);
  });

  t('normalizeTrigger preserves enabled:false', () => {
    const t = normalizeTrigger({ enabled: false });
    ok(t.enabled === false);
  });

  t('normalizeTrigger successAction defaults to none type', () => {
    const t = normalizeTrigger({});
    eq(t.successAction.type, 'none');
  });

  t('normalizeTrigger failureAction defaults to none type', () => {
    const t = normalizeTrigger({});
    eq(t.failureAction.type, 'none');
  });

  t('normalizeTrigger accepts gotoScene as successAction type', () => {
    const t = normalizeTrigger({ successAction: { type: 'gotoScene', param: 'scene-123' } });
    eq(t.successAction.type, 'gotoScene');
    eq(t.successAction.param, 'scene-123');
  });

  t('normalizeTrigger rejects unknown successAction type → none', () => {
    const t = normalizeTrigger({ successAction: { type: 'doMagic', param: null } });
    eq(t.successAction.type, 'none');
  });

  // ── updateTrigger advanced patches ────────────────────────────────────────
  t('updateTrigger patches atSec', () => {
    resetState();
    addTrigger();
    const id = state.session.triggers[0].id;
    updateTrigger(id, { atSec: 45 });
    eq(state.session.triggers[0].atSec, 45);
  });

  t('updateTrigger patches cooldownSec', () => {
    resetState();
    addTrigger();
    const id = state.session.triggers[0].id;
    updateTrigger(id, { cooldownSec: 90 });
    eq(state.session.triggers[0].cooldownSec, 90);
  });

  t('updateTrigger does not affect other triggers', () => {
    resetState();
    addTrigger(); addTrigger();
    const ids = state.session.triggers.map(t => t.id);
    updateTrigger(ids[0], { name: 'Changed' });
    eq(state.session.triggers[1].name, state.session.triggers[1].name,
      'second trigger name should be unchanged');
    ok(state.session.triggers[0].name === 'Changed');
  });


  // ── updateTrigger: id immutability ────────────────────────────────────────
  t('updateTrigger cannot overwrite trigger id', () => {
    const trig = addTrigger({ name: 'T1', atSec: 30 });
    const origId = trig.id;
    updateTrigger(origId, { id: 'stolen', name: 'patched' });
    const found = state.session.triggers.find(t => t.id === origId);
    ok(found !== undefined, 'trigger still findable by original id');
    eq(found.name, 'patched');
  });


  return R.summary();
}
