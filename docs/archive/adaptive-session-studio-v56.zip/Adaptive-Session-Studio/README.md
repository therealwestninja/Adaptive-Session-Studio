## Adaptive Session Studio

![Logo](docs/img/button-github-banner-2.png)

A fully local, browser-native environment for designing and running immersive adaptive adult sessions — combining media playback, haptic scripting, behavioral automation, and real-time adaptive control.

Built for experienced users who want increased flexibility, and control without relying on paid apps, setting up accounts, remembering passwords, or dealing with cloud services for a night of fun. Adaptive Session Studio brings together full audio/video media playback, scripting, automation, and real-time interactions into a single, self-contained and *easy to use* toolkit.

📣 **Discord**: [discord.gg/G6qD35nag7](https://discord.gg/G6qD35nag7)

---

## What Is Adaptive Session Studio?

Adaptive Session Studio is a desktop-first creative platform that runs entirely in your browser while operating locally on your machine. There are no accounts, no external dependencies beyond initial setup, and no ongoing internet requirement. Your private play sessions, media, and data stays entirely on your device and under your control. 

At its core, the Studio is designed to let you author structured, time-based, consensual, advanced Adult play sessions that combine:

- Text overlays and timed prompts displayed on-screen during playback  
- Text-to-speech narration synthesized from your scripts  
- Background audio and video layers with playlist and crossfade control  
- Subtitle scripting via `.ass` / `.ssa` files  
- FunScript haptic control — time-coded position scripts played to devices via Intiface Central  
- Behavioral scripting — rules that react to attention, intensity, and engagement metrics  
- AI-assisted authoring — generate session content from a text prompt  

All of this is orchestrated through an intuitive session timeline, giving you granular control over depth (on supported devices), speed, pacing, transitions, and interactivity.

## Possible Use Cases

 * Play alone or with a romantic partner
 * Remote play (coming soon!)
 * Guided audio-visual experiences
 * Personal training or improvement
 * Structured or guided discipline
 * Hypnosis and hypnotic induction
 * Behavioral conditioning with attention-driven reward/correction
 * Partner training sessions with live operator controls
 * Consensual surrender experiences with adaptive escalation

---

## A Fully Integrated Creative Workflow

Adaptive Session Studio isn’t just a player, it’s a complete authoring environment.

You can build sessions from the ground up using timed blocks, layering narration, visuals, and effects in a way that feels closer to video editing than traditional scripting. Background media can loop or sequence dynamically, while overlays and subtitles allow for precise visual communication.

For more advanced creators, the platform includes:

* **Macro Library & Injection Engine**
  Create reusable behavioral or motion patterns and inject them live into a running session with smooth blending. One could even call it *Adaptive*, no?

* **Multi-track FunScript Support**
  Design and edit haptic timelines with an interactive canvas editor, enabling complex, synchronized motion sequences.

* **Subtitle Styling with `.ass`**
  Import and override styles, language, positioning, and formatting for highly customized visual presentations.

---

## Real-Time Interaction & Adaptation

Where Adaptive Session Studio truly stands out is in its ability to adapt in real time.

With built-in webcam-based attention tracking, sessions can respond dynamically to user engagement: pausing playback, halting motion, or triggering macros automatically based on attention state. 

Combined with live macro injection, this creates a feedback loop where sessions are no longer static timelines, but responsive experience events.

---

## Designed for Local-First Privacy and Reliability

Everything in Adaptive Session Studio runs locally:

* No cloud processing
* No data collection
* No external dependencies during playback

This makes it ideal for users and their partners who prioritize personal safety, privacy, reliability, and offline capability. Once installed, the entire system operates independently on your Windows machine via a standard Chromium-based browser environment. 

---

## Safety as a Core Principle

Because Adaptive Session Studio can integrate with external devices and continuous playback systems, safety is treated as a first-class concern.

Key safeguards include:

* Immediate emergency stop via **double ESC**
* Clear operational warnings and best practices
* Strong emphasis on active supervision and responsible use
* Ongoing development of safe practices and processes 

These measures ensure that creators and users can explore advanced functionality without compromising safety. 

---

## Key Features at a Glance

* Local-only execution (no internet required after setup)
* Timeline-based session designer
* Layered audio, video, and image playback
* `.ass` subtitle support with styling overrides
* Multi-track FunScript playback and editing
* Real-time macro injection system
* Device integration via Buttplug.io / Intiface Central
* Webcam-based attention tracking
* Custom themes and UI personalization
* Import/export via self-contained `.assp` packages 

---

## Getting Started

Getting up and running. Straightforward and under 5 minutes:

1. Install prerequisites
 * [Apache Server 2.4](https://httpd.apache.org/download.cgi) or later
 * (Optional) [Python 3.1](https://www.python.org/downloads/windows/) or later
2. If you followed Apache Server instructions exactly,  Unzip this GitHub package and drop it into your server folder (Default: C:\Apache24\htdocs). Replace the existing index.html in 'htdocs' with the contents of this project.
3. Start the Apache Server
 * (Win+R), Type "cmd" and press enter.
 * Ctrl+C to copy, then right-click to paste into the command window:
  * cd C:\Apache24\bin
  * httpd -k start
4. Load https://localhost:80 in any modern version of Chrome, Edge, Safari, and Firefox.
5. Open a sample session or start building right away, and safely explore alone or with a trusted partner

### IMPORTANT NOTES: 
* *When you're done playing, SHUT DOWN the server*
  * (Win+R), Type "cmd" and press enter.
  * Ctrl+C to copy, then right-click to paste into the command window:
    * cd C:\Apache24\bin
    * httpd -k stop
* As part of this Getting Started guide, Apache Server was not installed as a service and will need to be started manually (start at step 3) and stopped (steps above) each time. 

Full install instructions → [docs/guides/01-quick-start.md](docs/guides/01-quick-start.md)

---

## Documentation

| Document | Description |
|---|---|
| [docs/INSTALL.md](docs/INSTALL.md) | System requirements and setup |
| [docs/SAFETY.md](docs/SAFETY.md) | Safety guidelines and emergency procedures |
| [docs/guides/01-quick-start.md](docs/guides/01-quick-start.md) | Getting up and running in minutes |
| [docs/guides/02-building-sessions.md](docs/guides/02-building-sessions.md) | Creating and editing sessions |
| [docs/guides/03-funscript-and-devices.md](docs/guides/03-funscript-and-devices.md) | FunScript playback and device integration |
| [docs/guides/04-subtitles.md](docs/guides/04-subtitles.md) | Working with .ass subtitle files |
| [docs/guides/05-macro-library.md](docs/guides/05-macro-library.md) | The macro library and live injection |
| [docs/guides/06-webcam-tracking.md](docs/guides/06-webcam-tracking.md) | Attention tracking and automation |
| [docs/guides/07-import-export.md](docs/guides/07-import-export.md) | Sharing and distributing sessions |
| [docs/guides/08-themes-and-settings.md](docs/guides/08-themes-and-settings.md) | Appearance, themes, and all settings |
| [docs/FAQ.md](docs/FAQ.md) | Frequently asked questions |
| [docs/CHANGELOG.md](docs/CHANGELOG.md) | Version history |
| [docs/CONTRIBUTING.md](docs/CONTRIBUTING.md) | How to contribute |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Codebase structure for developers |
| [docs/DEVELOPER.md](docs/DEVELOPER.md) | Developer and maintainer notes |
| [docs/LEGAL.md](docs/LEGAL.md) | License, disclaimers, third-party credits |

---

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Space` | Play / Pause |
| `Enter` | Stop |
| `E` | Toggle FunScript edit mode |
| `N` | Next scene |
| `← →` | Skip ±10 seconds |
| `↑ ↓` | Skip ±30 seconds |
| `F` | Toggle fullscreen |
| `Shift` | Toggle FunScript pause |
| `1–5` | Inject macro slot |
| `[ / ]` | Intensity −10% / +10% |
| `, / .` | Speed −0.1× / +0.1× |
| `R` | Reset live controls to default |
| `Ctrl+0` | Reset timeline zoom |
| `Scroll` | Zoom timeline |
| `ESC×2` | Emergency stop |
| `?` | Shortcut overlay |
| `Ctrl+Z / Y` | Undo / Redo |
| `Ctrl+S` | Export session package |

---

## Session File Format

Sessions save as `.assp` files (JSON). The session object contains:

- `blocks[]` — timed overlay, audio, video, TTS, pause, macro blocks
- `scenes[]` — named time ranges within the session
- `rules[]` — behavioral scripting rules (condition → action)
- `triggers[]` — time-window interaction checks with success/failure branches
- `funscriptTracks[]`, `audioTracks[]`, `videoTracks[]`, `subtitleTracks[]`
- `rampSettings`, `pacingSettings`, `safetySettings`
- `macroLibrary`, `macroSlots`
- `variables{}` — named runtime variables (`number`, `string`, `boolean`) with `{{varName}}` template support
- `scenes[].stateType` — optional state block type (`calm`/`build`/`peak`/`recovery`) per scene

---

## Module Architecture

38 ES modules 

| Module | Role |
|--------|------|
| `main.js` | Bootstrap, DOM event wiring, keyboard handler |
| `state.js` | Session state, normalizers, localStorage persistence |
| `playback.js` | RAF loop, block execution, emergency stop |
| `ui.js` | Sidebar, inspector tabs, settings form rendering |
| `funscript.js` | Multi-lane timeline canvas — overview + FS curve |
| `audio-engine.js` | Web Audio API, playlist, crossfade |
| `state-engine.js` | Real-time metric fusion (attention × device × intensity) |
| `rules-engine.js` | Behavioral scripting with conditioning presets |
| `trigger-windows.js` | Timed interaction windows with success/fail branches |
| `safety.js` | Hard intensity/speed limits, emergency cooldown |
| `intensity-ramp.js` | Configurable intensity ramp curves |
| `dynamic-pacing.js` | Engagement-driven speed modulation |
| `session-modes.js` | Preset session configurations (Exposure, Mindfulness, Focus) |
| `ai-authoring.js` | LLM-assisted session generation via Anthropic API |
| `live-control.js` | Real-time sliders with safety clamps |
| `macros.js` | FunScript macro library, key slots, injection |
| `macro-ui.js` | Macro library and inline editor rendering |
| `scenes.js` | Scene CRUD, timeline markers, skip navigation |
| `tracking.js` | Webcam FaceDetector, attention scoring, decay |
| `session-analytics.js` | Post-session data accumulation and display |
| `user-profile.js` | Adaptive difficulty, streak tracking, milestones |
| `suggestions.js` | Real-time session health suggestions |
| `subtitle.js` | ASS/SSA parsing and rendering |
| `notify.js` | Toast notification system with confirm dialogs |
| `history.js` | Undo/redo with snapshot model |
| `capabilities.js` | Browser feature detection and capability gates |
| `block-ops.js` | Block duplicate/delete operations |
| `fullscreen-hud.js` | Fullscreen overlay HUD rendering |
| `idb-storage.js` | Async IndexedDB wrapper with localStorage migration |
| `plugin-host.js` | Plugin manifest validation, capabilities, sandbox lifecycle |
| `content-packs.js` | Pre-built session templates (induction, conditioning, partner, surrender, grounding) |
| `import-validate.js` | Session file validation and size/structure guards |
| `metrics-history.js` | Daily metrics IDB storage, SVG activity chart, CSV/JSON import |
| `state-blocks.js` | State Block profiles (calm/build/peak/recovery) for scene-level overrides |
| `variables.js` | User-defined session variables, template resolution, CRUD panel |
| `sensor-bridge.js` | WebSocket bridge for biometric/sensor data into engagement engine |
| `funscript-patterns.js` | 10 pre-generated movement patterns + BPM-synced FunScript generator |
| `viz-blocks.js` | Canvas hypnotic visualizations (spiral, pendulum, tunnel, pulse, vortex) |

---

## Feature Status

Feature highlights (Phases 1–5 complete):

| Feature | Module |
|---------|--------|
| Behavioral Scripting | `rules-engine.js` |
| State Engine + Multi-Signal Fusion | `state-engine.js` |
| Macro Trigger System | `macros.js`, `macro-ui.js` |
| Timing Interaction Layer | `trigger-windows.js` |
| Webcam Attention Tracking | `tracking.js` |
| Adaptive Pausing | via `rules-engine.js` |
| Dynamic Pacing | `dynamic-pacing.js` |
| Intensity Ramp Curves | `intensity-ramp.js` |
| Safety Layer | `safety.js` |
| Behavioral Conditioning Presets | `rules-engine.js` |
| Adaptive Difficulty + User Profile | `user-profile.js` |
| Session Modes | `session-modes.js` |
| Biofeedback Plugin API | `setExternalSignal()` in state-engine |
| AI-Assisted Session Authoring | `ai-authoring.js` |
| Scene System | `scenes.js` |
| Post-Session Analytics | `session-analytics.js` |
| State Blocks (calm/build/peak/recovery) | `state-blocks.js` |
| User-Defined Variables + setVar | `variables.js` |
| Sensor Bridge (WebSocket biometrics) | `sensor-bridge.js` |
| Content Packs (5 session templates) | `content-packs.js` |
| FunScript Patterns (10) + BPM Generator | `funscript-patterns.js` |
| Hypnotic Visualization Blocks | `viz-blocks.js` |
| Plugin Host + Capability System | `plugin-host.js` |
| Session History + Metrics Chart | `metrics-history.js` |

---


## Building a Community Around Creation

As the platform evolves, we’re inviting creators, developers, and enthusiasts to:

* Share session designs and ideas
* Build reusable macros and templates
* Contribute to creation and development, tooling and extensions
* Help shape the future of adaptive, interactive adult media
* Join us on Discord: https://discord.gg/G6qD35nag7

---

## FAQ

Q: Can I *actually* use this for hypnosis?
>A: Only if free will doesn't exist.

Q: Can I contribute?
>A: Yes! If you can script, design, program, or an end-user (or their partner!) want to design or test .assp experience packages, or create funscripts and macros, or just help smooth out GitHub documentation, any help at all would be greatly appreciated. Don't forget you can also join our Discord community for even more interactions and sharing.

Q: Was the name and theme intentional? *A* daptive *S* ession *S* tudio. _*ASS*_? Using .ass and .assp files?
>A: Believe it or not, it wasn't intentional. But we found it funny so we kept it. 

Q: I have more questions, where is the best place to contact you?
>A: Discord, please and thanks. Or email if you want to be professional.

Q:
>A:

---

## License

Personal use only. Not for commercial redistribution.

---
![Footer](docs/img/button-github-banner.png)
---
