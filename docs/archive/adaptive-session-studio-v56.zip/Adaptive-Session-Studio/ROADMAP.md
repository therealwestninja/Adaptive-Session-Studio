# Adaptive Session Studio — Product Roadmap

---

## Implementation Status

| Phase | Status | Notes |
|-------|--------|-------|
| 1 — Foundation | ✅ Complete | Timeline engine, runtime, operator controls, HUD, onboarding, media preview |
| 2 — Branching & Co-Pilot | ✅ Complete | nextSceneId, gotoScene, override keyboard shortcuts, template vars |
| 3 — Plugin & Content Ecosystem | ✅ Foundation | Plugin host + capabilities, content packs (5 templates), FunScript patterns (10), viz blocks (in progress) |
| 4 — Profiles & Analytics | ✅ Complete | Profile panel, session history, metrics chart, milestones, post-session modal, IDB persistence |
| 5 — Advanced Adaptability | ✅ Complete | State Blocks (5.1), user-defined variables + setVar (5.2), sensor bridge WebSocket (5.3) |
| 6 — Distribution | 🔲 Planned | Marketplace, sharing system |

---

## Phase 3 — Plugin & Content Ecosystem (current focus)

### ✅ Plugin System (Foundation)
- `js/plugin-host.js` — Manifest validation, 9 capability groups (`dom.overlay`, `session.read/write`, `audio.play/capture`, `network.fetch`, `storage.local`, `input.keyboard`, `metrics.write`)
- Safe context factory, full lifecycle (mount/unmount), `dispatchPluginEvent`
- `metrics.write` capability allows plugins to inject session metrics

### ✅ Content Packs
- `js/content-packs.js` — 5 pre-built session templates across 4 categories:
  - 🌀 **Classic Induction** (300s, 4 state-typed scenes, progressive relaxation)
  - ⚙ **Conditioning Foundation** (240s, 2-loop, reward/correction rules + variables)
  - 🤝 **Partner Introduction** (180s, operator-cued TTS, `partner_name` variable)
  - 🌊 **Solo Surrender** (360s, calm→build→peak→recovery arc)
  - 🧘 **Grounding Reset** (180s, gentle come-down)
- Picker panel in Session inspector tab; "Sample" menubar button routes here

### ✅ FunScript Patterns (10 pre-generated)
- `js/funscript-patterns.js` — 60-second mathematical movement patterns:
  - *Steady*: Slow Pulse, Steady Rhythm
  - *Natural*: Wave Surge, Heartbeat (cardiac double-beat with hold + rest)
  - *Escalating*: Slow Build, Tease & Edge, Cascade, Storm
  - *Calming*: Deep Descent, Breath Sync (6s breathing cycle)
- Pattern picker inside FunScript track inspector
- `generateFromBPM()` — music-synced generation, 4 shapes (sine/square/sawtooth/bounce)

### ✅ Visualization Blocks (Complete)
- `js/viz-blocks.js` — 5 Canvas animations for induction/trance sessions:
  - 🌀 Spiral · 〰 Pendulum · ⭕ Tunnel · 💗 Pulse · 🌪 Vortex
  - `mountVizBlock(canvas, block)` / `unmountVizBlock(canvas)`
- `normalizeBlock` extended with `vizType`, `vizSpeed`, `vizColor`
- Inspector panel with pattern picker, live preview canvas, and BPM Generator
- Playback wiring: `mountVizBlock`/`unmountVizBlock` in RAF pipeline, `vizStageCanvas` in stage

### ✅ Phase 3 Complete

All planned Phase 3 items delivered:
- ✅ Viz block inspector, live preview canvas, playback wiring (`vizStageCanvas`)
- ✅ FunScript heatmap — speed-color SVG strip in sidebar and inspector (ScriptPlayer+ inspired)
- ✅ Script variant labels (Soft / Standard / Intense / Custom) on FunScript tracks
- ✅ Content packs — 6 templates including viz-enhanced Spiral Descent
- ✅ BPM Generator — music-synced FunScript creation from inspector
- ✅ 10 pre-generated movement patterns (biogroove-inspired)

---

## Phase 5 — Advanced Adaptability (Complete)

### 5.1 — State Blocks
- `js/state-blocks.js` — Four profiles as non-destructive live-control overrides:
  🌊 Calm (50% / 0.75×) · 📈 Build (80% / 1.0×) · ⚡ Peak (120% / 1.25×) · 🌱 Recovery (30% / 0.6×)
- `normalizeScene` gains `stateType` field; scene editor has State dropdown with auto-color
- Timeline canvas prefixes scene labels with emoji; `gotoScene` applies state profile

### 5.2 — User-Defined Variables
- `js/variables.js` — `state.session.variables` map with full CRUD
- `{{varName}}` resolves in text/TTS at runtime alongside built-in vars
- `setVar` action in rules and triggers; Variables panel in Session inspector
- Suggestions: `undefined_template_vars` + `setvar_missing_target` warnings
- AI generator emits variables in generated sessions

### 5.3 — Sensor Bridge
- `js/sensor-bridge.js` — WebSocket client for external biometric/sensor input
- Message formats: `{signal, value, weight}`, `{signals: [...]}`, `{variable, value}`
- Auto-reconnect with exponential backoff; stale signals auto-cleared after 5s
- UI panel in Settings → Advanced; `tickSensorBridge()` in RAF pipeline

---

## Session Modes (8 total)

| Mode | Icon | Purpose |
|------|------|---------|
| Exposure Therapy | 📈 | Gradual escalation with attention-aware pausing |
| Mindfulness / Focus | 🧘 | Low-intensity, engagement-rewarding |
| Deep Focus | 🎯 | Adaptive ramp, rewards peak engagement |
| Free Run | ▶ | No automation, full manual control |
| Guided Induction | 🌀 | Trance/hypnosis — slow pacing, redirect not pause |
| Behavioral Conditioning | ⚙ | Reward/correction loop, 3-rule adaptive system |
| Operator-Led Training | 🎛 | Partner sessions, one safety rule, manual pacing |
| Deep Surrender | 🌊 | Full escalation to 2.0×, zero automatic rules |

---

## Vision

Adaptive Session Studio is a **timeline-driven interactive session platform** for creating and running **dynamic, guided consensual adult experiences on a single device** — supporting solo play, partner training, hypnosis, behavioral conditioning, and everything between.

The system combines:
- A **deterministic timeline engine** (core)
- A **live operator control layer** (user or partner)
- Optional **assistive AI tools** (never part of runtime execution)
- **Haptic device integration** via Buttplug.io / Intiface Central
- **Biometric sensor bridge** for real-time external input

Two core operating modes:
- **Self-Guided Sessions** — user operates their own session
- **Partner-Guided Sessions** — a second person shares control on the same device

---

## Core Principles

1. **Timeline is the source of truth** — all behavior originates from the timeline
2. **Deterministic execution** — sessions are predictable, replayable, debuggable
3. **Single-device first** — no networking required; all interaction is local
4. **Non-destructive live control** — operator actions override temporarily, never rewrite
5. **Keyboard-first operation** — full control without UI navigation
6. **Extensibility-first design** — plugin system is foundational
7. **Optional intelligence** — AI enhances but never controls runtime
8. **Safety as a core concern** — emergency stop, safety layer, hard limits throughout

---

## Phase 6 — Distribution (Planned)

### Goals
- Support ecosystem growth and community sharing

### Features

#### 1. DLC / Marketplace
- Official content packs and community-created sessions
- Plugins and reusable script libraries

#### 2. Sharing System
- Easy `.assp` package import/export
- Session versioning and compatibility handling

---

## Engineering Metrics (current)

| Metric | Value |
|--------|-------|
| JS modules | 38 |
| Source lines | ~11,900 |
| Test suites | 25 |
| Tests | 1009+ |
| CSS lines | ~1,560 |

---

## Strategic Build Order

1. ✅ Timeline Engine + Runtime (Phase 1)
2. ✅ Operator Control System (Phase 1)
3. ✅ Branching + template vars (Phase 2)
4. ✅ Plugin system foundation (Phase 3)
5. ✅ Profiles & progression (Phase 4)
6. ✅ Advanced adaptability (Phase 5)
7. ✅ Viz blocks + BPM sync (Phase 3)
8. ✅ FunScript heatmap + variants (Phase 3)
9. 🔲 Marketplace/DLC (Phase 6)

---

## Risks & Mitigation

| Risk | Mitigation |
|------|-----------|
| Feature creep | Strict YAGNI adherence |
| Over-complexity | Timeline remains primary mental model |
| Control confusion | Consistent hotkeys, optional HUD, clear override feedback |
| AI overreach | AI fully optional and non-runtime |
| Plugin security | Sandboxing + permission system |
