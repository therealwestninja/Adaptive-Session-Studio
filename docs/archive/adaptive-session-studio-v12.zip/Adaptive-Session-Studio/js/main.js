// ── main.js ────────────────────────────────────────────────────────────────
// App entry point: event wiring, keyboard shortcuts, initialization.

import { state, persist, fmt, $id, uid, fileToDataUrl,
         normalizeBlock, normalizeSession, normalizeAudioTrack, normalizeVideoTrack, normalizeSubtitleTrack,
         sampleSession, defaultSession, applyCssVars, applyTheme } from './state.js';

import { startPlayback, stopPlayback, pausePlayback, resumePlayback,
         seekTo, skipBy, emergencyStop, skipToScene } from './playback.js';
import { refreshVolumes, setTrackMuted, crossfade } from './audio-engine.js';
import { parseAss, updateSubtitleCue } from './subtitle.js';
import { importFunScriptFile, initTimeline, drawTimeline,
         refreshTimelineVisibility, connectDevice, disconnectDevice,
         selectAllPoints, transformPoints,
         getCurrentPosition, updatePositionIndicator } from './funscript.js';

// ── Cross-module imports (previously missing — caused ReferenceError at runtime) ──
import { renderSidebar, updateSidebarSelection, renderInspector,
         syncSettingsForms, syncSessionFromSettings, syncTransportControls,
         renderThemeGrid, saveCustomTheme, deleteCustomTheme } from './ui.js';
import { notify }                 from './notify.js';
import { history }                from './history.js';
import { renderMacroLibrary, initMacroLibraryEvents } from './macro-ui.js';
import { initFullscreenHud }      from './fullscreen-hud.js';
import { initLiveControl }        from './live-control.js';
import { makeTrackingModule }     from './tracking.js';
import { detectCapabilities, applyCapabilityGates,
         warnMissingCapabilities, checkStorageBudget } from './capabilities.js';
import { checkAndNotify }         from './suggestions.js';
import { injectMacro, getSlotMacro, toggleFsPause } from './macros.js';
import { duplicateBlock, deleteBlock,
         registerBlockOpRenderers } from './block-ops.js';
import { skipToNextScene, renderSceneList, addScene } from './scenes.js';

// Expose for inspector button handlers
window._funscriptModule = { connectDevice, disconnectDevice }; // kept for external tooling compat

// Register renderers for block-ops (avoids circular dep: block-ops ← ui.js)
// Must be called after ui.js module initialises — deferred one microtask.
Promise.resolve().then(() => registerBlockOpRenderers(renderSidebar, renderInspector));

// ── Transport controls ───────────────────────────────────────────────────────
$id('playBtn').addEventListener('click', () => {
  if (!state.runtime)            startPlayback();
  else if (state.runtime.paused) resumePlayback();
  else                           pausePlayback();
});
$id('stopBtn').addEventListener('click', stopPlayback);
$id('skipBackBtn').addEventListener('click',  () => skipBy(-10));
$id('skipFwdBtn').addEventListener('click',   () => skipBy(10));
$id('nextSceneBtn')?.addEventListener('click', skipToNextScene);

$id('loopToggle').addEventListener('click', () => {
  const modes = ['none', 'count', 'minutes', 'forever'];
  const idx = modes.indexOf(state.session.loopMode);
  state.session.loopMode = modes[(idx === -1 ? 0 : idx + 1) % modes.length];
  syncTransportControls();
  persist();
});

const mvSlider = $id('masterVolumeSlider');
mvSlider.value = state.session.masterVolume;
mvSlider.addEventListener('input', e => {
  state.session.masterVolume = Number(e.target.value);
  if (state.runtime?.usingAudioEngine) refreshVolumes();
  else state.runtime?.backgroundAudio.forEach(a => a.volume = state.session.masterVolume * state.session.advanced.playlistAudioVolume);
  persist();
});

// Progress bar — click to seek (playing), shift+click to scrub-preview (stopped)
$id('progressBar').addEventListener('click', e => {
  const r = e.currentTarget.getBoundingClientRect();
  const pct = (e.clientX - r.left) / r.width;
  if (state.runtime) {
    seekTo(pct);
  } else if (e.shiftKey) {
    // Scrub-preview: show position in HUD and subtitle without starting playback
    const previewSec = pct * state.session.duration;
    const fill  = $id('progressFill');  if (fill)  fill.style.width  = `${pct*100}%`;
    const thumb = $id('progressThumb'); if (thumb) thumb.style.left   = `${pct*100}%`;
    const cur   = $id('tCurrent');      if (cur)   cur.textContent   = fmt(previewSec);
    const hud   = $id('stageHud');      if (hud)   hud.textContent   = `Preview ${fmt(previewSec)}`;
    // Show subtitle cue at this position
    updateSubtitleCue(previewSec);
    // Show active block name
    const ab = state.session.blocks.find(b => previewSec >= b.start && previewSec < b.start + b.duration);
    const ot = $id('overlayText');
    if (ot && ab?.type === 'text') {
      ot.textContent = ab.content;
      ot.style.opacity = '0.45';
      ot.style.fontSize = `${(ab.fontSize || 1.2) * 2.2}rem`;
    }
    // Show which FunScript position would be at this time
    updatePositionIndicator(getCurrentPosition(previewSec));
    // Draw timeline playhead at scrub position
    drawTimeline(previewSec);
  }
});

$id('fullscreenBtn').addEventListener('click', () => {
  if (!document.fullscreenElement) $id('mainStage').requestFullscreen?.();
  else document.exitFullscreen?.();
});

// ── Session actions ──────────────────────────────────────────────────────────
$id('newSessionBtn').addEventListener('click', async () => {
  const ok = await notify.confirm('Start a new session? Unsaved changes will be lost.', { confirmLabel: 'New session', danger: true });
  if (!ok) return;
  history.clear();
  state.session = defaultSession(); state.selectedBlockId = null;
  stopPlayback({ silent: true }); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms(); syncTransportControls();
  $id('tTotal').textContent = fmt(state.session.duration); persist();
});

$id('loadSampleBtn').addEventListener('click', async () => {
  const ok = await notify.confirm('Load the sample session? Unsaved changes will be lost.', { confirmLabel: 'Load sample' });
  if (!ok) return;
  history.clear();
  state.session = sampleSession(); state.selectedBlockId = state.session.blocks[0]?.id || null;
  stopPlayback({ silent: true }); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms(); syncTransportControls();
  $id('tTotal').textContent = fmt(state.session.duration); persist();
  notify.success('Sample session loaded.');
});

$id('exportPackageBtn').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(state.session, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  const filename = `${state.session.name || 'session'}.assp`;
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click(); URL.revokeObjectURL(a.href);
  notify.success(`Exported as ${filename}`);
});

$id('importPackageInput').addEventListener('change', async e => {
  const file = e.target.files?.[0]; if (!file) return;
  try {
    const text = await file.text();
    let raw;
    try { raw = JSON.parse(text); } catch (pe) { throw new Error(`Not valid JSON: ${pe.message}`); }
    history.clear();
    state.session = normalizeSession(raw);
    state.selectedBlockId = state.session.blocks[0]?.id || null;
    stopPlayback({ silent: true }); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms(); syncTransportControls(); persist();
    notify.success(`Imported "${state.session.name}" (v${raw.packageVersion ?? '?'})`);
  } catch (err) {
    notify.error(`Import failed: ${err.message}`);
  }
  e.target.value = '';
});

// ── Media file inputs ────────────────────────────────────────────────────────
$id('addAudioInput').addEventListener('change', async e => {
  const files = [...e.target.files];
  for (const f of files)
    state.session.playlists.audio.push(normalizeAudioTrack({ name: f.name, dataUrl: await fileToDataUrl(f), volume: 1, _muted: false }));
  persist(); renderSidebar();
  notify.success(`Added ${files.length} audio track${files.length > 1 ? 's' : ''}.`);
  e.target.value = '';
});

$id('addVideoInput').addEventListener('change', async e => {
  const files = [...e.target.files];
  for (const f of files)
    state.session.playlists.video.push(normalizeVideoTrack({ name: f.name, dataUrl: await fileToDataUrl(f), mediaKind: f.type.startsWith('image/') ? 'image' : 'video', mute: true, volume: 1 }));
  persist(); renderSidebar();
  notify.success(`Added ${files.length} video/image track${files.length > 1 ? 's' : ''}.`);
  e.target.value = '';
});

$id('addAssInput').addEventListener('change', async e => {
  const file = e.target.files?.[0]; if (!file) return;
  try {
    const rawText = await file.text();
    const parsed  = parseAss(rawText);
    if (!parsed.events?.length) {
      notify.warn(`"${file.name}" imported but has no cues — check the [Events] section.`);
    } else {
      notify.success(`Imported "${file.name}" — ${parsed.events.length} cues.`);
    }
    state.session.subtitleTracks.push(normalizeSubtitleTrack({ name: file.name, rawAss: rawText, styles: parsed.styles, events: parsed.events, _disabled: false }));
    persist(); renderSidebar();
  } catch (err) {
    notify.error(`Subtitle import failed for "${file.name}":\n${err.message}`);
  }
  e.target.value = '';
});

$id('addFunscriptInput').addEventListener('change', async e => {
  let imported = 0;
  for (const f of e.target.files) {
    try { await importFunScriptFile(f); imported++; }
    catch (err) { notify.error(`FunScript import failed for "${f.name}":\n${err.message}`); }
  }
  if (imported > 0) notify.success(`Imported ${imported} FunScript track${imported > 1 ? 's' : ''}.`);
  renderSidebar(); renderInspector(); drawTimeline();
  e.target.value = '';
});

// ── Block add buttons ────────────────────────────────────────────────────────
document.querySelectorAll('[data-add-block]').forEach(btn => {
  btn.addEventListener('click', () => {
    const type = btn.dataset.addBlock;
    const nextStart = state.session.blocks.length ? Math.max(...state.session.blocks.map(b => b.start + b.duration)) + 2 : 0;
    const block = normalizeBlock({ id: uid(), type, label: `New ${type}`, start: nextStart, duration: type === 'pause' ? 5 : 10 });
    state.session.blocks.push(block);
    state.selectedBlockId = block.id; state.selectedSidebarType = 'block';
    persist(); renderSidebar(); renderInspector();
  });
});

$id('sortBlocksBtn').addEventListener('click', () => {
  state.session.blocks.sort((a, b) => a.start - b.start); persist(); renderSidebar();
});

// ── Delegated events ─────────────────────────────────────────────────────────
document.addEventListener('click', e => {
  const itab = e.target.closest('.insp-tab');
  if (itab) {
    state.inspTab = itab.dataset.tab;
    document.querySelectorAll('.insp-tab').forEach(t => {
      t.classList.toggle('active', t === itab);
      t.setAttribute('aria-selected', t === itab ? 'true' : 'false');
    });
    renderInspector(); return;
  }

  const stab = e.target.closest('.settings-tab');
  if (stab) {
    state.settingsTab = stab.dataset.stab;
    document.querySelectorAll('.settings-tab').forEach(t => t.classList.toggle('active', t === stab));
    document.querySelectorAll('.settings-section').forEach(s => s.classList.toggle('active', s.dataset.section === state.settingsTab));
    if (state.settingsTab === 'macros') renderMacroLibrary();
    return;
  }

  const tc = e.target.closest('[data-theme-key]');
  if (tc) { applyTheme(tc.dataset.themeKey); syncSettingsForms(); return; }

  const muteBtn = e.target.closest('[data-mute-kind]');
  if (muteBtn) {
    const kind    = muteBtn.dataset.muteKind;
    const trackId = muteBtn.dataset.trackId;
    const idx     = Number(muteBtn.dataset.muteIdx);
    history.push();
    if (kind === 'audio') {
      const t = trackId
        ? state.session.playlists.audio.find(a => a.id === trackId)
        : state.session.playlists.audio[idx];
      if (t) {
        t._muted = !t._muted;
        // Update audio engine live so mute takes effect immediately during playback.
        // Use the crossfadeSeconds setting for a smooth ramp instead of a hard cut.
        if (state.runtime?.usingAudioEngine) {
          const fadeSec = state.session.advanced.crossfadeSeconds ?? 0.6;
          crossfade(
            t._muted ? t.id : null,   // fade out if now muted
            t._muted ? null  : t.id,  // fade in  if now unmuted
            fadeSec
          );
        } else if (state.runtime) {
          refreshVolumes();
        }
      }
    }
    if (kind === 'subtitle') {
      const t = trackId
        ? state.session.subtitleTracks.find(s => s.id === trackId)
        : state.session.subtitleTracks[idx];
      if (t) t._disabled = !t._disabled;
    }
    if (kind === 'funscript') {
      const t = trackId
        ? state.session.funscriptTracks.find(f => f.id === trackId)
        : state.session.funscriptTracks[idx];
      if (t) t._disabled = !t._disabled;
    }
    persist(); renderSidebar(); drawTimeline(); return;
  }

  const delBtn = e.target.closest('[data-del-kind]');
  if (delBtn) {
    const kind    = delBtn.dataset.delKind;
    const trackId = delBtn.dataset.trackId;
    const idx     = Number(delBtn.dataset.delIdx);
    history.push();
    if (kind === 'audio')    state.session.playlists.audio  = trackId
      ? state.session.playlists.audio.filter(t => t.id !== trackId)
      : (state.session.playlists.audio.splice(idx, 1), state.session.playlists.audio);
    if (kind === 'video')    state.session.playlists.video  = trackId
      ? state.session.playlists.video.filter(t => t.id !== trackId)
      : (state.session.playlists.video.splice(idx, 1), state.session.playlists.video);
    if (kind === 'subtitle') state.session.subtitleTracks = trackId
      ? state.session.subtitleTracks.filter(t => t.id !== trackId)
      : (state.session.subtitleTracks.splice(idx, 1), state.session.subtitleTracks);
    if (kind === 'funscript') {
      state.session.funscriptTracks = trackId
        ? state.session.funscriptTracks.filter(t => t.id !== trackId)
        : (state.session.funscriptTracks.splice(idx, 1), state.session.funscriptTracks);
      drawTimeline();
    }
    state.selectedSidebarType = null; state.selectedSidebarIdx = null; state.selectedSidebarId = null;
    persist(); renderSidebar(); renderInspector(); return;
  }

  const sbItem = e.target.closest('[data-sb-type]');
  if (sbItem && !e.target.closest('[data-mute-kind],[data-del-kind]')) {
    const type    = sbItem.dataset.sbType;
    const idx     = sbItem.dataset.sbIdx !== undefined ? Number(sbItem.dataset.sbIdx) : null;
    const bid     = sbItem.dataset.blockId;
    const trackId = sbItem.dataset.sbTrackId;
    state.selectedSidebarType = type;
    state.selectedSidebarIdx  = idx;
    state.selectedSidebarId   = trackId ?? null;
    if (type === 'block' && bid) {
      state.selectedBlockId = bid;
      state.inspTab = 'overlay';
      document.querySelectorAll('.insp-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === 'overlay'));
    }
    // Targeted class update — avoids full innerHTML rebuild just to flip .selected
    updateSidebarSelection();
    renderInspector();
    return;
  }
});

// ── Settings dialog ──────────────────────────────────────────────────────────
let _tracking = null;

function stopAndClearTracking() { _tracking?.stop(); _tracking = null; }

$id('settingsBtn').addEventListener('click', () => {
  stopAndClearTracking();
  syncSettingsForms(); renderMacroLibrary();
  $id('settingsDialog').showModal();
  _tracking = makeTrackingModule();
});
const closeSettings = () => { syncSessionFromSettings(); applyCssVars(); syncTransportControls(); $id('settingsDialog').close(); };
$id('closeSettings').addEventListener('click', closeSettings);
$id('settingsDoneBtn').addEventListener('click', closeSettings);
// Release camera on any close, including ESC-dismissed dialog
$id('settingsDialog').addEventListener('close', stopAndClearTracking);
$id('settingsDialog').addEventListener('input', e => { if (e.target.id === 's_jsonPreview') return; syncSessionFromSettings(); applyCssVars(); renderThemeGrid(); });
$id('saveCustomThemeBtn')?.addEventListener('click', saveCustomTheme);
$id('deleteCustomThemeBtn')?.addEventListener('click', deleteCustomTheme);
$id('startTrackingBtn').addEventListener('click', () => _tracking?.start());
$id('stopTrackingBtn').addEventListener('click',  () => _tracking?.stop());
$id('s_connectDevice')?.addEventListener('click', () => connectDevice($id('s_deviceWsUrl')?.value || 'ws://localhost:12345'));
$id('s_disconnectDevice')?.addEventListener('click', disconnectDevice);

// ── FunScript timeline ───────────────────────────────────────────────────────
const fsCanvas = $id('fsCanvas');
if (fsCanvas) {
  initTimeline(fsCanvas);
  new ResizeObserver(() => { fsCanvas.width = fsCanvas.offsetWidth; drawTimeline(state.runtime?.sessionTime ?? null); }).observe(fsCanvas.parentElement);
}
$id('fsEditToggle')?.addEventListener('click', () => {
  state.fsEditMode = !state.fsEditMode;
  const btn = $id('fsEditToggle'); btn.classList.toggle('active', state.fsEditMode); btn.textContent = state.fsEditMode ? '✎ Editing' : '✎ Edit';
  drawTimeline(state.runtime?.sessionTime ?? null);
  updateTransformBar();
});
$id('fsCollapseBtn')?.addEventListener('click', () => {
  const c = $id('fsCanvas'), collapsed = c.style.display === 'none';
  c.style.display = collapsed ? '' : 'none'; $id('fsCollapseBtn').textContent = collapsed ? '↑' : '↓';
});

// FunScript transform bar
function updateTransformBar() {
  const bar = $id('fsTransformBar');
  if (!bar) return;
  const show = state.fsEditMode;
  bar.style.display = show ? 'flex' : 'none';
  const count = $id('fs_selectionCount');
  if (count) count.textContent = state.selectedFsPoints.size ? `${state.selectedFsPoints.size} pts selected` : '';
}

$id('fs_applyTransform')?.addEventListener('click', () => {
  history.push();
  transformPoints({
    timeScale:  Number($id('fs_timeScale')?.value  ?? 1),
    posScale:   Number($id('fs_posScale')?.value   ?? 1),
    timeOffset: Number($id('fs_timeOffset')?.value ?? 0),
    posOffset:  Number($id('fs_posOffset')?.value  ?? 0),
  });
  updateTransformBar();
  notify.success('Transform applied.');
});
$id('fs_selectAll')?.addEventListener('click',   () => { selectAllPoints(); updateTransformBar(); });
$id('fs_clearSelect')?.addEventListener('click', () => {
  state.selectedFsPoints.clear(); state.selectedFsPoint = null;
  drawTimeline(state.runtime?.sessionTime ?? null); updateTransformBar();
});

// Update transform bar point count on canvas interaction
document.addEventListener('mouseup', () => {
  if (state.fsEditMode) updateTransformBar();
});

// ── Keyboard shortcuts (per README) ─────────────────────────────────────────
let _lastEscTime   = 0;
let _shiftAlone    = false; // true if Shift pressed without another key

document.addEventListener('keydown', e => {
  const inField = e.target.matches('input,textarea,select');
  if (inField && e.key !== 'Escape' && !e.ctrlKey) return;

  // If any non-modifier key pressed while Shift held → not standalone
  if (e.shiftKey && e.key !== 'Shift') _shiftAlone = false;

  switch (e.key) {
    case 'Shift':
      _shiftAlone = true; // may be cleared by subsequent key
      break;

    case ' ':
      e.preventDefault();
      if (!state.runtime)            startPlayback();
      else if (state.runtime.paused) resumePlayback();
      else                           pausePlayback();
      break;

    // Arrow keys: L/R = ±10s, U/D = ±30s  (per README)
    case 'ArrowLeft':  e.preventDefault(); skipBy(-10); break;
    case 'ArrowRight': e.preventDefault(); skipBy(10);  break;
    case 'ArrowUp':    e.preventDefault(); skipBy(30);  break;
    case 'ArrowDown':  e.preventDefault(); skipBy(-30); break;

    // Graceful stop + exit fullscreen
    case 'Enter':
    case 'F12':
      e.preventDefault();
      stopPlayback();
      document.exitFullscreen?.().catch(() => {});
      break;

    // ESC: single = graceful stop, double within 1.2s = emergency stop
    case 'Escape': {
      const now = Date.now();
      if (now - _lastEscTime < 1200) {
        e.preventDefault(); emergencyStop(); _lastEscTime = 0;
      } else {
        _lastEscTime = now;
        stopPlayback();
        document.exitFullscreen?.().catch(() => {});
      }
      break;
    }

    // Macro injection slots 1–5 (per README)
    case '1': case '2': case '3': case '4': case '5': {
      if (inField) break;
      _shiftAlone = false;
      const macro = getSlotMacro(Number(e.key));
      if (macro) { e.preventDefault(); injectMacro(macro.id); }
      break;
    }

    // Editor shortcuts
    case 'd': case 'D':
      if (!inField && state.selectedBlockId) duplicateBlock(); break;
    case 'n': case 'N':
      if (!inField && state.session.scenes?.length) { e.preventDefault(); skipToNextScene(); }
      break;
    case 'f': case 'F':
      if (!inField) {
        if (!document.fullscreenElement) $id('mainStage').requestFullscreen?.();
        else document.exitFullscreen?.();
      }
      break;
    case 'e': case 'E':
      if (!inField) {
        state.fsEditMode = !state.fsEditMode;
        const btn = $id('fsEditToggle');
        btn?.classList.toggle('active', state.fsEditMode);
        if (btn) btn.textContent = state.fsEditMode ? '✎ Editing' : '✎ Edit';
        drawTimeline(state.runtime?.sessionTime ?? null);
      }
      break;
    // A = select all FunScript points (edit mode only)
    case 'a': case 'A':
      if (!inField && state.fsEditMode) { e.preventDefault(); selectAllPoints(); }
      break;
    case 'Delete': case 'Backspace':
      if (!inField && state.selectedBlockId) { e.preventDefault(); deleteBlock(); }
      break;
    case 's':
      if (e.ctrlKey) { e.preventDefault(); $id('exportPackageBtn').click(); }
      break;

    // Undo / Redo
    case 'z':
      if (e.ctrlKey && !e.shiftKey) { e.preventDefault(); history.undo(); }
      break;
    case 'Z':
    case 'y':
      if (e.ctrlKey) { e.preventDefault(); history.redo(); }
      break;
    case '?':
    case '/':
      if (!inField) { e.preventDefault(); toggleShortcutsOverlay(); }
      break;
  }
});

// Shift keyup: if no other key was pressed during hold → toggle FS pause
document.addEventListener('keyup', e => {
  if (e.key === 'Shift' && _shiftAlone) {
    _shiftAlone = false;
    if (state.runtime) toggleFsPause();
  }
});

// ── Keyboard shortcuts overlay (? key) ───────────────────────────────────────
function toggleShortcutsOverlay() {
  const existing = document.getElementById('shortcutsOverlay');
  if (existing) { existing.remove(); return; }

  const overlay = document.createElement('div');
  overlay.id = 'shortcutsOverlay';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-label', 'Keyboard shortcuts');
  overlay.style.cssText = `
    position:fixed;inset:0;z-index:9998;
    background:rgba(0,0,0,0.7);backdrop-filter:blur(4px);
    display:flex;align-items:center;justify-content:center;
    font-family:Inter,system-ui,sans-serif;`;
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

  const groups = [
    { title: 'Playback', rows: [
      ['Space',       'Play / Pause session'],
      ['Shift',       'Play / Pause FunScript only'],
      ['1 – 5',       'Inject macro from slot'],
      ['← →',         'Skip ±10 seconds'],
      ['↑ ↓',         'Skip ±30 seconds'],
      ['Enter / F12', 'Graceful stop + exit fullscreen'],
      ['ESC',         'Stop + exit fullscreen'],
      ['ESC × 2',     'Emergency stop'],
    ]},
    { title: 'Editor', rows: [
      ['F',      'Toggle fullscreen'],
      ['E',      'Toggle FunScript edit mode'],
      ['N',      'Next scene (if scenes defined)'],
      ['D',      'Duplicate selected block'],
      ['Delete', 'Delete selected block'],
      ['Ctrl+Z', 'Undo'],
      ['Ctrl+Y', 'Redo'],
      ['Ctrl+S', 'Export session'],
      ['?',      'Show / hide this overlay'],
    ]},
  ];

  const card = document.createElement('div');
  card.style.cssText = `
    background:#16161c;border:0.5px solid rgba(255,255,255,0.12);
    border-radius:14px;padding:22px 24px;max-width:540px;width:92vw;
    max-height:88vh;overflow-y:auto;`;

  const heading = document.createElement('div');
  heading.style.cssText = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;';
  heading.innerHTML = `<h3 style="font-family:Syne,sans-serif;font-size:15px;font-weight:600;color:#e2e0d8;margin:0">Keyboard Shortcuts</h3>
    <button onclick="this.closest('#shortcutsOverlay').remove()" style="
      background:transparent;border:none;color:rgba(255,255,255,0.3);
      font-size:18px;cursor:pointer;line-height:1;padding:0;">✕</button>`;
  card.appendChild(heading);

  const grid = document.createElement('div');
  grid.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:0 24px;';

  for (const group of groups) {
    const col = document.createElement('div');
    const groupTitle = document.createElement('div');
    groupTitle.style.cssText = 'font-size:9.5px;font-weight:600;letter-spacing:.09em;text-transform:uppercase;color:rgba(255,255,255,0.25);margin-bottom:10px;';
    groupTitle.textContent = group.title;
    col.appendChild(groupTitle);

    for (const [key, desc] of group.rows) {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:baseline;gap:8px;margin-bottom:7px;';
      const kbd = document.createElement('kbd');
      kbd.style.cssText = 'background:#20202c;border:0.5px solid rgba(255,255,255,0.15);border-radius:4px;padding:2px 6px;font-size:10px;font-family:monospace;color:#f0a04a;white-space:nowrap;flex-shrink:0;';
      kbd.textContent = key;
      const label = document.createElement('span');
      label.style.cssText = 'font-size:11px;color:#908e86;';
      label.textContent = desc;
      row.appendChild(kbd); row.appendChild(label);
      col.appendChild(row);
    }
    grid.appendChild(col);
  }

  card.appendChild(grid);
  overlay.appendChild(card);
  document.body.appendChild(overlay);
  // Close on ESC (single press - not double)
  const handler = e => { if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', handler, true); } };
  document.addEventListener('keydown', handler, true);
}


// ── AudioContext resume (browser autoplay policy) ─────────────────────────────
// Browsers suspend AudioContext until a user gesture. This resumes it on the
// first click or keydown anywhere on the page.
let _audioCtxResumed = false;
function tryResumeAudio() {
  if (_audioCtxResumed) return;
  _audioCtxResumed = true;
  import('./audio-engine.js').then(({ resumeAudioEngine }) => resumeAudioEngine());
}
document.addEventListener('click',   tryResumeAudio, { once: true });
document.addEventListener('keydown',  tryResumeAudio, { once: true });

initMacroLibraryEvents();

// ── Live Control Panel ────────────────────────────────────────────────────────
initLiveControl();

// ── Fullscreen HUD ────────────────────────────────────────────────────────────
initFullscreenHud();

// ── Undo / Redo ───────────────────────────────────────────────────────────────
history.onchange(() => {
  renderSidebar(); renderInspector(); syncSettingsForms(); syncTransportControls(); applyCssVars();
  $id('tTotal').textContent = fmt(state.session.duration);
});
$id('undoBtn')?.addEventListener('click', () => history.undo());
$id('redoBtn')?.addEventListener('click', () => history.redo());

// ── Capabilities ───────────────────────────────────────────────────────────────
detectCapabilities();
applyCapabilityGates();
// Defer capability warnings slightly so UI is fully painted first
setTimeout(warnMissingCapabilities, 1200);

// ── Settings JSON apply / format ────────────────────────────────────────────
$id('applyJsonBtn').addEventListener('click', () => {
  const raw = $id('s_jsonPreview').value;
  try {
    history.push();
    state.session = normalizeSession(JSON.parse(raw));
    state.selectedBlockId = state.session.blocks[0]?.id || null;
    stopPlayback({ silent: true }); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms(); syncTransportControls();
    notify.success('JSON applied.');
  } catch (err) {
    history.undo(); // roll back the push
    notify.error(`Invalid JSON: ${err.message}`);
  }
});
$id('formatJsonBtn').addEventListener('click', () => {
  try { $id('s_jsonPreview').value = JSON.stringify(JSON.parse($id('s_jsonPreview').value), null, 2); }
  catch (err) { notify.error(`Invalid JSON: ${err.message}`); }
});

// ── Slider live value labels ──────────────────────────────────────────────────
const sliderLabels = [
  ['s_speechRate',         's_speechRateVal', v => v],
  ['s_playlistAudioVolume','s_pavVal',        v => v],
  ['s_playlistVideoVolume','s_pvvVal',        v => v],
  ['s_fsSpeed',            's_fsSpeedVal',    v => `${v}×`],
];
sliderLabels.forEach(([sliderId, labelId, fmt]) => {
  const slider = $id(sliderId), label = $id(labelId);
  if (!slider || !label) return;
  slider.addEventListener('input', () => {
    label.textContent = fmt(parseFloat(slider.value).toFixed(2).replace(/\.?0+$/, ''));
  });
});

// ── Storage budget check ──────────────────────────────────────────────────────
setTimeout(() => {
  const budget = checkStorageBudget();
  if (budget.warning) {
    notify.warn(`localStorage is ${budget.percentUsed}% full. Export your session to avoid auto-save failures.`, 8000);
  }
}, 2000);

// ── Suggestions on startup (deferred so UI paints first) ─────────────────────
setTimeout(() => checkAndNotify(), 3000);

// ── Safety banner dismiss ─────────────────────────────────────────────────────
$id('safetyDismiss')?.addEventListener('click', () => {
  const banner = $id('safetyBanner');
  if (banner) { banner.style.opacity = '0'; setTimeout(() => banner.remove(), 400); }
});

// ── Init ──────────────────────────────────────────────────────────────────────
applyCssVars();
renderSidebar();
renderInspector();
syncTransportControls();
drawTimeline();
