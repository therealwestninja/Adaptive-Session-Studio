// ── suggestions.js ────────────────────────────────────────────────────────
// Heuristic session analysis. Surfaces tips, warnings, and quality issues
// in the inspector Status tab and as dismissable notify toasts.
// All logic is deterministic — no AI/ML required.

import { state, fmt } from './state.js';
import { notify } from './notify.js';

// ── Suggestion types ────────────────────────────────────────────────────────
// Each suggestion: { id, severity, title, detail, action? }
// severity: 'info' | 'warn' | 'error'
// action: optional { label, fn } — button in the suggestions panel

export function analyzeSession() {
  const { session } = state;
  const suggestions = [];
  const dur = session.duration;
  const blocks = session.blocks;

  // ── No blocks at all ──────────────────────────────────────────────────────
  if (!blocks.length) {
    suggestions.push({
      id: 'no_blocks',
      severity: 'warn',
      title: 'Session has no content blocks',
      detail: 'Add text, TTS, audio, video, or pause blocks from the sidebar to give the session structure.',
    });
  }

  // ── Block issues ──────────────────────────────────────────────────────────
  const overflowing = blocks.filter(b => b.start + b.duration > dur);
  if (overflowing.length) {
    suggestions.push({
      id: 'blocks_overflow',
      severity: 'warn',
      title: `${overflowing.length} block${overflowing.length > 1 ? 's' : ''} extend past session duration`,
      detail: `"${overflowing[0].label}" ends at ${fmt(overflowing[0].start + overflowing[0].duration)} but session loops at ${fmt(dur)}. Blocks are cut off mid-display on each loop.`,
      action: { label: 'Sort & check', fn: () => {
        session.blocks.sort((a,b) => a.start - b.start);
        import('./state.js').then(({ persist }) => persist());
        import('./ui.js').then(({ renderSidebar }) => renderSidebar());
      }},
    });
  }

  const overlapping = [];
  const sorted = [...blocks].sort((a,b) => a.start - b.start);
  for (let i = 0; i < sorted.length - 1; i++) {
    if (sorted[i].type === 'text' && sorted[i+1].type === 'text') {
      if (sorted[i].start + sorted[i].duration > sorted[i+1].start) {
        overlapping.push([sorted[i], sorted[i+1]]);
      }
    }
  }
  if (overlapping.length) {
    suggestions.push({
      id: 'text_blocks_overlap',
      severity: 'info',
      title: `${overlapping.length} text block${overlapping.length > 1 ? 's overlap' : ' overlaps'} another`,
      detail: `"${overlapping[0][0].label}" and "${overlapping[0][1].label}" overlap. Only one text overlay is shown at a time — the later block takes priority.`,
    });
  }

  // ── No background content ──────────────────────────────────────────────────
  if (!session.playlists.audio.length && !session.playlists.video.length && !session.funscriptTracks.length) {
    suggestions.push({
      id: 'no_background',
      severity: 'info',
      title: 'No background media loaded',
      detail: 'Add looping audio, video, or a FunScript track from the sidebar to create a richer session.',
    });
  }

  // ── FunScript shorter than session ─────────────────────────────────────────
  for (const track of session.funscriptTracks) {
    if (track._disabled || !track.actions.length) continue;
    const trackDurMs = track.actions.at(-1)?.at ?? 0;
    if (trackDurMs < dur * 1000 * 0.9) {
      suggestions.push({
        id: `fs_short_${track.id}`,
        severity: 'warn',
        title: `FunScript "${track.name}" is shorter than session`,
        detail: `Track ends at ${fmt(trackDurMs/1000)} but session loops at ${fmt(dur)}. Output will be static (at last position) for the remaining ${fmt(dur - trackDurMs/1000)}.`,
      });
    }
  }

  // ── Long silence gaps ──────────────────────────────────────────────────────
  if (sorted.length >= 2) {
    for (let i = 0; i < sorted.length - 1; i++) {
      const gap = sorted[i+1].start - (sorted[i].start + sorted[i].duration);
      if (gap > 30) {
        suggestions.push({
          id: `gap_${i}`,
          severity: 'info',
          title: `${Math.round(gap)}s silence between "${sorted[i].label}" and "${sorted[i+1].label}"`,
          detail: `Consider adding a Pause block or audio content to fill the gap, or move blocks closer together.`,
        });
        break; // Only report the first large gap to avoid noise
      }
    }
  }

  // ── Subtitle tracks shorter than session ───────────────────────────────────
  for (const track of session.subtitleTracks) {
    if (track._disabled || !track.events?.length) continue;
    const lastCueEnd = Math.max(...track.events.map(e => e.end));
    if (lastCueEnd < dur * 0.9) {
      suggestions.push({
        id: `sub_short_${track.id ?? track.name}`,
        severity: 'info',
        title: `Subtitle track "${track.name}" ends before session loops`,
        detail: `Last cue ends at ${fmt(lastCueEnd)} but session loops at ${fmt(dur)}. The stage will be subtitle-free for ${fmt(dur - lastCueEnd)}.`,
      });
    }
  }

  // ── Session very short for loop count ─────────────────────────────────────
  if (session.loopMode === 'count' && session.loopCount > 10 && dur < 60) {
    suggestions.push({
      id: 'many_short_loops',
      severity: 'info',
      title: `${session.loopCount} loops of a ${Math.round(dur)}s session`,
      detail: `Total runtime: ~${fmt(session.loopCount * dur)}. Consider "Loop forever" mode or a longer duration instead.`,
    });
  }

  // ── TTS blocks with no voice selected ─────────────────────────────────────
  const ttsBlocks = blocks.filter(b => b.type === 'tts' && b.content);
  if (ttsBlocks.length && !window.speechSynthesis?.getVoices().length) {
    suggestions.push({
      id: 'tts_no_voices',
      severity: 'warn',
      title: 'TTS voices not loaded yet',
      detail: 'Browser voice list is still loading. TTS blocks may use a default voice. Check Settings → Playback after the page fully loads.',
    });
  }

  // ── Positive: session looks complete ──────────────────────────────────────
  if (!suggestions.length) {
    suggestions.push({
      id: 'all_good',
      severity: 'info',
      title: 'Session looks good',
      detail: 'No issues detected. Ready to play.',
    });
  }

  return suggestions;
}

// ── Render suggestions into a container element ─────────────────────────────
export function renderSuggestions(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const suggestions = analyzeSession();

  const ICONS = { info: 'ℹ', warn: '⚠', error: '✕' };
  const COLORS = {
    info:  { icon: '#5fa0dc', bg: 'rgba(95,160,220,0.08)',  border: 'rgba(95,160,220,0.2)'  },
    warn:  { icon: '#f0a04a', bg: 'rgba(240,160,74,0.08)',  border: 'rgba(240,160,74,0.25)' },
    error: { icon: '#e05050', bg: 'rgba(224,80,80,0.08)',   border: 'rgba(224,80,80,0.25)'  },
  };

  container.innerHTML = suggestions.map(s => {
    const c = COLORS[s.severity] || COLORS.info;
    const actionHtml = s.action
      ? `<button class="suggest-action" data-suggest-id="${s.id}" style="
          margin-top:5px;padding:3px 8px;font-size:10px;
          border:0.5px solid ${c.border};border-radius:4px;
          background:transparent;color:${c.icon};cursor:pointer;"
        >${s.action.label}</button>`
      : '';
    return `<div class="suggest-card" style="
      border:0.5px solid ${c.border};background:${c.bg};
      border-radius:6px;padding:8px 10px;margin-bottom:6px;">
      <div style="display:flex;align-items:flex-start;gap:7px;">
        <span style="color:${c.icon};font-size:12px;flex-shrink:0;margin-top:1px;">${ICONS[s.severity]}</span>
        <div>
          <div style="font-size:11px;font-weight:500;color:var(--text);margin-bottom:3px;">${s.title}</div>
          <div style="font-size:10.5px;color:var(--text2);line-height:1.5;">${s.detail}</div>
          ${actionHtml}
        </div>
      </div>
    </div>`;
  }).join('');

  // Bind action buttons
  container.querySelectorAll('.suggest-action').forEach(btn => {
    const id = btn.dataset.suggestId;
    const s  = suggestions.find(x => x.id === id);
    if (s?.action?.fn) btn.addEventListener('click', () => { s.action.fn(); renderSuggestions(containerId); });
  });
}

// ── Show critical suggestions as toasts on session load ────────────────────
export function checkAndNotify() {
  const suggestions = analyzeSession();
  const critical = suggestions.filter(s => s.severity === 'warn' || s.severity === 'error');
  // Show at most 2 toasts to avoid overwhelming the user
  critical.slice(0, 2).forEach(s => {
    notify.warn(`${s.title}\n${s.detail}`, 6000);
  });
}
