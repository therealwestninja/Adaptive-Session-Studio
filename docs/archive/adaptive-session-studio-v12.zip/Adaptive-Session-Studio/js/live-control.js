// ── live-control.js ────────────────────────────────────────────────────────
// Runtime performance modifiers: intensity scale, speed scale, randomness.
// These are applied every tick without restarting playback.
// They affect FunScript position output only (not session clock).
//
// State lives in state.liveControl, NOT in state.session (not persisted —
// live control is a performance tool, not a session property).

import { state, $id } from './state.js';

// ── Default live control values ────────────────────────────────────────────
export function defaultLiveControl() {
  return {
    intensityScale: 1.0,   // 0.0–2.0: scales FunScript position range
    speedScale:     1.0,   // 0.25–4.0: scales FunScript clock
    randomness:     0.0,   // 0.0–1.0: adds ±N% random variation to position
    fsPaused:       false, // mirrors state.fsPaused for the panel
  };
}

// Attach to state (non-persisted)
if (!state.liveControl) state.liveControl = defaultLiveControl();

// ── Apply modifiers to a raw position value (0–100) ────────────────────────
export function applyLiveControl(rawPos) {
  const lc = state.liveControl;
  let pos = rawPos * lc.intensityScale;
  if (lc.randomness > 0) {
    const jitter = (Math.random() * 2 - 1) * lc.randomness * 10;
    pos += jitter;
  }
  return Math.min(100, Math.max(0, pos));
}

// ── Speed scale: used by FunScript interpolation ────────────────────────────
// Returns the effective time in ms to query FunScript at, accounting for
// both the session's funscriptSettings.speed and the live speed multiplier.
export function getLiveSpeedMs(sessionTimeSec) {
  const baseSpeed  = state.session.funscriptSettings.speed || 1.0;
  const liveSpeed  = state.liveControl.speedScale;
  return sessionTimeSec * 1000 * (1 / (baseSpeed * liveSpeed));
}

// ── Render the live control panel ──────────────────────────────────────────
export function renderLiveControl() {
  const panel = $id('liveControlPanel');
  if (!panel) return;
  const lc = state.liveControl;

  panel.innerHTML = `
    <div class="lc-head">
      <span class="lc-title">Live Control</span>
      <span class="lc-hint">Active during playback</span>
    </div>

    <div class="lc-row">
      <div class="lc-label">Intensity</div>
      <div class="lc-slider-wrap">
        <input type="range" class="lc-slider" id="lc_intensity"
          min="0" max="2" step="0.05" value="${lc.intensityScale}"
          aria-label="Intensity scale" />
        <span class="lc-val" id="lc_intensityVal">${Math.round(lc.intensityScale * 100)}%</span>
      </div>
    </div>

    <div class="lc-row">
      <div class="lc-label">Speed</div>
      <div class="lc-slider-wrap">
        <input type="range" class="lc-slider" id="lc_speed"
          min="0.25" max="4" step="0.05" value="${lc.speedScale}"
          aria-label="Speed scale" />
        <span class="lc-val" id="lc_speedVal">${lc.speedScale.toFixed(2)}×</span>
      </div>
    </div>

    <div class="lc-row">
      <div class="lc-label">Variation</div>
      <div class="lc-slider-wrap">
        <input type="range" class="lc-slider" id="lc_random"
          min="0" max="1" step="0.05" value="${lc.randomness}"
          aria-label="Randomness amount" />
        <span class="lc-val" id="lc_randomVal">${Math.round(lc.randomness * 100)}%</span>
      </div>
    </div>

    <div class="lc-actions">
      <button class="lc-btn${state.fsPaused ? ' active' : ''}" id="lc_fsPause"
        title="Shift key also toggles this">
        ${state.fsPaused ? '▶ FS Resume' : '⏸ FS Pause'}
      </button>
      <button class="lc-btn lc-reset" id="lc_reset" title="Reset all to default">↺ Reset</button>
    </div>

    <div class="lc-meters">
      <div class="lc-meter-wrap" title="Current FunScript output position">
        <div class="lc-meter-label">FS Out</div>
        <div class="lc-meter-bar">
          <div class="lc-meter-fill" id="lc_meterFill"></div>
        </div>
        <span class="lc-meter-val" id="lc_meterVal">0%</span>
      </div>
    </div>`;

  // Bind slider events
  $id('lc_intensity')?.addEventListener('input', e => {
    state.liveControl.intensityScale = Number(e.target.value);
    $id('lc_intensityVal').textContent = `${Math.round(state.liveControl.intensityScale * 100)}%`;
  });
  $id('lc_speed')?.addEventListener('input', e => {
    state.liveControl.speedScale = Number(e.target.value);
    $id('lc_speedVal').textContent = `${state.liveControl.speedScale.toFixed(2)}×`;
  });
  $id('lc_random')?.addEventListener('input', e => {
    state.liveControl.randomness = Number(e.target.value);
    $id('lc_randomVal').textContent = `${Math.round(state.liveControl.randomness * 100)}%`;
  });
  $id('lc_fsPause')?.addEventListener('click', () => {
    import('./macros.js').then(({ toggleFsPause }) => {
      toggleFsPause();
      _updateFsPauseBtn(); // targeted update — don't rebuild sliders
    });
  });
  $id('lc_reset')?.addEventListener('click', () => {
    state.liveControl = defaultLiveControl();
    renderLiveControl();
  });
}

// ── Targeted FS-pause button update (no full re-render) ──────────────────────
function _updateFsPauseBtn() {
  const btn = $id('lc_fsPause');
  if (!btn) return;
  btn.classList.toggle('active', state.fsPaused);
  btn.textContent = state.fsPaused ? '▶ FS Resume' : '⏸ FS Pause';
}

// ── Update the FS output meter in the live control panel ────────────────────
export function updateLiveMeter(pos) {
  const fill = $id('lc_meterFill');
  const val  = $id('lc_meterVal');
  if (!fill || !val) return;
  fill.style.width = `${pos}%`;
  fill.style.background = pos > 70 ? '#e05050' : pos > 40 ? '#f0a04a' : '#5fa0dc';
  val.textContent = `${Math.round(pos)}%`;
}

// ── Init (called once from main.js) ────────────────────────────────────────
export function initLiveControl() {
  renderLiveControl();
}

// ── Sync FS-pause button state (called when Shift-key toggles fsPaused) ─────
export function updateLiveControlFsPause() {
  _updateFsPauseBtn();
}
