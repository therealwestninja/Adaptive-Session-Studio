// ── scenes.js ───────────────────────────────────────────────────────────────
// Scene system — ROADMAP Phase 3.3.
// Scenes are named time ranges within the session with optional per-scene
// loop behavior. They appear as colored bands on the FunScript timeline and
// can be jumped to during playback via the "Next Scene" transport button.

import { state, persist, $id, uid, esc, clampInt, fmt } from './state.js';
import { normalizeScene } from './state.js';
import { notify } from './notify.js';
import { history } from './history.js';
import { skipToScene } from './playback.js';

// ── Scene CRUD ───────────────────────────────────────────────────────────────

export function addScene() {
  history.push();
  const lastEnd = state.session.scenes.length
    ? Math.max(...state.session.scenes.map(s => s.end))
    : 0;
  const start = lastEnd;
  const end   = Math.min(start + 60, state.session.duration);
  if (start >= state.session.duration) {
    notify.warn('Session is full — extend the duration before adding more scenes.');
    return;
  }
  const scene = normalizeScene({ start, end, name: `Scene ${state.session.scenes.length + 1}` });
  state.session.scenes.push(scene);
  persist();
  renderSceneList();
}

export function deleteScene(sceneId) {
  history.push();
  state.session.scenes = state.session.scenes.filter(s => s.id !== sceneId);
  persist();
  renderSceneList();
}

export function updateScene(sceneId, patch) {
  const scene = state.session.scenes.find(s => s.id === sceneId);
  if (!scene) return;
  Object.assign(scene, patch);
  persist();
}

// ── Next-scene button ────────────────────────────────────────────────────────
// Jumps to the scene after the currently-playing one.

export function skipToNextScene() {
  const { runtime, session } = state;
  if (!session.scenes?.length) return;

  const sorted = [...session.scenes].sort((a, b) => a.start - b.start);
  const t = runtime ? runtime.sessionTime : 0;

  // Find the next scene that starts after current time
  const next = sorted.find(s => s.start > t + 0.5);
  if (next) {
    skipToScene(next.id);
    notify.info(`→ ${next.name}`);
  } else {
    // Wrap around to the first scene
    const first = sorted[0];
    if (first) { skipToScene(first.id); notify.info(`↩ ${first.name}`); }
  }
}

// ── Scene list renderer (for inspector / settings panel) ─────────────────────

export function renderSceneList(containerId = 'sceneListBody') {
  const el = $id(containerId);
  if (!el) return;

  const scenes = [...state.session.scenes].sort((a, b) => a.start - b.start);
  if (!scenes.length) {
    el.innerHTML = '<div style="font-size:11px;color:var(--text3);padding:8px 0">No scenes defined. Add one to divide the session into named segments.</div>';
    return;
  }

  el.innerHTML = scenes.map(sc => `
    <div class="scene-row" data-scene-id="${sc.id}" style="
      display:flex;align-items:center;gap:6px;margin-bottom:6px;
      padding:7px 8px;border-radius:6px;
      background:rgba(255,255,255,0.03);border:0.5px solid rgba(255,255,255,0.07)">
      <div style="width:10px;height:10px;border-radius:50%;background:${sc.color};flex-shrink:0"></div>
      <input type="text" class="scene-name" data-scene-id="${sc.id}" value="${esc(sc.name)}"
        style="flex:1;font-size:11px;background:transparent;border:none;color:var(--text);min-width:0" />
      <span style="font-size:10px;color:var(--text3);white-space:nowrap">${fmt(sc.start)}–${fmt(sc.end)}</span>
      <select class="scene-loop" data-scene-id="${sc.id}" style="font-size:10px;width:50px">
        <option value="once"${sc.loopBehavior==='once'?' selected':''}>once</option>
        <option value="loop"${sc.loopBehavior==='loop'?' selected':''}>loop</option>
      </select>
      <button class="scene-del" data-scene-id="${sc.id}"
        style="background:transparent;border:none;color:var(--danger,#e05050);cursor:pointer;font-size:14px;padding:0;line-height:1"
        title="Delete scene">×</button>
    </div>`).join('');

  // Wire events
  el.querySelectorAll('.scene-name').forEach(inp => {
    inp.addEventListener('input', e => {
      updateScene(e.target.dataset.sceneId, { name: e.target.value });
    });
  });
  el.querySelectorAll('.scene-loop').forEach(sel => {
    sel.addEventListener('change', e => {
      history.push();
      updateScene(e.target.dataset.sceneId, { loopBehavior: e.target.value });
    });
  });
  el.querySelectorAll('.scene-del').forEach(btn => {
    btn.addEventListener('click', e => {
      deleteScene(e.target.dataset.sceneId);
    });
  });
}

// ── Scene inspector panel (rendered inside the overlay inspector tab) ──────────
export function renderSceneInspector() {
  return `
    <div class="insp-block-name">🎬 Scenes</div>
    <p style="font-size:11px;color:var(--text2);line-height:1.6;margin-bottom:10px">
      Divide the session into named segments. Each scene can have its own loop
      behavior. Use Next Scene (→) during playback to jump forward.
    </p>
    <div id="sceneListBody"></div>
    <div style="display:flex;gap:6px;margin-top:8px">
      <button id="addSceneBtn" style="flex:1;font-size:11px">+ Add scene</button>
    </div>
    <div style="margin-top:10px">
      <div class="insp-group-label">Scene timing</div>
      <p style="font-size:10.5px;color:var(--text3);line-height:1.5">
        Edit start/end times directly in the FunScript timeline by dragging scene markers.
        Right-click a marker to set exact times.
      </p>
    </div>`;
}

export function attachSceneInspectorEvents() {
  renderSceneList('sceneListBody');
  $id('addSceneBtn')?.addEventListener('click', addScene);
}

// ── Timeline marker rendering ────────────────────────────────────────────────
// Called by drawTimeline in funscript.js to paint scene bands on the canvas.

export function drawSceneMarkers(ctx, canvasW, canvasH, secToX) {
  const scenes = state.session.scenes;
  if (!scenes?.length) return;

  for (const sc of scenes) {
    const x1 = secToX(sc.start);
    const x2 = secToX(sc.end);
    if (x2 < 0 || x1 > canvasW) continue;

    // Semi-transparent band
    ctx.fillStyle = sc.color + '22'; // 13% opacity
    ctx.fillRect(x1, 0, x2 - x1, canvasH);

    // Top border line
    ctx.strokeStyle = sc.color + '88';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x1, 0); ctx.lineTo(x1, canvasH);
    ctx.stroke();

    // Label at top-left of band
    if (x2 - x1 > 20) {
      ctx.fillStyle = sc.color + 'cc';
      ctx.font = '9px Inter, system-ui, sans-serif';
      ctx.textBaseline = 'top';
      ctx.fillText(sc.name, x1 + 3, 2);
    }
  }
}

// ── Active-scene HUD line ────────────────────────────────────────────────────
export function getActiveSceneName() {
  const rt = state.runtime;
  if (!rt?.activeScene) return null;
  return rt.activeScene.scene.name;
}
