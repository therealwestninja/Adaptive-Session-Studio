// ── history.js ────────────────────────────────────────────────────────────
// Undo / redo stack for session edits.
//
// Design: snapshot-based with deep clone.
// Each mutating operation calls history.push() before the mutation.
// Undo restores the previous snapshot; redo re-applies.
//
// Usage:
//   import { history } from './history.js';
//   history.push();          // before any mutation
//   block.content = newVal;
//   persist();
//
//   history.undo();          // restores previous snapshot + re-renders
//   history.redo();
//   history.canUndo()        // boolean
//   history.canRedo()

import { state, persist, applyCssVars, normalizeSession } from './state.js';

const MAX_HISTORY = 60;

const _past   = [];   // array of session JSON strings (oldest first)
const _future = [];   // array of session JSON strings (most-recent-undone first)

let _onChangeCallback = null;

export const history = {
  // Register a callback that re-renders the UI after undo/redo.
  // Called with no arguments. Wire up in main.js after all modules are loaded.
  onchange(fn) { _onChangeCallback = fn; },

  // Snapshot current session BEFORE a mutation.
  push() {
    _past.push(JSON.stringify(state.session));
    if (_past.length > MAX_HISTORY) _past.shift();
    _future.length = 0;           // clear redo stack on new action
    _notifyChange();
  },

  canUndo() { return _past.length > 0; },
  canRedo()  { return _future.length > 0; },

  undo() {
    if (!_past.length) return;
    _future.push(JSON.stringify(state.session));
    const snapshot = _past.pop();
    _applySnapshot(snapshot);
  },

  redo() {
    if (!_future.length) return;
    _past.push(JSON.stringify(state.session));
    const snapshot = _future.pop();
    _applySnapshot(snapshot);
  },

  // Clear all history (on new session / import)
  clear() { _past.length = 0; _future.length = 0; _notifyChange(); },

  // Current stack depths (for status display)
  depth() { return { past: _past.length, future: _future.length }; },
};

function _applySnapshot(json) {
  state.session = normalizeSession(JSON.parse(json));
  persist();
  applyCssVars();
  _onChangeCallback?.();
  _notifyChange();
}

function _notifyChange() {
  // Update undo/redo button states in the UI
  const ub = document.getElementById('undoBtn');
  const rb = document.getElementById('redoBtn');
  if (ub) ub.disabled = !history.canUndo();
  if (rb) rb.disabled = !history.canRedo();
}
