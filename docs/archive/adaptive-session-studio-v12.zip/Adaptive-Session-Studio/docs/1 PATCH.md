# PATCH.md

Static bug-hunt notes for **Adaptive Session Studio**.

Scope: source audit of the extracted project (`index.html`, `css/`, `js/`, and docs). I did not run an interactive browser session here, so findings below are based on code-path analysis and consistency checks.

## Summary

I found several concrete runtime and logic issues, plus a few lower-risk consistency problems.

### Highest-risk issues

1. Empty sessions are silently replaced with the sample session during normalization/import.
2. Webcam tracking instances are leaked when the settings dialog is reopened or closed without stopping tracking.
3. Dragging FunScript points can start mutating the wrong point after the action list re-sorts.
4. Device connection logic appears incomplete: it handshakes but never explicitly requests/scans for devices.
5. Video blocks can orphan previously-started playlist videos, causing detached media to keep running.

---

## Findings

### 1) Empty `blocks` arrays are converted into the sample session
**Severity:** High  
**Files:** `js/state.js:134-136`, `js/main.js:111-117`

**What happens**
- `normalizeSession()` only preserves `input.blocks` when the array exists **and has length**.
- If a saved/imported session intentionally has `blocks: []`, the code falls back to `sampleSession().blocks`.

```js
blocks: Array.isArray(input?.blocks) && input.blocks.length
  ? input.blocks.map(normalizeBlock)
  : sampleSession().blocks,
```

**Impact**
- A user cannot reliably save/import a blank session.
- Any intentionally empty project rehydrates as the demo content instead of the user’s data.
- This can also corrupt persisted local state after reload.

**Suggested fix**
- Preserve empty arrays.
- Use the sample only when `blocks` is missing/invalid, not when it is present and empty.

Example fix:
```js
blocks: Array.isArray(input?.blocks)
  ? input.blocks.map(normalizeBlock)
  : sampleSession().blocks,
```

---

### 2) Tracking/webcam sessions leak across dialog reopen/close
**Severity:** High  
**Files:** `js/main.js:214-221`, `js/tracking.js:35-55`

**What happens**
- Opening Settings creates a fresh tracking module every time:

```js
_tracking = makeTrackingModule();
```

- Closing Settings only closes the dialog; it does **not** stop the tracking module or release the camera stream.
- `makeTrackingModule().start()` also has no guard against repeated starts while already active.

**Impact**
- Webcam can stay active after the settings dialog is closed.
- Reopening settings can create multiple RAF loops / streams over time.
- This is a resource leak and a privacy/UX problem.

**Suggested fix**
- Stop tracking on dialog close.
- Reuse a single tracking module instance, or guard `start()` against double-start.
- Consider wiring cleanup to dialog `close` / `cancel` events as well.

---

### 3) Timeline point dragging can switch to editing the wrong point mid-drag
**Severity:** High  
**Files:** `js/funscript.js:213-220`

**What happens**
- During drag, the code updates a point by index, then sorts the array immediately:

```js
track.actions[_dragState.pointIdx].at  = ...
track.actions[_dragState.pointIdx].pos = ...
track.actions.sort((a, b) => a.at - b.at);
```

- Once the sort changes the array order, `_dragState.pointIdx` may no longer refer to the same action object.
- The next mousemove can update a different point.

**Impact**
- Point editing becomes unstable, especially when dragging across neighboring timestamps.
- Users can accidentally corrupt FunScript tracks.

**Suggested fix**
- Track the dragged action by object reference or unique point id, not by mutable index.
- Alternatively, defer sorting until mouseup.

---

### 4) Selected FunScript point state is not track-specific
**Severity:** Medium  
**Files:** `js/state.js:148`, `js/funscript.js:193`, `js/funscript.js:313-318`

**What happens**
- Selection is stored as `selectedFsPointIdx` only.
- Rendering compares just the point index:

```js
const isSelected = state.selectedFsPointIdx === i;
```

- If two tracks both have a point at index `0`, `1`, etc., more than one point can appear selected at once.

**Impact**
- Wrong visual selection when multiple tracks are loaded.
- Confusing editor state.

**Suggested fix**
- Store `{ trackId, pointIdx }` or a stable point id.
- Match both track and point when rendering selection.

---

### 5) Device connection path likely never discovers a usable device
**Severity:** High  
**Files:** `js/funscript.js:79-91`, `js/funscript.js:111-123`

**What happens**
- On WebSocket open, the code sends `RequestServerInfo`, then waits for `DeviceAdded` to populate `_deviceIndex`.
- It never explicitly requests a device list or starts scanning.

```js
ws.send(JSON.stringify([{ RequestServerInfo: { ... } }]));
```

- Output is blocked until `_deviceIndex !== null`:

```js
if (!state.deviceSocket || state.deviceSocket.readyState !== WebSocket.OPEN || _deviceIndex === null) return;
```

**Impact**
- The UI can say “Connected” while no controllable device is ever discovered.
- Haptic output may never start even though connection succeeded.

**Suggested fix**
- After the handshake, explicitly request discovery/listing according to the intended Buttplug/Intiface message flow.
- Also surface “connected but no device selected/found” distinctly from “ready”.

---

### 6) `deviceStatus` is duplicated across views
**Severity:** Medium  
**Files:** `index.html:323`, `js/ui.js:267`

**What happens**
- The settings dialog contains a permanent `id="deviceStatus"`.
- The FunScript inspector also renders another `id="deviceStatus"` dynamically.
- `updateDeviceStatus()` uses `document.getElementById('deviceStatus')`, which will only target the first matching element.

**Impact**
- Status updates can appear in the wrong panel.
- One view may look stale even though the other updates.
- Duplicate IDs are invalid DOM and make future bugs more likely.

**Suggested fix**
- Give each status area a unique id, or update both explicitly via class selectors.

---

### 7) Video blocks can orphan prior playlist/video elements
**Severity:** High  
**Files:** `js/playback.js:83-95`, `js/playback.js:216-229`, `js/playback.js:295-297`

**What happens**
- Playback starts by creating background playlist video elements and storing them in `runtime.backgroundVideo`.
- When a `video` block becomes active, the code wipes `bgHost`, creates a new element, and **replaces** `runtime.backgroundVideo` with `[el]`.

```js
bh.innerHTML = '';
...
state.runtime.backgroundVideo = [el];
```

- The old playlist video elements are removed from the DOM, but they are not paused or cleaned up before the reference list is overwritten.

**Impact**
- Detached media can keep decoding/playing.
- Audio from a previous video may continue unexpectedly.
- `stopPlayback()` only cleans up the current `runtime.backgroundVideo` array, not orphaned elements that were dropped earlier.

**Suggested fix**
- Pause and dispose all existing background video elements before replacing them.
- Keep playlist/background layers and one-shot video blocks in separate collections if they are meant to coexist.

---

### 8) Emergency stop message is immediately overwritten by normal stop cleanup
**Severity:** Medium  
**Files:** `js/playback.js:316-337`, `js/playback.js:301`

**What happens**
- `emergencyStop()` sets the HUD to `🛑 EMERGENCY STOP`.
- It then calls `stopPlayback()`, which resets the HUD text to `Idle` immediately.

```js
const hud = $id('stageHud'); if (hud) { hud.textContent = '🛑 EMERGENCY STOP'; ... }
stopPlayback();
```

**Impact**
- The emergency indication is effectively invisible or flashes too briefly to be meaningful.
- Users lose critical feedback during the most safety-sensitive action.

**Suggested fix**
- Let `stopPlayback()` accept a mode flag, or perform cleanup without resetting the HUD until after a visible delay.

---

### 9) Loop-mode support is inconsistent across the UI
**Severity:** Medium  
**Files:** `index.html:278-282`, `js/ui.js:129-132`, `js/playback.js:41-47`, `js/main.js:61-69`

**What happens**
- Settings and the session inspector both expose `minutes` loop mode.
- Playback logic supports `minutes`.
- But the top transport loop toggle cycles only:

```js
const modes  = ['none', 'count', 'forever'];
```

**Impact**
- A user can select `minutes` in one place, but can never cycle back to it from the main control.
- UI state is inconsistent and confusing.

**Suggested fix**
- Include `minutes` in the transport toggle, or remove it from the toggleable modes entirely and reflect the current mode clearly.

---

### 10) FunScript/macro import paths lack user-facing error handling
**Severity:** Medium  
**Files:** `js/main.js:142-145`, `js/macro-ui.js:253-258`, `js/funscript.js:49-63`, `js/macros.js:174-184`

**What happens**
- Both import flows parse JSON directly.
- Invalid files will throw and can reject the async handler without a user-visible recovery path.

Examples:
```js
const parsed = parseFunScript(text);
const raw  = JSON.parse(text);
```

**Impact**
- A malformed file can fail silently or leave the UI in a confusing state.
- Users do not get a clear import error message.

**Suggested fix**
- Wrap imports in `try/catch` and show a clear validation error.
- Validate action arrays before saving them into session state.

---

## Lower-risk inconsistencies

### 11) Keyboard shortcut documentation disagrees with the implementation
**Severity:** Low  
**Files:** `index.html:327-330`, `js/main.js:267-271`, `README.md:73-80`

**What happens**
- The README and fullscreen HUD say left/right skips are ±10s.
- The settings help text says left/right are ±5 sec.
- The implementation uses ±10s.

**Impact**
- Documentation/UI mismatch.

**Suggested fix**
- Make the settings text match the actual behavior.

---

### 12) Session-name field cannot be cleared to an empty string
**Severity:** Low  
**Files:** `js/ui.js:425`

**What happens**
```js
s.name = gv('s_sessionName')?.trim() || s.name;
```
- Clearing the field falls back to the previous name.

**Impact**
- Minor UX inconsistency.

**Suggested fix**
- Assign the trimmed value directly, even if empty, or enforce a placeholder/default separately.

---

## Suggested triage order

1. Fix `normalizeSession()` empty-block handling.
2. Fix tracking lifecycle and camera cleanup.
3. Fix FunScript drag state to follow the same point object throughout the drag.
4. Fix device discovery/ready-state handling.
5. Fix background video cleanup when a video block takes over the stage.
6. Clean up duplicate `deviceStatus` ids.
7. Polish loop-mode and emergency-stop UX inconsistencies.
8. Add import validation/error handling.

