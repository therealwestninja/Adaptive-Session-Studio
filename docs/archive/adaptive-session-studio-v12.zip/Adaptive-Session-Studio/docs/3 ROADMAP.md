# ROADMAP.md

Project direction: evolving from a functional session editor into a powerful, interactive, intelligent session platform.

**Primary goals:**
1. Improve usability and workflow
2. Expand core capabilities (timeline, playback, automation)
3. Enhance immersion and live control
4. Enable extensibility and future ecosystem growth

---

## PHASE 0 — Foundation (Completed ✅)

All core editing, playback, and device features shipping in v4.1.0.

| Feature | Status |
|---------|--------|
| Session designer (blocks, playlists, themes) | ✅ Done |
| FunScript import / playback / timeline editor | ✅ Done |
| .ass subtitle import / display / export | ✅ Done |
| Macro Library + injection engine (keys 1–5) | ✅ Done |
| Device integration via Intiface Central | ✅ Done (full handshake) |
| Webcam attention tracking + FS automation | ✅ Done |
| Fullscreen HUD | ✅ Done |
| Undo / Redo | ✅ Done |
| Toast notification system | ✅ Done |
| Browser capability detection | ✅ Done |
| Safe persistence + deep import validation | ✅ Done |
| All PATCH.md bugs fixed | ✅ Done |
| Full documentation suite | ✅ Done |

---

## PHASE 1 — Usability & Editing Foundations

**Goal:** Safe, fast, expressive session authoring.

### 1.1 Playback Engine Refactor
Replace ad-hoc `new Audio()` with a unified `PlaybackEngine`:
- `AudioContext` + `GainNode` graph per track → master gain
- Crossfade between audio tracks (finally implements the exposed setting)
- Deterministic media lifecycle (`idle → loading → playing → stopping → stopped`)
- Transport clock decoupled from RAF loop

### 1.2 Multi-Select + Transform Tools
Enable batch editing of FunScript points:
- `selectedPointIds: Set<actionRef>` replaces single selection
- Canvas drag-select (rubber-band selection)
- Transform panel: scale time, scale position, offset by N ms / N%
- Keyboard: `A` selects all points in active track

### 1.3 Timeline Scrubbing
Instant testing without full playback:
- Click anywhere on timeline to preview at that position
- Audio preview on scrub (short 100ms play burst)
- FunScript position shown in meter while scrubbing
- Subtitle cue highlighted if active at scrub point

### 1.4 Undo/Redo Improvements
Current: JSON snapshot, 60 steps.
- Switch to diff-based storage for large sessions (reduces memory ~90%)
- Undo group coalescing — rapid typing in one field = one undo step
- Undo history visible as a list (Settings → Advanced)

---

## PHASE 2 — Timeline & Playback Evolution

### 2.1 Multi-Lane Timeline UI

Replace the single canvas with structured lanes:

```
─────────────────────────────────────────────
 AUDIO   ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 VIDEO   ░░░░░░░░░░░░░░░░░░░░░░░░░
 BLOCKS  [Settle][Opening]  [Words]  [Close]
 FS      ∿∿∿∿∿∿∿∿∿∿∿∿∿∿∿∿∿∿∿∿∿∿∿
 SUBS    ─────╗══════╗────────╗═══╗
─────────────────────────────────────────────
```

Implementation:
- Vertical stack of lane canvases (each reuses the existing draw functions)
- Shared time axis, shared playhead
- Lane collapse / expand toggle

### 2.2 Crossfade + Audio Graph
- Web Audio API routing for all playlist audio
- `GainNode.linearRampToValueAtTime` crossfade on track transitions
- Per-track volume envelope: fade-in at session start, fade-out before stop

### 2.3 Timeline Zoom
- Mouse wheel zoom on timeline canvas (x-axis scale)
- Overview minimap below the main timeline
- Range selection handles for zoomed view

---

## PHASE 3 — Smart Features

### 3.1 Auto-Generate FunScript from Audio
- Load audio buffer into `OfflineAudioContext`
- Detect amplitude peaks and beat onsets
- Generate position curve: peak → high position, trough → low
- UI: "Generate from audio track" button + intensity/smoothing sliders

### 3.2 Smart Suggestions Panel
Heuristic-based suggestions shown during authoring:
- Silence gap detected → suggest Pause block
- Block extends past session duration → flag it
- FunScript shorter than session → warn about early cutoff
- No background audio → suggest adding a playlist track

### 3.3 Scene System
Organise sessions into named scenes:

```js
scenes: [
  { id, name: 'Warmup',  start: 0,   end: 60,  loopBehavior: 'once' },
  { id, name: 'Build',   start: 60,  end: 180, loopBehavior: 'loop' },
  { id, name: 'Peak',    start: 180, end: 240, loopBehavior: 'once' },
  { id, name: 'Cooldown',start: 240, end: 300, loopBehavior: 'once' },
]
```

- Scene markers on timeline
- Scene-level loop settings (override session loop)
- "Next scene" button during playback

---

## PHASE 4 — Interaction & Live Control

### 4.1 Live Control Panel (Performance Mode)
Side panel visible during fullscreen with runtime modifiers:
- **Intensity** — scales FunScript range in real-time (0%–200%)
- **Speed** — scales FunScript speed without reloading
- **Randomise** — adds ±N% random variation to position values
- **Skip to scene** — jump between scenes during playback
- Large touch-friendly buttons; works on a second monitor

### 4.2 Conditional Logic Engine

Simple rule system evaluated per tick:

```js
rules: [
  { if: { attention: '<', value: 0.3 }, then: { action: 'reduceFsIntensity', param: 0.5 } },
  { if: { loopCount: '>', value: 3 },   then: { action: 'nextScene' } },
]
```

- Rules editor in Settings
- Conditions: attention, loopCount, sessionTime, blockType
- Actions: reduceFsIntensity, injectMacro, nextScene, pauseFs, pauseSession

---

## PHASE 5 — Tracking & Feedback

### 5.1 Tracking State Machine
Explicit states replacing ad-hoc booleans:
```
idle → requesting_permission → warming_up → detecting | lost | unavailable | error
```

### 5.2 Normalized Attention Output
```js
trackingState = {
  status: 'detecting' | 'lost' | 'unavailable' | ...,
  attention: 0–1,     // 0 = lost, 1 = fully detected
  confidence: 0–1,    // FaceDetector confidence score
  lossSeconds: 0,     // how long attention has been lost
}
```
Feeds into rules engine and live modifiers.

### 5.3 Session Analytics
Post-session summary stored in localStorage:
- Time spent in each block
- Attention loss events (count, duration)
- Loop count and total runtime
- Displayed in a post-session modal after stop

---

## PHASE 6 — Sharing & Ecosystem

### 6.1 ZIP-Based .assp Container
Replace JSON-with-base64 with a proper ZIP:
```
session.zip
  manifest.json
  session.json
  media/
    audio_01.mp3
    video_bg.mp4
  subtitles/
    session.ass
  funscripts/
    main.funscript
```

Uses JSZip or native CompressionStream API.
Reduces export size by ~33%. Media referenced by path, not embedded.

### 6.2 Preset Libraries
Reusable building blocks distributed as small JSON files:
- Macro packs (themed sets of macros)
- Loop packs (curated FunScript loops)
- Session templates (pre-built block structures)
- Import via drag-drop or URL

### 6.3 Remote Control Companion
Minimal second-screen web page (same-device or LAN):
- Play / Pause / Stop / Emergency Stop
- Current time and loop display
- Intensity override slider
- No auth needed for LAN use; designed for phone

---

## PHASE 7 — Immersion & UX Polish

### 7.1 Fullscreen HUD Upgrade
- Live FunScript waveform visualiser (small canvas strip)
- Attention meter (bar or circle indicator)
- Macro injection animation (ripple effect on trigger)
- Configurable HUD layout (which elements to show)

### 7.2 Accessibility
- Full keyboard navigation for sidebar and inspector
- `role`, `aria-label` throughout
- Non-canvas FunScript point editor (table view)
- High-contrast mode toggle
- Reduced-motion preference respect (already partially done via `@media prefers-reduced-motion`)

---

## Development Priority Order

1. Playback engine refactor (audio graph, crossfade)
2. Tracking state machine
3. Timeline scrubbing
4. Multi-lane timeline UI
5. Live Control Panel (performance mode)
6. Scene system
7. Auto-generate FunScript from audio
8. ZIP-based container
9. Remote control companion
10. UX / HUD polish

---

## Design Principles

- **Small, modular changes** over large rewrites
- **No frameworks** unless the problem genuinely requires one
- **Deterministic and debuggable** — avoid hidden state and side-effect-heavy patterns
- **Separation of concerns** — state / UI / playback / device remain distinct modules
- **Real-time performance** — nothing in the RAF loop that takes > 1ms
- **Safety first** — emergency stop path must always work, always be reachable
