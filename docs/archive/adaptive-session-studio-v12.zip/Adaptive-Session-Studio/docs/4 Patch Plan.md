# Adaptive Session Studio — Patch Plan

## Mission

Read `./docs/*` as the product goalposts, then patch the app so the current code matches those goals and removes the remaining dead ends, regressions, and architecture drift.

This patch set should prioritize correctness, UI/data consistency, and safe future extension over cosmetic refactors.

Do **not** do a broad rewrite. Make targeted fixes in small, reviewable commits.

---

## Ground Rules

1. Preserve existing behavior unless it is clearly broken, misleading, dead-end, or contradicts `docs/*`.
2. Prefer existing global normalization/state systems over local ad-hoc object mutation.
3. Fix user-facing inconsistencies before deeper cleanup.
4. Add small smoke tests and pure logic tests where possible.
5. Keep file/module boundaries intact unless a change is clearly beneficial and low-risk.
6. When uncertain, prefer:

   * stable IDs over array indices
   * central resync functions over one-off UI updates
   * normalized writes over raw object pushes

---

## Repo Goalposts to Honor

Use these docs as product intent:

* `docs/NEXT-STEPS.md`
* `docs/ROADMAP.md`
* `docs/PATCH.md`

Important note: some docs are stale and claim items are “done” when code is still incomplete. Treat docs as intent, not proof.

---

# Phase 1 — Fix real regressions and dead-end UI

## 1. Fix playlist track creation so new items get normalized IDs

### Problem

New audio/video playlist entries added in `js/main.js` are pushed as raw objects and do not get stable `id` fields.

### Evidence

* `js/main.js` add-audio / add-video handlers push raw objects
* `js/ui.js` mute/delete/select behavior expects `t.id`
* `js/state.js` normalization already supports track IDs

### Required change

Replace raw pushes with normalized track creation through the global normalization path.

### Implementation direction

In `js/state.js`, add dedicated normalizers if they do not already exist:

* `normalizeAudioTrack(input)`
* `normalizeVideoTrack(input)`
* optionally `normalizeSubtitleTrack(input)` and `normalizeFunscriptTrack(input)` for consistency

Each should:

* assign stable `id` via `uid()`
* fill default fields
* preserve known existing fields

Then update `js/main.js` file import handlers to push normalized objects instead of raw literals.

### Acceptance criteria

* Newly added audio tracks have stable IDs immediately
* Newly added video/image tracks have stable IDs immediately
* Sidebar mute/delete/select works on tracks added during the current session without requiring reload/import

---

## 2. Remove or complete dead-end playlist selection UI

### Problem

Audio/video playlist tracks are selectable in the sidebar, but there is no inspector UI for them.

### Decision

Complete the feature rather than hiding selection.

### Required change

Add inspector panels for:

* audio playlist track
* video/image playlist track

### Minimum fields for audio inspector

* track name
* volume
* mute toggle
* delete button
* maybe source preview text like file name only

### Minimum fields for video/image inspector

* track name
* media kind
* mute toggle
* volume if relevant
* delete button

### Files

* `js/ui.js`
* `js/main.js` if event wiring is needed
* `js/playback.js` and/or `js/audio-engine.js` for live updates if inspector edits should affect active playback

### Acceptance criteria

* Selecting an audio playlist item shows an inspector
* Selecting a video/image playlist item shows an inspector
* Inspector edits update session state and persist
* No sidebar item leads to a blank or misleading inspector state

---

## 3. Centralize transport/UI resync after any session mutation

### Problem

Top controls drift out of sync with session state after import/new session/sample load/settings edits.

Examples:

* top loop toggle text/class not updated when loop mode changes elsewhere
* master volume slider does not resync after import/reset/sample load
* settings numeric readouts can be stale when opening dialog

### Required change

Create a single resync function for top-level transport/settings UI.

### Suggested function

In `js/main.js` or `js/ui.js`, add something like:

* `syncTransportControlsFromState()`
* `syncSettingsReadoutsFromState()`

The transport sync should update at least:

* loop button text
* loop button active state
* master volume slider value
* any visible transport labels tied to state

The settings sync should update:

* slider values
* companion numeric labels/text readouts
* active tab if state stores it

### Call sites

Invoke resync after:

* import
* new session
* load sample
* undo/redo
* session inspector edits that affect transport/session globals
* settings apply/save
* any code path that mutates top-level session transport fields

### Acceptance criteria

* loop mode is visually correct everywhere after any change
* master volume slider always reflects current state
* opening Settings never shows stale slider readouts
* no need for user input to “wake up” labels

---

## 4. Make crossfade honest: implement or clearly mark unavailable

### Problem

Crossfade is exposed as a setting but is not actually integrated into the playback flow.

### Decision

Do the low-risk truthful version now:

* if full implementation is not already natural in current playback architecture, mark it as not currently active in UI
* do not fake support

### Two acceptable outcomes

#### Option A — honest UI label now

Add visible `(coming soon)` or disabled-state treatment in Settings → Playback for crossfade.

#### Option B — wire up real use

Only do this if there is a clear actual transition point in playback where outgoing/incoming playlist audio tracks change.
If the app is not yet doing playlist track transitions in a way that naturally supports crossfade, do not force a pseudo-implementation.

### Files

* `index.html`
* `js/ui.js`
* `js/audio-engine.js`
* `js/playback.js`

### Acceptance criteria

* UI no longer claims crossfade works when it does not
* no dead setting remains misleading

---

## 5. Make undo/redo coverage consistent for editor actions

### Problem

Many mutation paths call `persist()` without `history.push()`.

### Required change

Audit all user-triggered write paths and decide whether they should create undo steps.

### High-priority places to patch

* playlist mute/delete
* playlist track inspector edits
* session inspector edits
* settings changes that alter session data
* subtitle track edits
* FunScript track settings edits where state changes are user-authored

### Guidance

Use `history.push()` for meaningful user edits, but avoid noisy history spam for every keystroke if current UI uses `input` events continuously.

Prefer:

* `change` for committed controls
* debounced grouping for text input if practical
* one snapshot before a multi-field destructive operation

### Acceptance criteria

* common editor actions are undoable
* no surprising “can’t undo that” for obvious edits
* history does not explode from tiny slider moves unless existing behavior already expects that

---

# Phase 2 — Finish stable-ID migration and remove fragile index-based logic

## 6. Give stable IDs to all sidebar-managed track/item types

### Problem

Subtitle tracks still appear index-based. Some sidebar actions remain tied to array order.

### Required change

Ensure stable IDs exist for:

* audio playlist tracks
* video/image playlist tracks
* subtitle tracks
* FunScript tracks if not already stable
* optionally points/actions where editor semantics benefit from stable reference

### Files

* `js/state.js`
* `js/ui.js`
* any modules mutating or rendering these collections

### Acceptance criteria

* sidebar actions never depend on array index for identity
* reordering or sorting cannot retarget a delete/mute/select action
* DOM data attributes use IDs, not indices, for durable entities

---

## 7. Standardize mutation paths to use global systems

### Problem

Some local internal code paths directly mutate data structures instead of using normalization/global helpers.

### Required change

Audit writes in:

* `js/main.js`
* `js/ui.js`
* `js/funscript.js`
* `js/macro-ui.js`
* `js/macros.js`

Replace local ad-hoc object assembly with:

* shared normalizers
* shared helper functions
* state-aware update flows

### Specific targets

* playlist item creation
* imported tracks/cues/items
* any duplicate object schema literal repeated in more than one file

### Acceptance criteria

* schema defaults live in one place
* new entities are created consistently
* fewer raw object literals for durable state objects

---

# Phase 3 — Remove incomplete or misleading settings/UI

## 8. Settings menu audit: ensure every persistent setting is represented correctly

### Problem

Some settings are exposed but stale, incomplete, misleading, or not fully mirrored in Settings.

### Required change

Audit `state.session.advanced`, `state.funscriptSettings`, and related persisted settings against:

* Settings dialog
* inspector surfaces
* actual runtime use

### For each setting, classify as one of:

1. implemented + represented
2. implemented but missing from UI
3. exposed in UI but not implemented
4. dead/unused and should be removed
5. runtime-only and should not be user-facing

### Deliverable changes

* add missing UI for implemented settings that matter
* mark nonfunctional settings honestly
* remove dead settings from UI if unused
* remove dead persisted fields if clearly obsolete and safe to migrate

### Known candidate

* `funscriptSettings.deviceConnected` looks unused/dead

### Acceptance criteria

* settings UI reflects real supported behavior
* no obvious persisted field is orphaned without reason
* no visible setting silently does nothing

---

## 9. Fix duplicate IDs / inaccessible or ambiguous DOM targets

### Problem

This repo has a history of duplicate `id` usage and inconsistent targeting.

### Required change

Audit generated and static DOM for:

* duplicate IDs
* controls without labels
* invalid `aria-*` relationships
* small click targets that break actual usability

### High-priority examples

* any repeated `deviceStatus`-style IDs
* sidebar micro-buttons
* dynamically rendered inspector controls

### Acceptance criteria

* no duplicate DOM IDs
* critical controls are targetable and unambiguous
* keyboard/focus behavior still works after render cycles

---

# Phase 4 — Logic cleanup, bug fixes, and dead code trimming

## 10. Dead code / duplication audit

### Required change

Identify exports and state fields that are unused or misleading.

### Known likely candidates

* `audio-engine.js`

  * `setMasterVolume()` may be superseded by `refreshVolumes()`
  * `setTrackMuted()` may be unused
  * `crossfade()` currently unused unless Phase 1 implements it
* `state.js`

  * dead flags or legacy fields

### Action

For each candidate:

* remove it if truly dead
* or wire it into real use
* or leave with a comment if intentionally staged for next phase

### Acceptance criteria

* obvious dead exports are cleaned up
* duplicated logic is reduced
* comments match reality

---

## 11. Fix known UI/state logic mismatches

Patch these concretely if still present after earlier phases:

* loop mode controls behave consistently across top bar, session inspector, and settings
* Settings tab restore behavior matches `state.settingsTab`
* custom font family field can be truly cleared if that is intended
* any emergency stop/HUD or media cleanup regressions found during smoke test are addressed

Only change these after verifying the current code path.

---

# Phase 5 — Tests and smoke pass

## 12. Add pure logic tests

### Goal

Start small. Cover the code most likely to regress.

### Prefer tests for

* `state.js`

  * `normalizeSession`
  * `normalizeBlock`
  * track normalizers
* `subtitle.js`

  * `parseAss`
* `history.js`

  * push/undo/redo transitions
* `funscript.js`

  * pure helpers only, not DOM-heavy parts

### Tooling

Use a lightweight setup. Do not introduce a heavy bundler.

If the repo has no package tooling yet, acceptable options:

* minimal `vitest`
* `uvu`
* or native browser test harness if extremely light

### Acceptance criteria

* tests run locally with one command
* normalization regressions are covered
* at least one test proves empty arrays remain empty where intended

---

## 13. Add a smoke-test checklist and, if feasible, a minimal script

### Manual smoke checklist

Verify at least these flows:

1. load app with no console-breaking errors
2. new session works
3. sample session works
4. import/export package works
5. add audio track → select → mute → delete
6. add video/image track → select → mute/delete
7. open settings → values/readouts match state
8. change loop mode from:

   * top transport
   * session inspector
   * settings
     and confirm all three stay in sync
9. undo/redo works on representative edits
10. playback still starts/stops without obvious regressions

### Optional automation

If easy, add a tiny browser smoke harness for core render/startup/import interactions.

### Acceptance criteria

* smoke checklist is documented in repo
* core flows can be manually verified quickly
* no newly introduced blocker remains

---

# Suggested Execution Order

Apply in this order:

1. Add/finish normalizers for playlist and track entities
2. Patch playlist add/import flows to use normalizers
3. Build inspector UI for audio/video playlist tracks
4. Centralize UI resync helpers
5. Patch loop/master/settings drift
6. Expand undo coverage for newly touched actions
7. Finish stable-ID migration for subtitles and any remaining sidebar entities
8. Audit settings truthfulness and crossfade honesty
9. Remove duplicate IDs / DOM ambiguities
10. Trim dead code and duplication
11. Add tests
12. Run and document smoke pass

---

# File-by-File Work Map

## `js/state.js`

* add/fix normalizers for track entities
* ensure stable IDs for all durable entities
* migrate dead/default fields carefully
* keep empty arrays preserved where intended

## `js/main.js`

* replace raw playlist pushes with normalized writes
* call shared resync helpers after session mutations
* add `history.push()` to meaningful user edits where missing

## `js/ui.js`

* add inspector views for audio/video playlist tracks
* stop index-based identity in rendered controls
* sync settings readouts from state
* fix selection dead ends
* ensure tab restore/UI state consistency

## `js/playback.js`

* only touch as needed for:

  * live update support from inspector edits
  * truthful crossfade handling
  * any discovered media cleanup issue

## `js/audio-engine.js`

* either wire exported helpers into actual use or trim dead exports
* do not leave “implemented” helpers permanently unused without clear comment

## `index.html`

* update labels/disabled states for settings that are not active yet
* fix any duplicate IDs or labeling issues

## `docs/*`

After code changes, update docs so they match reality.
Especially:

* remove stale claims of “done”
* reflect what was actually fixed in this patch
* document smoke-test steps

---

# Definition of Done

This patch is done when all of the following are true:

* newly added playlist tracks work immediately in sidebar actions
* no selectable sidebar entity leads to a dead-end inspector
* transport and settings UI stay in sync with state
* no visible setting misleadingly appears implemented when it is not
* sidebar identity is ID-based, not index-based, for durable entities
* obvious dead code/unused state is reduced
* at least a small test layer exists for normalization/history
* a smoke checklist exists and passes

---

# Preferred Commit Breakdown

Ask Claude to keep commits small and logical, for example:

1. `state: add track normalizers and stable IDs`
2. `main: normalize playlist additions and sync transport controls`
3. `ui: add playlist track inspector panels`
4. `ui: sync settings readouts and loop/master state`
5. `history: cover playlist and session edits`
6. `refactor: remove index-based sidebar identity`
7. `docs: align docs with actual patch status`
8. `test: add normalization and history smoke coverage`

---

# Final instruction

Do not return only an analysis. Execute the patch plan in code, verify the touched flows, and then summarize:

1. what changed
2. what remains intentionally deferred
3. any settings still marked as future work
4. exact smoke-test results
