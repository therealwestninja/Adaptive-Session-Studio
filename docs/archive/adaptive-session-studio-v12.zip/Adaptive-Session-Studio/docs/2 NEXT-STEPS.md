# NEXT-STEPS.md

Engineering priorities. Status reflects v4.3.4.

---

## Completed ✅

### v4.1.0 — All PATCH.md bugs fixed
Empty-blocks fix, tracking lifecycle, drag-by-reference, track-specific FS selection,
device discovery (RequestDeviceList + StartScanning), duplicate deviceStatus IDs,
video block orphan cleanup, emergency stop HUD ordering, loop mode cycles all 4 modes,
import error handling, keyboard shortcut docs, session name clearing.

### v4.2.0 — Web Audio API, tracking state machine, stable IDs, accessibility
AudioContext graph, per-track GainNode, master gain, crossfade. 7-state tracking machine
with 1.5s warmup, single-instance guard, exact-once loss/return callbacks. Sidebar stable
IDs (uid-based), data-track-id delegation. Keyboard shortcuts overlay. Shift+click scrub
preview. ARIA roles, focus rings, 20px hit targets.

### v4.3.0 — Live Control, FunScript multi-select, Smart Suggestions, Crossfade
Runtime intensity/speed/variation sliders. Multi-select points + transform bar. Suggestions
panel in Status tab. Crossfade wired to audio engine.

### v4.3.1 — Normalization, transport sync, inspector completeness
Playlist tracks normalized on add. syncTransportControls() centralized. Audio/video
inspector panels. All sidebar mute/delete fully ID-based. history.push() on mute/delete.

### v4.3.2 — Test suite
Browser-native ES module tests: state normalizers (35), funscript (20), subtitle (15),
history (18), block-ops (13). SMOKE.md manual checklist.

### v4.3.3 — Critical import bug, module graph cleanup
Fixed: main.js was missing ALL 22 cross-module imports (app was non-functional).
Removed window._ bridges: _stateModule, _funscriptModule, _appDuplicateBlock,
_appDeleteBlock, _appSyncTransport. New block-ops.js module. syncTransportControls
exported from ui.js. Targeted sidebar selection (no innerHTML rebuild). FS-pause
button targeted update (no slider rebuild).

### v4.3.4 — Session analytics, crossfade wired, undo coverage, frame accuracy
Session analytics (ROADMAP Phase 5.3): block-time, FS pos avg/peak, attention loss.
Post-session modal + Last session panel in Status tab. Real frame delta time in RAF loop.
Static fsState import (no lazy import per frame). Crossfade setting connected to mute
toggle. All inspector events covered by history.push() with _snapOnce debounce.
drawTimeline statically imported in ui.js. Two new suggestion checks (no blocks, short
subtitle). Attention loss analytics wired into tracking.js.

---

## Remaining — High Priority

### Playback/media architecture refactor
**Severity:** High
**Current:** startPlayback/stopPlayback work but lack a clean lifecycle model.

Remaining work:
- Create `PlaybackEngine` class with `play()`, `pause()`, `seek(t)`, `stop()` interface
- Separate transport clock (performance.now-based) from UI refresh clock (RAF)
- Deterministic media cleanup: each element tracked with explicit lifecycle states
- stopPlayback currently does 15+ DOM operations inline — candidate for extraction

### Scene system (ROADMAP Phase 3.3)
Named time ranges within a session with per-scene loop behavior. Scene markers on timeline.
"Next scene" button during playback.

### Multi-lane timeline UI (ROADMAP Phase 2.1)
Replace single FunScript canvas with stacked lane canvases:
Audio / Video / Blocks / FunScript / Subtitles.
Shared time axis, shared playhead, lane collapse/expand.

---

## Remaining — Medium Priority

### Rendering discipline — inspector
`renderInspector()` rebuilds `inspBody.innerHTML` on every call. The Status tab
stat cards are refreshed every RAF tick by `refreshLiveStatus()`, which is fine
(targeted DOM updates). But switching tabs or clicking a sidebar item still triggers
a full inspector rebuild including event re-binding. Low harm but worth a targeted
patch for the session/block inspector tabs.

### Diff-based undo history (ROADMAP Phase 1.4)
Current: JSON snapshot per step, 60-step limit. For sessions with large FunScript
tracks (100k+ actions), each snapshot is expensive. Switch to diff-based storage.

### Timeline zoom (ROADMAP Phase 2.3)
Mouse-wheel zoom on timeline canvas (x-axis scale). Overview minimap.

### Conditional logic engine (ROADMAP Phase 4.2)
Rule system: if attention < threshold → reduceFsIntensity. Editor in Settings.

---

## Remaining — Low Priority

### Session analytics history view
`getStoredAnalytics()` is available. A dedicated analytics history panel (Settings →
Advanced or a separate modal) showing trends across sessions would complete Phase 5.3.

### ZIP-based .assp container (ROADMAP Phase 6.1)
Replace JSON-with-base64 with a ZIP containing manifest + media files.

### Remote control companion (ROADMAP Phase 6.3)
Minimal second-screen web page for LAN use.

### Auto-generate FunScript from audio (ROADMAP Phase 3.1)
OfflineAudioContext amplitude analysis → position curve.

---

## Development Priority Order

1. Playback engine refactor
2. Scene system scaffold
3. Multi-lane timeline UI
4. Diff-based undo
5. Timeline zoom
6. Auto-generate FunScript from audio
7. ZIP container
8. Remote control companion
