// ── tests/scenes.test.js ─────────────────────────────────────────────────
// Tests for normalizeScene (state.js) and scene CRUD helpers (scenes.js).

import { makeRunner }            from './harness.js';
import { normalizeScene, state, uid } from '../js/state.js';
import { addScene, deleteScene, updateScene } from '../js/scenes.js';

export function runSceneTests() {
  const R  = makeRunner('scenes — normalizer & CRUD');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // ── normalizeScene ────────────────────────────────────────────────────
  t('normalizeScene generates stable id', () => {
    ok(normalizeScene({}).id?.startsWith('b_'));
  });
  t('normalizeScene preserves existing id', () => {
    eq(normalizeScene({ id: 'sc-1' }).id, 'sc-1');
  });
  t('normalizeScene defaults name to Scene', () => {
    eq(normalizeScene({}).name, 'Scene');
  });
  t('normalizeScene preserves name', () => {
    eq(normalizeScene({ name: 'Warmup' }).name, 'Warmup');
  });
  t('normalizeScene defaults start to 0', () => {
    eq(normalizeScene({}).start, 0);
  });
  t('normalizeScene defaults end to 60', () => {
    eq(normalizeScene({}).end, 60);
  });
  t('normalizeScene clamps start min to 0', () => {
    eq(normalizeScene({ start: -5 }).start, 0);
  });
  t('normalizeScene clamps end min to 1', () => {
    eq(normalizeScene({ end: 0 }).end, 1);
  });
  t('normalizeScene defaults loopBehavior to once', () => {
    eq(normalizeScene({}).loopBehavior, 'once');
  });
  t('normalizeScene accepts loop loopBehavior', () => {
    eq(normalizeScene({ loopBehavior: 'loop' }).loopBehavior, 'loop');
  });
  t('normalizeScene rejects invalid loopBehavior', () => {
    eq(normalizeScene({ loopBehavior: 'bounce' }).loopBehavior, 'once');
  });
  t('normalizeScene has a color field', () => {
    ok(typeof normalizeScene({}).color === 'string' && normalizeScene({}).color.startsWith('#'));
  });
  t('normalizeScene preserves valid custom color', () => {
    eq(normalizeScene({ color: '#aabbcc' }).color, '#aabbcc');
  });

  // ── addScene / deleteScene / updateScene ─────────────────────────────
  function resetScenes(duration = 300, ...scenes) {
    state.session = {
      ...state.session,
      duration,
      scenes: scenes.map(s => normalizeScene(s)),
    };
  }

  t('addScene appends a normalized scene', () => {
    resetScenes(300);
    addScene();
    eq(state.session.scenes.length, 1);
    ok(state.session.scenes[0].id?.startsWith('b_'));
  });
  t('addScene places new scene after existing ones', () => {
    resetScenes(300, { start: 0, end: 60 });
    addScene();
    const last = state.session.scenes.at(-1);
    ok(last.start >= 60, `expected start >= 60, got ${last.start}`);
  });
  t('addScene does not add scene beyond session duration', () => {
    resetScenes(60, { start: 0, end: 60 });
    const before = state.session.scenes.length;
    addScene();
    eq(state.session.scenes.length, before, 'should not add beyond duration');
  });
  t('deleteScene removes by id', () => {
    resetScenes(300, { start: 0, end: 60, name: 'A' }, { start: 60, end: 120, name: 'B' });
    const idToDelete = state.session.scenes[0].id;
    deleteScene(idToDelete);
    eq(state.session.scenes.length, 1);
    ok(state.session.scenes[0].name === 'B');
  });
  t('deleteScene no-op on unknown id', () => {
    resetScenes(300, { start: 0, end: 60, name: 'A' });
    deleteScene('nonexistent');
    eq(state.session.scenes.length, 1);
  });
  t('updateScene patches a field by id', () => {
    resetScenes(300, { start: 0, end: 60, name: 'Original' });
    const id = state.session.scenes[0].id;
    updateScene(id, { name: 'Updated' });
    eq(state.session.scenes[0].name, 'Updated');
  });
  t('updateScene patches loopBehavior', () => {
    resetScenes(300, { start: 0, end: 60, loopBehavior: 'once' });
    const id = state.session.scenes[0].id;
    updateScene(id, { loopBehavior: 'loop' });
    eq(state.session.scenes[0].loopBehavior, 'loop');
  });
  t('updateScene no-op on unknown id', () => {
    resetScenes(300, { start: 0, end: 60, name: 'Stable' });
    updateScene('bad-id', { name: 'Should not change' });
    eq(state.session.scenes[0].name, 'Stable');
  });

  return R.summary();
}
