// ── tests/block-ops.test.js ───────────────────────────────────────────────
// Tests for js/block-ops.js — duplicateBlock and deleteBlock.
// These tests stub the renderer callbacks so no DOM is needed.

import { makeRunner } from './harness.js';
import { state }      from '../js/state.js';
import { duplicateBlock, deleteBlock, registerBlockOpRenderers } from '../js/block-ops.js';
import { normalizeBlock, uid } from '../js/state.js';

export function runBlockOpsTests() {
  const R  = makeRunner('block-ops.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // Stub renderers so tests don't need the DOM
  let renderSidebarCalls   = 0;
  let renderInspectorCalls = 0;
  registerBlockOpRenderers(
    () => renderSidebarCalls++,
    () => renderInspectorCalls++,
  );

  function makeBlock(overrides = {}) {
    return normalizeBlock({ id: uid(), type: 'text', label: 'Test', start: 0, duration: 10, ...overrides });
  }

  function resetSession(...blocks) {
    state.session = {
      ...state.session,
      blocks: blocks.map(b => makeBlock(b)),
    };
    state.selectedBlockId = state.session.blocks[0]?.id ?? null;
    renderSidebarCalls   = 0;
    renderInspectorCalls = 0;
  }

  // ── duplicateBlock ────────────────────────────────────────────────────
  t('duplicateBlock creates a new block', () => {
    resetSession({ label: 'Original', start: 0, duration: 10 });
    const before = state.session.blocks.length;
    duplicateBlock();
    eq(state.session.blocks.length, before + 1);
  });

  t('duplicateBlock selects the new copy', () => {
    resetSession({ label: 'Original', start: 0, duration: 10 });
    const origId = state.selectedBlockId;
    duplicateBlock();
    ok(state.selectedBlockId !== origId, 'selection should move to the copy');
  });

  t('duplicateBlock places copy after original', () => {
    resetSession({ label: 'Orig', start: 5, duration: 10 });
    duplicateBlock();
    const copy = state.session.blocks.find(b => b.id === state.selectedBlockId);
    ok(copy.start >= 5 + 10, 'copy start should be after original end');
  });

  t('duplicateBlock appends " copy" to label', () => {
    resetSession({ label: 'MyBlock', start: 0, duration: 5 });
    duplicateBlock();
    const copy = state.session.blocks.find(b => b.id === state.selectedBlockId);
    ok(copy.label.includes('copy'), `expected "copy" in label, got "${copy.label}"`);
  });

  t('duplicateBlock assigns a new unique id', () => {
    resetSession({ label: 'Orig', start: 0, duration: 5 });
    const origId = state.session.blocks[0].id;
    duplicateBlock();
    const copyId = state.selectedBlockId;
    ok(copyId !== origId, 'copy must have different id');
  });

  t('duplicateBlock is a no-op when no block selected', () => {
    resetSession({ label: 'A', start: 0, duration: 5 });
    state.selectedBlockId = null;
    const before = state.session.blocks.length;
    duplicateBlock();
    eq(state.session.blocks.length, before, 'nothing added if no selection');
  });

  t('duplicateBlock calls render callbacks', () => {
    resetSession({ label: 'A', start: 0, duration: 5 });
    renderSidebarCalls = 0;
    duplicateBlock();
    ok(renderSidebarCalls > 0, 'renderSidebar should be called');
    ok(renderInspectorCalls > 0, 'renderInspector should be called');
  });

  // ── deleteBlock ───────────────────────────────────────────────────────
  t('deleteBlock removes the selected block', () => {
    resetSession({ label: 'A', start: 0 }, { label: 'B', start: 20 });
    const idToDelete = state.selectedBlockId;
    deleteBlock();
    ok(!state.session.blocks.find(b => b.id === idToDelete), 'deleted block should be gone');
  });

  t('deleteBlock selects the next remaining block', () => {
    resetSession({ label: 'A', start: 0 }, { label: 'B', start: 20 });
    deleteBlock();
    ok(state.session.blocks.length === 1, 'one block should remain');
    eq(state.selectedBlockId, state.session.blocks[0].id);
  });

  t('deleteBlock on last block sets selectedBlockId to null', () => {
    resetSession({ label: 'Only', start: 0 });
    deleteBlock();
    eq(state.session.blocks.length, 0);
    eq(state.selectedBlockId, null);
  });

  t('deleteBlock is a no-op when no block selected', () => {
    resetSession({ label: 'A', start: 0 }, { label: 'B', start: 20 });
    state.selectedBlockId = null;
    const before = state.session.blocks.length;
    deleteBlock();
    eq(state.session.blocks.length, before);
  });

  t('deleteBlock calls render callbacks', () => {
    resetSession({ label: 'A', start: 0 }, { label: 'B', start: 20 });
    renderSidebarCalls = 0;
    deleteBlock();
    ok(renderSidebarCalls > 0, 'renderSidebar should be called');
  });

  t('deleteBlock preserves other blocks', () => {
    resetSession({ label: 'A', start: 0 }, { label: 'B', start: 20 }, { label: 'C', start: 40 });
    state.selectedBlockId = state.session.blocks[1].id; // select B
    deleteBlock();
    eq(state.session.blocks.length, 2);
    ok(state.session.blocks.every(b => b.label !== 'B'), 'B should be gone');
    ok(state.session.blocks.some(b => b.label === 'A'), 'A should remain');
    ok(state.session.blocks.some(b => b.label === 'C'), 'C should remain');
  });

  return R.summary();
}
