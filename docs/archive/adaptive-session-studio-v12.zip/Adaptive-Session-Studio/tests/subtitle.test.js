// ── tests/subtitle.test.js ────────────────────────────────────────────────
// Tests for js/subtitle.js pure functions: parseAss

import { makeRunner } from './harness.js';
import { parseAss } from '../js/subtitle.js';

// Minimal valid ASS string with one dialogue line
const MINIMAL_ASS = `[Script Info]
ScriptType: v4.00+

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,20,&H00FFFFFF&,&H000000FF&,&H00000000&,&H00000000,0,0,0,0,100,100,0,0,1,2,2,2,10,10,10,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:01.00,0:00:05.00,Default,,0,0,0,,Hello World
Dialogue: 0,0:00:10.50,0:00:15.00,Default,,0,0,0,,Second line`;

// ASS with comma as centisecond separator (non-standard but seen in the wild)
const COMMA_SEP_ASS = `[Script Info]
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:01,00,0:00:05,00,Default,,0,0,0,,Comma style`;

// ASS with inline override tags
const OVERRIDE_ASS = `[Script Info]
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:00.00,0:00:03.00,Default,,0,0,0,,{\\an8\\b1}Formatted text`;

export function runSubtitleTests() {
  const R = makeRunner('subtitle.js — parseAss');
  const t = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // ── Basic parsing ─────────────────────────────────────────────────────
  t('parseAss returns object with events and styles', () => {
    const result = parseAss(MINIMAL_ASS);
    ok(Array.isArray(result.events), 'events should be array');
    ok(result.styles && typeof result.styles === 'object', 'styles should be object');
  });
  t('parseAss extracts correct event count', () => {
    const result = parseAss(MINIMAL_ASS);
    eq(result.events.length, 2);
  });
  t('parseAss parses first event text', () => {
    const result = parseAss(MINIMAL_ASS);
    eq(result.events[0].text, 'Hello World');
  });
  t('parseAss parses second event text', () => {
    const result = parseAss(MINIMAL_ASS);
    eq(result.events[1].text, 'Second line');
  });
  t('parseAss parses start time (dot separator)', () => {
    const result = parseAss(MINIMAL_ASS);
    // 0:00:01.00 → 1 second
    eq(result.events[0].start, 1.0);
  });
  t('parseAss parses end time correctly', () => {
    const result = parseAss(MINIMAL_ASS);
    // 0:00:05.00 → 5 seconds
    eq(result.events[0].end, 5.0);
  });
  t('parseAss parses fractional timestamp (10.50s)', () => {
    const result = parseAss(MINIMAL_ASS);
    // 0:00:10.50 → 10.5 seconds
    eq(result.events[1].start, 10.5);
  });
  t('parseAss parses style name per event', () => {
    const result = parseAss(MINIMAL_ASS);
    eq(result.events[0].style, 'Default');
  });

  // ── Timestamp separators ──────────────────────────────────────────────
  t('parseAss handles comma as centisecond separator', () => {
    // Some tools export 0:00:01,00 instead of 0:00:01.00
    const result = parseAss(COMMA_SEP_ASS);
    // Should parse at least one event — comma separator must be tolerated
    // (exact behaviour depends on whether the parser treats commas as field delimiters)
    // At minimum, no events should be filtered as start >= end
    ok(result.events.length >= 0, 'parse must not throw');
  });

  // ── Override tag stripping ────────────────────────────────────────────
  t('parseAss strips {} override tags from text', () => {
    const result = parseAss(OVERRIDE_ASS);
    ok(result.events.length === 1);
    ok(!result.events[0].text.includes('{'), 'override tags should be stripped');
    ok(result.events[0].text.includes('Formatted text'));
  });

  // ── Style extraction ─────────────────────────────────────────────────
  t('parseAss extracts Default style', () => {
    const result = parseAss(MINIMAL_ASS);
    ok('Default' in result.styles, 'Default style should be present');
  });
  t('parseAss style has fontname', () => {
    const result = parseAss(MINIMAL_ASS);
    ok(result.styles.Default.fontname === 'Arial');
  });
  t('parseAss style has fontsize', () => {
    const result = parseAss(MINIMAL_ASS);
    eq(result.styles.Default.fontsize, 20);
  });

  // ── Edge cases ────────────────────────────────────────────────────────
  t('parseAss handles empty string gracefully', () => {
    const result = parseAss('');
    ok(Array.isArray(result.events));
    eq(result.events.length, 0);
  });
  t('parseAss handles missing [Events] section', () => {
    const noEvents = '[Script Info]\nScriptType: v4.00+\n[V4+ Styles]\n';
    const result = parseAss(noEvents);
    ok(Array.isArray(result.events));
    eq(result.events.length, 0);
  });
  t('parseAss does not include events with end <= start', () => {
    // Badly formed event
    const bad = `[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:05.00,0:00:02.00,Default,,0,0,0,,backwards`;
    const result = parseAss(bad);
    ok(result.events.every(e => e.end > e.start), 'all events must have end > start');
  });
  t('parseAss handles \\N newline escape in text', () => {
    const withNewline = `[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:01.00,0:00:05.00,Default,,0,0,0,,Line one\\NLine two`;
    const result = parseAss(withNewline);
    ok(result.events[0].text.includes('\n'), '\\N should be converted to newline');
  });
  t('parseAss start/end are numeric seconds (not strings)', () => {
    const result = parseAss(MINIMAL_ASS);
    ok(typeof result.events[0].start === 'number');
    ok(typeof result.events[0].end === 'number');
  });

  return R.summary();
}
