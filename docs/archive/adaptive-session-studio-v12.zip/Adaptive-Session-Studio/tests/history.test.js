// ── tests/history.test.js ─────────────────────────────────────────────────
// Tests for js/history.js — push/undo/redo state transitions, canUndo/canRedo,
// clear, and depth() reporting.
//
// NOTE: history.js depends on state.js and persist(). In a browser test
// environment, state.js initializes cleanly (localStorage empty → sampleSession),
// and persist() writes to localStorage, which is acceptable here.
// The DOM helpers in _notifyChange (undo/redo button disable) will silently
// no-op since the test page does not include those elements.

import { makeRunner } from './harness.js';
import { history } from '../js/history.js';
import { state } from '../js/state.js';

export function runHistoryTests() {
  const R = makeRunner('history.js');
  const t = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // Reset to a clean baseline before each group by clearing history
  // and setting a known session state. We use mutation of state.session
  // directly to keep tests isolated.

  function reset() {
    history.clear();
    // Give state.session a known baseline
    state.session = { ...state.session, name: 'baseline', loopMode: 'none' };
  }

  // ── Initial state ─────────────────────────────────────────────────────
  t('canUndo returns false on empty stack', () => {
    reset();
    ok(!history.canUndo());
  });
  t('canRedo returns false on empty stack', () => {
    reset();
    ok(!history.canRedo());
  });
  t('depth() returns zero past and future after clear', () => {
    reset();
    const d = history.depth();
    eq(d.past, 0);
    eq(d.future, 0);
  });

  // ── push ─────────────────────────────────────────────────────────────
  t('canUndo returns true after push', () => {
    reset();
    history.push();
    ok(history.canUndo());
  });
  t('canRedo returns false immediately after push', () => {
    reset();
    history.push();
    ok(!history.canRedo());
  });
  t('depth().past increments on push', () => {
    reset();
    history.push();
    history.push();
    eq(history.depth().past, 2);
  });
  t('push clears the redo stack', () => {
    reset();
    history.push();
    state.session = { ...state.session, name: 'step1' };
    history.undo();                   // creates a redo entry
    ok(history.canRedo(), 'sanity: redo should be available');
    history.push();                   // new action should clear redo
    ok(!history.canRedo(), 'redo stack must be cleared by push');
  });

  // ── undo ─────────────────────────────────────────────────────────────
  t('undo restores previous session state', () => {
    reset();
    const before = state.session.name;
    history.push();
    state.session = { ...state.session, name: 'mutated' };
    history.undo();
    eq(state.session.name, before, 'undo must restore name to pre-mutation value');
  });
  t('canRedo returns true after undo', () => {
    reset();
    history.push();
    state.session = { ...state.session, name: 'changed' };
    history.undo();
    ok(history.canRedo());
  });
  t('canUndo returns false after full undo', () => {
    reset();
    history.push();
    history.undo();
    ok(!history.canUndo());
  });
  t('undo is a no-op when stack is empty', () => {
    reset();
    const nameBefore = state.session.name;
    history.undo(); // must not throw
    eq(state.session.name, nameBefore);
  });
  t('depth().future increments after undo', () => {
    reset();
    history.push();
    history.push();
    history.undo();
    eq(history.depth().future, 1);
    eq(history.depth().past,   1);
  });

  // ── redo ─────────────────────────────────────────────────────────────
  t('redo restores undone state', () => {
    reset();
    history.push();
    state.session = { ...state.session, name: 'step-forward' };
    history.undo();
    history.redo();
    eq(state.session.name, 'step-forward');
  });
  t('canRedo returns false after redo consumes stack', () => {
    reset();
    history.push();
    history.undo();
    history.redo();
    ok(!history.canRedo());
  });
  t('redo is a no-op when stack is empty', () => {
    reset();
    const nameBefore = state.session.name;
    history.redo(); // must not throw
    eq(state.session.name, nameBefore);
  });

  // ── Multi-step undo/redo ──────────────────────────────────────────────
  t('multi-step undo/redo sequence is consistent', () => {
    reset();
    const names = ['alpha', 'beta', 'gamma'];
    for (const name of names) {
      history.push();
      state.session = { ...state.session, name };
    }
    // Undo all three
    history.undo(); // back to beta
    history.undo(); // back to alpha
    history.undo(); // back to baseline
    eq(state.session.name, 'baseline');
    // Redo to gamma in one shot
    history.redo();
    history.redo();
    history.redo();
    eq(state.session.name, 'gamma');
  });

  // ── clear ─────────────────────────────────────────────────────────────
  t('clear empties past stack', () => {
    reset();
    history.push();
    history.push();
    history.clear();
    ok(!history.canUndo());
    eq(history.depth().past, 0);
  });
  t('clear empties future stack', () => {
    reset();
    history.push();
    history.undo();
    ok(history.canRedo(), 'sanity');
    history.clear();
    ok(!history.canRedo());
    eq(history.depth().future, 0);
  });

  // ── MAX_HISTORY cap ───────────────────────────────────────────────────
  t('history stack does not exceed 60 entries', () => {
    reset();
    for (let i = 0; i < 70; i++) history.push();
    ok(history.depth().past <= 60, `past depth should be ≤60, got ${history.depth().past}`);
  });

  return R.summary();
}
