# NEXT-STEPS.md

Engineering priorities beyond the immediate patch set.
Status updated to reflect what has been completed.

---

## Completed ✅

### 1) Safe persistence — DONE
- `persist()` wrapped in `try/catch` with `QuotaExceededError` detection
- Visible "⚠ Unsaved" badge in topbar on failure
- `persistState` object tracks dirty/error/lastSaved
- `checkStorageBudget()` warns at 80% usage on startup

### 2) Deep import validation — DONE
- `normalizeAudioTrack`, `normalizeVideoTrack`, `normalizeFunscriptTrack`, `normalizeSubtitleTrack`, `normalizeMacro` added to `state.js`
- All nested arrays in `normalizeSession` pass through their specific normalizer
- Numeric fields clamped; malformed entries filtered with descriptive errors

### 3) Notification system — DONE
- `notify.js`: `info`, `success`, `warn`, `error` (sticky), `confirm` (async dialog)
- All `alert()` calls removed from the codebase
- Import/export operations show success/failure toasts with filenames and item counts

### 4) Undo / Redo — DONE (basic)
- `history.js`: 60-step JSON snapshot stack
- `Ctrl+Z` / `Ctrl+Y` keyboard shortcuts
- Undo/Redo buttons in topbar with disabled state
- Block edit, duplicate, delete, and JSON apply all undoable

### 5) Browser capability detection — DONE
- `capabilities.js`: detects FaceDetector, speechSynthesis, fullscreen, Web Audio, IndexedDB
- `.requires-face-detector` class dims and disables unavailable webcam automation controls
- Startup warning toasts for missing features (deferred 1.2s)
- localStorage budget check on startup

### 6) Device connection path — DONE
- `RequestDeviceList` + `StartScanning` sent after handshake
- Handles `DeviceList`, `DeviceAdded`, `DeviceRemoved`, `ScanningFinished`, `Error`
- Status progression: `Connecting…` → `Scanning…` → `Device: <name>` | `No device found`
- Duplicate `deviceStatus` ID fixed; uses class selector across multiple panels

---

## Remaining — High Priority

### Playback/media architecture refactor
**Severity:** High
**Current:** Ad-hoc `new Audio()` elements, no unified lifecycle, crossfade unimplemented.

Recommended work:
- Create `PlaybackEngine` class with `play()`, `pause()`, `seek(t)`, `stop()` methods
- Move audio to Web Audio API graph: `AudioContext` → `GainNode` per track → master gain
- Implement crossfade between audio tracks using `GainNode.linearRampToValueAtTime`
- Separate transport clock (performance.now-based) from UI refresh clock (RAF)
- Add deterministic cleanup: each media element tracked with explicit lifecycle (`start`, `playing`, `stopping`, `stopped`)

### Tracking lifecycle and state machine
**Severity:** Medium-High
**Current:** Tracking now has double-start protection and dialog-close cleanup. Single module instance ensured.

Remaining:
- Replace ad-hoc boolean flags with explicit tracking states: `idle | requesting_permission | warming_up | detecting | lost | unavailable | error`
- `warming_up` state after camera starts (1–2s for FaceDetector to stabilise)
- Expose tracking state in the status panel rather than just raw text strings
- Disable FunScript automation controls in the UI when `state === 'unavailable'`

### Editor state cleanup
**Severity:** Medium-High
**Current:** FunScript point selection uses `{ trackId, actionRef }` (fixed). Sidebar uses indices.

Remaining:
- Sidebar delete/mute actions currently use array indices (`data-del-idx`, `data-mute-idx`). When arrays are mutated between render and click, these can target the wrong item. Replace with stable IDs (audio track `id`, subtitle/funscript track `id`).
- Add `id` fields to audio and video playlist items (currently nameless objects)

---

## Remaining — Medium Priority

### Rendering discipline
**Current:** `innerHTML` replacement throughout `ui.js`. Events rebound after each render.

Recommended incremental improvements (not a full rewrite):
- For hot-path elements (sidebar block list, inspector fields), use targeted DOM mutation instead of full `innerHTML` replace
- Scoped event listeners that are explicitly removed before rebind
- `renderSidebar()` should not scroll the user's position back to top on each call — save and restore `scrollTop`

### Automated tests for pure logic
**Priority:** Medium (enables safer future changes)

Start small, pure functions only — no DOM:
```
state.js:   normalizeSession, normalizeBlock, all deep normalizers
funscript.js: parseFunScript, interpolatePosition, exportFunScript
macros.js:  buildInjectionSequence, macroDuration
subtitle.js: parseAss, secToAssTime
history.js: push/undo/redo state transitions
```
Tools: browser-native `import` + a test runner (e.g., `uvu` or `vitest` in library mode with no bundler required).

### Accessibility pass
- Add `role`, `aria-label` to sidebar items and inspector tabs
- Visible focus outlines (currently suppressed by `outline: none` on inputs)
- Canvas timeline: add a non-canvas fallback table of action points for keyboard editing
- Larger click targets for sidebar mute/delete micro-buttons (currently 14×14px)

---

## Remaining — Low Priority

### Docs/UI sync
- Crossfade setting in Settings → Playback is exposed but not implemented — add a `(coming soon)` label
- In-app keyboard shortcut overlay (`?` key shows a modal)
- "Known limitations" section visible in-app (e.g., small info panel in Settings → Advanced)

---

## Recommended Order for Next Session

1. Playback engine refactor (Web Audio API, proper media lifecycle)
2. Tracking state machine
3. Sidebar stable IDs (replace index-based mutation targets)
4. Automated tests for pure logic
5. Accessibility pass
6. Rendering discipline improvements
