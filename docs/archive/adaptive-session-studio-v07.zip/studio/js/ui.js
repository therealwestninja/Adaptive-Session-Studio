// ── ui.js ──────────────────────────────────────────────────────────────────
// All DOM rendering: sidebar lists, inspector panel, settings dialog.

import { state, persist, fmt, esc, $id, uid, clampInt, themeMap, applyCssVars, applyTheme, builtinThemes, normalizeBlock } from './state.js';
import { downloadAss } from './subtitle.js';
import { downloadFunScript, refreshTimelineVisibility } from './funscript.js';
import { history } from './history.js';

// ── Sidebar ─────────────────────────────────────────────────────────────────
const DOT_COLORS = ['#5fa0dc','#f0a04a','#7dc87a','#b084cc','#e07a5f','#64b5c8'];
const BLOCK_COLORS = { text:'#5fa0dc', tts:'#7dc87a', audio:'#f0a04a', video:'#b084cc', pause:'#555350' };
const BLOCK_ICONS  = { text:'T', tts:'◎', audio:'♪', video:'▶', pause:'⏸', funscript:'⚡' };

export function renderSidebar() {
  renderAudioList();
  renderVideoList();
  renderBlockList();
  renderSubtitleList();
  renderFunScriptList();
  refreshTimelineVisibility();
}

function renderAudioList() {
  const el = $id('audioList');
  if (!el) return;
  const tracks = state.session.playlists.audio;
  if (!tracks.length) { el.innerHTML = '<div class="sb-empty">No audio tracks</div>'; return; }
  el.innerHTML = tracks.map((t, i) => `
    <div class="sb-item${state.selectedSidebarType==='audio'&&state.selectedSidebarIdx===i?' selected':''}" data-sb-type="audio" data-sb-idx="${i}">
      <div class="sb-item-dot" style="background:${DOT_COLORS[i%6]}"></div>
      <span class="sb-item-name">${esc(t.name||`Audio ${i+1}`)}</span>
      <button class="sb-item-mute${t._muted?' muted':''}" data-mute-kind="audio" data-mute-idx="${i}" title="${t._muted?'Unmute':'Mute'}">${t._muted?'✕':'●'}</button>
      <button class="sb-item-del" data-del-kind="audio" data-del-idx="${i}" title="Remove">×</button>
    </div>`).join('');
}

function renderVideoList() {
  const el = $id('videoList');
  if (!el) return;
  const tracks = state.session.playlists.video;
  if (!tracks.length) { el.innerHTML = '<div class="sb-empty">No video tracks</div>'; return; }
  el.innerHTML = tracks.map((t, i) => `
    <div class="sb-item${state.selectedSidebarType==='video'&&state.selectedSidebarIdx===i?' selected':''}" data-sb-type="video" data-sb-idx="${i}">
      <div class="sb-item-dot" style="background:${DOT_COLORS[(i+3)%6]}"></div>
      <span class="sb-item-name">${esc(t.name||`Video ${i+1}`)}</span>
      <span class="sb-item-badge">${t.mediaKind||'vid'}</span>
      <button class="sb-item-del" data-del-kind="video" data-del-idx="${i}" title="Remove">×</button>
    </div>`).join('');
}

function renderBlockList() {
  const el = $id('blockList');
  if (!el) return;
  const sorted = [...state.session.blocks].sort((a, b) => a.start - b.start);
  if (!sorted.length) { el.innerHTML = '<div class="sb-empty">No blocks</div>'; return; }
  el.innerHTML = sorted.map(b => `
    <div class="sb-item${b.id===state.selectedBlockId?' selected':''}" data-sb-type="block" data-block-id="${b.id}">
      <div class="sb-item-dot" style="background:${BLOCK_COLORS[b.type]||'#888'}"></div>
      <span class="sb-item-name">${esc(b.label)}</span>
      <span style="font-size:10px;color:var(--text3)">${fmt(b.start)}</span>
    </div>`).join('');
}

function renderSubtitleList() {
  const el = $id('subtitleList');
  if (!el) return;
  const tracks = state.session.subtitleTracks;
  if (!tracks.length) { el.innerHTML = '<div class="sb-empty">No subtitle tracks</div>'; return; }
  el.innerHTML = tracks.map((t, i) => `
    <div class="sb-item${state.selectedSidebarType==='subtitle'&&state.selectedSidebarIdx===i?' selected':''}" data-sb-type="subtitle" data-sb-idx="${i}">
      <div class="sb-item-dot" style="background:#5fa0dc;border-radius:2px"></div>
      <span class="sb-item-name">${esc(t.name)}</span>
      <span class="sb-item-badge">${t.events?.length||0}</span>
      <button class="sb-item-mute${t._disabled?' muted':''}" data-mute-kind="subtitle" data-mute-idx="${i}" title="${t._disabled?'Enable':'Disable'}">${t._disabled?'✕':'●'}</button>
      <button class="sb-item-del" data-del-kind="subtitle" data-del-idx="${i}" title="Remove">×</button>
    </div>`).join('');
}

function renderFunScriptList() {
  const el = $id('funscriptList');
  if (!el) return;
  const tracks = state.session.funscriptTracks;
  if (!tracks.length) { el.innerHTML = '<div class="sb-empty">No FunScript tracks</div>'; return; }
  el.innerHTML = tracks.map((t, i) => `
    <div class="sb-item${state.selectedSidebarType==='funscript'&&state.selectedSidebarIdx===i?' selected':''}" data-sb-type="funscript" data-sb-idx="${i}">
      <div class="sb-item-dot" style="background:${t._color||'#f0a04a'};border-radius:2px"></div>
      <span class="sb-item-name">${esc(t.name)}</span>
      <span class="sb-item-badge">${t.actions?.length||0} pts</span>
      <button class="sb-item-mute${t._disabled?' muted':''}" data-mute-kind="funscript" data-mute-idx="${i}" title="${t._disabled?'Enable':'Disable'}">${t._disabled?'✕':'●'}</button>
      <button class="sb-item-del" data-del-kind="funscript" data-del-idx="${i}" title="Remove">×</button>
    </div>`).join('');
}

// ── Inspector ───────────────────────────────────────────────────────────────
export function renderInspector() {
  const body = $id('inspBody');
  if (!body) return;
  switch (state.inspTab) {
    case 'status':  body.innerHTML = renderStatusTab();  break;
    case 'session': body.innerHTML = renderSessionTab(); attachSessionTabEvents(); break;
    default:        body.innerHTML = renderOverlayTab(); attachOverlayTabEvents(); break;
  }
}

function renderStatusTab() {
  const rt = state.runtime;
  if (!rt) return `<div class="insp-status">Not playing.</div>
    ${statCard('Time','—','s_timeVal')}${statCard('Loop','—','s_loopVal')}${statCard('Block','—','s_blockVal')}${statCard('FS pos','—','s_fsPos')}`;
  return `
    ${statCard('Time',`${fmt(rt.sessionTime)} / ${fmt(state.session.duration)}`,'s_timeVal')}
    ${statCard('Loop', rt.totalLoops?`${rt.loopIndex+1}/${rt.totalLoops}`:`${rt.loopIndex+1}/∞`,'s_loopVal')}
    ${statCard('Block', esc(rt.activeBlock?.label||'—'),'s_blockVal')}
    ${statCard('FS pos','0%','s_fsPos')}`;
}

function statCard(label, val, id = '') {
  return `<div class="stat-card"><div class="stat-label">${label}</div><div class="stat-val"${id?` id="${id}"`:''}>${val}</div></div>`;
}

function renderSessionTab() {
  const s = state.session;
  return `
    <div class="insp-group">
      <div class="insp-group-label">Identity</div>
      <label style="font-size:11px;color:var(--text2);margin-bottom:6px">Name<input type="text" id="si_name" value="${esc(s.name)}" /></label>
    </div>
    <div class="insp-group">
      <div class="insp-group-label">Timing</div>
      <div class="insp-row"><span>Duration (s)</span><input type="number" id="si_dur" value="${s.duration}" min="10" style="width:80px" /></div>
      <div class="insp-row"><span>Loop mode</span>
        <select id="si_loop" style="width:100px">
          ${['none','count','minutes','forever'].map(v=>`<option value="${v}"${s.loopMode===v?' selected':''}>${v}</option>`).join('')}
        </select>
      </div>
      <div class="insp-row"><span>Loop count</span><input type="number" id="si_lc" value="${s.loopCount}" min="1" style="width:80px" /></div>
    </div>
    <div class="insp-group">
      <div class="insp-group-label">Block actions</div>
      <div style="display:flex;gap:5px;flex-wrap:wrap">
        <button id="si_dup" style="flex:1;font-size:11px">Duplicate</button>
        <button id="si_del" style="flex:1;font-size:11px;color:var(--danger)">Delete</button>
        <button id="si_sort" style="width:100%;font-size:11px">Sort by start time</button>
      </div>
    </div>`;
}

function attachSessionTabEvents() {
  $id('si_name')?.addEventListener('input', e => { state.session.name = e.target.value; persist(); });
  $id('si_dur')?.addEventListener('input', e => {
    state.session.duration = clampInt(e.target.value, 10, 86400, 180);
    persist();
    const tot = $id('tTotal');
    if (tot) tot.textContent = fmt(state.session.duration);
  });
  $id('si_loop')?.addEventListener('change', e => { state.session.loopMode = e.target.value; persist(); });
  $id('si_lc')?.addEventListener('input', e => { state.session.loopCount = clampInt(e.target.value, 1, 100000, 1); persist(); });
  $id('si_dup')?.addEventListener('click', () => { window._appDuplicateBlock?.(); });
  $id('si_del')?.addEventListener('click', () => { window._appDeleteBlock?.(); });
  $id('si_sort')?.addEventListener('click', () => {
    state.session.blocks.sort((a, b) => a.start - b.start); persist(); renderSidebar();
  });
}

function renderOverlayTab() {
  const block = state.session.blocks.find(b => b.id === state.selectedBlockId);

  // FunScript track selected?
  if (state.selectedSidebarType === 'funscript' && state.selectedSidebarIdx !== null) {
    return renderFunScriptInspector();
  }
  // Subtitle track selected?
  if (state.selectedSidebarType === 'subtitle' && state.selectedSidebarIdx !== null) {
    return renderSubtitleInspector();
  }

  if (!block) return '<div class="insp-status">Select a block or track from the sidebar.</div>';

  const colorTag = { text:'tag-blue', tts:'tag-green', audio:'tag-amber', video:'tag-purple', pause:'' }[block.type] || '';
  let html = `
    <div class="insp-block-name">${esc(block.label)}</div>
    <span class="tag ${colorTag}" style="margin-bottom:10px;display:inline-flex">${BLOCK_ICONS[block.type]||'?'} ${block.type}</span>
    <div class="insp-group">
      <div class="insp-group-label">Label</div>
      <input type="text" data-field="label" value="${esc(block.label)}" />
    </div>
    <div class="insp-group">
      <div class="insp-group-label">Timing</div>
      <div class="insp-row"><span>Start (s)</span><input type="number" data-field="start" value="${block.start}" min="0" step="1" style="width:80px"/></div>
      <div class="insp-row"><span>Duration (s)</span><input type="number" data-field="duration" value="${block.duration}" min="1" step="1" style="width:80px"/></div>
      <div class="insp-row"><span>End (s)</span><span style="color:var(--text3)">${block.start+block.duration}</span></div>
    </div>`;

  if (block.type === 'text') {
    html += `
      <div class="insp-group"><div class="insp-group-label">Content</div>
        <textarea data-field="content" rows="4" style="width:100%;font-size:11px;resize:vertical">${esc(block.content)}</textarea></div>
      <div class="insp-group"><div class="insp-group-label">Typography</div>
        <div class="insp-row"><span>Size</span><input type="number" data-field="fontSize" value="${block.fontSize||1.2}" min="0.5" max="5" step="0.05" style="width:80px"/></div>
      </div>
      <div class="insp-group"><div class="insp-group-label">Position</div>
        <div class="pos-grid">${['top-left','top','top-right','left','center','right','bottom-left','bottom','bottom-right'].map(p=>`<button class="pos-btn${(block._position||'center')===p?' active':''}" data-pos="${p}">${posLabel(p)}</button>`).join('')}</div>
      </div>`;
  } else if (block.type === 'tts') {
    html += `
      <div class="insp-group"><div class="insp-group-label">Spoken text</div>
        <textarea data-field="content" rows="4" style="width:100%;font-size:11px;resize:vertical">${esc(block.content)}</textarea></div>
      <div class="insp-row"><span>Volume</span><input type="number" data-field="volume" value="${block.volume||1}" min="0" max="1" step="0.05" style="width:80px"/></div>
      <label style="font-size:11px;color:var(--text2)">Voice name<input type="text" data-field="voiceName" value="${esc(block.voiceName||'')}" placeholder="default" /></label>`;
  } else if (block.type === 'audio') {
    html += `
      <div class="insp-group"><div class="insp-group-label">File</div>
        <p style="font-size:11px;color:var(--text3);margin-bottom:4px">${block.dataUrlName?esc(block.dataUrlName):'No file'}</p>
        <label class="file-pick-btn">Browse…<input type="file" accept="audio/*" data-file-field="dataUrl" hidden /></label>
      </div>
      <div class="insp-row"><span>Volume</span><input type="number" data-field="volume" value="${block.volume||1}" min="0" max="1" step="0.05" style="width:80px"/></div>
      <label style="font-size:11px;color:var(--text2)">Notes<textarea data-field="content" rows="3" style="width:100%;font-size:11px;resize:vertical">${esc(block.content)}</textarea></label>`;
  } else if (block.type === 'video') {
    html += `
      <div class="insp-group"><div class="insp-group-label">File</div>
        <p style="font-size:11px;color:var(--text3);margin-bottom:4px">${block.dataUrlName?esc(block.dataUrlName):'No file'}</p>
        <label class="file-pick-btn">Browse…<input type="file" accept="video/*,image/*" data-file-field="dataUrl" hidden /></label>
      </div>
      <div class="insp-row"><span>Mute</span>
        <select data-field="mute" style="width:80px"><option value="true"${block.mute!==false?' selected':''}>Yes</option><option value="false"${block.mute===false?' selected':''}>No</option></select>
      </div>`;
  } else if (block.type === 'pause') {
    html += `<p style="font-size:11px;color:var(--text2);line-height:1.6">Pause block — stage stays quiet while playlist layers continue.</p>`;
  }

  html += `<div style="display:flex;gap:6px;margin-top:12px">
    <button id="ib_dup" style="flex:1;font-size:11px">Duplicate</button>
    <button id="ib_del" style="flex:1;font-size:11px;color:var(--danger)">Delete</button>
  </div>`;
  return html;
}

function renderFunScriptInspector() {
  const idx = state.selectedSidebarIdx;
  const track = state.session.funscriptTracks[idx];
  if (!track) return '<div class="insp-status">Track not found.</div>';
  const settings = state.session.funscriptSettings;
  return `
    <div class="insp-block-name">⚡ ${esc(track.name)}</div>
    <div class="insp-group">
      <div class="insp-group-label">Track info</div>
      <div class="insp-row"><span>Points</span><span style="color:var(--text)">${track.actions?.length||0}</span></div>
      <div class="insp-row"><span>Duration</span><span style="color:var(--text)">${fmt((track.actions?.at(-1)?.at||0)/1000)}</span></div>
      <div class="insp-row"><span>Range</span><span style="color:var(--text)">0–${track.range||100}</span></div>
    </div>
    <div class="insp-group">
      <div class="insp-group-label">Global FunScript settings</div>
      <div class="insp-row"><span>Speed</span>
        <input type="number" id="fs_speed" value="${settings.speed||1}" min="0.25" max="4" step="0.25" style="width:70px"/>
        <span style="font-size:10px;color:var(--text3)">×</span>
      </div>
      <div class="insp-row"><span>Invert</span>
        <select id="fs_invert" style="width:70px">
          <option value="false"${!settings.invert?' selected':''}>No</option>
          <option value="true"${settings.invert?' selected':''}>Yes</option>
        </select>
      </div>
      <div class="insp-row"><span>Range</span>
        <input type="number" id="fs_range" value="${settings.range||100}" min="1" max="100" step="1" style="width:70px"/>
      </div>
    </div>
    <div class="insp-group">
      <div class="insp-group-label">Device</div>
      <div class="device-status-display" style="font-size:11px;color:var(--text3);margin-bottom:6px">Disconnected</div>
      <div style="display:flex;flex-direction:column;gap:5px">
        <input type="text" id="fs_wsUrl" value="ws://localhost:12345" style="font-size:11px" placeholder="ws://localhost:12345" />
        <div style="display:flex;gap:5px">
          <button id="fs_connect" class="btn-primary" style="flex:1;font-size:11px">Connect</button>
          <button id="fs_disconnect" style="flex:1;font-size:11px">Disconnect</button>
        </div>
      </div>
    </div>
    <div style="display:flex;flex-direction:column;gap:5px;margin-top:4px">
      <button id="fs_export" style="font-size:11px">Export .funscript</button>
      <button id="fs_delete" style="font-size:11px;color:var(--danger)">Remove track</button>
    </div>`;
}

function renderSubtitleInspector() {
  const idx = state.selectedSidebarIdx;
  const track = state.session.subtitleTracks[idx];
  if (!track) return '<div class="insp-status">Track not found.</div>';
  return `
    <div class="insp-block-name">◌ ${esc(track.name)}</div>
    <div class="insp-group">
      <div class="insp-group-label">Track info</div>
      <div class="insp-row"><span>Cues</span><span style="color:var(--text)">${track.events?.length||0}</span></div>
      <div class="insp-row"><span>Styles</span><span style="color:var(--text)">${Object.keys(track.styles||{}).join(', ')||'Default'}</span></div>
    </div>
    <div style="display:flex;flex-direction:column;gap:5px;margin-top:4px">
      <button id="ass_export" style="font-size:11px">Export .ass</button>
      <button id="ass_delete" style="font-size:11px;color:var(--danger)">Remove track</button>
    </div>`;
}

function attachOverlayTabEvents() {
  const body = $id('inspBody');
  if (!body) return;

  body.querySelectorAll('[data-field]').forEach(el => {
    el.addEventListener('input',  handleBlockFieldChange);
    el.addEventListener('change', handleBlockFieldChange);
  });
  body.querySelectorAll('[data-file-field]').forEach(el => el.addEventListener('change', handleBlockFileChange));
  body.querySelectorAll('.pos-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
      if (!block) return;
      block._position = btn.dataset.pos;
      persist();
      body.querySelectorAll('.pos-btn').forEach(b => b.classList.toggle('active', b === btn));
    });
  });

  $id('ib_dup')?.addEventListener('click', () => window._appDuplicateBlock?.());
  $id('ib_del')?.addEventListener('click', () => window._appDeleteBlock?.());

  // FunScript inspector events
  $id('fs_speed')?.addEventListener('input', e => { state.session.funscriptSettings.speed = Number(e.target.value)||1; persist(); });
  $id('fs_invert')?.addEventListener('change', e => { state.session.funscriptSettings.invert = e.target.value==='true'; persist(); });
  $id('fs_range')?.addEventListener('input', e => { state.session.funscriptSettings.range = clampInt(e.target.value,1,100,100); persist(); });
  $id('fs_connect')?.addEventListener('click', () => {
    const { connectDevice } = window._funscriptModule;
    connectDevice($id('fs_wsUrl')?.value || 'ws://localhost:12345');
  });
  $id('fs_disconnect')?.addEventListener('click', () => window._funscriptModule?.disconnectDevice());
  $id('fs_export')?.addEventListener('click', () => {
    const idx = state.selectedSidebarIdx;
    if (idx !== null) downloadFunScript(state.session.funscriptTracks[idx]?.id);
  });
  $id('fs_delete')?.addEventListener('click', () => {
    const idx = state.selectedSidebarIdx;
    if (idx !== null) {
      state.session.funscriptTracks.splice(idx, 1);
      state.selectedSidebarType = null; state.selectedSidebarIdx = null;
      persist(); renderSidebar(); renderInspector();
    }
  });

  // Subtitle inspector events
  $id('ass_export')?.addEventListener('click', () => { const idx=state.selectedSidebarIdx; if(idx!==null) downloadAss(idx); });
  $id('ass_delete')?.addEventListener('click', () => {
    const idx = state.selectedSidebarIdx;
    if (idx !== null) {
      state.session.subtitleTracks.splice(idx, 1);
      state.selectedSidebarType = null; state.selectedSidebarIdx = null;
      persist(); renderSidebar(); renderInspector();
    }
  });
}

function handleBlockFieldChange(e) {
  const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
  if (!block) return;
  // Snapshot before first keystroke in a field (debounced — only if field identity changes)
  if (handleBlockFieldChange._lastField !== e.target) {
    history.push();
    handleBlockFieldChange._lastField = e.target;
  }
  const field = e.target.dataset.field;
  let val = e.target.value;
  if (field === 'start' || field === 'duration') val = clampInt(val, field==='duration'?1:0, 86400, block[field]);
  if (field === 'fontSize' || field === 'volume') val = Number(val);
  if (field === 'mute') val = val === 'true';
  block[field] = val;
  persist();
  renderSidebar();
}
handleBlockFieldChange._lastField = null;

async function handleBlockFileChange(e) {
  const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
  const file  = e.target.files?.[0];
  if (!block || !file) return;
  const { fileToDataUrl } = await import('./state.js');
  block.dataUrl     = await fileToDataUrl(file);
  block.dataUrlName = file.name;
  block.mediaKind   = file.type.startsWith('audio/') ? 'audio' : file.type.startsWith('video/') ? 'video' : 'image';
  persist();
  renderInspector();
}

// ── Settings dialog ──────────────────────────────────────────────────────────
export function syncSettingsForms() {
  const s  = state.session;
  const v  = (id, val) => { const el = $id(id); if (el) el.value = val; };
  const c  = (id, val) => { const el = $id(id); if (el) el.checked = val; };
  v('s_sessionName', s.name);
  v('s_duration', s.duration);
  v('s_loopMode', s.loopMode);
  v('s_loopCount', s.loopCount);
  v('s_runtimeMinutes', s.runtimeMinutes);
  v('s_speechRate', s.speechRate);
  v('s_playlistAudioVolume', s.advanced.playlistAudioVolume);
  v('s_playlistVideoVolume', s.advanced.playlistVideoVolume);
  v('s_crossfadeSeconds', s.advanced.crossfadeSeconds);
  v('s_backgroundColor', s.backgroundColor);
  v('s_textColor', s.textColor);
  v('s_accentColor', s.accentColor);
  v('s_stageBlur', s.advanced.stageBlur);
  v('s_fontFamily', s.advanced.fontFamily);
  v('s_assTextColor', s.subtitleSettings.textColor);
  v('s_assFontSize', s.subtitleSettings.fontSize);
  v('s_assPosition', s.subtitleSettings.position);
  v('s_assOverride', s.subtitleSettings.override);
  c('s_trackingEnabled', s.tracking.enabled);
  c('s_autoPauseOnAttentionLoss', s.tracking.autoPauseOnAttentionLoss);
  c('s_autoResumeOnAttentionReturn', s.advanced.autoResumeOnAttentionReturn);
  v('s_attentionThreshold', s.tracking.attentionThreshold);
  // Webcam → FS options
  const tfo = s.trackingFsOptions ?? {};
  c('s_pauseFsOnLoss',       tfo.pauseFsOnLoss       ?? false);
  c('s_injectMacroOnLoss',   tfo.injectMacroOnLoss   ?? false);
  v('s_lossInjectSlot',      tfo.lossInjectSlot      ?? 0);
  c('s_injectMacroOnReturn', tfo.injectMacroOnReturn ?? false);
  v('s_returnInjectSlot',    tfo.returnInjectSlot    ?? 0);
  // FunScript settings
  v('s_fsSpeed',  s.funscriptSettings.speed);
  v('s_fsRange',  s.funscriptSettings.range);
  c('s_fsInvert', s.funscriptSettings.invert);
  renderThemeGrid();
}

export function syncSessionFromSettings() {
  const gv = id => $id(id)?.value;
  const gc = id => $id(id)?.checked;
  const s  = state.session;
  s.name = gv('s_sessionName')?.trim() ?? s.name;
  s.duration = clampInt(gv('s_duration'), 10, 86400, s.duration);
  s.loopMode = gv('s_loopMode') || s.loopMode;
  s.loopCount = clampInt(gv('s_loopCount'), 1, 100000, s.loopCount);
  s.runtimeMinutes = clampInt(gv('s_runtimeMinutes'), 1, 100000, s.runtimeMinutes);
  s.speechRate = Number(gv('s_speechRate')) || s.speechRate;
  s.advanced.playlistAudioVolume = Number(gv('s_playlistAudioVolume'));
  s.advanced.playlistVideoVolume = Number(gv('s_playlistVideoVolume'));
  s.advanced.crossfadeSeconds    = Number(gv('s_crossfadeSeconds'));
  s.backgroundColor = gv('s_backgroundColor') || s.backgroundColor;
  s.textColor   = gv('s_textColor')   || s.textColor;
  s.accentColor = gv('s_accentColor') || s.accentColor;
  s.advanced.stageBlur  = clampInt(gv('s_stageBlur'), 0, 24, s.advanced.stageBlur);
  s.advanced.fontFamily = gv('s_fontFamily')?.trim() || s.advanced.fontFamily;
  s.subtitleSettings.textColor = gv('s_assTextColor') || s.subtitleSettings.textColor;
  s.subtitleSettings.fontSize  = Number(gv('s_assFontSize')) || s.subtitleSettings.fontSize;
  s.subtitleSettings.position  = gv('s_assPosition') || s.subtitleSettings.position;
  s.subtitleSettings.override  = gv('s_assOverride')  || s.subtitleSettings.override;
  s.tracking.enabled = gc('s_trackingEnabled');
  s.tracking.autoPauseOnAttentionLoss = gc('s_autoPauseOnAttentionLoss');
  s.advanced.autoResumeOnAttentionReturn = gc('s_autoResumeOnAttentionReturn');
  s.tracking.attentionThreshold = clampInt(gv('s_attentionThreshold'), 1, 120, 5);
  // Webcam → FS options
  if (!s.trackingFsOptions) s.trackingFsOptions = {};
  s.trackingFsOptions.pauseFsOnLoss       = gc('s_pauseFsOnLoss');
  s.trackingFsOptions.injectMacroOnLoss   = gc('s_injectMacroOnLoss');
  s.trackingFsOptions.lossInjectSlot      = Number(gv('s_lossInjectSlot') ?? 0);
  s.trackingFsOptions.injectMacroOnReturn = gc('s_injectMacroOnReturn');
  s.trackingFsOptions.returnInjectSlot    = Number(gv('s_returnInjectSlot') ?? 0);
  // FunScript
  s.funscriptSettings.speed  = Number(gv('s_fsSpeed'))  || 1;
  s.funscriptSettings.range  = clampInt(gv('s_fsRange'), 1, 100, 100);
  s.funscriptSettings.invert = gc('s_fsInvert');
  applyCssVars();
  persist();
}

export function renderThemeGrid() {
  const grid = $id('themeGrid');
  if (!grid) return;
  grid.innerHTML = Object.entries(themeMap()).map(([key, t]) => `
    <button class="theme-chip${state.session.theme===key?' active':''}" data-theme-key="${key}">
      <div class="theme-dot" style="background:${t.backgroundColor};border:2px solid ${t.accentColor}"></div>
      ${esc(t.name)}
    </button>`).join('');
}

export function saveCustomTheme() {
  const key = $id('s_customThemeKey')?.value.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, '-');
  const name= $id('s_customThemeName')?.value.trim() || key;
  if (!key) {
    import('./notify.js').then(({ notify }) => notify.warn('Enter a theme key (e.g. "oceanic") first.'));
    return;
  }
  state.session.customThemes[key] = {
    name,
    backgroundColor: $id('s_customThemeBg')?.value,
    accentColor:     $id('s_customThemeAccent')?.value,
    textColor:       $id('s_customThemeText')?.value,
  };
  applyTheme(key);
  persist();
  renderThemeGrid();
  import('./notify.js').then(({ notify }) => notify.success(`Theme "${name}" saved.`));
}

export function deleteCustomTheme() {
  if (builtinThemes[state.session.theme]) {
    import('./notify.js').then(({ notify }) => notify.warn('Built-in themes cannot be deleted. Select a custom theme first.'));
    return;
  }
  const name = state.session.customThemes[state.session.theme]?.name ?? state.session.theme;
  delete state.session.customThemes[state.session.theme];
  applyTheme('midnight');
  persist();
  renderThemeGrid();
  import('./notify.js').then(({ notify }) => notify.info(`Theme "${name}" deleted.`));
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function posLabel(p) {
  return { 'top-left':'↖', top:'↑', 'top-right':'↗', left:'←', center:'·', right:'→', 'bottom-left':'↙', bottom:'↓', 'bottom-right':'↘' }[p] || p;
}
