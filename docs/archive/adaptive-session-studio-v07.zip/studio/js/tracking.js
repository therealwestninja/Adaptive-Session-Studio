// ── tracking.js ────────────────────────────────────────────────────────────
// Webcam attention tracking via FaceDetector API + visual overlay.
// Includes optional FunScript pause and macro injection on attention events.

import { state, $id } from './state.js';
import { pausePlayback, resumePlayback } from './playback.js';
import { toggleFsPause, injectMacro, getSlotMacro } from './macros.js';

export function makeTrackingModule() {
  let stream = null, raf = 0, lastSeen = performance.now();
  let wasSessionPaused = false, wasFsPaused = false;
  let lossInjected = false, returnInjected = false;
  let detector = null;

  if ('FaceDetector' in window) {
    try { detector = new FaceDetector({ fastMode: true, maxDetectedFaces: 1 }); } catch {}
  }

  const pv  = $id('trackingPreview');
  const oc  = $id('trackingOverlay');
  const ctx = oc?.getContext('2d');

  function setStatus(camera, face, lossText) {
    const cs = $id('cameraStatus');         if (cs && camera   != null) cs.textContent = camera;
    const fs = $id('faceStatus');           if (fs && face     != null) fs.textContent = face;
    const ad = $id('attentionLossDisplay'); if (ad && lossText != null) ad.textContent = lossText;
  }

  function resizeCanvas() {
    if (!oc || !pv) return;
    const r = pv.getBoundingClientRect();
    oc.width = r.width; oc.height = r.height;
  }

  async function start() {
    if (stream) stop();
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      pv.srcObject = stream;
      setStatus('Live', null, null);
      resizeCanvas();
      raf = requestAnimationFrame(loop);
    } catch (err) {
      setStatus('Denied', 'Unavailable', null);
      // Lazy import to avoid circular dependency
      import('./notify.js').then(({ notify }) =>
        notify.error(`Webcam access denied: ${err.message}\n\nGrant camera permission in your browser settings.`)
      );
    }
  }

  function stop() {
    cancelAnimationFrame(raf);
    if (stream) stream.getTracks().forEach(t => t.stop());
    stream = null;
    if (pv) pv.srcObject = null;
    ctx?.clearRect(0, 0, oc?.width ?? 0, oc?.height ?? 0);
    setStatus('Off', 'Unknown', '0.0s');
  }

  async function loop() {
    resizeCanvas();
    ctx?.clearRect(0, 0, oc.width, oc.height);

    let face = null;
    if (detector && pv?.readyState >= 2) {
      try { const faces = await detector.detect(pv); face = faces[0] || null; } catch {}
    }

    if (face) {
      drawFace(face.boundingBox);
      setStatus(null, 'Detected', '0.0s');
      const loss = (performance.now() - lastSeen) / 1000;
      lastSeen = performance.now();
      lossInjected = false;

      // On return — only fires once per loss event
      if (!returnInjected && loss > (state.session.tracking.attentionThreshold ?? 5)) {
        const opts = state.session.trackingFsOptions ?? {};

        // Resume session if we paused it
        if (wasSessionPaused && state.session.advanced.autoResumeOnAttentionReturn && state.runtime?.pausedByAttention) {
          resumePlayback(true);
          wasSessionPaused = false;
        }
        // Un-pause FS if we paused it
        if (wasFsPaused && state.fsPaused) {
          toggleFsPause();
          wasFsPaused = false;
        }
        // Inject return macro
        if (opts.injectMacroOnReturn && opts.returnInjectSlot) {
          const macro = getSlotMacro(Number(opts.returnInjectSlot));
          if (macro) injectMacro(macro.id);
        }
        returnInjected = true;
      }

    } else {
      const loss = (performance.now() - lastSeen) / 1000;
      setStatus(null, detector ? 'Not detected' : 'Live preview', `${loss.toFixed(1)}s`);
      returnInjected = false;

      const { tracking } = state.session;
      if (!tracking.enabled) { raf = requestAnimationFrame(loop); return; }

      const overThreshold = loss >= (tracking.attentionThreshold ?? 5);
      const opts = state.session.trackingFsOptions ?? {};

      if (overThreshold && !lossInjected) {
        lossInjected = true;

        // Pause session
        if (tracking.autoPauseOnAttentionLoss && state.runtime && !state.runtime.paused) {
          pausePlayback(true);
          wasSessionPaused = true;
        }
        // Pause FS only
        if (opts.pauseFsOnLoss && !state.fsPaused) {
          toggleFsPause();
          wasFsPaused = true;
        }
        // Inject loss macro
        if (opts.injectMacroOnLoss && opts.lossInjectSlot) {
          const macro = getSlotMacro(Number(opts.lossInjectSlot));
          if (macro) injectMacro(macro.id);
        }
      }
    }

    raf = requestAnimationFrame(loop);
  }

  function drawFace(box) {
    if (!ctx || !pv) return;
    const sx = oc.width  / (pv.videoWidth  || 1);
    const sy = oc.height / (pv.videoHeight || 1);
    ctx.strokeStyle = state.session.accentColor || '#f0a04a';
    ctx.lineWidth = 2;
    ctx.strokeRect(box.x * sx, box.y * sy, box.width * sx, box.height * sy);
  }

  return { start, stop };
}
