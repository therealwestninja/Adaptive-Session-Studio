// ── user-profile.js ────────────────────────────────────────────────────────
// User Profiling System — ROADMAP Phase 3.12 (Local Only)
//
// Builds and maintains a persistent local profile derived from session analytics.
// Stores: session history, preferred intensity, attention stability, engagement
// trend, total runtime, and streak tracking.
//
// Storage: IndexedDB key 'ass-profile-v1' (migrated from localStorage on first load)
// All data is local-only. No network calls. Export/import optional.

import { state, fmt, esc } from './state.js';
import { getStoredAnalytics, clearStoredAnalytics } from './session-analytics.js';
import { renderMetricsChart, importExternalMetrics, clearMetricsHistory } from './metrics-history.js';
import { notify } from './notify.js';
import { idbGet, idbSet, idbDel } from './idb-storage.js';

const PROFILE_KEY = 'ass-profile-v1';

// ── Profile shape ─────────────────────────────────────────────────────────────
export function defaultProfile() {
  return {
    version:          1,
    // Identity (Phase 4 — user can set these in the profile panel)
    displayName:      '',           // user's chosen name (optional)
    avatarEmoji:      '🧘',         // single emoji avatar
    goals:            '',           // free-text session goals / preferences
    primaryUse:       'self',       // 'self' | 'self-for-partner' | 'partner-trains-me' | 'i-train-partner' | 'other'
    role:             'primary',    // 'primary' | 'operator'
    retainDays:       180,          // metrics history retention window (days)
    sessionCount:     0,
    totalRuntimeSec:  0,
    lastSessionAt:    null,
    streak:           0,         // consecutive days with at least one session
    lastStreakDate:   null,       // date string YYYY-MM-DD
    // Derived from analytics history (rolling average over last 10 sessions)
    avgAttentionStability: null, // 0–1: 1 = never lost attention
    avgEngagementPct:      null, // 0–100: average engagement score
    preferredIntensityAvg: null, // average FS output percentage
    preferredIntensityMax: null, // average peak FS output
    // Responsiveness: how quickly user re-engages after attention loss
    avgReengagementSec: null,
    // Trend flags
    intensityTrend: 'stable',    // 'rising' | 'falling' | 'stable'
    attentionTrend: 'stable',
    // ── Phase 6: Achievements, XP, Quests ─────────────────────────────────
    xp:                    0,     // total lifetime XP
    achievements:          [],    // array of earned achievement ids
    modesUsed:             [],    // array of session mode ids ever used
    highAttentionSessions: 0,     // sessions with ≥80% attention (legacy compat)
    // App engagement tracking
    appOpens:              0,     // total number of times the app has been opened
    hapticSessions:        0,     // sessions completed with an active haptic track
    vizSessions:           0,     // sessions completed with a visualization block
    rulesSessions:         0,     // sessions completed with at least one active rule
    multiSessionDays:      0,     // days where 2+ sessions were completed
    maxSessionsInDay:      0,     // personal best sessions in a single day
    // Daily quests (reset each day)
    quests:    [],    // [{ id, done }] for today
    questDate: null,          // YYYY-MM-DD of quest generation
    packsLoaded: [],          // content pack ids ever loaded (Pack Explorer)
    // Perfect quest streak tracking
    perfectQuestStreak:    0,     // consecutive days with all 3 quests completed
    lastPerfectQuestDate:  null,  // YYYY-MM-DD of last perfect quest day
    perfectQuestDaysList:  [],    // list of YYYY-MM-DD strings for perfect quest days
    // ── Per-session counters for achievements ─────────────────────────────
    totalQuestsCompleted: 0,  // lifetime quest completions
    questTypesCompleted:  [], // quest ids ever completed (for quest_types_all)
    perfectQuestDays:     0,  // days all 3 quests were completed
    perfectSessions:      0,  // sessions with zero attention losses
    focusStreakCount:      0,  // consecutive high-focus sessions (resets on break)
    lowDriftSessions:     0,  // sessions with <2 drifts or 80%+ focus
    // ── Calendar / return tracking ────────────────────────────────────────
    todayDate:     null,      // YYYY-MM-DD of last session (for double-session tracking)
    sessionsToday: 0,         // sessions completed on todayDate
    monthCounts:   {},        // { 'YYYY-MM': count } for monthly tracking
  };
}

// ── Load / save ───────────────────────────────────────────────────────────────
// In-memory cache so synchronous callers get consistent data
let _profileCache = null;

// Eagerly hydrate cache from IDB (with localStorage migration on first run)
(async () => {
  let p = await idbGet(PROFILE_KEY);
  if (!p) {
    // Migrate from localStorage if present
    try {
      const lsRaw = localStorage.getItem(PROFILE_KEY);
      if (lsRaw) {
        p = { ...defaultProfile(), ...JSON.parse(lsRaw) };
        await idbSet(PROFILE_KEY, p);
        localStorage.removeItem(PROFILE_KEY);
      }
    } catch {}
  }
  _profileCache = p ? { ...defaultProfile(), ...p } : defaultProfile();
})();

export function loadProfile() {
  return _profileCache ?? defaultProfile();
}

export function saveProfile(profile) {
  _profileCache = profile;
  idbSet(PROFILE_KEY, profile).catch(() => {}); // fire-and-forget
}

export function clearProfile() {
  _profileCache = defaultProfile();
  idbDel(PROFILE_KEY).catch(() => {});
}

// ── Rebuild profile from analytics history ────────────────────────────────────
export function rebuildProfile() {
  const history = getStoredAnalytics();
  if (!history.length) return defaultProfile();

  // Start from defaults but preserve any user-set identity fields
  const existing = loadProfile();
  const profile = defaultProfile();
  // Carry over identity fields the user has personalised
  profile.displayName  = existing?.displayName  || '';
  profile.avatarEmoji  = existing?.avatarEmoji  || '🧘';
  profile.goals        = existing?.goals        || '';
  profile.primaryUse   = existing?.primaryUse   || 'self';
  profile.role         = existing?.role         || 'primary';
  profile.retainDays   = typeof existing?.retainDays === 'number' ? Math.max(7, Math.min(365, existing.retainDays)) : 180;

  // ── Carry over all progression/achievement fields (never recompute from analytics) ──
  // These are authoritative in the saved profile — analytics cannot reconstruct them.
  const CARRY_OVER = [
    'xp', 'achievements', 'modesUsed', 'packsLoaded',
    'totalQuestsCompleted', 'questTypesCompleted', 'perfectQuestDays',
    'perfectSessions', 'focusStreakCount', 'lowDriftSessions',
    'highAttentionSessions',
    'appOpens', 'hapticSessions', 'vizSessions', 'rulesSessions',
    'multiSessionDays', 'maxSessionsInDay',
    'todayDate', 'sessionsToday', 'monthCounts',
    'quests', 'questDate',
    'perfectQuestStreak', 'lastPerfectQuestDate', 'perfectQuestDaysList',
  ];
  for (const key of CARRY_OVER) {
    if (existing?.[key] !== undefined) profile[key] = existing[key];
  }

  profile.sessionCount    = history.length;
  profile.totalRuntimeSec = history.reduce((s, h) => s + (h.totalSec ?? 0), 0);
  profile.lastSessionAt   = history[0]?.timestamp ?? null;

  // Use up to the last 10 sessions for rolling averages
  const recent = history.slice(0, 10);

  // Attention stability: 1 - (lossEvents / sessionDuration)
  const stabilityScores = recent
    .filter(h => h.totalSec > 0)
    .map(h => Math.max(0, 1 - (h.attentionLossEvents ?? 0) / (h.totalSec / 60)));
  if (stabilityScores.length) {
    profile.avgAttentionStability = +(stabilityScores.reduce((a, b) => a + b, 0) / stabilityScores.length).toFixed(2);
  }

  // Engagement average — sourced from avgEngagement on each history entry (0–1 scale → 0–100%)
  const engagementSamples = recent
    .filter(h => h.avgEngagement !== null && h.avgEngagement !== undefined && Number.isFinite(h.avgEngagement));
  if (engagementSamples.length) {
    profile.avgEngagementPct = Math.round(
      engagementSamples.reduce((a, h) => a + h.avgEngagement, 0) / engagementSamples.length * 100
    );
  }

  // FS intensity preference
  const fsAvgSamples = recent.filter(h => h.fsAvg !== null).map(h => h.fsAvg);
  const fsMaxSamples = recent.filter(h => h.fsMax !== null).map(h => h.fsMax);
  if (fsAvgSamples.length) {
    profile.preferredIntensityAvg = Math.round(fsAvgSamples.reduce((a, b) => a + b, 0) / fsAvgSamples.length);
    profile.preferredIntensityMax = Math.round(fsMaxSamples.reduce((a, b) => a + b, 0) / fsMaxSamples.length);
  }

  // Re-engagement speed: total loss time / loss events
  const reengageSamples = recent
    .filter(h => (h.attentionLossEvents ?? 0) > 0)
    .map(h => (h.attentionLossTotalSec ?? 0) / h.attentionLossEvents);
  if (reengageSamples.length) {
    profile.avgReengagementSec = +(reengageSamples.reduce((a, b) => a + b, 0) / reengageSamples.length).toFixed(1);
  }

  // Streak: count consecutive calendar days with sessions
  profile.streak       = _computeStreak(history);
  profile.lastStreakDate = _todayStr();

  // Derive monthCounts from full history (YYYY-MM → session count)
  // Merge with any carried-over value so the two sources stay in sync.
  const derivedMonths = {};
  for (const h of history) {
    const key = _timestampToLocalDateStr(h.timestamp).slice(0, 7); // YYYY-MM
    derivedMonths[key] = (derivedMonths[key] ?? 0) + 1;
  }
  // Merge: take the max of derived vs carried-over to avoid overcounting
  const carriedMonths = profile.monthCounts ?? {};
  const mergedMonths  = { ...derivedMonths };
  for (const [k, v] of Object.entries(carriedMonths)) {
    if ((mergedMonths[k] ?? 0) < v) mergedMonths[k] = v;
  }
  profile.monthCounts = mergedMonths;

  // Trends: compare first vs second half of recent sessions
  if (recent.length >= 4) {
    const half = Math.floor(recent.length / 2);
    const older = recent.slice(half);
    const newer = recent.slice(0, half);

    const avgFs = arr => arr.filter(h => h.fsAvg !== null).reduce((s, h) => s + h.fsAvg, 0) / (arr.filter(h => h.fsAvg !== null).length || 1);
    const avgStab = arr => arr.filter(h => h.totalSec > 0).reduce((s, h) => s + Math.max(0, 1 - (h.attentionLossEvents ?? 0) / (h.totalSec / 60)), 0) / arr.length;

    const fsDelta   = avgFs(newer)   - avgFs(older);
    const stabDelta = avgStab(newer) - avgStab(older);

    profile.intensityTrend = fsDelta >  5 ? 'rising' : fsDelta < -5 ? 'falling' : 'stable';
    profile.attentionTrend = stabDelta > 0.05 ? 'rising' : stabDelta < -0.05 ? 'falling' : 'stable';
  }

  saveProfile(profile);
  return profile;
}

function _todayStr() {
  const d = new Date();
  // Use local year/month/day, zero-padded, to avoid UTC-day vs local-day mismatch
  // around midnight (e.g. 11 PM local = next UTC day).
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function _timestampToLocalDateStr(ts) {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function _computeStreak(history) {
  if (!history.length) return 0;
  const days = [...new Set(history.map(h => _timestampToLocalDateStr(h.timestamp)))].sort().reverse();
  let streak  = 0;
  let expected = _todayStr();
  for (const day of days) {
    if (day === expected) {
      streak++;
      const d = new Date(expected);
      d.setDate(d.getDate() - 1);
      expected = _timestampToLocalDateStr(d.getTime());
    } else {
      break;
    }
  }
  return streak;
}

// ── Habit Training (ROADMAP Phase 3.13) ──────────────────────────────────────
// Returns a difficulty level (1–5) derived from session history, and streak.
// Used to suggest gradual escalation in session settings.

export function computeDifficultyLevel(profile) {
  if (!profile || profile.sessionCount < 2) return 1;

  let level = 1;

  // Streak bonus: consistent practice → higher baseline
  if (profile.streak >= 7)  level += 1;
  if (profile.streak >= 30) level += 1;

  // Attention stability → readiness for longer/harder sessions
  if ((profile.avgAttentionStability ?? 0) >= 0.8) level += 0.5;
  if ((profile.avgAttentionStability ?? 0) >= 0.95) level += 0.5;

  // Rising intensity trend → user is ready for more
  if (profile.intensityTrend === 'rising') level += 0.5;

  return Math.min(5, Math.round(level));
}

// ── Adaptive Difficulty Curves (ROADMAP Phase 3.11) ──────────────────────────
// Returns suggested ramp settings based on profile data. Callers can apply
// these directly or present them to the user as a recommendation.

export function getAdaptiveRampSuggestion() {
  // Use saved profile if available (faster); rebuild from analytics otherwise.
  // rebuildProfile() is authoritative — call it and save so loadProfile() stays current.
  const profile = rebuildProfile();
  saveProfile(profile);
  const level   = computeDifficultyLevel(profile);

  // Scale intensity from profile's preferred range with level bonus
  const baseAvg = (profile.preferredIntensityAvg ?? 50) / 100;
  const basePeak= (profile.preferredIntensityMax ?? 80) / 100;

  // Progressive overload: each level adds ~10% headroom
  const levelBonus = (level - 1) * 0.1;

  return {
    enabled:   true,
    mode:      profile.avgAttentionStability !== null ? 'adaptive' : 'time',
    startVal:  Math.max(0.2, Math.min(1.0, baseAvg - 0.1)),
    endVal:    Math.min(2.0, basePeak + levelBonus),
    curve:     level >= 4 ? 'exponential' : 'sine',
    steps:     [],
    blendMode: 'max',
    _note:     `Based on ${profile.sessionCount} session${profile.sessionCount !== 1 ? 's' : ''}, level ${level}/5`,
  };
}

// ── Habit Streak Milestones ─────────────────────────────────────────────────
export function getStreakMilestone(streak) {
  if (streak <= 0) return null;
  const milestones = [
    { days: 3,   message: '3-day streak 🔥 Building momentum' },
    { days: 7,   message: '1-week streak 🏆 A full week!' },
    { days: 14,  message: '2-week streak ⚡ Strong habit forming' },
    { days: 30,  message: '30-day streak 🌟 Incredible consistency' },
    { days: 100, message: '100-day streak 🎯 Elite practitioner' },
  ];
  return milestones.filter(m => streak === m.days).at(-1) ?? null;
}

// Returns a milestone message for a session count, or null.
export function getSessionCountMilestone(count) {
  const milestones = [
    { count: 1,   message: 'First session complete 🎉 Welcome!' },
    { count: 5,   message: '5 sessions 🌱 Getting into the groove' },
    { count: 10,  message: '10 sessions 💪 A real habit!' },
    { count: 25,  message: '25 sessions 🔑 You\'re experienced now' },
    { count: 50,  message: '50 sessions 🏅 Dedicated practitioner' },
    { count: 100, message: '100 sessions 🌟 Century achieved!' },
  ];
  return milestones.filter(m => count === m.count).at(-1) ?? null;
}

// Returns a milestone message for total runtime in seconds, or null.
export function getRuntimeMilestone(totalSec) {
  const milestones = [
    { sec: 3600,    message: 'First hour of sessions ⏱ Getting started' },
    { sec: 36_000,  message: '10 hours of sessions 🕐 Committed!' },
    { sec: 180_000, message: '50 hours of sessions 🏆 Deep practice' },
    { sec: 360_000, message: '100 hours of sessions 🌟 Century of time' },
  ];
  return milestones.filter(m => totalSec >= m.sec && totalSec < m.sec + 3600).at(-1) ?? null;
}
// ── Update the persistent menubar avatar button ──────────────────────────────
// Called after every session end, profile save, and on boot.
// Keeps the emoji, name, and XP fill bar in sync without opening the panel.
export function updateMenubarAvatar(profile) {
  if (!profile) return;
  const p = profile;

  const emojiEl = document.getElementById('profileAvatarEmoji');
  const nameEl  = document.getElementById('profileAvatarName');
  const fillEl  = document.getElementById('profileAvatarXpFill');
  const ringEl  = document.getElementById('profileAvatarRing');

  if (emojiEl) emojiEl.textContent = p.avatarEmoji || '🧘';

  if (nameEl) {
    const displayName = p.displayName?.trim();
    nameEl.textContent = displayName || 'Profile';
  }

  if (fillEl) {
    // levelProgressPct is imported at the top of this file
    const xp  = p.xp ?? 0;
    const pct = levelProgressPct(xp);
    fillEl.style.width = `${Math.max(2, Math.round(pct * 100))}%`;
  }

  if (ringEl) {
    const streak = p.streak ?? 0;
    ringEl.classList.remove('mb-profile-ring--warm', 'mb-profile-ring--hot');
    if (streak >= 7) ringEl.classList.add('mb-profile-ring--hot');
    else if (streak >= 3) ringEl.classList.add('mb-profile-ring--warm');
  }
}

export async function renderProfilePanel(containerId = 'profilePanel') {
  const el = document.getElementById(containerId);
  if (!el) return;

  const p = rebuildProfile();
  saveProfile(p);  // keep persisted profile in sync with latest analytics
  const history = getStoredAnalytics();
  const streakMilestone   = getStreakMilestone(p.streak);
  const countMilestone    = getSessionCountMilestone(p.sessionCount);

  // ── Load achievements/XP data ──────────────────────────────────────────
  const {
    ACHIEVEMENTS, ACHIEVEMENT_MAP, LEVEL_NAMES, MAX_LEVEL,
    levelFromXp, levelProgressPct, xpToNextLevel, getTodayQuestDefs, QUEST_POOL,
  } = await import('./achievements.js');
  const currentXp    = p.xp ?? 0;
  const currentLevel = levelFromXp(currentXp);
  const levelName    = LEVEL_NAMES[currentLevel] ?? `Level ${currentLevel}`;
  const progressPct  = levelProgressPct(currentXp);
  const xpNeeded     = xpToNextLevel(currentXp);
  const earnedSet    = new Set(p.achievements ?? []);
  const todayQuests  = getTodayQuestDefs();
  const questDate    = p.questDate ?? '';
  const today        = new Date().toISOString().slice(0, 10);
  const questStates  = (questDate === today) ? (p.quests ?? []) : todayQuests.map(q => ({ id: q.id, done: false }));
  const runtimeMilestone  = getRuntimeMilestone(p.totalRuntimeSec);
  const milestone = streakMilestone ?? countMilestone ?? runtimeMilestone;

  const chartDays = Math.min(p.retainDays ?? 180, 60); // show up to 60 bars
  const metricsChartHtml = await renderMetricsChart(chartDays, p.retainDays ?? 180);

  const trendIcon  = t => t === 'rising' ? '↑' : t === 'falling' ? '↓' : '→';
  const trendColor = t => t === 'rising' ? '#7dc87a' : t === 'falling' ? '#e05050' : 'var(--text3)';

  const recPill = (label, value, unit = '') => value === null ? '' : `
    <div style="background:rgba(255,255,255,0.04);border:0.5px solid rgba(255,255,255,0.08);
      border-radius:8px;padding:8px;text-align:center;min-width:72px">
      <div style="font-size:14px;font-weight:700;color:#f0f0e8">${value}${unit}</div>
      <div style="font-size:9.5px;color:rgba(255,255,255,0.3);text-transform:uppercase;letter-spacing:.06em">${label}</div>
    </div>`;

  // ── Primary use tagline ──────────────────────────────────────────────────
  const USE_TAGLINE = {
    'self':              'Here for myself',
    'self-for-partner':  'Training for someone special',
    'partner-trains-me': 'Being guided by my partner',
    'i-train-partner':   'Guiding my partner',
    'other':             'Private mode',
  };
  const ROLE_BADGE = {
    'primary':  { label: 'Primary User', icon: '🫀' },
    'operator': { label: 'Operator',     icon: '🎛' },
  };
  const tagline   = USE_TAGLINE[p.primaryUse] ?? 'Here for myself';
  const roleBadge = ROLE_BADGE[p.role] ?? ROLE_BADGE.primary;

  // ── Streak ring gradient ──────────────────────────────────────────────────
  // Streak 0 = cold grey, 3 = warm amber, 7+ = hot rose-pink
  const streakGlow = p.streak >= 7 ? '#e8708a' : p.streak >= 3 ? '#e8963a' : 'rgba(255,255,255,0.12)';
  const streakGlowShadow = p.streak >= 7 ? '0 0 18px rgba(232,112,138,0.5)' : p.streak >= 3 ? '0 0 14px rgba(232,150,58,0.35)' : 'none';

  // ── Compatibility score (attention stability as %) ─────────────────────────
  const compatPct = p.avgAttentionStability !== null
    ? Math.round(p.avgAttentionStability * 100)
    : null;

  // ── Relationship status for completion states ──────────────────────────────
  const STATUS_EMOJI = { completed: '💚', interrupted: '🟡', emergency: '🔴' };
  const STATUS_LABEL = { completed: 'Completed', interrupted: 'Left early', emergency: 'Safe stop' };

  el.innerHTML = `
  <div class="pc2">

    <!-- ── HEADER BAND ── -->
    <div class="pc2-header">
      <div style="display:flex;align-items:flex-end;gap:14px;position:relative;z-index:1">

        <!-- Avatar + collar ring -->
        <button id="pp_emojiBtn" class="pc2-avatar-ring" title="Tap to change avatar" style="background:none;cursor:pointer;padding:0">
          <div class="pc2-avatar-btn">${p.avatarEmoji || '🧘'}</div>
        </button>

        <!-- Identity column -->
        <div style="flex:1;min-width:0;padding-bottom:2px">
          <input id="pp_displayName" type="text" maxlength="40"
            placeholder="Your name…" value="${esc(p.displayName || '')}"
            class="pc2-name" autocomplete="off" />
          <div class="pc2-tagline">${esc(tagline)}</div>
          <span class="pc2-role-badge">${roleBadge.icon} ${esc(roleBadge.label)}</span>
        </div>
      </div>
    </div>

    <div style="padding:14px">

    <!-- ── COMPATIBILITY / MAIN STAT ── -->
    ${compatPct !== null ? `
    <div class="pc2-compat">
      <div class="pc2-compat-num">${compatPct}<span class="pc2-compat-unit">%</span></div>
      <div class="pc2-compat-label">Attention compatibility</div>
      ${p.attentionTrend !== 'stable' ? `<div style="font-size:10px;margin-top:4px;color:${p.attentionTrend==='rising'?'#6dbf6a':'#c45c5c'}">${p.attentionTrend==='rising'?'↑ improving':'↓ declining'}</div>` : ''}
    </div>` : `
    <div class="pc2-compat">
      <div style="font-size:11px;color:rgba(240,236,228,0.22);font-style:italic;font-family:var(--serif)">
        Complete a session to see your score
      </div>
    </div>`}

    <!-- ── STAT TRIO ── -->
    <div class="pc2-stats">
      <div class="pc2-stat">
        <div class="pc2-stat-val">${p.sessionCount}</div>
        <div class="pc2-stat-lbl">Sessions</div>
        <div class="pc2-stat-bar" style="width:${Math.min(100,p.sessionCount/10*100)}%"></div>
      </div>
      <div class="pc2-stat">
        <div class="pc2-stat-val" style="font-size:13px">${fmt(p.totalRuntimeSec)}</div>
        <div class="pc2-stat-lbl">Runtime</div>
        <div class="pc2-stat-bar" style="width:${Math.min(100,p.totalRuntimeSec/36000*100)}%"></div>
      </div>
      <div class="pc2-stat" style="${p.streak>=3?`border-color:rgba(196,154,60,0.25)`:''}">
        <div class="pc2-stat-val" style="${p.streak>=3?`color:var(--gold)`:''}">
          ${p.streak}${p.streak>=7?' 🔥':''}
        </div>
        <div class="pc2-stat-lbl">Day streak</div>
        <div class="pc2-stat-bar" style="width:${Math.min(100,p.streak/14*100)}%;${p.streak>=3?'background:var(--gold)':''}"></div>
      </div>
    </div>

    <!-- ── MILESTONE ── -->
    ${milestone ? `
    <div class="pc2-milestone">
      <span style="font-size:18px;flex-shrink:0">◆</span>
      <div>
        <div style="font-size:9px;text-transform:uppercase;letter-spacing:.09em;color:var(--gold);margin-bottom:2px">Achievement</div>
        <div style="font-size:11.5px;color:var(--ivory2)">${esc(milestone.message)}</div>
      </div>
    </div>` : ''}

    <!-- ── ABOUT ME ── -->
    <div class="pc2-sec">About me</div>
    <textarea id="pp_goals" rows="3" maxlength="500"
      placeholder="What are you here for? What are you working toward?"
      style="width:100%;font-size:11.5px;line-height:1.6;resize:none;font-style:italic;
        color:rgba(240,236,228,0.52);background:rgba(255,255,255,0.02);
        border:0.5px solid rgba(196,154,60,0.10);border-radius:8px;
        padding:8px 10px;box-sizing:border-box;caret-color:var(--gold);outline:none;
        font-family:var(--serif)"
    >${esc(p.goals || '')}</textarea>

    <!-- ── LOOKING FOR / ROLE ── -->
    <div class="pc2-sec">Looking for</div>
    <select id="pp_primaryUse" style="width:100%;font-size:11.5px;padding:6px 10px;margin-bottom:8px;
      background:rgba(255,255,255,0.03);border:0.5px solid rgba(196,154,60,0.12);
      border-radius:8px;color:rgba(240,236,228,0.65)">
      <option value="self"${(p.primaryUse||'self')==='self'?' selected':''}>Training myself, for myself</option>
      <option value="self-for-partner"${p.primaryUse==='self-for-partner'?' selected':''}>Training myself, for my partner</option>
      <option value="partner-trains-me"${p.primaryUse==='partner-trains-me'?' selected':''}>Being trained by my partner</option>
      <option value="i-train-partner"${p.primaryUse==='i-train-partner'?' selected':''}>Training my partner</option>
      <option value="other"${p.primaryUse==='other'?' selected':''}>Private / demo mode</option>
    </select>
    <select id="pp_role" style="width:100%;font-size:11.5px;padding:6px 10px;
      background:rgba(255,255,255,0.03);border:0.5px solid rgba(196,154,60,0.12);
      border-radius:8px;color:rgba(240,236,228,0.65)">
      <option value="primary"${(p.role||'primary')==='primary'?' selected':''}>The subject of the session</option>
      <option value="operator"${p.role==='operator'?' selected':''}>The one in control</option>
    </select>

    <!-- ── INTENSITY PROFILE ── -->
    ${p.preferredIntensityAvg !== null ? `
    <div class="pc2-sec">Intensity profile</div>
    <div style="display:flex;justify-content:space-between;font-size:10px;color:rgba(240,236,228,0.28);margin-bottom:5px;font-family:var(--dmono)">
      <span>avg ${p.preferredIntensityAvg}%</span><span>peak ${p.preferredIntensityMax}%</span>
    </div>
    <div style="height:3px;background:rgba(255,255,255,0.04);border-radius:2px;overflow:hidden">
      <div style="height:3px;border-radius:2px;background:linear-gradient(90deg,var(--ox),var(--gold));width:${p.preferredIntensityAvg}%;transition:width 0.8s ease"></div>
    </div>` : ''}

    <!-- ── ACTIVITY CHART ── -->
    <div class="pc2-sec" style="margin-top:16px">
      Recent activity
      <span style="color:rgba(255,255,255,0.15);font-size:8.5px;letter-spacing:0;text-transform:none;margin-left:auto;display:flex;align-items:center;gap:5px">
        <input id="pp_retainDays" type="number" min="7" max="365"
          value="${p.retainDays ?? 180}"
          style="width:34px;font-size:9.5px;text-align:center;
            background:rgba(196,154,60,0.06);border:0.5px solid rgba(196,154,60,0.15);
            border-radius:3px;color:rgba(196,154,60,0.6);padding:1px 3px;outline:none"> days
        <button id="pp_importMetrics" title="Import metrics from device or script"
          style="font-size:9px;padding:2px 6px;opacity:0.45;border-radius:4px;
            border:0.5px solid rgba(196,154,60,0.18);background:rgba(196,154,60,0.05);
            color:var(--gold);cursor:pointer">⬆ Import</button>
        <input id="pp_importMetricsFile" type="file" accept=".json,.csv" style="display:none">
      </span>
    </div>
    <div id="pp_metricsChart" style="margin-top:4px">${metricsChartHtml}</div>

    <!-- ── XP / LEVEL BAR ── -->
    <div class="pc2-sec" style="margin-top:16px">Progress</div>
    <div style="background:rgba(255,255,255,0.03);border:0.5px solid rgba(255,255,255,0.07);border-radius:10px;padding:12px 14px;margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:6px">
        <div>
          <span style="font-size:14px;font-weight:700;color:var(--gold)">Level ${currentLevel}</span>
          <span style="font-size:11px;color:var(--text3);margin-left:6px">${esc(levelName)}</span>
        </div>
        <span style="font-size:10px;color:var(--text3)">${currentLevel < MAX_LEVEL ? `${xpNeeded} XP to next` : '✦ Max level'}</span>
      </div>
      <div style="height:6px;border-radius:3px;background:rgba(255,255,255,0.07);overflow:hidden">
        <div style="height:100%;width:${progressPct}%;border-radius:3px;background:linear-gradient(90deg,var(--ox),var(--gold));transition:width 1s ease"></div>
      </div>
      <div style="font-size:9.5px;color:var(--text3);margin-top:4px;text-align:right">${currentXp.toLocaleString()} XP total</div>
    </div>

    <!-- ── DAILY QUESTS ── -->
    <div class="pc2-sec">Daily Quests <span style="font-size:9px;color:var(--text3);font-weight:400;margin-left:4px">Reset at midnight</span></div>
    <div style="display:flex;flex-direction:column;gap:5px;margin-bottom:12px">
      ${todayQuests.map(q => {
        const state = questStates.find(qs => qs.id === q.id);
        const done  = state?.done ?? false;
        return `<div style="display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:8px;
          background:${done?'rgba(45,106,79,0.15)':'rgba(255,255,255,0.03)'};
          border:0.5px solid ${done?'rgba(45,106,79,0.3)':'rgba(255,255,255,0.07)'}">
          <span style="font-size:14px;flex-shrink:0">${done?'✅':q.icon}</span>
          <div style="flex:1;min-width:0">
            <div style="font-size:11px;color:${done?'rgba(144,200,144,0.8)':'var(--text2)'};${done?'text-decoration:line-through;':''}">${esc(q.name)}</div>
            <div style="font-size:10px;color:var(--text3)">${esc(q.desc)}</div>
          </div>
          <span style="font-size:10px;color:var(--gold);flex-shrink:0">+${q.xp} XP</span>
        </div>`;
      }).join('')}
    </div>

    <!-- ── ACHIEVEMENTS ── -->
    <div class="pc2-sec">Achievements <span style="font-size:9px;color:var(--text3);font-weight:400;margin-left:4px">${earnedSet.size}/${ACHIEVEMENTS.filter(a=>!a.secret).length} visible · ${ACHIEVEMENTS.filter(a=>a.secret&&earnedSet.has(a.id)).length} hidden found</span></div>

    ${(()=>{
      const CAT_LABELS = { starter:'First Steps', consistency:'Consistency', depth:'Sessions', endurance:'Endurance', focus:'Focus', craft:'Craft & Exploration', quests:'Quests', levels:'Levels' };
      const byCategory = {};
      for (const a of ACHIEVEMENTS) {
        if (!a.secret || earnedSet.has(a.id)) (byCategory[a.category] = byCategory[a.category]??[]).push(a);
      }
      return Object.entries(CAT_LABELS).map(([cat, label]) => {
        const achs = byCategory[cat]; if (!achs?.length) return '';
        const earnedCount = achs.filter(a=>earnedSet.has(a.id)).length;
        const visibleCount = achs.filter(a=>!a.secret).length;
        return `<div style="margin-bottom:12px">
          <div style="font-size:9.5px;text-transform:uppercase;letter-spacing:.07em;color:var(--text3);margin-bottom:5px;display:flex;justify-content:space-between">
            <span>${esc(label)}</span><span style="color:${earnedCount===visibleCount&&visibleCount>0?'var(--gold)':'var(--text3)'}">${earnedCount}/${visibleCount}</span>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:5px">
            ${achs.map(a=>{
              const e=earnedSet.has(a.id);
              return `<div title="${esc(e?a.name+' — '+a.desc:(a.secret?'Secret achievement':a.desc))}"
                style="display:flex;align-items:center;gap:5px;padding:5px 9px;border-radius:8px;cursor:default;
                  background:${e?'rgba(196,154,60,0.12)':'rgba(255,255,255,0.02)'};
                  border:0.5px solid ${e?'rgba(196,154,60,0.35)':'rgba(255,255,255,0.06)'};
                  opacity:${e?1:0.4}">
                <span style="font-size:12px">${e?a.icon:'🔒'}</span>
                <span style="font-size:10px;color:${e?'var(--gold)':'var(--text3)'}">${esc(e?a.name:(a.secret?'???':a.name))}</span>
              </div>`;
            }).join('')}
          </div>
        </div>`;
      }).join('');
    })()}

    <!-- ── SESSION HISTORY ── -->
    ${history.length ? `
    <div class="pc2-sec">Recent sessions</div>
    ${history.slice(0,8).map(h => {
      const cs = h.completionState ?? 'completed';
      const dotColor = cs==='emergency'?'#7a1a2e':cs==='interrupted'?'#8a7030':'#2d6a4f';
      const dateStr = new Date(h.timestamp).toLocaleDateString(undefined,{month:'short',day:'numeric'});
      return `<div class="pc2-hrow">
        <div class="pc2-hrow-dot" style="background:${dotColor}"></div>
        <span class="pc2-hrow-name">${esc(h.sessionName)}</span>
        <span class="pc2-hrow-meta">${fmt(h.totalSec)}</span>
        <span class="pc2-hrow-meta" style="min-width:36px;text-align:right">${dateStr}</span>
      </div>`;
    }).join('')}` : `
    <div style="text-align:center;padding:18px 0;border:0.5px dashed rgba(196,154,60,0.10);border-radius:10px;margin-top:12px">
      <div style="font-family:var(--serif);font-style:italic;font-size:13px;color:rgba(240,236,228,0.25);margin-bottom:3px">No sessions yet</div>
      <div style="font-size:10px;color:rgba(240,236,228,0.15)">Complete your first to begin</div>
    </div>`}

    </div>
  </div>`;
        </div>`;
      }).join('')}
    </div>` : `
    <div style="text-align:center;padding:16px 0;margin-bottom:16px;
      border:0.5px dashed rgba(255,255,255,0.07);border-radius:10px">
      <div style="font-size:13px;margin-bottom:4px;opacity:0.4">No sessions yet</div>
      <div style="font-size:10.5px;color:rgba(255,255,255,0.2);font-style:italic">
        Complete your first session to start your profile
      </div>
    </div>`}

    <!-- ── ACTIONS ── -->
    <div style="display:flex;flex-direction:column;gap:6px;margin-top:4px">

      <button id="pp_restartOnboarding"
        style="width:100%;padding:7px;border-radius:8px;font-size:11px;
          background:transparent;border:0.5px solid rgba(255,255,255,0.07);
          color:rgba(255,255,255,0.25);cursor:pointer;transition:all 0.15s"
        title="Replay the welcome tutorial">
        ↺ Replay onboarding tutorial
      </button>

      <button id="pp_resetSettings"
        style="width:100%;padding:7px;border-radius:8px;font-size:11px;
          background:transparent;border:0.5px solid rgba(255,255,255,0.07);
          color:rgba(255,255,255,0.25);cursor:pointer;transition:all 0.15s"
        title="Reset HUD, display, and playback settings to defaults">
        ⟳ Reset settings to defaults
      </button>

      <button id="clearProfileBtn" class="pp-clear-btn"
        style="width:100%;padding:7px;border-radius:8px;font-size:11px;
          background:transparent;border:0.5px solid rgba(122,26,46,0.25);
          color:rgba(196,80,80,0.45);cursor:pointer;transition:all 0.15s"
        title="Permanently erase all profile data, history, and achievements">
        ✕ Clear profile &amp; all history
      </button>

    </div>

  </div>`;

  // ── Wire identity field events ──────────────────────────────────────────
  document.getElementById('pp_displayName')?.addEventListener('input', e => {
    p.displayName = e.target.value.slice(0, 40);
    saveProfile(p);
  });
  document.getElementById('pp_goals')?.addEventListener('input', e => {
    p.goals = e.target.value.slice(0, 500);
    saveProfile(p);
  });
  document.getElementById('pp_primaryUse')?.addEventListener('change', e => {
    p.primaryUse = e.target.value;
    saveProfile(p);
  });
  document.getElementById('pp_role')?.addEventListener('change', e => {
    p.role = e.target.value;
    saveProfile(p);
  });
  document.getElementById('pp_retainDays')?.addEventListener('change', async e => {
    const val = Math.max(7, Math.min(365, Number(e.target.value) || 180));
    e.target.value = val;
    p.retainDays = val;
    saveProfile(p);
    // Re-render chart with new window
    const chartEl = document.getElementById('pp_metricsChart');
    if (chartEl) chartEl.innerHTML = await renderMetricsChart(Math.min(val, 60), val);
  });

  // Import button opens hidden file input
  document.getElementById('pp_importMetrics')?.addEventListener('click', () => {
    document.getElementById('pp_importMetricsFile')?.click();
  });
  document.getElementById('pp_importMetricsFile')?.addEventListener('change', async e => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      // Reject oversized files before reading — max 2 MB for metrics JSON/CSV
      if (file.size > 2_000_000) throw new Error(
        `Metrics file is too large (${(file.size/1e6).toFixed(1)} MB). Max: 2 MB.`
      );
      const text = await file.text();
      let records;
      if (file.name.endsWith('.csv')) {
        records = _parseMetricsCsv(text);
      } else {
        const parsed = JSON.parse(text);
        records = Array.isArray(parsed) ? parsed : parsed.records ?? parsed.data ?? [];
      }
      // Cap record count to prevent runaway imports
      if (!Array.isArray(records)) throw new Error('Metrics file must contain a JSON array or CSV rows.');
      if (records.length > 1_000) throw new Error(
        `Too many records (${records.length}). Max allowed: 1,000 per import.`
      );
      const result = await importExternalMetrics(records, file.name.replace(/\.[^.]+$/, ''), p.retainDays ?? 180);
      notify.success(`Imported ${result.imported} day${result.imported !== 1 ? 's' : ''} of metrics from ${esc(file.name)}.${result.errors.length ? ` ${result.errors.length} records skipped.` : ''}`);
      // Refresh chart
      const chartEl = document.getElementById('pp_metricsChart');
      if (chartEl) chartEl.innerHTML = await renderMetricsChart(Math.min(p.retainDays ?? 180, 60), p.retainDays ?? 180);
    } catch (err) {
      notify.error(`Could not import metrics: ${err.message}`);
    }
    e.target.value = ''; // reset so same file can be reimported
  });
  // Emoji picker: cycle through a small curated set on each click
  const AVATAR_EMOJIS = ['🧘','🎯','🏋','⚡','🌊','🔥','🎸','🌙','🦋','🐉','✨','💎'];
  document.getElementById('pp_emojiBtn')?.addEventListener('click', () => {
    const idx = (AVATAR_EMOJIS.indexOf(p.avatarEmoji) + 1) % AVATAR_EMOJIS.length;
    p.avatarEmoji = AVATAR_EMOJIS[idx];
    saveProfile(p);
    // Update the inner styled div, NOT btn.textContent — that would strip .pc2-avatar-btn
    const inner = document.querySelector('#pp_emojiBtn .pc2-avatar-btn');
    if (inner) inner.textContent = p.avatarEmoji;
    updateMenubarAvatar(p);
  });

  document.getElementById('clearProfileBtn')?.addEventListener('click', async () => {
    const first = await notify.confirm(
      'This will permanently erase your profile, all session history, XP, achievements, and streaks. Are you sure?',
      { confirmLabel: 'Yes, erase everything', danger: true }
    );
    if (!first) return;
    const second = await notify.confirm(
      "Are you really, really sure? 🥺 This cannot be undone — your streak, level, and all achievements will be gone forever.",
      { confirmLabel: 'Yes, I\'m sure', danger: true }
    );
    if (!second) return;
    clearProfile();
    await clearStoredAnalytics();
    await clearMetricsHistory();
    await renderProfilePanel(containerId);
    notify.success('Profile cleared. Starting fresh.');
  });

  document.getElementById('pp_restartOnboarding')?.addEventListener('click', () => {
    window.dispatchEvent(new CustomEvent('ass:restartOnboarding'));
    notify.info('Replaying onboarding tutorial…');
  });

  document.getElementById('pp_resetSettings')?.addEventListener('click', async () => {
    const confirmed = await notify.confirm(
      'Reset all settings to their defaults? Your session content and profile data will not be affected.',
      { confirmLabel: 'Reset settings', danger: false }
    );
    if (!confirmed) return;
    const { defaultSession, normalizeSession } = await import('./state.js');
    const { state, persist }                   = await import('./state.js');
    const { history }                          = await import('./history.js');
    const current = state.session;
    const fresh   = normalizeSession(defaultSession());
    // Preserve content (blocks, scenes, rules, etc.) — reset only settings fields
    const SETTINGS_KEYS = [
      'masterVolume', 'speechRate', 'loopMode', 'loopCount', 'runtimeMinutes',
      'theme', 'backgroundColor', 'accentColor', 'textColor', 'customThemes',
      'rampSettings', 'pacingSettings', 'hudOptions', 'displayOptions',
      'advanced', 'safetySettings', 'funscriptSettings', 'subtitleSettings',
      'tracking', 'trackingFsOptions',
    ];
    history.push();
    for (const key of SETTINGS_KEYS) {
      state.session[key] = fresh[key];
    }
    persist();
    // Re-sync the open settings dialog if present
    const { syncSettingsForms } = await import('./ui.js');
    syncSettingsForms();
    notify.success('Settings reset to defaults.');
  });
}

// ── CSV import helper ─────────────────────────────────────────────────────────
// Accepts a simple CSV with a header row. Recognised columns:
//   date, totalRuntimeSec, avgIntensityPct, avgEngagement, avgAttentionStability, sessionCount
function _parseMetricsCsv(text) {
  const lines = text.trim().split(/\r?\n/);
  if (lines.length < 2) return [];
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  return lines.slice(1).map(line => {
    const cols = line.split(',');
    const rec = {};
    headers.forEach((h, i) => {
      const v = cols[i]?.trim() ?? '';
      if (h === 'date') rec.date = v;
      else {
        const n = Number(v);
        if (!isNaN(n) && v !== '') rec[h] = n;
      }
    });
    return rec;
  }).filter(r => r.date);
}
