# Smoke Test Checklist — Adaptive Session Studio

Run this checklist manually after any significant change. Check every item before shipping.

**How to run:** Open `index.html` in a browser (requires a local HTTP server — e.g. `npx serve .` or VS Code Live Server). Open DevTools console and watch for errors throughout.

---

## 0. Pre-flight

- [ ] Open `tests/index.html` on the same server — all automated unit tests pass (green banner)
- [ ] Open `tests/boot-smoke.html` on the same server — all boot smoke checks pass (green summary)
  - This catches startup-breaking module errors (duplicate imports, missing exports) that the unit runner does not exercise
- [ ] Open `index.html` — no red console errors on load

---

## 1. Session lifecycle

- [ ] **New session** — click New Session → confirm dialog appears → session resets to empty  
  - Loop toggle shows `↺ Off` (or `↺ Loop` depending on default)
  - Master volume slider reflects `defaultSession().masterVolume`
  - `tTotal` shows correct duration
  - Sidebar block list shows "No blocks"
  - Inspector shows "Select a block"

- [ ] **Load sample** — click Load Sample → confirm dialog → sample loads  
  - Loop toggle text matches `loopMode` of sample session
  - Sidebar shows sample blocks sorted by start time

- [ ] **Export** — click Export → `.assp` file downloads, filename matches session name

- [ ] **Import** — import the exported file  
  - Session restores exactly (name, blocks, playlists)
  - Loop toggle, master volume slider, and tTotal all update immediately (no stale state)
  - Console shows no errors

---

## 2. Audio playlist tracks

- [ ] Add an audio file via the audio playlist section
  - Track appears in sidebar with name and `●` mute button
  - **Click track** → audio track inspector opens
    - **Preview section** shows an `<audio controls>` player — press ▶ to verify the correct file plays
    - **Size badge** shows estimated MB embedded
    - Edit name → sidebar label updates
    - Change volume → persists
  - **Mute** button toggles (● ↔ ✕) and persists after reload

- [ ] **Ctrl+Z after delete** — deleted audio track is restored

- [ ] **Ctrl+Z after mute toggle** — mute state is restored

- [ ] Start playback with an audio track present  
  - Toggle mute during playback → audio silences/resumes immediately (no restart required)
  - **Delete** a track during playback → audio stops immediately; UI shows track gone

---

## 3. Video/image playlist tracks

- [ ] Add a video or image file
  - Track appears in sidebar with kind badge (`vid` / `image`)
  - **Click track** → video track inspector opens
    - **Image**: thumbnail shown in inspector — correct image visible
    - **Video**: `<video controls>` preview visible — pressing ▶ shows the correct video
    - **Size badge** shows estimated MB embedded
    - Mute audio toggle persists
    - Volume change persists
  - **Delete** a video track during playback → background video disappears immediately

---

## 4. Subtitle tracks

- [ ] Import a `.ass` file
  - Track appears in sidebar with cue count badge
  - **Enable/disable** toggle (`●` / `✕`) works — Ctrl+Z restores
  - **Delete** works — Ctrl+Z restores
  - **Click track** → subtitle inspector opens (cues, styles, Export .ass, Remove)
  - **Export .ass** downloads file

- [ ] Import two subtitle tracks → delete the first → second track's delete still targets the correct track (ID-based, not index-based)

---

## 5. FunScript tracks

- [ ] Import a `.funscript` file
  - Track appears in sidebar with point count badge
  - **Enable/disable** toggle works
  - **Delete** works
  - **Click track** → FunScript inspector opens (Track info, Global settings, Device, Export, Remove)
  - **Export .funscript** downloads file
  - Removing first track when two tracks loaded → second track's controls target the correct track

---

## 6. Loop mode consistency

Change loop mode via each of the three paths and confirm the other two stay in sync:

- [ ] **Transport bar toggle** (↺ Off / ↺ Loop / ↺ Min / ↺ ∞) → all four modes reachable, Settings and inspector stay in sync
- [ ] **Session inspector** loop mode select → transport bar loop toggle updates immediately
- [ ] **Settings dialog** loop mode select → close Settings → transport bar loop toggle updates

---

## 7. Settings dialog

- [ ] Open Settings → slider values and text fields match current session state (no stale readouts)
- [ ] **Master volume** — slider present in Playback tab. Change it → master volume transport slider in the bottom bar reflects the new value immediately. Change the transport slider → Settings dialog slider updates if open.
- [ ] Change theme in Settings → stage background and accent colors update live
- [ ] Open Settings, start webcam tracking → close Settings (any method: Done, ✕, ESC) → camera light goes off
- [ ] **Device WebSocket URL** — change the URL in FunScript tab → close → reopen Settings → saved URL is restored (persisted in `session.advanced.deviceWsUrl`, survives export/import)

---

## 8. Undo / Redo

- [ ] Edit a block label → Ctrl+Z → label reverts
- [ ] Delete a block → Ctrl+Z → block is restored
- [ ] Mute an audio track → Ctrl+Z → mute state reverts
- [ ] Delete a subtitle track → Ctrl+Z → track is restored
- [ ] Undo button is disabled when stack is empty; Redo button same

---

## 9. Playback

- [ ] Space / Play button starts playback
- [ ] Space / Pause button pauses
- [ ] Stop button stops and resets progress bar to 0
- [ ] Progress bar click seeks during playback
- [ ] Shift+click on progress bar scrubs preview without starting playback
- [ ] `←` `→` skip ±10s; `↑` `↓` skip ±30s
- [ ] ESC × 2 within 1.2s triggers emergency stop (🛑 EMERGENCY STOP appears in HUD for 4s)
- [ ] Playback stops cleanly — no orphaned audio after stop

---

## 10. FunScript editor (edit mode)

- [ ] Press `E` or click Edit button → edit mode activates, transform bar appears
- [ ] Click on canvas → point added
- [ ] Drag point → point follows cursor, no wrong-point jumps across neighbors
- [ ] Shift+click points → multi-select (outlined dots)
- [ ] Drag any selected point → all selected move by same delta
- [ ] `A` key → all points selected
- [ ] Transform bar → apply time/position scale or offset → points update

---

## 11. Storage

- [ ] Reload page → session restores from localStorage exactly (blocks, playlists, tracks)
- [ ] Empty session (New Session, no blocks added) → reload → stays empty (does NOT rehydrate to sample)

---

## Known deferred items (do not flag as failures)

- Crossfade between playlist tracks: implemented in audio engine and configurable via Settings → Playback → Crossfade (sec). No playlist-swap UI gesture yet.
- Automated test coverage for `main.js`, `playback.js`, `ui.js`, `tracking.js`, `audio-engine.js`, `macros.js`, `session-analytics.js`, `session-modes.js`, `suggestions.js`, `notify.js`, `fullscreen-hud.js`, `capabilities.js`, `live-control.js`, `ai-authoring.js`: pending (DOM/integration-heavy; not exercised by the unit test runner in `tests/index.html`)

---

## 12. Rules engine

- [ ] Open Sidebar → Rules section → click to open inspector
- [ ] "No rules yet" shown when empty
- [ ] **Add rule** → row appears with name, metric, op, value, duration, action, cooldown
- [ ] Edit name → persists
- [ ] Change metric (attention / intensity / engagement / sessionTime / loopCount) → saves
- [ ] Set action to `setIntensity` → param field appears
- [ ] Enable/disable checkbox → badge count updates
- [ ] Start playback → if attention < threshold for duration → action fires
- [ ] Ctrl+Z undoes rule add/delete

## 13. State engine live meters

- [ ] Start playback with webcam tracking active
- [ ] Live Control panel shows three meters: FS Out, Attention, Engage
- [ ] Status tab (▶ icon tab) shows Attention and Engagement stat cards
- [ ] Attention meter rises when face detected, decays smoothly when face leaves frame
- [ ] Engagement follows attention with ~3s smoothing
