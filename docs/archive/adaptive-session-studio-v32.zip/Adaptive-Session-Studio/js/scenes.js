// ── scenes.js ───────────────────────────────────────────────────────────────
// Scene system — ROADMAP Phase 3.3.
// Scenes are named time ranges within the session with optional per-scene
// loop behavior. They appear as colored bands on the FunScript timeline and
// can be jumped to during playback via the "Next Scene" transport button.

import { state, persist, $id, uid, esc, clampInt, fmt,
         normalizeScene } from './state.js';
import { notify } from './notify.js';
import { history } from './history.js';
import { skipToScene } from './playback.js';

// Lazy: ui.js imports scenes.js, so we can't import it statically here.
// Call syncTransportControls after scene mutations so the Next Scene button
// appears/disappears immediately without requiring a full sidebar re-render.
function _syncTransport() {
  import('./ui.js').then(({ syncTransportControls }) => syncTransportControls());
}

// ── Scene CRUD ───────────────────────────────────────────────────────────────

export function addScene() {
  history.push();
  const lastEnd = state.session.scenes.length
    ? Math.max(...state.session.scenes.map(s => s.end))
    : 0;
  const start = lastEnd;
  const end   = Math.min(start + 60, state.session.duration);
  if (start >= state.session.duration) {
    notify.warn('Session is full — extend the duration before adding more scenes.');
    return;
  }
  const scene = normalizeScene({ start, end, name: `Scene ${state.session.scenes.length + 1}` });
  state.session.scenes.push(scene);
  persist();
  _syncTransport();
  renderSceneList();
}

export function deleteScene(sceneId) {
  history.push();
  state.session.scenes = state.session.scenes.filter(s => s.id !== sceneId);
  persist();
  _syncTransport();
  renderSceneList();
}

export function updateScene(sceneId, patch) {
  const scene = state.session.scenes.find(s => s.id === sceneId);
  if (!scene) return;
  Object.assign(scene, patch);
  // Enforce valid timing after patch — re-run normalizeScene on the timing fields
  if ('start' in patch || 'end' in patch) {
    const start = Math.max(0, Math.min(86400, scene.start ?? 0));
    scene.start = start;
    scene.end   = Math.max(start + 1, Math.min(86400, scene.end ?? start + 60));
  }
  persist();
}

// ── Next-scene button ────────────────────────────────────────────────────────
// Jumps to the scene after the currently-playing one.

export function skipToNextScene() {
  const { runtime, session } = state;
  if (!session.scenes?.length) return;

  const sorted = [...session.scenes].sort((a, b) => a.start - b.start);
  const t = runtime ? runtime.sessionTime : 0;

  // Find the next scene that starts after current time
  const next = sorted.find(s => s.start > t + 0.5);
  if (next) {
    skipToScene(next.id);
    notify.info(`→ ${next.name}`);
  } else {
    // Wrap around to the first scene
    const first = sorted[0];
    if (first) { skipToScene(first.id); notify.info(`↩ ${first.name}`); }
  }
}

// ── Scene list renderer (for inspector / settings panel) ─────────────────────

export function renderSceneList(containerId = 'sceneListBody') {
  const el = $id(containerId);
  if (!el) return;

  const scenes = [...state.session.scenes].sort((a, b) => a.start - b.start);
  if (!scenes.length) {
    el.innerHTML = '<div style="font-size:11px;color:var(--text3);padding:8px 0">No scenes defined. Add one to divide the session into named segments.</div>';
    return;
  }

  el.innerHTML = scenes.map(sc => `
    <div class="scene-row" data-scene-id="${sc.id}" style="
      display:flex;flex-direction:column;gap:4px;margin-bottom:6px;
      padding:7px 8px;border-radius:6px;
      background:rgba(255,255,255,0.03);border:0.5px solid rgba(255,255,255,0.07)">
      <div style="display:flex;align-items:center;gap:6px">
        <input type="color" class="scene-color" data-scene-id="${sc.id}" value="${sc.color}"
          style="width:18px;height:18px;border:none;border-radius:50%;padding:0;cursor:pointer;
                 background:transparent;flex-shrink:0" title="Scene color" />
        <input type="text" class="scene-name" data-scene-id="${sc.id}" value="${esc(sc.name)}"
          style="flex:1;font-size:11px;background:transparent;border:none;color:var(--text);min-width:0" />
        <select class="scene-loop" data-scene-id="${sc.id}" style="font-size:10px;width:50px">
          <option value="once"${sc.loopBehavior==='once'?' selected':''}>once</option>
          <option value="loop"${sc.loopBehavior==='loop'?' selected':''}>loop</option>
        </select>
        <button class="scene-del" data-scene-id="${sc.id}"
          style="background:transparent;border:none;color:var(--danger,#e05050);cursor:pointer;font-size:14px;padding:0;line-height:1"
          title="Delete scene">×</button>
      </div>
      <div style="display:flex;align-items:center;gap:4px;font-size:10.5px;color:var(--text3)">
        <span>Start</span>
        <input type="number" class="scene-start" data-scene-id="${sc.id}" value="${sc.start}"
          min="0" max="${state.session.duration - 1}" step="1"
          style="width:55px;font-size:10.5px" title="Start time in seconds" />
        <span>—</span>
        <span>End</span>
        <input type="number" class="scene-end" data-scene-id="${sc.id}" value="${sc.end}"
          min="1" max="${state.session.duration}" step="1"
          style="width:55px;font-size:10.5px" title="End time in seconds" />
        <span style="margin-left:4px;color:var(--text3)">s · ${fmt(sc.end - sc.start)} long</span>
      </div>
    </div>`).join('');

  // Wire events
  el.querySelectorAll('.scene-color').forEach(inp => {
    inp.addEventListener('input', e => {
      updateScene(e.target.dataset.sceneId, { color: e.target.value });
      import('./funscript.js').then(({ drawTimeline }) => drawTimeline());
    });
  });
  el.querySelectorAll('.scene-name').forEach(inp => {
    inp.addEventListener('input', e => {
      updateScene(e.target.dataset.sceneId, { name: e.target.value });
    });
  });
  el.querySelectorAll('.scene-start').forEach(inp => {
    inp.addEventListener('change', e => {
      history.push();
      const newStart = Math.max(0, Number(e.target.value));
      updateScene(e.target.dataset.sceneId, { start: newStart });
      renderSceneList(containerId); // re-render to refresh duration display
      import('./funscript.js').then(({ drawTimeline }) => drawTimeline());
    });
  });
  el.querySelectorAll('.scene-end').forEach(inp => {
    inp.addEventListener('change', e => {
      history.push();
      const newEnd = Math.min(state.session.duration, Math.max(1, Number(e.target.value)));
      updateScene(e.target.dataset.sceneId, { end: newEnd });
      renderSceneList(containerId);
      import('./funscript.js').then(({ drawTimeline }) => drawTimeline());
    });
  });
  el.querySelectorAll('.scene-loop').forEach(sel => {
    sel.addEventListener('change', e => {
      history.push();
      updateScene(e.target.dataset.sceneId, { loopBehavior: e.target.value });
    });
  });
  el.querySelectorAll('.scene-del').forEach(btn => {
    btn.addEventListener('click', e => {
      deleteScene(e.target.dataset.sceneId);
    });
  });
}

// ── Scene inspector panel (rendered inside the overlay inspector tab) ──────────
export function renderSceneInspector() {
  return `
    <div class="insp-block-name">🎬 Scenes</div>
    <p style="font-size:11px;color:var(--text2);line-height:1.6;margin-bottom:10px">
      Divide the session into named segments. Each scene can have its own loop
      behavior. Use Next Scene (→) during playback to jump forward.
    </p>
    <div id="sceneListBody"></div>
    <div style="display:flex;gap:6px;margin-top:8px">
      <button id="addSceneBtn" style="flex:1;font-size:11px">+ Add scene</button>
    </div>
    <div style="margin-top:10px">
      <div class="insp-group-label">About scenes</div>
      <p style="font-size:10.5px;color:var(--text3);line-height:1.5">
        Scenes appear as colored bands on the FunScript timeline. Edit start/end times
        directly in the fields above, or drag scene markers on the timeline canvas.
        Click the color swatch to change a scene's color.
      </p>
    </div>`;
}

export function attachSceneInspectorEvents() {
  renderSceneList('sceneListBody');
  $id('addSceneBtn')?.addEventListener('click', addScene);
}

// ── skipToNextScene ──────────────────────────────────────────────────────────
// Exported for keyboard shortcut (N key) and next-scene button.
// The authoritative scene-band rendering lives in funscript.js drawOverviewLane.
