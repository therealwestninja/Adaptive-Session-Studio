(() => {
  const STORAGE_KEY = 'adaptive-session-studio-v3';
  const PACKAGE_VERSION = 3;

  const builtinThemes = {
    midnight: { name: 'Midnight', backgroundColor: '#05070a', accentColor: '#7fb0ff', textColor: '#eef4fb' },
    ember: { name: 'Ember', backgroundColor: '#160909', accentColor: '#ff9f71', textColor: '#fff0ea' },
    moss: { name: 'Moss', backgroundColor: '#07130b', accentColor: '#9be7a1', textColor: '#eefcf1' },
    violet: { name: 'Violet', backgroundColor: '#100916', accentColor: '#c8a4ff', textColor: '#f4ebff' }
  };

  const defaultSession = () => ({
    packageVersion: PACKAGE_VERSION,
    name: 'adaptive_session',
    duration: 180,
    theme: 'midnight',
    customThemes: {},
    masterVolume: 0.8,
    speechRate: 1,
    loopMode: 'count',
    loopCount: 1,
    runtimeMinutes: 10,
    backgroundColor: builtinThemes.midnight.backgroundColor,
    accentColor: builtinThemes.midnight.accentColor,
    textColor: builtinThemes.midnight.textColor,
    advanced: {
      stageBlur: 0,
      fontFamily: 'Inter, system-ui, Arial, sans-serif',
      crossfadeSeconds: 0.6,
      playlistAudioVolume: 0.7,
      playlistVideoVolume: 0.6,
      autoResumeOnAttentionReturn: false
    },
    tracking: {
      enabled: false,
      autoPauseOnAttentionLoss: false,
      attentionThreshold: 5
    },
    playlists: { audio: [], video: [] },
    blocks: []
  });

  const sampleSession = () => ({
    ...defaultSession(),
    name: 'grounded_focus_package',
    duration: 120,
    loopCount: 2,
    speechRate: 0.95,
    blocks: [
      { id: uid(), type: 'text', label: 'Settle', start: 0, duration: 12, content: 'Settle in. Let your breathing slow.', fontSize: 1.2 },
      { id: uid(), type: 'tts', label: 'Opening cue', start: 14, duration: 10, content: 'You can take your time. There is no need to rush.', volume: 0.9, voiceName: '' },
      { id: uid(), type: 'text', label: 'Anchor words', start: 34, duration: 12, content: 'Steady.\nClear.\nPresent.', fontSize: 1.55 },
      { id: uid(), type: 'pause', label: 'Spacing', start: 52, duration: 8, content: '' },
      { id: uid(), type: 'tts', label: 'Closing cue', start: 68, duration: 12, content: 'Carry the same steadiness into your next action.', volume: 0.9, voiceName: '' }
    ]
  });

  const $ = (id) => document.getElementById(id);
  const refs = {
    sessionName: $('sessionName'), sessionDuration: $('sessionDuration'), themeSelect: $('themeSelect'), masterVolume: $('masterVolume'), speechRate: $('speechRate'),
    loopMode: $('loopMode'), loopCount: $('loopCount'), runtimeMinutes: $('runtimeMinutes'), backgroundColor: $('backgroundColor'), accentColor: $('accentColor'), textColor: $('textColor'),
    audioTrackList: $('audioTrackList'), videoTrackList: $('videoTrackList'), timelineBody: $('timelineBody'), blockEditor: $('blockEditor'), timelineOverview: $('timelineOverview'), jsonPreview: $('jsonPreview'),
    timeDisplay: $('timeDisplay'), loopDisplay: $('loopDisplay'), activeBlockDisplay: $('activeBlockDisplay'), attentionDisplay: $('attentionDisplay'),
    previewStage: $('previewStage'), backgroundHost: $('backgroundHost'), overlayText: $('overlayText'), stageHud: $('stageHud'),
    trackingEnabled: $('trackingEnabled'), autoPauseOnAttentionLoss: $('autoPauseOnAttentionLoss'), attentionThreshold: $('attentionThreshold'), trackingPreview: $('trackingPreview'), trackingOverlay: $('trackingOverlay'),
    cameraStatus: $('cameraStatus'), faceStatus: $('faceStatus'), facePosition: $('facePosition'), attentionLossDisplay: $('attentionLossDisplay'),
    advancedDialog: $('advancedDialog'), stageBlur: $('stageBlur'), fontFamily: $('fontFamily'), crossfadeSeconds: $('crossfadeSeconds'), playlistAudioVolume: $('playlistAudioVolume'), playlistVideoVolume: $('playlistVideoVolume'), autoResumeOnAttentionReturn: $('autoResumeOnAttentionReturn'),
    customThemeKey: $('customThemeKey'), customThemeName: $('customThemeName'), customThemeBg: $('customThemeBg'), customThemeAccent: $('customThemeAccent'), customThemeText: $('customThemeText')
  };

  let session = loadSession();
  let selectedBlockId = session.blocks[0]?.id || null;
  let runtime = null;
  let tracking = makeTrackingModule();

  function uid() {
    return 'b_' + Math.random().toString(36).slice(2, 10);
  }

  function titleCase(str) {
    return String(str || '').replace(/(^|[_\s-])(\w)/g, (_, a, b) => `${a}${b.toUpperCase()}`);
  }

  function clampInt(value, min, max, fallback) {
    const num = Number(value);
    if (!Number.isFinite(num)) return fallback;
    return Math.min(max, Math.max(min, Math.round(num)));
  }

  function escapeHtml(str) {
    return String(str || '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
  }

  function loadSession() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? normalizeSession(JSON.parse(raw)) : normalizeSession(sampleSession());
    } catch {
      return normalizeSession(sampleSession());
    }
  }

  function normalizeSession(input) {
    const base = defaultSession();
    const merged = {
      ...base,
      ...input,
      tracking: { ...base.tracking, ...(input?.tracking || {}) },
      playlists: {
        audio: Array.isArray(input?.playlists?.audio) ? input.playlists.audio : [],
        video: Array.isArray(input?.playlists?.video) ? input.playlists.video : []
      },
      advanced: { ...base.advanced, ...(input?.advanced || {}) },
      customThemes: { ...(input?.customThemes || {}) },
      blocks: Array.isArray(input?.blocks) ? input.blocks.map(normalizeBlock) : []
    };
    if (!merged.blocks.length) merged.blocks = sampleSession().blocks;
    return merged;
  }

  function normalizeBlock(block, index = 0) {
    return {
      id: block?.id || uid(),
      type: block?.type || 'text',
      label: block?.label || `Block ${index + 1}`,
      start: clampInt(block?.start ?? 0, 0, 86400, 0),
      duration: clampInt(block?.duration ?? 10, 1, 86400, 10),
      content: block?.content || '',
      fontSize: Number(block?.fontSize ?? 1.2),
      volume: Number(block?.volume ?? 1),
      voiceName: block?.voiceName || '',
      dataUrl: block?.dataUrl || '',
      dataUrlName: block?.dataUrlName || '',
      mediaKind: block?.mediaKind || '',
      mute: block?.mute !== false
    };
  }

  function getThemeMap() {
    return { ...builtinThemes, ...session.customThemes };
  }

  function rebuildThemeSelect() {
    const themes = getThemeMap();
    refs.themeSelect.innerHTML = Object.entries(themes).map(([key, value]) => `<option value="${key}">${escapeHtml(value.name)}</option>`).join('');
    if (!themes[session.theme]) session.theme = 'midnight';
    refs.themeSelect.value = session.theme;
  }

  function applyTheme(themeKey) {
    const theme = getThemeMap()[themeKey];
    if (!theme) return;
    session.theme = themeKey;
    session.backgroundColor = theme.backgroundColor;
    session.accentColor = theme.accentColor;
    session.textColor = theme.textColor;
    applyCssVars();
    syncForm();
    persist();
  }

  function applyCssVars() {
    document.documentElement.style.setProperty('--bg', session.backgroundColor);
    document.documentElement.style.setProperty('--accent', session.accentColor);
    document.documentElement.style.setProperty('--text', session.textColor);
    document.documentElement.style.setProperty('--overlay-font', session.advanced.fontFamily);
    document.documentElement.style.setProperty('--stage-blur', `${session.advanced.stageBlur}px`);
    refs.previewStage.style.background = session.backgroundColor;
    refs.overlayText.style.color = session.textColor;
  }

  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
    refs.jsonPreview.value = JSON.stringify(session, null, 2);
  }

  function saveAndRender() {
    persist();
    renderAll();
  }

  function syncForm() {
    refs.sessionName.value = session.name;
    refs.sessionDuration.value = session.duration;
    refs.masterVolume.value = session.masterVolume;
    refs.speechRate.value = session.speechRate;
    refs.loopMode.value = session.loopMode;
    refs.loopCount.value = session.loopCount;
    refs.runtimeMinutes.value = session.runtimeMinutes;
    refs.backgroundColor.value = session.backgroundColor;
    refs.accentColor.value = session.accentColor;
    refs.textColor.value = session.textColor;
    refs.trackingEnabled.checked = session.tracking.enabled;
    refs.autoPauseOnAttentionLoss.checked = session.tracking.autoPauseOnAttentionLoss;
    refs.attentionThreshold.value = session.tracking.attentionThreshold;
    refs.stageBlur.value = session.advanced.stageBlur;
    refs.fontFamily.value = session.advanced.fontFamily;
    refs.crossfadeSeconds.value = session.advanced.crossfadeSeconds;
    refs.playlistAudioVolume.value = session.advanced.playlistAudioVolume;
    refs.playlistVideoVolume.value = session.advanced.playlistVideoVolume;
    refs.autoResumeOnAttentionReturn.checked = session.advanced.autoResumeOnAttentionReturn;
    rebuildThemeSelect();
    refs.themeSelect.value = session.theme;
  }

  function renderAll() {
    applyCssVars();
    renderPlaylists();
    renderTimelineTable();
    renderTimelineOverview();
    renderBlockEditor();
    refreshRuntimeDisplays();
  }

  function renderPlaylists() {
    refs.audioTrackList.innerHTML = session.playlists.audio.map((track, index) => playlistItem(track, index, 'audio')).join('');
    refs.videoTrackList.innerHTML = session.playlists.video.map((track, index) => playlistItem(track, index, 'video')).join('');
  }

  function playlistItem(track, index, kind) {
    return `<li class="track-item">
      <div class="track-top">
        <strong>${escapeHtml(track.name || `${titleCase(kind)} ${index + 1}`)}</strong>
        <div class="track-actions">
          <button data-track-kind="${kind}" data-track-index="${index}" data-track-action="up">↑</button>
          <button data-track-kind="${kind}" data-track-index="${index}" data-track-action="down">↓</button>
          ${kind === 'video' ? `<button data-track-kind="${kind}" data-track-index="${index}" data-track-action="mute">${track.mute ? 'Unmute' : 'Mute'}</button>` : ''}
          <button data-track-kind="${kind}" data-track-index="${index}" data-track-action="remove">Remove</button>
        </div>
      </div>
      <div class="track-meta">${kind === 'video' ? `${track.mediaKind || 'video'} • ${track.mute ? 'muted' : 'with audio'}` : 'looping playlist item'}</div>
    </li>`;
  }

  function renderTimelineTable() {
    const rows = [...session.blocks].sort((a, b) => a.start - b.start).map((block, index) => {
      const end = block.start + block.duration;
      const snippet = block.content ? block.content.slice(0, 140) : '';
      const active = block.id === selectedBlockId ? 'active' : '';
      return `<tr class="timeline-row ${active}" data-block-id="${block.id}">
        <td>${index + 1}</td>
        <td><input data-row-field="start" type="number" min="0" step="1" value="${block.start}" /></td>
        <td><input data-row-field="end" type="number" min="1" step="1" value="${end}" /></td>
        <td><input data-row-field="duration" type="number" min="1" step="1" value="${block.duration}" /></td>
        <td>
          <select data-row-field="type">
            ${['text','tts','audio','video','pause'].map((type) => `<option value="${type}" ${block.type === type ? 'selected' : ''}>${titleCase(type)}</option>`).join('')}
          </select>
        </td>
        <td><input data-row-field="label" type="text" value="${escapeHtml(block.label)}" /></td>
        <td><textarea data-row-field="content">${escapeHtml(snippet)}</textarea></td>
        <td>
          <div class="row-actions">
            <button data-row-action="select">Edit</button>
            <button data-row-action="dup">Copy</button>
            <button data-row-action="up">↑</button>
            <button data-row-action="down">↓</button>
          </div>
        </td>
      </tr>`;
    }).join('');
    refs.timelineBody.innerHTML = rows;
  }

  function renderTimelineOverview() {
    const duration = Math.max(1, session.duration);
    refs.timelineOverview.innerHTML = session.blocks.map((block) => {
      const top = (block.start / duration) * 100;
      const height = Math.max(6, (block.duration / duration) * 100);
      return `<div class="timeline-pill" style="top:${top}%;height:${height}%;border-color:${session.accentColor};">${escapeHtml(block.label)} · ${block.start}s</div>`;
    }).join('');
  }

  function renderBlockEditor() {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    if (!block) {
      refs.blockEditor.innerHTML = '<p class="muted">Select a script row to edit it in detail.</p>';
      return;
    }
    refs.blockEditor.innerHTML = `
      <label>Label<input data-field="label" type="text" value="${escapeHtml(block.label)}" /></label>
      <div class="block-field-grid">
        <label>Start (sec)<input data-field="start" type="number" min="0" step="1" value="${block.start}" /></label>
        <label>Duration (sec)<input data-field="duration" type="number" min="1" step="1" value="${block.duration}" /></label>
      </div>
      <label>Type<select data-field="type">${['text','tts','audio','video','pause'].map((type) => `<option value="${type}" ${block.type === type ? 'selected' : ''}>${titleCase(type)}</option>`).join('')}</select></label>
      ${typeSpecificEditor(block)}
    `;
    refs.blockEditor.querySelectorAll('[data-field]').forEach((node) => {
      node.addEventListener('input', handleBlockFieldChange);
      node.addEventListener('change', handleBlockFieldChange);
    });
    refs.blockEditor.querySelectorAll('[data-file-field]').forEach((node) => node.addEventListener('change', handleBlockFileFieldChange));
  }

  function typeSpecificEditor(block) {
    switch (block.type) {
      case 'text':
        return `<label>Content<textarea data-field="content" rows="6">${escapeHtml(block.content)}</textarea></label>
          <label>Font size multiplier<input data-field="fontSize" type="number" min="0.6" max="4" step="0.05" value="${block.fontSize ?? 1.2}" /></label>`;
      case 'tts':
        return `<label>Spoken content<textarea data-field="content" rows="6">${escapeHtml(block.content)}</textarea></label>
          <div class="block-field-grid">
            <label>Volume<input data-field="volume" type="number" min="0" max="1" step="0.05" value="${block.volume ?? 1}" /></label>
            <label>Voice name<input data-field="voiceName" type="text" value="${escapeHtml(block.voiceName || '')}" placeholder="Optional system voice name" /></label>
          </div>`;
      case 'audio':
        return `<label>Caption / note<textarea data-field="content" rows="4">${escapeHtml(block.content)}</textarea></label>
          <label>Volume<input data-field="volume" type="number" min="0" max="1" step="0.05" value="${block.volume ?? 1}" /></label>
          <label>Audio file<input data-file-field="dataUrl" type="file" accept="audio/*" /></label>
          <p class="small muted">${block.dataUrlName ? `Current: ${escapeHtml(block.dataUrlName)}` : 'No audio selected.'}</p>`;
      case 'video':
        return `<label>Caption / note<textarea data-field="content" rows="4">${escapeHtml(block.content)}</textarea></label>
          <div class="block-field-grid">
            <label>Mute audio<select data-field="mute"><option value="true" ${block.mute !== false ? 'selected' : ''}>Yes</option><option value="false" ${block.mute === false ? 'selected' : ''}>No</option></select></label>
            <label>Overlay text size<input data-field="fontSize" type="number" min="0.6" max="4" step="0.05" value="${block.fontSize ?? 1.1}" /></label>
          </div>
          <label>Visual file<input data-file-field="dataUrl" type="file" accept="video/*,image/*" /></label>
          <p class="small muted">${block.dataUrlName ? `Current: ${escapeHtml(block.dataUrlName)}` : 'No visual selected.'}</p>`;
      case 'pause':
      default:
        return '<p class="muted">Pause blocks intentionally leave the stage quiet while playlist layers keep their own state.</p>';
    }
  }

  function refreshRuntimeDisplays() {
    if (!runtime) {
      refs.timeDisplay.textContent = `00:00 / ${fmt(session.duration)}`;
      refs.loopDisplay.textContent = session.loopMode === 'count' ? `1 / ${session.loopCount}` : '—';
      refs.activeBlockDisplay.textContent = '—';
      return;
    }
    refs.timeDisplay.textContent = `${fmt(runtime.sessionTime)} / ${fmt(session.duration)}`;
    refs.loopDisplay.textContent = runtime.totalLoops ? `${runtime.loopIndex + 1} / ${runtime.totalLoops}` : `${runtime.loopIndex + 1} / ∞`;
    refs.activeBlockDisplay.textContent = runtime.activeBlock?.label || '—';
  }

  function fmt(sec) {
    const s = Math.max(0, Math.floor(sec));
    const m = Math.floor(s / 60);
    return `${String(m).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`;
  }

  function handleBlockFieldChange(e) {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    if (!block) return;
    const field = e.target.dataset.field;
    let value = e.target.value;
    if (field === 'start' || field === 'duration') value = clampInt(value, field === 'duration' ? 1 : 0, 86400, block[field]);
    if (field === 'fontSize' || field === 'volume') value = Number(value);
    if (field === 'mute') value = value === 'true';
    block[field] = value;
    saveAndRender();
  }

  async function handleBlockFileFieldChange(e) {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    const file = e.target.files?.[0];
    if (!block || !file) return;
    block.dataUrl = await fileToDataUrl(file);
    block.dataUrlName = file.name;
    block.mediaKind = file.type.startsWith('audio/') ? 'audio' : (file.type.startsWith('video/') ? 'video' : 'image');
    saveAndRender();
  }

  function addBlock(type) {
    const block = normalizeBlock({ id: uid(), type, label: `New ${titleCase(type)}`, start: estimateNextStart(), duration: type === 'pause' ? 5 : 10 }, session.blocks.length);
    session.blocks.push(block);
    selectedBlockId = block.id;
    saveAndRender();
  }

  function estimateNextStart() {
    if (!session.blocks.length) return 0;
    return Math.max(...session.blocks.map((b) => b.start + b.duration + 2));
  }

  function moveTrack(kind, index, direction) {
    const list = session.playlists[kind];
    const target = index + direction;
    if (target < 0 || target >= list.length) return;
    [list[index], list[target]] = [list[target], list[index]];
    saveAndRender();
  }

  function removeTrack(kind, index) {
    session.playlists[kind].splice(index, 1);
    saveAndRender();
  }

  function duplicateSelectedBlock() {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    if (!block) return;
    const copy = { ...structuredClone(block), id: uid(), start: block.start + block.duration + 1, label: `${block.label} copy` };
    session.blocks.push(copy);
    selectedBlockId = copy.id;
    saveAndRender();
  }

  function deleteSelectedBlock() {
    if (!selectedBlockId) return;
    session.blocks = session.blocks.filter((b) => b.id !== selectedBlockId);
    selectedBlockId = session.blocks[0]?.id || null;
    saveAndRender();
  }

  function sortBlocks() {
    session.blocks.sort((a, b) => a.start - b.start);
    saveAndRender();
  }

  function nudgeSelected(delta) {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    if (!block) return;
    block.start = Math.max(0, block.start + delta);
    saveAndRender();
  }

  function stretchSelected(delta) {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    if (!block) return;
    block.duration = Math.max(1, block.duration + delta);
    saveAndRender();
  }

  function applyRowChange(row, field, raw) {
    const block = session.blocks.find((b) => b.id === row.dataset.blockId);
    if (!block) return;
    if (field === 'end') block.duration = Math.max(1, clampInt(raw, 1, 86400, block.start + block.duration) - block.start);
    else if (field === 'start' || field === 'duration') block[field] = clampInt(raw, field === 'duration' ? 1 : 0, 86400, block[field]);
    else block[field] = raw;
    saveAndRender();
  }

  function syncSessionFromForm() {
    session.name = refs.sessionName.value.trim() || 'adaptive_session';
    session.duration = clampInt(refs.sessionDuration.value, 10, 86400, session.duration);
    session.masterVolume = Number(refs.masterVolume.value);
    session.speechRate = Number(refs.speechRate.value);
    session.loopMode = refs.loopMode.value;
    session.loopCount = clampInt(refs.loopCount.value, 1, 100000, session.loopCount);
    session.runtimeMinutes = clampInt(refs.runtimeMinutes.value, 1, 100000, session.runtimeMinutes);
    session.backgroundColor = refs.backgroundColor.value;
    session.accentColor = refs.accentColor.value;
    session.textColor = refs.textColor.value;
    session.tracking.enabled = refs.trackingEnabled.checked;
    session.tracking.autoPauseOnAttentionLoss = refs.autoPauseOnAttentionLoss.checked;
    session.tracking.attentionThreshold = clampInt(refs.attentionThreshold.value, 1, 120, session.tracking.attentionThreshold);
    session.advanced.stageBlur = clampInt(refs.stageBlur.value, 0, 24, session.advanced.stageBlur);
    session.advanced.fontFamily = refs.fontFamily.value.trim() || defaultSession().advanced.fontFamily;
    session.advanced.crossfadeSeconds = Number(refs.crossfadeSeconds.value);
    session.advanced.playlistAudioVolume = Number(refs.playlistAudioVolume.value);
    session.advanced.playlistVideoVolume = Number(refs.playlistVideoVolume.value);
    session.advanced.autoResumeOnAttentionReturn = refs.autoResumeOnAttentionReturn.checked;
    applyCssVars();
    persist();
  }

  async function handleAudioFiles(files) {
    for (const file of files) {
      session.playlists.audio.push({ name: file.name, dataUrl: await fileToDataUrl(file), volume: 1 });
    }
    saveAndRender();
  }

  async function handleVideoFiles(files) {
    for (const file of files) {
      session.playlists.video.push({ name: file.name, dataUrl: await fileToDataUrl(file), mediaKind: file.type.startsWith('image/') ? 'image' : 'video', mute: true, volume: 1 });
    }
    saveAndRender();
  }

  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function downloadPackage() {
    const blob = new Blob([JSON.stringify(session, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${session.name || 'adaptive-session'}.assp`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  async function importPackage(file) {
    const text = await file.text();
    session = normalizeSession(JSON.parse(text));
    selectedBlockId = session.blocks[0]?.id || null;
    stopPlayback();
    saveAndRender();
    syncForm();
  }

  function applyJsonPreview() {
    try {
      session = normalizeSession(JSON.parse(refs.jsonPreview.value));
      selectedBlockId = session.blocks[0]?.id || null;
      stopPlayback();
      syncForm();
      saveAndRender();
    } catch (err) {
      alert(`Invalid package JSON: ${err.message}`);
    }
  }

  function formatJsonPreview() {
    try {
      refs.jsonPreview.value = JSON.stringify(JSON.parse(refs.jsonPreview.value), null, 2);
    } catch (err) {
      alert(`Invalid JSON: ${err.message}`);
    }
  }

  function saveCustomTheme() {
    const key = refs.customThemeKey.value.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, '-');
    const name = refs.customThemeName.value.trim() || key;
    if (!key) return alert('Enter a theme key first.');
    session.customThemes[key] = {
      name,
      backgroundColor: refs.customThemeBg.value,
      accentColor: refs.customThemeAccent.value,
      textColor: refs.customThemeText.value
    };
    rebuildThemeSelect();
    applyTheme(key);
    saveAndRender();
  }

  function deleteSelectedTheme() {
    if (builtinThemes[session.theme]) return alert('Built-in themes cannot be deleted.');
    delete session.customThemes[session.theme];
    applyTheme('midnight');
    rebuildThemeSelect();
    saveAndRender();
  }

  function makeTrackingModule() {
    const overlayCtx = refs.trackingOverlay.getContext('2d');
    let stream = null;
    let detector = 'FaceDetector' in window ? new FaceDetector({ fastMode: true, maxDetectedFaces: 1 }) : null;
    let raf = 0;
    let lastSeen = performance.now();
    let wasAutoPaused = false;

    function resizeCanvas() {
      const rect = refs.trackingPreview.getBoundingClientRect();
      refs.trackingOverlay.width = rect.width;
      refs.trackingOverlay.height = rect.height;
    }

    async function start() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        refs.trackingPreview.srcObject = stream;
        refs.cameraStatus.textContent = 'Live';
        resizeCanvas();
        loop();
      } catch (err) {
        refs.cameraStatus.textContent = 'Denied';
        refs.faceStatus.textContent = 'Unavailable';
        alert(`Could not start webcam: ${err.message}`);
      }
    }

    function stop() {
      cancelAnimationFrame(raf);
      if (stream) stream.getTracks().forEach((t) => t.stop());
      stream = null;
      refs.trackingPreview.srcObject = null;
      refs.cameraStatus.textContent = 'Off';
      refs.faceStatus.textContent = 'Unknown';
      refs.facePosition.textContent = '—';
      refs.attentionLossDisplay.textContent = '0.0s';
      overlayCtx.clearRect(0, 0, refs.trackingOverlay.width, refs.trackingOverlay.height);
    }

    async function loop() {
      resizeCanvas();
      overlayCtx.clearRect(0, 0, refs.trackingOverlay.width, refs.trackingOverlay.height);
      let face = null;
      if (detector && refs.trackingPreview.readyState >= 2) {
        try {
          const faces = await detector.detect(refs.trackingPreview);
          face = faces[0] || null;
        } catch {}
      }
      if (face) {
        drawFace(face.boundingBox);
        const cx = face.boundingBox.x + face.boundingBox.width / 2;
        const cy = face.boundingBox.y + face.boundingBox.height / 2;
        refs.faceStatus.textContent = 'Detected';
        refs.facePosition.textContent = `${Math.round(cx)}, ${Math.round(cy)}`;
        refs.attentionDisplay.textContent = 'Present';
        lastSeen = performance.now();
        if (wasAutoPaused && session.advanced.autoResumeOnAttentionReturn && runtime?.pausedByAttention) resumePlayback(true);
        wasAutoPaused = false;
      } else {
        refs.faceStatus.textContent = detector ? 'Not detected' : 'Live preview only';
        const loss = (performance.now() - lastSeen) / 1000;
        refs.attentionLossDisplay.textContent = `${loss.toFixed(1)}s`;
        refs.attentionDisplay.textContent = detector ? 'Uncertain' : 'Preview only';
        if (session.tracking.enabled && session.tracking.autoPauseOnAttentionLoss && loss >= session.tracking.attentionThreshold && runtime && !runtime.paused) {
          pausePlayback(true);
          wasAutoPaused = true;
        }
      }
      raf = requestAnimationFrame(loop);
    }

    function drawFace(box) {
      const sx = refs.trackingOverlay.width / refs.trackingPreview.videoWidth;
      const sy = refs.trackingOverlay.height / refs.trackingPreview.videoHeight;
      overlayCtx.strokeStyle = session.accentColor;
      overlayCtx.lineWidth = 2;
      overlayCtx.strokeRect(box.x * sx, box.y * sy, box.width * sx, box.height * sy);
    }

    return { start, stop };
  }

  function computeTotalLoops() {
    if (session.loopMode === 'count') return Math.max(1, session.loopCount);
    if (session.loopMode === 'minutes') return Math.max(1, Math.ceil((session.runtimeMinutes * 60) / session.duration));
    if (session.loopMode === 'none') return 1;
    return null;
  }

  function startPlayback() {
    stopPlayback();
    runtime = {
      startedAt: performance.now(),
      pauseStartedAt: 0,
      totalPausedMs: 0,
      paused: false,
      pausedByAttention: false,
      sessionTime: 0,
      activeBlockId: null,
      activeBlock: null,
      triggered: new Set(),
      loopIndex: 0,
      totalLoops: computeTotalLoops(),
      raf: 0,
      speechUtterance: null,
      playingOneShots: [],
      backgroundAudio: [],
      backgroundVideo: []
    };
    startPlaylistLayers();
    tickPlayback();
  }

  function startPlaylistLayers() {
    refs.backgroundHost.innerHTML = '';
    session.playlists.video.forEach((track) => {
      const el = track.mediaKind === 'image' ? document.createElement('img') : document.createElement('video');
      el.src = track.dataUrl;
      el.dataset.layerType = 'playlist-video';
      if (el.tagName === 'VIDEO') {
        el.loop = true;
        el.autoplay = true;
        el.muted = !!track.mute;
        el.volume = session.masterVolume * session.advanced.playlistVideoVolume * (track.volume ?? 1);
        el.playsInline = true;
        el.play().catch(() => {});
      }
      refs.backgroundHost.appendChild(el);
      runtime.backgroundVideo.push(el);
    });
    session.playlists.audio.forEach((track) => {
      const audio = new Audio(track.dataUrl);
      audio.loop = true;
      audio.volume = session.masterVolume * session.advanced.playlistAudioVolume * (track.volume ?? 1);
      audio.play().catch(() => {});
      runtime.backgroundAudio.push(audio);
    });
  }

  function tickPlayback() {
    if (!runtime || runtime.paused) return;
    const elapsed = performance.now() - runtime.startedAt - runtime.totalPausedMs;
    const totalSessionTime = elapsed / 1000;
    const totalDuration = session.duration;
    const totalLoops = runtime.totalLoops;

    if (totalLoops && totalSessionTime >= totalLoops * totalDuration) {
      stopPlayback();
      return;
    }

    runtime.loopIndex = Math.floor(totalSessionTime / totalDuration);
    runtime.sessionTime = totalSessionTime % totalDuration;
    const activeBlock = session.blocks.find((b) => runtime.sessionTime >= b.start && runtime.sessionTime < b.start + b.duration) || null;
    runtime.activeBlock = activeBlock;
    handleActiveBlock(activeBlock);
    refreshRuntimeDisplays();
    refs.stageHud.textContent = runtime.paused ? 'Paused' : `Loop ${runtime.loopIndex + 1} · ${fmt(runtime.sessionTime)}`;
    runtime.raf = requestAnimationFrame(tickPlayback);
  }

  function handleActiveBlock(block) {
    refs.overlayText.style.fontSize = `${(block?.fontSize || 1.2) * 2.2}rem`;
    refs.overlayText.textContent = block?.content || '';
    if (!block) return;
    const loopScopedKey = `${runtime.loopIndex}:${block.id}`;
    if (runtime.triggered.has(loopScopedKey)) return;
    runtime.triggered.add(loopScopedKey);
    if (block.type === 'tts' && block.content) {
      const u = new SpeechSynthesisUtterance(block.content);
      u.rate = session.speechRate;
      u.volume = Math.max(0, Math.min(1, session.masterVolume * (block.volume ?? 1)));
      const voice = speechSynthesis.getVoices().find((v) => v.name === block.voiceName);
      if (voice) u.voice = voice;
      speechSynthesis.speak(u);
      runtime.speechUtterance = u;
    }
    if (block.type === 'audio' && block.dataUrl) {
      const audio = new Audio(block.dataUrl);
      audio.volume = Math.max(0, Math.min(1, session.masterVolume * (block.volume ?? 1)));
      runtime.playingOneShots.push(audio);
      audio.play().catch(() => {});
    }
    if (block.type === 'video' && block.dataUrl) {
      refs.backgroundHost.innerHTML = '';
      const el = block.mediaKind === 'image' ? document.createElement('img') : document.createElement('video');
      el.src = block.dataUrl;
      if (el.tagName === 'VIDEO') {
        el.autoplay = true;
        el.loop = Math.ceil(block.duration / Math.max(1, (el.duration || 1))) > 1;
        el.muted = !!block.mute;
        el.volume = session.masterVolume * session.advanced.playlistVideoVolume;
        el.playsInline = true;
        el.play().catch(() => {});
      }
      refs.backgroundHost.appendChild(el);
      runtime.backgroundVideo = [el];
    }
  }

  function pauseMedia() {
    speechSynthesis.pause();
    runtime?.backgroundAudio.forEach((a) => a.pause());
    runtime?.backgroundVideo.forEach((v) => v.pause?.());
    runtime?.playingOneShots.forEach((a) => a.pause?.());
  }

  function resumeMedia() {
    speechSynthesis.resume();
    runtime?.backgroundAudio.forEach((a) => a.play().catch(() => {}));
    runtime?.backgroundVideo.forEach((v) => v.play?.().catch(() => {}));
    runtime?.playingOneShots.forEach((a) => a.play?.().catch(() => {}));
  }

  function pausePlayback(fromAttention = false) {
    if (!runtime || runtime.paused) return;
    runtime.paused = true;
    runtime.pausedByAttention = fromAttention;
    runtime.pauseStartedAt = performance.now();
    cancelAnimationFrame(runtime.raf);
    pauseMedia();
    refs.stageHud.textContent = fromAttention ? 'Paused by attention tracking' : 'Paused';
  }

  function resumePlayback(fromAttention = false) {
    if (!runtime || !runtime.paused) return;
    runtime.totalPausedMs += performance.now() - runtime.pauseStartedAt;
    runtime.paused = false;
    runtime.pausedByAttention = false;
    resumeMedia();
    refs.stageHud.textContent = fromAttention ? 'Attention returned' : 'Playing';
    tickPlayback();
  }

  function stopPlayback() {
    if (!runtime) return;
    cancelAnimationFrame(runtime.raf);
    speechSynthesis.cancel();
    runtime.backgroundAudio.forEach((a) => { a.pause(); a.src = ''; });
    runtime.backgroundVideo.forEach((v) => { try { v.pause?.(); v.src = ''; } catch {} });
    runtime.playingOneShots.forEach((a) => { try { a.pause?.(); a.src = ''; } catch {} });
    refs.backgroundHost.innerHTML = '';
    refs.overlayText.textContent = '';
    refs.stageHud.textContent = 'Idle';
    runtime = null;
    refreshRuntimeDisplays();
  }

  function toggleFullscreen() {
    if (!document.fullscreenElement) refs.previewStage.requestFullscreen?.();
    else document.exitFullscreen?.();
  }

  document.addEventListener('click', (e) => {
    const trackBtn = e.target.closest('[data-track-action]');
    if (trackBtn) {
      const kind = trackBtn.dataset.trackKind;
      const index = Number(trackBtn.dataset.trackIndex);
      const action = trackBtn.dataset.trackAction;
      if (action === 'up') moveTrack(kind, index, -1);
      if (action === 'down') moveTrack(kind, index, 1);
      if (action === 'remove') removeTrack(kind, index);
      if (action === 'mute') {
        session.playlists.video[index].mute = !session.playlists.video[index].mute;
        saveAndRender();
      }
      return;
    }

    const rowBtn = e.target.closest('[data-row-action]');
    if (rowBtn) {
      const row = rowBtn.closest('.timeline-row');
      selectedBlockId = row.dataset.blockId;
      if (rowBtn.dataset.rowAction === 'dup') duplicateSelectedBlock();
      else if (rowBtn.dataset.rowAction === 'up') nudgeSelected(-1);
      else if (rowBtn.dataset.rowAction === 'down') nudgeSelected(1);
      else renderAll();
      return;
    }

    const row = e.target.closest('.timeline-row');
    if (row && !e.target.closest('input,textarea,select,button')) {
      selectedBlockId = row.dataset.blockId;
      renderAll();
    }
  });

  refs.timelineBody.addEventListener('input', (e) => {
    const row = e.target.closest('.timeline-row');
    if (!row) return;
    applyRowChange(row, e.target.dataset.rowField, e.target.value);
  });
  refs.timelineBody.addEventListener('change', (e) => {
    const row = e.target.closest('.timeline-row');
    if (!row) return;
    applyRowChange(row, e.target.dataset.rowField, e.target.value);
  });

  document.querySelectorAll('[data-add-block]').forEach((btn) => btn.addEventListener('click', () => addBlock(btn.dataset.addBlock)));
  $('newSessionBtn').addEventListener('click', () => { session = defaultSession(); selectedBlockId = null; stopPlayback(); syncForm(); saveAndRender(); });
  $('loadSampleBtn').addEventListener('click', () => { session = sampleSession(); selectedBlockId = session.blocks[0].id; stopPlayback(); syncForm(); saveAndRender(); });
  $('exportPackageBtn').addEventListener('click', downloadPackage);
  $('importPackageInput').addEventListener('change', (e) => e.target.files?.[0] && importPackage(e.target.files[0]));
  $('toggleFullscreenBtn').addEventListener('click', toggleFullscreen);
  $('playBtn').addEventListener('click', () => runtime?.paused ? resumePlayback(false) : startPlayback());
  $('pauseBtn').addEventListener('click', () => pausePlayback(false));
  $('stopBtn').addEventListener('click', stopPlayback);
  $('duplicateBlockBtn').addEventListener('click', duplicateSelectedBlock);
  $('deleteBlockBtn').addEventListener('click', deleteSelectedBlock);
  $('sortBlocksBtn').addEventListener('click', sortBlocks);
  $('nudgeBackBtn').addEventListener('click', () => nudgeSelected(-1));
  $('nudgeForwardBtn').addEventListener('click', () => nudgeSelected(1));
  $('stretchShorterBtn').addEventListener('click', () => stretchSelected(-1));
  $('stretchLongerBtn').addEventListener('click', () => stretchSelected(1));
  $('cloneTimingBtn').addEventListener('click', duplicateSelectedBlock);
  $('addAudioTrackInput').addEventListener('change', (e) => handleAudioFiles([...e.target.files]));
  $('addVideoTrackInput').addEventListener('change', (e) => handleVideoFiles([...e.target.files]));
  $('startTrackingBtn').addEventListener('click', () => tracking.start());
  $('stopTrackingBtn').addEventListener('click', () => tracking.stop());
  $('applyJsonBtn').addEventListener('click', applyJsonPreview);
  $('formatJsonBtn').addEventListener('click', formatJsonPreview);
  $('advancedSettingsBtn').addEventListener('click', () => refs.advancedDialog.showModal());
  $('saveCustomThemeBtn').addEventListener('click', saveCustomTheme);
  $('deleteCustomThemeBtn').addEventListener('click', deleteSelectedTheme);

  [refs.sessionName, refs.sessionDuration, refs.masterVolume, refs.speechRate, refs.loopMode, refs.loopCount, refs.runtimeMinutes, refs.backgroundColor, refs.accentColor, refs.textColor, refs.trackingEnabled, refs.autoPauseOnAttentionLoss, refs.attentionThreshold, refs.stageBlur, refs.fontFamily, refs.crossfadeSeconds, refs.playlistAudioVolume, refs.playlistVideoVolume, refs.autoResumeOnAttentionReturn]
    .forEach((el) => el.addEventListener('input', syncSessionFromForm));
  refs.themeSelect.addEventListener('change', (e) => applyTheme(e.target.value));

  syncForm();
  saveAndRender();
})();
