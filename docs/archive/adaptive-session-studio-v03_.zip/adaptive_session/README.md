# Adaptive Session Studio v3

A self-contained local web app for building passive audiovisual conditioning sessions.

## What's new in v3

- Fixed theme selector behavior.
- Added custom themes.
- Added Advanced Settings dialog.
- Upgraded the script editor into a subtitle-style timing table with start/end/duration editing.
- Split webcam tracking into its own dedicated module with live preview, overlay, and status panel.
- Improved playback pause/resume so timeline, playlist audio, playlist video, and one-shot media pause together.

## How to use

1. Unzip the package.
2. Open `index.html` in a modern desktop browser.
3. Click **Load Sample** to start from an example.
4. Add playlist media, edit script rows, and export the `.assp` package.

## Notes

- The package format is still a single-file JSON-style `.assp` export for simplicity and maintainability.
- Media is embedded as data URLs, which keeps the package portable but can make files large.
- Webcam attention estimation works best in browsers that support the Face Detection API.

## Suggested next upgrades

- Real ZIP-based session container with `manifest.json` and media folders.
- Multi-track subtitle lanes.
- Keyboard shortcuts for timeline editing.
- Rule engine for attention-triggered branching.
