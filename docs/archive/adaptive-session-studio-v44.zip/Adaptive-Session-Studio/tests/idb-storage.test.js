// ── tests/idb-storage.test.js ─────────────────────────────────────────────
// Tests for idb-storage.js — runs in browser test environment where IndexedDB
// is available. Validates the full async key/value lifecycle.

import { makeRunner } from './harness.js';
import { idbGet, idbSet, idbDel, idbHas } from '../js/idb-storage.js';

export function runIdbStorageTests() {
  const R  = makeRunner('idb-storage.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // Use a test-specific key prefix to avoid colliding with real app data
  const KEY = 'test:idb-storage-suite';
  const KEY2 = 'test:idb-storage-suite-2';

  // ── idbSet / idbGet round-trip ────────────────────────────────────────
  t('idbSet then idbGet returns the same primitive string', async () => {
    await idbSet(KEY, 'hello');
    const val = await idbGet(KEY);
    eq(val, 'hello');
    await idbDel(KEY);
  });

  t('idbSet then idbGet returns the same object', async () => {
    const obj = { a: 1, b: [2, 3], c: true, d: null };
    await idbSet(KEY, obj);
    const val = await idbGet(KEY);
    eq(JSON.stringify(val), JSON.stringify(obj));
    await idbDel(KEY);
  });

  t('idbSet then idbGet returns the same number', async () => {
    await idbSet(KEY, 42.5);
    const val = await idbGet(KEY);
    eq(val, 42.5);
    await idbDel(KEY);
  });

  t('idbSet then idbGet returns the same array', async () => {
    await idbSet(KEY, [1, 'two', { three: 3 }]);
    const val = await idbGet(KEY);
    eq(JSON.stringify(val), JSON.stringify([1, 'two', { three: 3 }]));
    await idbDel(KEY);
  });

  // ── idbGet on missing key ─────────────────────────────────────────────
  t('idbGet returns null for a key that does not exist', async () => {
    await idbDel(KEY); // ensure clean state
    const val = await idbGet(KEY);
    eq(val, null);
  });

  // ── idbDel ───────────────────────────────────────────────────────────
  t('idbDel removes the key so idbGet returns null', async () => {
    await idbSet(KEY, 'to-delete');
    await idbDel(KEY);
    const val = await idbGet(KEY);
    eq(val, null);
  });

  t('idbDel on a non-existent key does not throw', async () => {
    await idbDel('test:nonexistent-key-xyz'); // must not throw
    ok(true, 'no exception thrown');
  });

  // ── idbHas ───────────────────────────────────────────────────────────
  t('idbHas returns false for missing key', async () => {
    await idbDel(KEY);
    ok(!(await idbHas(KEY)));
  });

  t('idbHas returns true after idbSet', async () => {
    await idbSet(KEY, 'present');
    ok(await idbHas(KEY));
    await idbDel(KEY);
  });

  // ── Overwrite ─────────────────────────────────────────────────────────
  t('idbSet overwrites a previously stored value', async () => {
    await idbSet(KEY, 'first');
    await idbSet(KEY, 'second');
    const val = await idbGet(KEY);
    eq(val, 'second');
    await idbDel(KEY);
  });

  // ── Multiple keys are independent ─────────────────────────────────────
  t('two distinct keys do not interfere', async () => {
    await idbSet(KEY,  'alpha');
    await idbSet(KEY2, 'beta');
    eq(await idbGet(KEY),  'alpha');
    eq(await idbGet(KEY2), 'beta');
    await idbDel(KEY);
    await idbDel(KEY2);
    eq(await idbGet(KEY), null, 'KEY should be gone');
    ok(await idbHas(KEY2) === false, 'KEY2 should be gone');
  });

  // ── Large value ───────────────────────────────────────────────────────
  t('idbSet handles a 500 KB JSON object', async () => {
    const large = { data: 'x'.repeat(500_000) };
    await idbSet(KEY, large);
    const val = await idbGet(KEY);
    ok(val?.data?.length === 500_000, 'large value survives round-trip');
    await idbDel(KEY);
  });

  return R.summary();
}
