# Adaptive Session Studio — Product Roadmap (Revised)

---
---

## Implementation Status

| Phase | Status | Notes |
|-------|--------|-------|
| 1 — Foundation | ✅ Complete | Timeline engine, runtime, operator controls, HUD, onboarding, media preview |
| 2 — Branching & Co-Pilot | ✅ Complete | nextSceneId, gotoScene, override keyboard shortcuts, template vars |
| 3 — Plugin Ecosystem | ✅ Foundation | Manifest, capabilities (9 groups), context API, metrics.write |
| 4 — Profiles & Analytics | ✅ Complete | Profile, session history, stats, milestones, post-session modal, metrics chart |
| 5 — Advanced Adaptability | ✅ Phase 5.1+5.2 | State Blocks (calm/build/peak/recovery), user-defined variables, setVar action |
| 6 — Distribution | ❌ Not started | Marketplace, sharing system |

### Phase 5 Detail
- **5.1 State Blocks** — `stateType` on scenes (calm/build/peak/recovery). Entering a scene applies a non-destructive intensity/pacing profile via live-control override. Color suggestions per state. Scene editor dropdown.
- **5.2 User Variables** — `state.session.variables` map. CRUD via Variables panel (Session inspector tab). `{{varName}}` in text/TTS template strings. `setVar` rule and trigger action (`name=value` param). `normalizeVariables` round-trip safe.

---

## Vision

Adaptive Session Studio is a **timeline-driven interactive session platform** designed for creating and running **dynamic, guided experiences on a single device**.

The system combines:

* A **deterministic timeline engine** (core)
* A **live operator control layer** (user or partner)
* Optional **assistive AI tools** (never part of runtime execution)

The application runs as a **fullscreen presentation system**, where:

* The **Audience View** displays the session
* The **Operator (user or partner)** controls playback and dynamics via keyboard, mouse, touchscreen, or controller

The platform supports two core modes:

* **Self-Guided Sessions** — user operates their own session
* **Partner-Guided Sessions (Co-Pilot Mode)** — a second person shares control on the same device

---

## Core Principles

1. **Timeline is the source of truth**
   All session behavior originates from the timeline

2. **Deterministic execution**
   Sessions must be predictable, replayable, and debuggable

3. **Single-device first**
   No networking required; all interaction occurs locally

4. **Non-destructive live control**
   Operator actions override temporarily, never rewrite

5. **Keyboard-first operation**
   Full control must be possible without UI navigation

6. **Extensibility-first design**
   Plugin system is foundational

7. **Optional intelligence**
   AI enhances but never controls runtime

8. **Progressive complexity**
   Start linear → evolve to branching → expand carefully

---

## System Architecture Overview

### Dual-Layer Runtime Model

#### 🎬 Audience View (Primary Output)

* Fullscreen, immersive presentation layer
* Displays session content only (media, visuals, scripts)
* No UI clutter or debug elements

#### 🎛️ Operator Control Layer

* Keyboard-driven control system
* Optional minimal overlay HUD
* Enables:

  * Playback control
  * Parameter adjustment
  * Trigger execution
  * Emergency stop

---

## Phase 1 — Foundation (Core Engine & UX Cleanup)

### Goals

* Establish a stable, predictable runtime
* Build the core timeline system
* Optimize usability and workflow

---

### Features

#### 1. Timeline Engine (Linear Base)

* Multi-track timeline:

  * audio
  * video/image
  * script/text
  * control
  * input/sensor
  * output/device

* Event-based clips:

  * start time, duration
  * actions (media, scripts, commands)
  * modifiers (fade, blending, priority)
  * optional conditions (light gating only)

* Core control flow:

  * markers (named timeline anchors)
  * triggers (manual or timed)
  * basic navigation (jump, replay)

---

#### 2. Runtime Layer

* Deterministic playback engine
* Real-time safe execution
* Support for:

  * parameter changes
  * manual triggers
* Non-destructive override system:

  * temporary
  * layered
  * reversible

---

#### 3. Operator Control System (Keyboard-First)

* Playback:

  * play/pause
  * skip/rewind
  * jump to markers

* Parameter control:

  * intensity
  * pace
  * focus

* Trigger system:

  * hotkeys for predefined events

* Emergency system:

  * E-stop (instant safe halt)

---

#### 4. Overlay HUD (Optional)

* Toggleable minimal display:

  * current time / marker
  * active phase
  * intensity / pace
  * active overrides
  * upcoming events

---

#### 5. UX Improvements

* Replace Import/Export with:

  * New / Save / Load

* Media quick-preview

* Improved asset library

* One-click folder population:

  * music
  * video
  * images
  * scripts
  * plugins

* Optional onboarding tutorial (skippable)

---

#### 6. Project Structure

* Standardized session/project format
* Clear separation of:

  * timeline data
  * assets
  * plugins

---

## Phase 2 — Branching & Co-Pilot Control

### Goals

* Introduce controlled adaptability
* Expand live control capabilities
* Preserve timeline clarity

---

### Features

#### 1. Branching System (Extension of Linear Timeline)

* Branch points at markers only

* Branch targets:

  * named markers or segments

* Branch triggers:

  * operator input
  * simple variable thresholds

* Rules:

  * must define default path
  * visible in timeline
  * no hidden logic

---

#### 2. Global Variables System

Core runtime variables:

* intensity (0–100)
* pace (slow → fast)
* focus (content weighting)

Used by:

* timeline clips
* overrides
* branching decisions

---

#### 3. Co-Pilot (Single Device)

* Shared keyboard control
* Role flexibility:

  * user or partner can operate

Capabilities:

* adjust variables
* trigger events
* override behavior
* navigate timeline

---

#### 4. Override System (Expanded)

* Temporary deviations from timeline:

  * boost intensity
  * mute/enable tracks
  * inject alternate content

* Smooth return to baseline behavior

---

## Phase 3 — Plugin & Content Ecosystem

### Goals

* Enable extensibility and customization
* Support community-driven features

---

### Features

#### 1. Plugin System

Plugin API supports:

* new interaction types
* device/sensor integration
* custom timeline actions
* new media handlers/codecs
* settings panels
* new block categories
* AI provider swapping

Architecture:

* sandboxed execution
* permission-based access

---

#### 2. Content Packs

* Prebuilt sessions
* Media bundles
* Script libraries

---

#### 3. One-Click Import System

* Auto-detect and organize:

  * media
  * scripts
  * plugins

---

#### 4. Package Format

Portable bundles containing:

* timeline
* assets
* dependencies

---

## Phase 4 — Profiles, Progression & Analytics

### Goals

* Personalization and retention
* Track meaningful progress

---

### Features

#### 1. User Profiles

* Name, avatar/icon

* Optional:

  * age
  * gender
  * bio

* Custom text blocks:

  * notes
  * goals
  * preferences

---

#### 2. Session History (Core)

Track:

* session name

* date/time

* duration

* completion state:

  * completed
  * interrupted
  * E-stopped

* variable trends:

  * intensity curve
  * pacing changes

---

#### 3. Stats Engine

Auto-derived:

* total sessions
* total time
* streaks
* averages
* usage patterns

---

#### 4. Achievements & Milestones

* session counts
* streak milestones
* duration milestones

Design constraints:

* lightweight
* non-intrusive
* no pressure mechanics

---

#### 5. Post-Session Summary

* timeline recap
* key stats
* milestones reached

---

#### 6. Optional AI Layer

* session analysis
* improvement suggestions
* remix / generation tools

AI remains:

* optional
* user-triggered
* non-runtime

---

## Phase 5 — Advanced Adaptability

### Goals

* Expand flexibility without sacrificing clarity

---

### Features

#### 1. State Blocks (Optional Layer)

* High-level phases:

  * calm
  * build
  * peak
  * recovery

* Controlled transitions

---

#### 2. Advanced Variables

* Expanded variable system
* Used for:

  * branching
  * modulation
  * dynamic scaling

---

#### 3. Advanced Triggers

* sensor-driven events
* plugin-driven logic
* operator-triggered chains

---

## Phase 6 — Distribution & Monetization

### Goals

* Support ecosystem growth

---

### Features

#### 1. DLC / Marketplace

* official content packs
* community-created sessions
* plugins and scripts

---

#### 2. Sharing System

* easy export/import
* version compatibility handling

---

## Strategic Priorities

### Build Order

1. Timeline Engine + Runtime (Phase 1)
2. Operator Control System (Phase 1)
3. UX + onboarding (Phase 1)
4. Branching + variables (Phase 2)
5. Co-pilot control refinement (Phase 2)
6. Plugin system (Phase 3)
7. Profiles & progression (Phase 4)
8. Advanced adaptability (Phase 5)
9. Marketplace/DLC (Phase 6)

---

## Risks & Mitigation

### Feature Creep

* Mitigation: strict YAGNI adherence 

### Over-complexity

* Mitigation: timeline remains primary mental model

### Control Confusion

* Mitigation:

  * consistent hotkeys
  * optional HUD
  * clear override feedback

### AI Overreach

* Mitigation: keep AI fully optional and non-runtime

### Plugin Security

* Mitigation:

  * sandboxing
  * permission system

---

## Summary

Adaptive Session Studio evolves as a **timeline-first interactive system** with layered capabilities:

* **Core:** deterministic timeline engine
* **Layer 1:** keyboard-driven live control
* **Layer 2:** controlled branching & variables
* **Layer 3:** extensibility via plugins
* **Layer 4:** personalization via profiles

By enforcing strict boundaries:

* timeline = authority
* operator = real-time influence
* AI = assistive only

…the system can scale in power without losing clarity, reliability, or usability.