# Adaptive Session Studio

**A fully local, browser-native environment for designing and running immersive adaptive adult sessions — combining media playback, haptic scripting, behavioral automation, and real-time adaptive control.**

> No accounts. No cloud. No external dependencies after initial setup. Everything runs locally on your machine.

📣 **Discord**: [discord.gg/G6qD35nag7](https://discord.gg/G6qD35nag7)

---

## What it is

Adaptive Session Studio (ASS) lets you author and run time-based sessions that combine:

- **Text overlays and timed prompts** displayed on-screen during playback  
- **Text-to-speech narration** synthesized from your scripts  
- **Background audio and video layers** with playlist and crossfade control  
- **Subtitle scripting** via `.ass` / `.ssa` files  
- **FunScript haptic control** — time-coded position scripts played to devices via Intiface Central  
- **Behavioral scripting** — rules that react to attention, intensity, and engagement metrics  
- **AI-assisted authoring** — generate session content from a text prompt  

---

## Interface

The UI is organized as a professional **DAW-style layout** — three columns with a multi-lane timeline editor at the bottom:

```
┌────────────────┬───────────────────────────────────┬───────────────┐
│  TRACK PANEL   │             STAGE                  │   INSPECTOR   │
│  Blocks ■ ◎ ♪ │  (video · overlay · subtitles)     │  Block        │
│  Audio         ├───────────────────────────────────┤  Session      │
│  Video         │  TIMELINE EDITOR                   │  Status       │
│  Subtitles     │  ░ Navigator ───────────────────░  │               │
│  FunScript     │  ⚡ FunScript ──────────────────░  │               │
│  Scenes        ├───────────────────────────────────┤               │
│  Rules         │  LIVE CONTROL · RAMP · SAFETY      │               │
│  Triggers      ├───────────────────────────────────┤               │
│                │  ◄◄  ■  ▶  ►► ↺ Loop  🛑           │               │
└────────────────┴───────────────────────────────────┴───────────────┘
```

---

## Getting Started

### Requirements

- **Chrome 110+** or **Edge 110+** — required for FaceDetector API and ES modules  
- No build step — open `index.html` directly or serve with any static file server  
- For haptic devices: [Intiface Central](https://intiface.com/central/) running on `ws://localhost:12345`

### Quick start

```bash
# Open directly (works for most features)
open index.html

# Or serve locally (recommended)
npx serve .
python3 -m http.server 8080
```

Click **Sample** in the menubar to load a pre-built demo session and explore the interface.

---

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Space` | Play / Pause |
| `Enter` | Stop |
| `E` | Toggle FunScript edit mode |
| `N` | Next scene |
| `← →` | Skip ±10 seconds |
| `↑ ↓` | Skip ±30 seconds |
| `F` | Toggle fullscreen |
| `Shift` | Toggle FunScript pause |
| `1–5` | Inject macro slot |
| `Ctrl+0` | Reset timeline zoom |
| `Scroll` | Zoom timeline |
| `ESC×2` | Emergency stop |
| `?` | Shortcut overlay |
| `Ctrl+Z / Y` | Undo / Redo |
| `Ctrl+S` | Export session package |

---

## Session File Format

Sessions save as `.assp` files (JSON). The session object contains:

- `blocks[]` — timed overlay, audio, video, TTS, pause, macro blocks
- `scenes[]` — named time ranges within the session
- `rules[]` — behavioral scripting rules (condition → action)
- `triggers[]` — time-window interaction checks with success/failure branches
- `funscriptTracks[]`, `audioTracks[]`, `videoTracks[]`, `subtitleTracks[]`
- `rampSettings`, `pacingSettings`, `safetySettings`
- `macroLibrary`, `macroSlots`

---

## Module Architecture

28 ES modules — no bundler, no framework, no build step.

| Module | Role |
|--------|------|
| `main.js` | Bootstrap, DOM event wiring, keyboard handler |
| `state.js` | Session state, normalizers, localStorage persistence |
| `playback.js` | RAF loop, block execution, emergency stop |
| `ui.js` | Sidebar, inspector tabs, settings form rendering |
| `funscript.js` | Multi-lane timeline canvas — overview + FS curve |
| `audio-engine.js` | Web Audio API, playlist, crossfade |
| `state-engine.js` | Real-time metric fusion (attention × device × intensity) |
| `rules-engine.js` | Behavioral scripting with conditioning presets |
| `trigger-windows.js` | Timed interaction windows with success/fail branches |
| `safety.js` | Hard intensity/speed limits, emergency cooldown |
| `intensity-ramp.js` | Configurable intensity ramp curves |
| `dynamic-pacing.js` | Engagement-driven speed modulation |
| `session-modes.js` | Preset session configurations (Exposure, Mindfulness, Focus) |
| `ai-authoring.js` | LLM-assisted session generation via Anthropic API |
| `live-control.js` | Real-time sliders with safety clamps |
| `macros.js` | FunScript macro library, key slots, injection |
| `macro-ui.js` | Macro library and inline editor rendering |
| `scenes.js` | Scene CRUD, timeline markers, skip navigation |
| `tracking.js` | Webcam FaceDetector, attention scoring, decay |
| `session-analytics.js` | Post-session data accumulation and display |
| `user-profile.js` | Adaptive difficulty, streak tracking, milestones |
| `suggestions.js` | Real-time session health suggestions |
| `subtitle.js` | ASS/SSA parsing and rendering |
| `notify.js` | Toast notification system with confirm dialogs |
| `history.js` | Undo/redo with snapshot model |
| `capabilities.js` | Browser feature detection and capability gates |
| `block-ops.js` | Block duplicate/delete operations |
| `fullscreen-hud.js` | Fullscreen overlay HUD rendering |

---

## Feature Status

All 18+ planned features implemented:

| Feature | Module |
|---------|--------|
| Behavioral Scripting | `rules-engine.js` |
| State Engine + Multi-Signal Fusion | `state-engine.js` |
| Macro Trigger System | `macros.js`, `macro-ui.js` |
| Timing Interaction Layer | `trigger-windows.js` |
| Webcam Attention Tracking | `tracking.js` |
| Adaptive Pausing | via `rules-engine.js` |
| Dynamic Pacing | `dynamic-pacing.js` |
| Intensity Ramp Curves | `intensity-ramp.js` |
| Safety Layer | `safety.js` |
| Behavioral Conditioning Presets | `rules-engine.js` |
| Adaptive Difficulty + User Profile | `user-profile.js` |
| Session Modes | `session-modes.js` |
| Biofeedback Plugin API | `setExternalSignal()` in state-engine |
| AI-Assisted Session Authoring | `ai-authoring.js` |
| Scene System | `scenes.js` |
| Post-Session Analytics | `session-analytics.js` |

---

## License

Personal use only. Not for commercial redistribution.
