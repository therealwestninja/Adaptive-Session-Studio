// ── user-profile.js ────────────────────────────────────────────────────────
// User Profiling System — ROADMAP Phase 3.12 (Local Only)
//
// Builds and maintains a persistent local profile derived from session analytics.
// Stores: session history, preferred intensity, attention stability, engagement
// trend, total runtime, and streak tracking.
//
// Storage: localStorage key 'ass-profile-v1'
// All data is local-only. No network calls. Export/import optional.

import { state, fmt, esc } from './state.js';
import { getStoredAnalytics } from './session-analytics.js';
import { notify } from './notify.js';

const PROFILE_KEY = 'ass-profile-v1';

// ── Profile shape ─────────────────────────────────────────────────────────────
function defaultProfile() {
  return {
    version:          1,
    sessionCount:     0,
    totalRuntimeSec:  0,
    lastSessionAt:    null,
    streak:           0,         // consecutive days with at least one session
    lastStreakDate:   null,       // date string YYYY-MM-DD
    // Derived from analytics history (rolling average over last 10 sessions)
    avgAttentionStability: null, // 0–1: 1 = never lost attention
    avgEngagementPct:      null, // 0–100: average engagement score
    preferredIntensityAvg: null, // average FS output percentage
    preferredIntensityMax: null, // average peak FS output
    // Responsiveness: how quickly user re-engages after attention loss
    avgReengagementSec: null,
    // Trend flags
    intensityTrend: 'stable',    // 'rising' | 'falling' | 'stable'
    attentionTrend: 'stable',
  };
}

// ── Load / save ───────────────────────────────────────────────────────────────
export function loadProfile() {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    return raw ? { ...defaultProfile(), ...JSON.parse(raw) } : defaultProfile();
  } catch {
    return defaultProfile();
  }
}

export function saveProfile(profile) {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  } catch { /* quota — silently skip */ }
}

export function clearProfile() {
  localStorage.removeItem(PROFILE_KEY);
}

// ── Rebuild profile from analytics history ────────────────────────────────────
export function rebuildProfile() {
  const history = getStoredAnalytics();
  if (!history.length) return defaultProfile();

  const profile = defaultProfile();
  profile.sessionCount    = history.length;
  profile.totalRuntimeSec = history.reduce((s, h) => s + (h.totalSec ?? 0), 0);
  profile.lastSessionAt   = history[0]?.timestamp ?? null;

  // Use up to the last 10 sessions for rolling averages
  const recent = history.slice(0, 10);

  // Attention stability: 1 - (lossEvents / sessionDuration)
  const stabilityScores = recent
    .filter(h => h.totalSec > 0)
    .map(h => Math.max(0, 1 - (h.attentionLossEvents ?? 0) / (h.totalSec / 60)));
  if (stabilityScores.length) {
    profile.avgAttentionStability = +(stabilityScores.reduce((a, b) => a + b, 0) / stabilityScores.length).toFixed(2);
  }

  // FS intensity preference
  const fsAvgSamples = recent.filter(h => h.fsAvg !== null).map(h => h.fsAvg);
  const fsMaxSamples = recent.filter(h => h.fsMax !== null).map(h => h.fsMax);
  if (fsAvgSamples.length) {
    profile.preferredIntensityAvg = Math.round(fsAvgSamples.reduce((a, b) => a + b, 0) / fsAvgSamples.length);
    profile.preferredIntensityMax = Math.round(fsMaxSamples.reduce((a, b) => a + b, 0) / fsMaxSamples.length);
  }

  // Re-engagement speed: total loss time / loss events
  const reengageSamples = recent
    .filter(h => (h.attentionLossEvents ?? 0) > 0)
    .map(h => (h.attentionLossTotalSec ?? 0) / h.attentionLossEvents);
  if (reengageSamples.length) {
    profile.avgReengagementSec = +(reengageSamples.reduce((a, b) => a + b, 0) / reengageSamples.length).toFixed(1);
  }

  // Streak: count consecutive calendar days with sessions
  profile.streak       = _computeStreak(history);
  profile.lastStreakDate = _todayStr();

  // Trends: compare first vs second half of recent sessions
  if (recent.length >= 4) {
    const half = Math.floor(recent.length / 2);
    const older = recent.slice(half);
    const newer = recent.slice(0, half);

    const avgFs = arr => arr.filter(h => h.fsAvg !== null).reduce((s, h) => s + h.fsAvg, 0) / (arr.filter(h => h.fsAvg !== null).length || 1);
    const avgStab = arr => arr.filter(h => h.totalSec > 0).reduce((s, h) => s + Math.max(0, 1 - (h.attentionLossEvents ?? 0) / (h.totalSec / 60)), 0) / arr.length;

    const fsDelta   = avgFs(newer)   - avgFs(older);
    const stabDelta = avgStab(newer) - avgStab(older);

    profile.intensityTrend = fsDelta >  5 ? 'rising' : fsDelta < -5 ? 'falling' : 'stable';
    profile.attentionTrend = stabDelta > 0.05 ? 'rising' : stabDelta < -0.05 ? 'falling' : 'stable';
  }

  saveProfile(profile);
  return profile;
}

function _todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function _computeStreak(history) {
  if (!history.length) return 0;
  const days = [...new Set(history.map(h => new Date(h.timestamp).toISOString().slice(0, 10)))].sort().reverse();
  let streak  = 0;
  let expected = _todayStr();
  for (const day of days) {
    if (day === expected) {
      streak++;
      const d = new Date(expected);
      d.setDate(d.getDate() - 1);
      expected = d.toISOString().slice(0, 10);
    } else {
      break;
    }
  }
  return streak;
}

// ── Habit Training (ROADMAP Phase 3.13) ──────────────────────────────────────
// Returns a difficulty level (1–5) derived from session history, and streak.
// Used to suggest gradual escalation in session settings.

export function computeDifficultyLevel(profile) {
  if (!profile || profile.sessionCount < 2) return 1;

  let level = 1;

  // Streak bonus: consistent practice → higher baseline
  if (profile.streak >= 7)  level += 1;
  if (profile.streak >= 30) level += 1;

  // Attention stability → readiness for longer/harder sessions
  if ((profile.avgAttentionStability ?? 0) >= 0.8) level += 0.5;
  if ((profile.avgAttentionStability ?? 0) >= 0.95) level += 0.5;

  // Rising intensity trend → user is ready for more
  if (profile.intensityTrend === 'rising') level += 0.5;

  return Math.min(5, Math.round(level));
}

// ── Adaptive Difficulty Curves (ROADMAP Phase 3.11) ──────────────────────────
// Returns suggested ramp settings based on profile data. Callers can apply
// these directly or present them to the user as a recommendation.

export function getAdaptiveRampSuggestion() {
  // Use saved profile if available (faster); rebuild from analytics otherwise.
  // rebuildProfile() is authoritative — call it and save so loadProfile() stays current.
  const profile = rebuildProfile();
  saveProfile(profile);
  const level   = computeDifficultyLevel(profile);

  // Scale intensity from profile's preferred range with level bonus
  const baseAvg = (profile.preferredIntensityAvg ?? 50) / 100;
  const basePeak= (profile.preferredIntensityMax ?? 80) / 100;

  // Progressive overload: each level adds ~10% headroom
  const levelBonus = (level - 1) * 0.1;

  return {
    enabled:   true,
    mode:      profile.avgAttentionStability !== null ? 'adaptive' : 'time',
    startVal:  Math.max(0.2, Math.min(1.0, baseAvg - 0.1)),
    endVal:    Math.min(2.0, basePeak + levelBonus),
    curve:     level >= 4 ? 'exponential' : 'sine',
    steps:     [],
    blendMode: 'max',
    _note:     `Based on ${profile.sessionCount} session${profile.sessionCount !== 1 ? 's' : ''}, level ${level}/5`,
  };
}

// ── Habit Streak Milestones ─────────────────────────────────────────────────
export function getStreakMilestone(streak) {
  if (streak <= 0) return null;
  const milestones = [
    { days: 3,  message: '3-day streak 🔥 Building momentum' },
    { days: 7,  message: '1-week streak 🏆 A full week!' },
    { days: 14, message: '2-week streak ⚡ Strong habit forming' },
    { days: 30, message: '30-day streak 🌟 Incredible consistency' },
    { days: 100, message: '100-day streak 🎯 Elite practitioner' },
  ];
  return milestones.filter(m => streak === m.days).at(-1) ?? null;
}
export function renderProfilePanel(containerId = 'profilePanel') {
  const el = document.getElementById(containerId);
  if (!el) return;

  const p = rebuildProfile();
  saveProfile(p);  // keep persisted profile in sync with latest analytics
  const history = getStoredAnalytics();
  const milestone = getStreakMilestone(p.streak);

  const trendIcon = t => t === 'rising' ? '↑' : t === 'falling' ? '↓' : '→';
  const trendColor = t => t === 'rising' ? '#7dc87a' : t === 'falling' ? '#e05050' : 'var(--text3)';

  const recPill = (label, value, unit = '') => value === null ? '' : `
    <div style="background:rgba(255,255,255,0.04);border:0.5px solid rgba(255,255,255,0.08);
      border-radius:8px;padding:8px;text-align:center;min-width:72px">
      <div style="font-size:14px;font-weight:700;color:#f0f0e8">${value}${unit}</div>
      <div style="font-size:9.5px;color:rgba(255,255,255,0.3);text-transform:uppercase;letter-spacing:.06em">${label}</div>
    </div>`;

  el.innerHTML = `
    <div style="font-size:14px;font-weight:700;color:#f0f0e8;font-family:Syne,sans-serif;margin-bottom:12px">
      My Profile
    </div>

    ${milestone ? `
    <div style="background:rgba(240,160,74,0.12);border:0.5px solid rgba(240,160,74,0.3);
      border-radius:8px;padding:8px 12px;margin-bottom:10px;font-size:11px;color:#f0a04a">
      ${milestone.message}
    </div>` : ''}

    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px">
      ${recPill('Sessions', p.sessionCount)}
      ${recPill('Runtime', fmt(p.totalRuntimeSec))}
      ${recPill('Streak', p.streak, p.streak === 1 ? ' day' : ' days')}
    </div>

    ${p.avgAttentionStability !== null ? `
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px">
        <span style="color:var(--text2)">Attention stability</span>
        <span>${Math.round(p.avgAttentionStability * 100)}%
          <span style="color:${trendColor(p.attentionTrend)}">${trendIcon(p.attentionTrend)}</span>
        </span>
      </div>
      <div style="height:4px;background:rgba(255,255,255,0.08);border-radius:2px">
        <div style="height:4px;border-radius:2px;background:#7dc87a;width:${Math.round(p.avgAttentionStability*100)}%"></div>
      </div>
    </div>` : ''}

    ${p.preferredIntensityAvg !== null ? `
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px">
        <span style="color:var(--text2)">Preferred intensity (avg / peak)</span>
        <span>${p.preferredIntensityAvg}% / ${p.preferredIntensityMax}%
          <span style="color:${trendColor(p.intensityTrend)}">${trendIcon(p.intensityTrend)}</span>
        </span>
      </div>
      <div style="height:4px;background:rgba(255,255,255,0.08);border-radius:2px">
        <div style="height:4px;border-radius:2px;background:#f0a04a;width:${p.preferredIntensityAvg}%"></div>
      </div>
    </div>` : ''}

    ${p.avgReengagementSec !== null ? `
    <div style="font-size:11px;color:var(--text2);margin-bottom:8px">
      Avg re-engagement time: <strong>${p.avgReengagementSec}s</strong>
    </div>` : ''}

    ${history.length ? `
    <details style="margin-top:10px">
      <summary style="cursor:pointer;font-size:10px;font-weight:600;letter-spacing:.08em;
        text-transform:uppercase;color:rgba(255,255,255,0.25);list-style:none">
        Session history (${history.length})
      </summary>
      <div style="margin-top:8px;max-height:180px;overflow-y:auto">
        ${history.slice(0, 10).map(h => `
          <div style="display:flex;justify-content:space-between;padding:4px 0;
            border-bottom:0.5px solid rgba(255,255,255,0.05);font-size:11px">
            <span style="color:var(--text2)">${esc(h.sessionName)}</span>
            <span style="color:var(--text3)">${fmt(h.totalSec)} · ${new Date(h.timestamp).toLocaleDateString()}</span>
          </div>`).join('')}
      </div>
    </details>` : `<p style="font-size:11px;color:var(--text3)">Complete a session to build your profile.</p>`}

    <button id="clearProfileBtn" style="margin-top:12px;font-size:11px;color:var(--danger);
      background:transparent;border:0.5px solid rgba(224,80,80,0.3);border-radius:6px;
      padding:5px 10px;cursor:pointer;width:100%">
      Clear profile data
    </button>`;

  document.getElementById('clearProfileBtn')?.addEventListener('click', async () => {
    const ok = await notify.confirm('Clear all profile and session history data?', { confirmLabel: 'Clear', danger: true });
    if (ok) {
      clearProfile();
      localStorage.removeItem('ass-analytics-v1');
      renderProfilePanel(containerId);
      notify.success('Profile cleared.');
    }
  });
}
