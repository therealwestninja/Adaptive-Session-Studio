// ── state.js ──────────────────────────────────────────────────────────────
// Single source of truth: session model, runtime state, utilities.

export const STORAGE_KEY = 'adaptive-session-studio-v4';
export const PACKAGE_VERSION = 4;

// ── Built-in themes ────────────────────────────────────────────────────────
export const builtinThemes = {
  midnight: { name: 'Midnight', backgroundColor: '#05070a', accentColor: '#7fb0ff', textColor: '#eef4fb' },
  ember:    { name: 'Ember',    backgroundColor: '#160909', accentColor: '#ff9f71', textColor: '#fff0ea' },
  moss:     { name: 'Moss',     backgroundColor: '#07130b', accentColor: '#9be7a1', textColor: '#eefcf1' },
  violet:   { name: 'Violet',   backgroundColor: '#100916', accentColor: '#c8a4ff', textColor: '#f4ebff' },
  dusk:     { name: 'Dusk',     backgroundColor: '#0d0a14', accentColor: '#f0a04a', textColor: '#f0ece6' },
  slate:    { name: 'Slate',    backgroundColor: '#080c10', accentColor: '#64b5c8', textColor: '#d8eaf0' },
};

// ── Utilities ───────────────────────────────────────────────────────────────
export const uid = () => 'b_' + Math.random().toString(36).slice(2, 10);
export const clampInt = (v, lo, hi, fb) => { const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n))) : fb; };
export const esc = s => String(s ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
export const fmt = sec => { const s = Math.max(0, Math.floor(sec)), m = Math.floor(s / 60); return `${String(m).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`; };
export const fileToDataUrl = f => new Promise((ok, err) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = err; r.readAsDataURL(f); });
export const $id = id => document.getElementById(id);

// ── Default session factory ────────────────────────────────────────────────
export const defaultSession = () => ({
  packageVersion: PACKAGE_VERSION,
  name: 'new_session',
  duration: 180,
  theme: 'midnight',
  customThemes: {},
  masterVolume: 0.8,
  speechRate: 1,
  loopMode: 'count',
  loopCount: 1,
  runtimeMinutes: 10,
  backgroundColor: builtinThemes.midnight.backgroundColor,
  accentColor:     builtinThemes.midnight.accentColor,
  textColor:       builtinThemes.midnight.textColor,
  advanced: {
    stageBlur: 0,
    fontFamily: 'Syne, system-ui, sans-serif',
    crossfadeSeconds: 0.6,
    playlistAudioVolume: 0.7,
    playlistVideoVolume: 0.6,
    autoResumeOnAttentionReturn: false,
  },
  tracking: {
    enabled: false,
    autoPauseOnAttentionLoss: false,
    attentionThreshold: 5,
  },
  subtitleSettings: {
    textColor: '#ffffff',
    fontSize: 1.4,
    position: 'bottom',
    override: 'none',
  },
  funscriptSettings: {
    speed: 1.0,
    invert: false,
    range: 100,
  },
  // Webcam → FS options
  trackingFsOptions: {
    pauseFsOnLoss: false,
    injectMacroOnLoss: false,
    injectMacroOnReturn: false,
    lossInjectSlot: 0,      // 0 = none, 1-5 = slot
    returnInjectSlot: 0,
  },
  playlists: { audio: [], video: [] },
  subtitleTracks: [],
  funscriptTracks: [],
  macroLibrary: [],         // user-saved macros
  macroSlots: { 1:null, 2:null, 3:null, 4:null, 5:null }, // slot → macro id
  blocks: [],
});

export const sampleSession = () => ({
  ...defaultSession(),
  name: 'grounded_focus',
  duration: 120,
  loopCount: 2,
  speechRate: 0.95,
  blocks: [
    { id: uid(), type: 'text',  label: 'Settle',       start: 0,  duration: 12, content: 'Settle in.\nLet your breathing slow.', fontSize: 1.2 },
    { id: uid(), type: 'tts',   label: 'Opening',      start: 14, duration: 10, content: 'You can take your time. There is no need to rush.', volume: 0.9, voiceName: '' },
    { id: uid(), type: 'text',  label: 'Anchor words', start: 34, duration: 12, content: 'Steady.\nClear.\nPresent.', fontSize: 1.55 },
    { id: uid(), type: 'pause', label: 'Silence',      start: 52, duration: 8,  content: '' },
    { id: uid(), type: 'tts',   label: 'Closing',      start: 68, duration: 12, content: 'Carry the same steadiness into your next action.', volume: 0.9, voiceName: '' },
  ],
});

// ── Deep normalizers for nested session structures ─────────────────────────

export function normalizeAudioTrack(t) {
  return {
    id:     typeof t?.id === 'string' && t.id ? t.id : uid(),
    name:   typeof t?.name    === 'string' ? t.name    : 'Audio',
    dataUrl:typeof t?.dataUrl === 'string' ? t.dataUrl : '',
    volume: typeof t?.volume  === 'number' && isFinite(t.volume) ? Math.min(2, Math.max(0, t.volume)) : 1,
    _muted: t?._muted === true,
  };
}

export function normalizeVideoTrack(t) {
  return {
    id:       typeof t?.id === 'string' && t.id ? t.id : uid(),
    name:     typeof t?.name      === 'string' ? t.name      : 'Video',
    dataUrl:  typeof t?.dataUrl   === 'string' ? t.dataUrl   : '',
    mediaKind:['video','image'].includes(t?.mediaKind) ? t.mediaKind : 'video',
    mute:     t?.mute !== false,
    volume:   typeof t?.volume === 'number' && isFinite(t.volume) ? Math.min(2, Math.max(0, t.volume)) : 1,
  };
}

export function normalizeFunscriptTrack(t) {
  const actions = Array.isArray(t?.actions)
    ? t.actions
        .filter(a => Number.isFinite(+a?.at) && Number.isFinite(+a?.pos))
        .map(a => ({ at: Math.max(0, Math.round(+a.at)), pos: Math.min(100, Math.max(0, Math.round(+a.pos))) }))
        .sort((a, b) => a.at - b.at)
    : [];
  return {
    id:        typeof t?.id === 'string' ? t.id : uid(),
    name:      typeof t?.name === 'string' ? t.name : 'Script',
    version:   Number.isFinite(+t?.version) ? +t.version : 1,
    inverted:  t?.inverted === true,
    range:     Number.isFinite(+t?.range) ? Math.min(100, Math.max(1, Math.round(+t.range))) : 100,
    actions,
    _disabled: t?._disabled === true,
    _color:    typeof t?._color === 'string' ? t._color : '#f0a04a',
  };
}

export function normalizeSubtitleTrack(t) {
  const events = Array.isArray(t?.events)
    ? t.events.filter(e => Number.isFinite(+e?.start) && Number.isFinite(+e?.end) && +e.end > +e.start)
        .map(e => ({ start: +e.start, end: +e.end, text: String(e?.text ?? ''), style: String(e?.style ?? 'Default') }))
    : [];
  return {
    id:        typeof t?.id === 'string' && t.id ? t.id : uid(),
    name:      typeof t?.name === 'string' ? t.name : 'Subtitles',
    rawAss:    typeof t?.rawAss === 'string' ? t.rawAss : '',
    styles:    t?.styles && typeof t.styles === 'object' ? t.styles : {},
    events,
    _disabled: t?._disabled === true,
  };
}

export function normalizeMacro(m) {
  const actions = Array.isArray(m?.actions)
    ? m.actions
        .filter(a => Number.isFinite(+a?.at) && Number.isFinite(+a?.pos))
        .map(a => ({ at: Math.max(0, Math.round(+a.at)), pos: Math.min(100, Math.max(0, Math.round(+a.pos))) }))
        .sort((a, b) => a.at - b.at)
    : [];
  return {
    id:      typeof m?.id === 'string' ? m.id : uid(),
    name:    typeof m?.name === 'string' && m.name ? m.name : 'Macro',
    builtin: m?.builtin === true,
    actions,
  };
}

// ── Block normalizer ────────────────────────────────────────────────────────
export function normalizeBlock(block, idx = 0) {
  return {
    id:          block?.id || uid(),
    type:        block?.type || 'text',
    label:       block?.label || `Block ${idx + 1}`,
    start:       clampInt(block?.start ?? 0, 0, 86400, 0),
    duration:    clampInt(block?.duration ?? 10, 1, 86400, 10),
    content:     block?.content || '',
    fontSize:    Number(block?.fontSize ?? 1.2),
    volume:      Number(block?.volume ?? 1),
    voiceName:   block?.voiceName || '',
    dataUrl:     block?.dataUrl || '',
    dataUrlName: block?.dataUrlName || '',
    mediaKind:   block?.mediaKind || '',
    mute:        block?.mute !== false,
    _position:   block?._position || 'center',
  };
}

export function normalizeSession(input) {
  const base = defaultSession();
  const out = {
    ...base, ...input,
    tracking:          { ...base.tracking,          ...(input?.tracking          ?? {}) },
    advanced:          { ...base.advanced,          ...(input?.advanced          ?? {}) },
    subtitleSettings:  { ...base.subtitleSettings,  ...(input?.subtitleSettings  ?? {}) },
    funscriptSettings: { ...base.funscriptSettings, ...(input?.funscriptSettings ?? {}) },
    customThemes:      { ...(input?.customThemes ?? {}) },
    playlists: {
      audio: Array.isArray(input?.playlists?.audio) ? input.playlists.audio.map(normalizeAudioTrack) : [],
      video: Array.isArray(input?.playlists?.video) ? input.playlists.video.map(normalizeVideoTrack) : [],
    },
    subtitleTracks:  Array.isArray(input?.subtitleTracks)  ? input.subtitleTracks.map(normalizeSubtitleTrack)   : [],
    funscriptTracks: Array.isArray(input?.funscriptTracks) ? input.funscriptTracks.map(normalizeFunscriptTrack)  : [],
    macroLibrary:    Array.isArray(input?.macroLibrary)    ? input.macroLibrary.map(normalizeMacro)              : [],
    macroSlots:      { ...base.macroSlots, ...(input?.macroSlots ?? {}) },
    trackingFsOptions: { ...base.trackingFsOptions, ...(input?.trackingFsOptions ?? {}) },
    blocks: Array.isArray(input?.blocks)
      ? input.blocks.map(normalizeBlock)
      : sampleSession().blocks,
  };
  return out;
}

// ── Mutable app state ──────────────────────────────────────────────────────
export const state = {
  session: null,
  runtime: null,
  selectedBlockId: null,
  selectedSidebarType: null,
  selectedSidebarIdx: null,
  selectedSidebarId: null,    // stable track ID for audio/video items
  selectedFsPoint:  null,     // { trackId, actionRef } — primary single point
  selectedFsPoints: new Set(),// Set of actionRef objects — multi-selection
  inspTab: 'overlay',
  settingsTab: 'appearance',
  fsEditMode: false,
  fsPaused: false,            // FS-only pause (Shift)
  injection: null,            // active macro injection
  deviceSocket: null,
  _lastEscTime: 0,            // for double-ESC emergency stop
  _editingMacroId: null,      // macro library editor
};

// ── Load session ────────────────────────────────────────────────────────────
try {
  const raw = localStorage.getItem(STORAGE_KEY);
  state.session = normalizeSession(raw ? JSON.parse(raw) : sampleSession());
} catch {
  state.session = normalizeSession(sampleSession());
}
state.selectedBlockId = state.session.blocks[0]?.id || null;

// Expose for cross-module use (history.js needs it without circular import)
window._stateModule = { normalizeSession };

// ── Persist ─────────────────────────────────────────────────────────────────
// ── Persistence state ───────────────────────────────────────────────────────
export const persistState = { dirty: false, error: null, lastSaved: null };

export function persist() {
  const json = JSON.stringify(state.session);
  try {
    localStorage.setItem(STORAGE_KEY, json);
    persistState.dirty   = false;
    persistState.error   = null;
    persistState.lastSaved = Date.now();
    _updatePersistBadge(false, null);
  } catch (e) {
    persistState.dirty = true;
    persistState.error = e;
    if (e.name === 'QuotaExceededError' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
      _updatePersistBadge(true, 'Storage full — export your session now to avoid losing work.');
      import('./notify.js').then(({ notify }) => {
        notify.error(
          '⚠ localStorage quota exceeded.\nYour session could not be auto-saved.\n\nExport an .assp file now to save your work.',
          0
        );
      });
    } else {
      _updatePersistBadge(true, `Auto-save failed: ${e.message}`);
    }
  }
  // Always update JSON preview if open
  const jp = $id('s_jsonPreview');
  if (jp) jp.value = json.length > 200000 ? '(session too large to preview)' : JSON.stringify(state.session, null, 2);
}

function _updatePersistBadge(error, message) {
  const badge = document.getElementById('persistBadge');
  if (!badge) return;
  badge.style.display = error ? 'inline-flex' : 'none';
  badge.title = message ?? '';
}

// ── Theme helpers ────────────────────────────────────────────────────────────
export const themeMap = () => ({ ...builtinThemes, ...state.session.customThemes });

export function applyCssVars() {
  const s = state.session;
  const r = document.documentElement.style;
  r.setProperty('--stage-bg',     s.backgroundColor);
  r.setProperty('--stage-text',   s.textColor);
  r.setProperty('--stage-accent', s.accentColor);
  r.setProperty('--stage-blur',   `${s.advanced.stageBlur}px`);
  r.setProperty('--overlay-font', s.advanced.fontFamily);
  const stage = $id('mainStage');
  if (stage) stage.style.background = s.backgroundColor;
  const ot = $id('overlayText');
  if (ot) { ot.style.color = s.textColor; ot.style.fontFamily = s.advanced.fontFamily; }
}

export function applyTheme(key) {
  const t = themeMap()[key];
  if (!t) return;
  const s = state.session;
  s.theme = key;
  s.backgroundColor = t.backgroundColor;
  s.accentColor     = t.accentColor;
  s.textColor       = t.textColor;
  applyCssVars();
  persist();
}
