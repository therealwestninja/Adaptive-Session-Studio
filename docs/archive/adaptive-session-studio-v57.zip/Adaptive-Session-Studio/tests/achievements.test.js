// ── tests/achievements.test.js ────────────────────────────────────────────
// Tests for js/achievements.js — 66 achievements across 8 categories,
// daily quests, XP/level math, and processSessionEnd data flow.

import { makeRunner } from './harness.js';
import {
  ACHIEVEMENTS, ACHIEVEMENT_MAP, LEVEL_NAMES, MAX_LEVEL, LEVEL_THRESHOLDS,
  levelFromXp, xpToNextLevel, levelProgressPct,
  getDailyQuests, checkAndAwardAchievements, calculateSessionXp, checkQuestProgress,
} from '../js/achievements.js';

export function runAchievementsTests() {
  const R  = makeRunner('achievements.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // ── Catalogue shape ────────────────────────────────────────────────────────
  t('ACHIEVEMENTS has 60+ entries', () => {
    ok(ACHIEVEMENTS.length >= 60, `expected ≥60, got ${ACHIEVEMENTS.length}`);
  });

  t('all achievement ids are unique', () => {
    const ids = ACHIEVEMENTS.map(a => a.id);
    eq(new Set(ids).size, ids.length, 'duplicate id found');
  });

  t('every achievement has required fields with correct types', () => {
    const VALID_CATS = new Set(['starter','consistency','depth','endurance','focus','craft','quests','levels']);
    for (const a of ACHIEVEMENTS) {
      ok(typeof a.id       === 'string' && a.id.length,       `${a.id}: bad id`);
      ok(typeof a.icon     === 'string' && a.icon.length,     `${a.id}: bad icon`);
      ok(typeof a.name     === 'string' && a.name.length,     `${a.id}: bad name`);
      ok(typeof a.desc     === 'string' && a.desc.length,     `${a.id}: bad desc`);
      ok(typeof a.xp       === 'number' && a.xp >= 0,         `${a.id}: bad xp`);
      ok(VALID_CATS.has(a.category),                           `${a.id}: bad category "${a.category}"`);
    }
  });

  t('ACHIEVEMENT_MAP contains every achievement keyed by id', () => {
    for (const a of ACHIEVEMENTS) {
      ok(ACHIEVEMENT_MAP[a.id] === a, `${a.id} missing from ACHIEVEMENT_MAP`);
    }
  });

  t('each category is represented in ACHIEVEMENTS', () => {
    const cats = new Set(ACHIEVEMENTS.map(a => a.category));
    for (const c of ['starter','consistency','depth','endurance','focus','craft','quests','levels']) {
      ok(cats.has(c), `category "${c}" has no achievements`);
    }
  });

  t('secret achievements have secret:true and are a reasonable fraction', () => {
    const secrets = ACHIEVEMENTS.filter(a => a.secret);
    ok(secrets.length >= 8,  `expected ≥8 secret achievements, got ${secrets.length}`);
    ok(secrets.length <= 30, `too many secret achievements (${secrets.length})`);
    ok(secrets.every(a => a.secret === true));
  });

  // ── Level system ──────────────────────────────────────────────────────────
  t('levelFromXp(0) returns 1',         () => eq(levelFromXp(0), 1));
  t('levelFromXp at L2 threshold is 2', () => eq(levelFromXp(LEVEL_THRESHOLDS[1]), 2));
  t('levelFromXp at max returns 20',    () => eq(levelFromXp(999999), MAX_LEVEL));
  t('LEVEL_NAMES has 21 entries (0-20)',     () => eq(LEVEL_NAMES.length, MAX_LEVEL + 1));
  t('LEVEL_THRESHOLDS are strictly increasing', () => {
    for (let i = 1; i < LEVEL_THRESHOLDS.length - 1; i++)
      ok(LEVEL_THRESHOLDS[i] > LEVEL_THRESHOLDS[i-1], `threshold ${i} not strictly increasing`);
  });
  t('xpToNextLevel(0) matches L2 threshold',    () => eq(xpToNextLevel(0), LEVEL_THRESHOLDS[1]));
  t('xpToNextLevel at max returns 0',           () => eq(xpToNextLevel(999999), 0));
  t('levelProgressPct(0) is 0',                () => eq(levelProgressPct(0), 0));
  t('levelProgressPct at max is 100',          () => eq(levelProgressPct(999999), 100));
  t('levelProgressPct mid-level is 0-100', () => {
    const mid = Math.floor((LEVEL_THRESHOLDS[1] + LEVEL_THRESHOLDS[2]) / 2);
    const pct = levelProgressPct(mid);
    ok(pct > 0 && pct < 100, `mid-level pct should be 0-100, got ${pct}`);
  });

  // ── getDailyQuests ────────────────────────────────────────────────────────
  t('getDailyQuests returns exactly 3 quests',          () => eq(getDailyQuests('2026-04-14').length, 3));
  t('getDailyQuests always includes q_complete_any',    () => ok(getDailyQuests('2026-04-14').some(q => q.id === 'q_complete_any')));
  t('getDailyQuests is deterministic for same date',    () => {
    const a = getDailyQuests('2026-04-14').map(q => q.id).join(',');
    const b = getDailyQuests('2026-04-14').map(q => q.id).join(',');
    eq(a, b);
  });
  t('getDailyQuests produces unique quest ids each day', () => {
    for (const d of ['2026-04-14','2026-05-01','2026-12-25']) {
      const ids = getDailyQuests(d).map(q => q.id);
      eq(new Set(ids).size, 3, `${d}: duplicate quest ids`);
    }
  });
  t('getDailyQuests does not throw (BigInt regression)', () => {
    let threw = false;
    try { ['2026-04-14','2026-12-31','2027-01-01'].forEach(d => getDailyQuests(d)); }
    catch { threw = true; }
    ok(!threw, 'quest seeding must not throw');
  });
  t('getDailyQuests stable across 10 calls', () => {
    const results = Array.from({length:10}, () => getDailyQuests('2026-06-15').map(q=>q.id).join(','));
    ok(results.every(r => r === results[0]));
  });
  t('all quest condition functions are callable without throwing', () => {
    const quests = getDailyQuests('2026-04-14');
    for (const q of quests) {
      ok(typeof q.condition === 'function', `${q.id}: condition not a function`);
      let threw = false;
      try {
        q.condition(
          { completionState:'completed', totalSec:600, attentionLossEvents:0, loopsCompleted:1, attentionLossTotalSec:0 },
          { blocks:[], scenes:[], funscriptTracks:[], rules:[], rampSettings:{enabled:false}, pacingSettings:{enabled:false} },
          { streak:0, todayDate: new Date().toISOString().slice(0,10), sessionsToday:1 }
        );
      } catch { threw = true; }
      ok(!threw, `${q.id}: condition() threw`);
    }
  });

  // ── calculateSessionXp ────────────────────────────────────────────────────
  t('calculateSessionXp returns 0 for emergency', () => {
    eq(calculateSessionXp({ completionState:'emergency', totalSec:300, attentionLossEvents:0 }, {}, {}), 0);
  });
  t('calculateSessionXp > 0 for completed session', () => {
    ok(calculateSessionXp({ completionState:'completed', totalSec:300, attentionLossEvents:0 }, {}, {}) > 0);
  });
  t('longer session earns more XP (up to cap)', () => {
    const s  = { completionState:'completed', attentionLossEvents:0 };
    const s1 = { ...s, totalSec:120 };
    const s2 = { ...s, totalSec:1200 };
    ok(calculateSessionXp(s2,{},{}) > calculateSessionXp(s1,{},{}));
  });
  t('zero attention losses earns focus bonus', () => {
    const base   = { completionState:'completed', totalSec:600, attentionLossEvents:3, attentionLossTotalSec:120 };
    const noLoss = { completionState:'completed', totalSec:600, attentionLossEvents:0, attentionLossTotalSec:0 };
    ok(calculateSessionXp(noLoss,{},{}) > calculateSessionXp(base,{},{}));
  });
  t('haptic track earns feature bonus', () => {
    const s    = { completionState:'completed', totalSec:300, attentionLossEvents:0 };
    const wFs  = { funscriptTracks:[{_disabled:false}] };
    const noFs = { funscriptTracks:[] };
    ok(calculateSessionXp(s, wFs, {}) > calculateSessionXp(s, noFs, {}));
  });

  // ── checkAndAwardAchievements ─────────────────────────────────────────────
  t('first_session awarded at count=1', () => {
    const p = { sessionCount:1, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(newlyEarned.includes('first_session'));
  });

  t('first_comeback awarded at count=2', () => {
    const p = { sessionCount:2, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(newlyEarned.includes('first_comeback'));
  });

  t('already-earned achievements not re-awarded', () => {
    const p = { sessionCount:5, streak:0, totalRuntimeSec:0, achievements:['first_session','sessions_3'], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(!newlyEarned.includes('first_session'));
    ok(!newlyEarned.includes('sessions_3'));
  });

  t('perfect_attention awarded for 5+ min zero-loss session', () => {
    const p = { sessionCount:1, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:360, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(newlyEarned.includes('perfect_attention'));
  });

  t('perfect_attention NOT awarded for < 5 min', () => {
    const p = { sessionCount:1, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:120, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(!newlyEarned.includes('perfect_attention'));
  });

  t('use_viz awarded on completed session with viz block', () => {
    const p = { sessionCount:1, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const sess = { blocks:[{type:'viz'}] };
    const { newlyEarned } = checkAndAwardAchievements(p, s, sess);
    ok(newlyEarned.includes('use_viz'));
  });

  t('modes_2 awarded when modesUsed has 2 entries', () => {
    const p = { sessionCount:2, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:['exposure','focus'], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, { mode:'focus' });
    ok(newlyEarned.includes('modes_2'));
  });

  t('all_modes requires all 8 modes', () => {
    const eight = ['exposure','mindfulness','focus','freerun','induction','conditioning','training','surrender'];
    const p = { sessionCount:10, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:eight, monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(newlyEarned.includes('all_modes'));
  });

  t('level achievements awarded based on xp in profile', () => {
    const p = { sessionCount:1, streak:0, totalRuntimeSec:0, achievements:[], xp:250, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(newlyEarned.includes('first_level_up'), 'should earn first_level_up at level 4');
    ok(newlyEarned.includes('level_3'),        'should earn level_3 at level 4');
  });

  t('quest-count achievements awarded based on totalQuestsCompleted', () => {
    const p = { sessionCount:5, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0, totalQuestsCompleted:10, questTypesCompleted:[] };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(newlyEarned.includes('first_quest'));
    ok(newlyEarned.includes('quests_5'));
    ok(newlyEarned.includes('quests_10'));
  });

  t('monthly_visitor awarded when any month has 3+ sessions', () => {
    const p = { sessionCount:5, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{'2026-04':3}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(newlyEarned.includes('monthly_visitor'));
  });

  t('three_months awarded after sessions in 3 different months', () => {
    const p = { sessionCount:5, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{'2026-02':1,'2026-03':1,'2026-04':1}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(newlyEarned.includes('three_months'));
  });

  t('two_in_one_day awarded when sessionsToday >= 2 on todayDate', () => {
    const today = new Date().toISOString().slice(0, 10);
    const p = { sessionCount:2, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:today, sessionsToday:2 };
    const s = { completionState:'completed', totalSec:60, attentionLossEvents:0, attentionLossTotalSec:0 };
    const { newlyEarned } = checkAndAwardAchievements(p, s, {});
    ok(newlyEarned.includes('two_in_one_day'));
  });

  t('scene_arc requires all 4 scene state types', () => {
    const p = { sessionCount:1, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:300, attentionLossEvents:0, attentionLossTotalSec:0 };
    const sess = { scenes:[
      { stateType:'calm' },{ stateType:'build' },
      { stateType:'peak' },{ stateType:'recovery' },
    ]};
    const { newlyEarned } = checkAndAwardAchievements(p, s, sess);
    ok(newlyEarned.includes('scene_arc'));
  });

  t('scene_arc NOT awarded with only 3 scene types', () => {
    const p = { sessionCount:1, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:300, attentionLossEvents:0, attentionLossTotalSec:0 };
    const sess = { scenes:[{ stateType:'calm' },{ stateType:'build' },{ stateType:'peak' }] };
    const { newlyEarned } = checkAndAwardAchievements(p, s, sess);
    ok(!newlyEarned.includes('scene_arc'));
  });

  t('builder awarded with 8+ blocks in a completed session', () => {
    const p = { sessionCount:1, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:300, attentionLossEvents:0, attentionLossTotalSec:0 };
    const sess = { blocks: Array.from({length:8}, (_,i) => ({ type:'text', label:`b${i}` })) };
    const { newlyEarned } = checkAndAwardAchievements(p, s, sess);
    ok(newlyEarned.includes('builder'));
  });

  t('all_features awarded for haptic + viz + rules session', () => {
    const p = { sessionCount:1, streak:0, totalRuntimeSec:0, achievements:[], xp:0, modesUsed:[], monthCounts:{}, todayDate:null, sessionsToday:0 };
    const s = { completionState:'completed', totalSec:300, attentionLossEvents:0, attentionLossTotalSec:0 };
    const sess = {
      funscriptTracks:[{_disabled:false}],
      blocks:[{type:'viz'}],
      rules:[{enabled:true}],
    };
    const { newlyEarned } = checkAndAwardAchievements(p, s, sess);
    ok(newlyEarned.includes('all_features'));
  });

  // ── checkQuestProgress ────────────────────────────────────────────────────
  t('q_complete_any completes for a finished session', () => {
    const today = new Date().toISOString().slice(0, 10);
    const p = { questDate:today, quests:[{id:'q_complete_any',done:false}] };
    const s = { completionState:'completed', totalSec:300, attentionLossEvents:0, loopsCompleted:0, attentionLossTotalSec:0 };
    const { completed } = checkQuestProgress(s, {}, p);
    ok(completed.includes('q_complete_any'));
  });

  t('already-done quests do not re-fire', () => {
    const today = new Date().toISOString().slice(0, 10);
    const p = { questDate:today, quests:[{id:'q_complete_any',done:true}] };
    const s = { completionState:'completed', totalSec:300, attentionLossEvents:0, loopsCompleted:0, attentionLossTotalSec:0 };
    const { completed } = checkQuestProgress(s, {}, p);
    ok(!completed.includes('q_complete_any'));
  });

  t('perfect_quest_day triggered when all 3 quests done', () => {
    const today = new Date().toISOString().slice(0, 10);
    const quests = getDailyQuests(today);
    const questStates = quests.map(q => ({ id:q.id, done:true }));
    const p = { questDate:today, quests:questStates, perfectQuestDays:0 };
    // All already done — simulate it being set
    ok(questStates.every(q => q.done), 'all quests should be done in test');
  });

  return R.summary();
}
