# Adaptive Session Studio

A self-contained local web app for designing and running customizable passive sessions with text, browser TTS, images, videos, and audio.

## What it is

This app is meant to be a rapid-prototype authoring and playback environment for personal audiovisual conditioning sessions.

It is:
- self-contained
- editable by humans
- easy to expand
- dependency-free
- fully local

No build tools, frameworks, servers, or external CDNs are required.

## Files

- `index.html` — app shell
- `styles.css` — layout and theme styling
- `app.js` — editor logic, runtime engine, JSON import/export, playback control
- `sample-session.json` — starter session file

## How to run

### Simplest

Double-click `index.html`.

### Better for browser media behavior

Some browsers are happier if you serve local files through a tiny local server.

Python 3:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## Main features

- session metadata editor
- theme controls
- custom background audio
- custom background image or video
- block timeline editor
- block types:
  - text
  - browser TTS
  - image
  - video
  - audio
  - pause
- JSON import/export
- live JSON preview
- local autosave in browser storage
- fullscreen preview stage
- dependency-free runtime

## Session model

A session has:
- `name`
- `duration`
- `theme`
- visual/audio settings
- `blocks[]`

Each block contains scheduling and content data.

### Example block

```json
{
  "id": "abc123",
  "type": "text",
  "label": "Anchor words",
  "start": 35,
  "duration": 16,
  "content": "Still.\nCentered.\nUnhurried.",
  "fontSize": 1.5
}
```

## Notes about self-contained media

When you load media through the editor, the app stores it in the session JSON as a `data:` URL.
That makes exported session files portable, but large media files can make the JSON very large.

For small experiments, this is convenient.
For larger future versions, a clean extension would be:
- add an asset manifest
- store media as separate files
- reference them by relative path

## Easy extension points

### Add new block types

In `app.js`, update:
- block type selector
- `renderTypeSpecificFields()`
- `renderActiveBlocks()`
- `triggerBlockEffects()`

### Add rule logic

You can add a `rules` object to the session model and run it inside `tick()`.
Examples:
- repeat a block if attention is low
- trigger alternate narration if gaze drifts
- pause if headset is removed

### Add sensing

Possible future additions:
- webcam attention tracking
- posture estimation
- breathing proxy
- microphone reactivity detection
- WebXR headset support

## Known limits

- browser TTS voice availability depends on the browser and OS
- autoplay rules may require a user gesture before audio starts
- very large embedded media files can bloat exported JSON
- no waveform editor or drag timeline yet

## Suggested next upgrades

- drag-and-drop timeline editing
- asset library sidebar
- session validation panel
- cue transitions and easing
- rule engine
- multi-track layering
- headset / webcam sensing
- WebXR runtime mode
