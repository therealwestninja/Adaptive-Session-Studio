(() => {
  const STORAGE_KEY = 'adaptive-session-studio-v1';
  const themes = {
    midnight: { name: 'Midnight', backgroundColor: '#05070a', accentColor: '#7fb0ff', textColor: '#eef3fb' },
    ember: { name: 'Ember', backgroundColor: '#150909', accentColor: '#ff9a6b', textColor: '#fff0ea' },
    moss: { name: 'Moss', backgroundColor: '#07120b', accentColor: '#9be7a1', textColor: '#eefcf1' },
    violet: { name: 'Violet', backgroundColor: '#100916', accentColor: '#c09cff', textColor: '#f4ebff' }
  };

  const sampleSession = {
    name: 'grounded_steady_sample',
    duration: 180,
    theme: 'midnight',
    masterVolume: 0.7,
    autoLoop: false,
    speechRate: 0.95,
    backgroundColor: '#05070a',
    accentColor: '#7fb0ff',
    assets: { bgAudioName: '', bgAudioDataUrl: '', bgVisualName: '', bgVisualDataUrl: '', bgVisualKind: '' },
    blocks: [
      { id: uid(), type: 'text', label: 'Opening line', start: 0, duration: 12, content: 'Settle in. Breathe slowly. Let your attention narrow to this moment.', fontSize: 1.15 },
      { id: uid(), type: 'tts', label: 'Steady cue', start: 15, duration: 12, content: 'You do not need to rush. Slow is stable. Stable is clear.', voiceName: '', volume: 0.85 },
      { id: uid(), type: 'text', label: 'Anchor words', start: 35, duration: 16, content: 'Still.\nCentered.\nUnhurried.', fontSize: 1.5 },
      { id: uid(), type: 'pause', label: 'Quiet spacing', start: 58, duration: 10 },
      { id: uid(), type: 'tts', label: 'Reinforcement', start: 72, duration: 12, content: 'Each breath softens urgency. Each pause makes you more deliberate.', voiceName: '', volume: 0.85 },
      { id: uid(), type: 'text', label: 'Closing line', start: 105, duration: 20, content: 'Carry this steadiness with you after the session ends.', fontSize: 1.2 }
    ]
  };

  const el = (id) => document.getElementById(id);
  const refs = {
    sessionName: el('sessionName'), sessionDuration: el('sessionDuration'), themeSelect: el('themeSelect'), masterVolume: el('masterVolume'), autoLoop: el('autoLoop'), speechRate: el('speechRate'), backgroundColor: el('backgroundColor'), accentColor: el('accentColor'),
    bgAudioInput: el('bgAudioInput'), bgVisualInput: el('bgVisualInput'), bgAudioLabel: el('bgAudioLabel'), bgVisualLabel: el('bgVisualLabel'),
    blockList: el('blockList'), blockEditor: el('blockEditor'), jsonPreview: el('jsonPreview'),
    timeDisplay: el('timeDisplay'), activeBlockDisplay: el('activeBlockDisplay'), rateDisplay: el('rateDisplay'), previewStage: el('previewStage'), backgroundHost: el('backgroundHost'), overlayText: el('overlayText'), stageHud: el('stageHud')
  };

  let session = loadState();
  let selectedBlockId = session.blocks[0]?.id || null;
  let playback = { running: false, raf: null, startTs: 0, elapsed: 0, spokenIds: new Set(), audioMap: new Map(), startedMediaIds: new Set() };
  let bgAudio = null;

  init();

  function init() {
    buildThemeOptions();
    bindTopLevelInputs();
    bindButtons();
    renderAll();
  }

  function buildThemeOptions() {
    refs.themeSelect.innerHTML = Object.entries(themes).map(([key, value]) => `<option value="${key}">${value.name}</option>`).join('');
  }

  function bindTopLevelInputs() {
    ['sessionName','sessionDuration','themeSelect','masterVolume','autoLoop','speechRate','backgroundColor','accentColor'].forEach((key) => {
      refs[key].addEventListener('input', syncSessionFromInputs);
      refs[key].addEventListener('change', syncSessionFromInputs);
    });

    refs.bgAudioInput.addEventListener('change', async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const dataUrl = await fileToDataUrl(file);
      session.assets.bgAudioName = file.name;
      session.assets.bgAudioDataUrl = dataUrl;
      refs.bgAudioLabel.textContent = file.name;
      saveAndRender();
    });

    refs.bgVisualInput.addEventListener('change', async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const dataUrl = await fileToDataUrl(file);
      session.assets.bgVisualName = file.name;
      session.assets.bgVisualDataUrl = dataUrl;
      session.assets.bgVisualKind = file.type.startsWith('video/') ? 'video' : 'image';
      refs.bgVisualLabel.textContent = file.name;
      saveAndRender();
    });
  }

  function bindButtons() {
    document.querySelectorAll('[data-add-block]').forEach((btn) => btn.addEventListener('click', () => addBlock(btn.dataset.addBlock)));
    el('newSessionBtn').addEventListener('click', () => {
      session = structuredClone(sampleSession);
      session.name = 'new_session';
      session.blocks = [];
      selectedBlockId = null;
      stopPlayback();
      saveAndRender();
    });
    el('loadSampleBtn').addEventListener('click', () => {
      session = structuredClone(sampleSession);
      selectedBlockId = session.blocks[0]?.id || null;
      stopPlayback();
      saveAndRender();
    });
    el('duplicateBlockBtn').addEventListener('click', duplicateSelectedBlock);
    el('deleteBlockBtn').addEventListener('click', deleteSelectedBlock);
    el('saveSessionBtn').addEventListener('click', exportSession);
    el('applyJsonBtn').addEventListener('click', importFromTextarea);
    el('formatJsonBtn').addEventListener('click', () => { refs.jsonPreview.value = JSON.stringify(session, null, 2); });
    el('importSessionInput').addEventListener('change', handleImportFile);
    el('playBtn').addEventListener('click', startPlayback);
    el('pauseBtn').addEventListener('click', pausePlayback);
    el('stopBtn').addEventListener('click', stopPlayback);
    el('toggleFullscreenBtn').addEventListener('click', toggleFullscreen);
  }

  function syncSessionFromInputs() {
    session.name = refs.sessionName.value.trim() || 'untitled_session';
    session.duration = Math.max(10, Number(refs.sessionDuration.value || 60));
    session.theme = refs.themeSelect.value;
    session.masterVolume = Number(refs.masterVolume.value || 0.7);
    session.autoLoop = refs.autoLoop.value === 'true';
    session.speechRate = Number(refs.speechRate.value || 1);
    session.backgroundColor = refs.backgroundColor.value;
    session.accentColor = refs.accentColor.value;
    saveAndRender();
  }

  function renderAll() {
    renderTopLevelInputs();
    renderBlockList();
    renderBlockEditor();
    renderJson();
    renderStageBase();
    refs.rateDisplay.textContent = `${session.speechRate.toFixed(2)}x`;
    refs.bgAudioLabel.textContent = session.assets.bgAudioName || 'None selected';
    refs.bgVisualLabel.textContent = session.assets.bgVisualName || 'None selected';
    updateTimeDisplay(playback.elapsed);
  }

  function renderTopLevelInputs() {
    refs.sessionName.value = session.name || '';
    refs.sessionDuration.value = session.duration || 60;
    refs.themeSelect.value = session.theme || 'midnight';
    refs.masterVolume.value = session.masterVolume ?? 0.7;
    refs.autoLoop.value = String(session.autoLoop ?? false);
    refs.speechRate.value = session.speechRate ?? 1;
    refs.backgroundColor.value = session.backgroundColor || '#05070a';
    refs.accentColor.value = session.accentColor || '#7fb0ff';
  }

  function renderBlockList() {
    refs.blockList.innerHTML = '';
    const sorted = [...session.blocks].sort((a,b) => a.start - b.start);
    const tpl = el('blockItemTemplate');
    sorted.forEach((block, index) => {
      const node = tpl.content.firstElementChild.cloneNode(true);
      node.classList.toggle('active', block.id === selectedBlockId);
      node.querySelector('.block-title').textContent = `${index + 1}. ${block.label || titleCase(block.type)}`;
      node.querySelector('.block-meta').textContent = `${titleCase(block.type)} · ${block.start}s → ${block.start + (block.duration || 0)}s`;
      node.querySelector('.block-button').addEventListener('click', () => { selectedBlockId = block.id; renderBlockList(); renderBlockEditor(); });
      refs.blockList.appendChild(node);
    });
  }

  function renderBlockEditor() {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    if (!block) {
      refs.blockEditor.innerHTML = '<p class="muted">Select a block to edit its settings.</p>';
      return;
    }
    refs.blockEditor.innerHTML = `
      <div class="block-field-grid">
        <label>Label<input data-field="label" type="text" value="${escapeHtml(block.label || '')}" /></label>
        <label>Type<select data-field="type">${['text','tts','image','video','audio','pause'].map(type => `<option value="${type}" ${block.type===type?'selected':''}>${titleCase(type)}</option>`).join('')}</select></label>
        <label>Start (sec)<input data-field="start" type="number" min="0" step="1" value="${block.start || 0}" /></label>
        <label>Duration (sec)<input data-field="duration" type="number" min="0" step="1" value="${block.duration || 0}" /></label>
      </div>
      <hr />
      ${renderTypeSpecificFields(block)}
    `;

    refs.blockEditor.querySelectorAll('[data-field]').forEach((input) => {
      input.addEventListener('input', async (e) => {
        const field = e.target.dataset.field;
        let value = e.target.value;
        if (['start','duration','fontSize','volume'].includes(field)) value = Number(value);
        block[field] = value;
        saveAndRender();
      });
      input.addEventListener('change', async (e) => {
        if (e.target.dataset.fileField) {
          const file = e.target.files?.[0];
          if (!file) return;
          block[e.target.dataset.fileField] = await fileToDataUrl(file);
          block[`${e.target.dataset.fileField}Name`] = file.name;
          saveAndRender();
        }
      });
    });
  }

  function renderTypeSpecificFields(block) {
    switch (block.type) {
      case 'text':
        return `
          <label>Text<textarea data-field="content" rows="8">${escapeHtml(block.content || '')}</textarea></label>
          <div class="block-field-grid">
            <label>Font size multiplier<input data-field="fontSize" type="number" min="0.5" max="3" step="0.05" value="${block.fontSize || 1}" /></label>
          </div>`;
      case 'tts':
        return `
          <label>Speech text<textarea data-field="content" rows="8">${escapeHtml(block.content || '')}</textarea></label>
          <div class="block-field-grid">
            <label>Voice name (optional)<input data-field="voiceName" type="text" value="${escapeHtml(block.voiceName || '')}" placeholder="Browser voice name" /></label>
            <label>Volume<input data-field="volume" type="number" min="0" max="1" step="0.05" value="${block.volume ?? 1}" /></label>
          </div>`;
      case 'image':
        return `
          <label>Caption<textarea data-field="content" rows="4">${escapeHtml(block.content || '')}</textarea></label>
          <label>Image file<input data-field="ignored" data-file-field="dataUrl" type="file" accept="image/*" /></label>
          <p class="small muted">${block.dataUrlName ? `Current: ${escapeHtml(block.dataUrlName)}` : 'No image selected yet.'}</p>`;
      case 'video':
        return `
          <label>Caption<textarea data-field="content" rows="4">${escapeHtml(block.content || '')}</textarea></label>
          <label>Video file<input data-field="ignored" data-file-field="dataUrl" type="file" accept="video/*" /></label>
          <p class="small muted">${block.dataUrlName ? `Current: ${escapeHtml(block.dataUrlName)}` : 'No video selected yet.'}</p>`;
      case 'audio':
        return `
          <label>Caption<textarea data-field="content" rows="4">${escapeHtml(block.content || '')}</textarea></label>
          <div class="block-field-grid">
            <label>Volume<input data-field="volume" type="number" min="0" max="1" step="0.05" value="${block.volume ?? 1}" /></label>
          </div>
          <label>Audio file<input data-field="ignored" data-file-field="dataUrl" type="file" accept="audio/*" /></label>
          <p class="small muted">${block.dataUrlName ? `Current: ${escapeHtml(block.dataUrlName)}` : 'No audio selected yet.'}</p>`;
      case 'pause':
      default:
        return '<p class="muted">A pause block holds space and displays no new media.</p>';
    }
  }

  function addBlock(type) {
    const base = { id: uid(), type, label: `New ${titleCase(type)}`, start: estimateNextStart(), duration: type === 'pause' ? 5 : 10, content: '', volume: 1, fontSize: 1 };
    if (type === 'tts') base.content = 'Write the spoken line here.';
    if (type === 'text') base.content = 'Write the on-screen text here.';
    session.blocks.push(base);
    selectedBlockId = base.id;
    saveAndRender();
  }

  function duplicateSelectedBlock() {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    if (!block) return;
    const copy = structuredClone(block);
    copy.id = uid();
    copy.start = (block.start || 0) + 2;
    copy.label = `${block.label || titleCase(block.type)} Copy`;
    session.blocks.push(copy);
    selectedBlockId = copy.id;
    saveAndRender();
  }

  function deleteSelectedBlock() {
    if (!selectedBlockId) return;
    session.blocks = session.blocks.filter((b) => b.id !== selectedBlockId);
    selectedBlockId = session.blocks[0]?.id || null;
    saveAndRender();
  }

  function renderJson() {
    refs.jsonPreview.value = JSON.stringify(session, null, 2);
  }

  function importFromTextarea() {
    try {
      const next = JSON.parse(refs.jsonPreview.value);
      normalizeSession(next);
      session = next;
      selectedBlockId = session.blocks[0]?.id || null;
      stopPlayback();
      saveAndRender();
    } catch (err) {
      alert(`Invalid JSON: ${err.message}`);
    }
  }

  async function handleImportFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const next = JSON.parse(text);
      normalizeSession(next);
      session = next;
      selectedBlockId = session.blocks[0]?.id || null;
      stopPlayback();
      saveAndRender();
    } catch (err) {
      alert(`Could not import session: ${err.message}`);
    }
  }

  function exportSession() {
    const blob = new Blob([JSON.stringify(session, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${session.name || 'session'}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 500);
  }

  function renderStageBase() {
    document.documentElement.style.setProperty('--accent', session.accentColor || '#7fb0ff');
    refs.previewStage.style.background = session.backgroundColor || '#05070a';
    refs.overlayText.style.color = themes[session.theme]?.textColor || '#eef3fb';
    refs.backgroundHost.innerHTML = '';
    refs.overlayText.textContent = '';
    refs.stageHud.textContent = playback.running ? 'Running' : 'Idle';

    if (session.assets.bgVisualDataUrl) {
      if (session.assets.bgVisualKind === 'video') {
        const v = document.createElement('video');
        v.src = session.assets.bgVisualDataUrl;
        v.autoplay = playback.running;
        v.loop = true;
        v.muted = true;
        v.playsInline = true;
        refs.backgroundHost.appendChild(v);
        if (playback.running) v.play().catch(() => {});
      } else {
        const img = document.createElement('img');
        img.src = session.assets.bgVisualDataUrl;
        refs.backgroundHost.appendChild(img);
      }
    }

    if (bgAudio) {
      bgAudio.pause();
      bgAudio = null;
    }
    if (session.assets.bgAudioDataUrl) {
      bgAudio = new Audio(session.assets.bgAudioDataUrl);
      bgAudio.loop = true;
      bgAudio.volume = (session.masterVolume ?? 0.7) * 0.7;
      if (playback.running) bgAudio.play().catch(() => {});
    }
  }

  async function startPlayback() {
    if (playback.running) return;
    playback.running = true;
    playback.startTs = performance.now() - playback.elapsed * 1000;
    refs.stageHud.textContent = 'Running';
    renderStageBase();
    if (bgAudio) bgAudio.play().catch(() => {});
    tick();
  }

  function pausePlayback() {
    playback.running = false;
    cancelAnimationFrame(playback.raf);
    if (bgAudio) bgAudio.pause();
    stopTransientAudio();
    speechSynthesis.cancel();
    refs.stageHud.textContent = 'Paused';
  }

  function stopPlayback() {
    playback.running = false;
    cancelAnimationFrame(playback.raf);
    playback.elapsed = 0;
    playback.spokenIds.clear();
    playback.startedMediaIds.clear();
    if (bgAudio) { bgAudio.pause(); bgAudio.currentTime = 0; }
    stopTransientAudio();
    speechSynthesis.cancel();
    renderStageBase();
    refs.activeBlockDisplay.textContent = '—';
    updateTimeDisplay(0);
  }

  function tick() {
    if (!playback.running) return;
    playback.elapsed = Math.min(session.duration, (performance.now() - playback.startTs) / 1000);
    updateTimeDisplay(playback.elapsed);
    const active = getActiveBlocks(playback.elapsed);
    renderActiveBlocks(active);
    triggerBlockEffects(active);

    if (playback.elapsed >= session.duration) {
      if (session.autoLoop) {
        playback.elapsed = 0;
        playback.startTs = performance.now();
        playback.spokenIds.clear();
        playback.startedMediaIds.clear();
        stopTransientAudio();
        speechSynthesis.cancel();
      } else {
        stopPlayback();
        refs.stageHud.textContent = 'Complete';
        return;
      }
    }
    playback.raf = requestAnimationFrame(tick);
  }

  function getActiveBlocks(t) {
    return session.blocks.filter((block) => t >= block.start && t < block.start + (block.duration || 0)).sort((a,b) => a.start - b.start);
  }

  function renderActiveBlocks(activeBlocks) {
    const textLike = activeBlocks.filter((b) => ['text','tts','image','video','audio'].includes(b.type)).at(-1);
    refs.activeBlockDisplay.textContent = textLike ? `${textLike.label || titleCase(textLike.type)} (${titleCase(textLike.type)})` : '—';
    refs.overlayText.textContent = textLike?.content || '';
    refs.overlayText.style.fontSize = `${(textLike?.fontSize || 1) * 2}rem`;

    const mediaBlock = activeBlocks.filter((b) => ['image','video'].includes(b.type) && b.dataUrl).at(-1);
    if (mediaBlock) {
      refs.backgroundHost.innerHTML = '';
      if (mediaBlock.type === 'video') {
        const v = document.createElement('video');
        v.src = mediaBlock.dataUrl;
        v.autoplay = true;
        v.loop = true;
        v.muted = true;
        v.playsInline = true;
        refs.backgroundHost.appendChild(v);
        v.play().catch(() => {});
      } else {
        const img = document.createElement('img');
        img.src = mediaBlock.dataUrl;
        refs.backgroundHost.appendChild(img);
      }
    } else if (session.assets.bgVisualDataUrl && refs.backgroundHost.children.length === 0) {
      renderStageBase();
    }
  }

  function triggerBlockEffects(activeBlocks) {
    activeBlocks.forEach((block) => {
      if (block.type === 'tts' && !playback.spokenIds.has(block.id)) {
        playback.spokenIds.add(block.id);
        speakBlock(block);
      }
      if (block.type === 'audio' && block.dataUrl && !playback.startedMediaIds.has(block.id)) {
        playback.startedMediaIds.add(block.id);
        const a = new Audio(block.dataUrl);
        a.volume = clamp((block.volume ?? 1) * (session.masterVolume ?? 0.7));
        playback.audioMap.set(block.id, a);
        a.play().catch(() => {});
      }
    });

    for (const [id, audio] of playback.audioMap.entries()) {
      const stillActive = activeBlocks.some((b) => b.id === id);
      if (!stillActive) {
        audio.pause();
        playback.audioMap.delete(id);
      }
    }
  }

  function speakBlock(block) {
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(block.content || '');
    utterance.rate = session.speechRate || 1;
    utterance.volume = clamp((block.volume ?? 1) * (session.masterVolume ?? 0.7));
    const voices = speechSynthesis.getVoices();
    if (block.voiceName) {
      const matched = voices.find((v) => v.name === block.voiceName);
      if (matched) utterance.voice = matched;
    }
    speechSynthesis.speak(utterance);
  }

  function stopTransientAudio() {
    for (const audio of playback.audioMap.values()) audio.pause();
    playback.audioMap.clear();
  }

  function updateTimeDisplay(seconds) {
    refs.timeDisplay.textContent = `${fmt(seconds)} / ${fmt(session.duration || 0)}`;
  }

  function toggleFullscreen() {
    if (!document.fullscreenElement) refs.previewStage.requestFullscreen?.();
    else document.exitFullscreen?.();
  }

  function estimateNextStart() {
    if (!session.blocks.length) return 0;
    return Math.max(...session.blocks.map((b) => (b.start || 0) + (b.duration || 0))) + 2;
  }

  function saveAndRender() {
    persistState();
    renderAll();
  }

  function persistState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return structuredClone(sampleSession);
      const parsed = JSON.parse(raw);
      normalizeSession(parsed);
      return parsed;
    } catch {
      return structuredClone(sampleSession);
    }
  }

  function normalizeSession(obj) {
    obj.name ||= 'untitled_session';
    obj.duration = Math.max(10, Number(obj.duration || 60));
    obj.theme ||= 'midnight';
    obj.masterVolume = clamp(Number(obj.masterVolume ?? 0.7));
    obj.autoLoop = Boolean(obj.autoLoop);
    obj.speechRate = Number(obj.speechRate || 1);
    obj.backgroundColor ||= themes[obj.theme]?.backgroundColor || '#05070a';
    obj.accentColor ||= themes[obj.theme]?.accentColor || '#7fb0ff';
    obj.assets ||= { bgAudioName: '', bgAudioDataUrl: '', bgVisualName: '', bgVisualDataUrl: '', bgVisualKind: '' };
    obj.blocks = Array.isArray(obj.blocks) ? obj.blocks : [];
    obj.blocks.forEach((b) => {
      b.id ||= uid();
      b.type ||= 'text';
      b.label ||= titleCase(b.type);
      b.start = Number(b.start || 0);
      b.duration = Number(b.duration || 0);
      b.content ||= '';
      if (b.volume == null) b.volume = 1;
      if (b.fontSize == null) b.fontSize = 1;
    });
  }

  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function uid() { return Math.random().toString(36).slice(2, 10); }
  function fmt(totalSec) {
    const sec = Math.floor(totalSec % 60).toString().padStart(2, '0');
    const min = Math.floor(totalSec / 60).toString().padStart(2, '0');
    return `${min}:${sec}`;
  }
  function titleCase(s) { return (s || '').replace(/_/g, ' ').replace(/\b\w/g, (m) => m.toUpperCase()); }
  function clamp(n) { return Math.min(1, Math.max(0, Number(n))); }
  function escapeHtml(text) { return String(text).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;'); }
})();
