# Architecture Reference

## Overview

Adaptive Session Studio is a browser-native ES module application. No bundler, no framework, no build step. 28 JavaScript modules communicate through explicit imports and a shared `state` object.

## File Structure

```
Adaptive-Session-Studio/
├── index.html              # Single HTML shell — all DOM IDs
├── css/
│   └── style.css           # Complete design system + component styles
├── js/
│   ├── main.js             # Entry point — wires all modules to DOM
│   ├── state.js            # Shared state, normalizers, uid, helpers
│   ├── playback.js         # RAF loop, block execution, transport
│   ├── ui.js               # Sidebar, inspector, settings rendering
│   ├── funscript.js        # Multi-lane timeline canvas rendering
│   ├── audio-engine.js     # Web Audio API playback
│   ├── state-engine.js     # Multi-signal fusion engagement engine
│   ├── rules-engine.js     # Behavioral scripting evaluation
│   ├── trigger-windows.js  # Timed interaction windows
│   ├── safety.js           # Hard limits and emergency cooldown
│   ├── intensity-ramp.js   # Configurable intensity curves
│   ├── dynamic-pacing.js   # Engagement-driven speed
│   ├── session-modes.js    # Preset session configurations
│   ├── ai-authoring.js     # LLM session generation
│   ├── live-control.js     # Real-time playback sliders
│   ├── macros.js           # FunScript macro library
│   ├── macro-ui.js         # Macro library/editor UI rendering
│   ├── scenes.js           # Scene CRUD and navigation
│   ├── tracking.js         # Webcam attention tracking
│   ├── session-analytics.js# Post-session data
│   ├── user-profile.js     # Adaptive difficulty, streaks
│   ├── suggestions.js      # Session health suggestions
│   ├── subtitle.js         # ASS/SSA parsing and display
│   ├── notify.js           # Toast notifications
│   ├── history.js          # Undo/redo stack
│   ├── capabilities.js     # Browser feature detection
│   ├── block-ops.js        # Block duplicate/delete
│   └── fullscreen-hud.js   # Fullscreen overlay HUD
├── tests/
│   ├── index.html          # Test runner
│   ├── harness.js          # Minimal test framework
│   └── *.test.js           # 11 test files, ~250 tests
└── docs/
    ├── README.md           # User-facing documentation
    ├── ARCHITECTURE.md     # This file
    └── CHANGELOG.md        # Version history
```

## State Model

All session data lives in `state.js`:

```js
state.session   // The full session object (blocks, scenes, rules, tracks...)
state.runtime   // Active playback runtime (null when stopped)
state.liveControl  // Real-time intensity/speed overrides
state.engineState  // Published metrics from state-engine (attention, engagement...)
state.fsEditMode   // Timeline edit mode flag
state.fsPaused     // FunScript pause flag
state._fsStateRef  // Bridge for deviceLoad metric (set by playback.js)
```

`state.session` is persisted to `localStorage` under `adaptive-session-studio-v4` after every mutation via `persist()`.

## RAF Loop (playback.js)

The main playback loop runs at ~60fps when active. Tick order:

1. State engine publish (`tickStateEngine`)
2. Rules engine evaluation (`tickRulesEngine`)
3. Intensity ramp apply (`applyRamp`)
4. Dynamic pacing modulate (`tickDynamicPacing`)
5. Trigger windows check (`tickTriggerWindows`)
6. Safety layer tick (`tickSafety`)
7. Block handling (overlay text, audio, video, macro injection)
8. Analytics accumulation
9. Subtitle cue update
10. FunScript position calculation → device output
11. Timeline canvas draw
12. Transport UI update
13. Live status refresh
14. Live engine meters update
15. Fullscreen HUD tick

## Import Graph (simplified)

```
main.js
  ├── state.js (shared by all)
  ├── ui.js → session-modes.js, trigger-windows.js, ai-authoring.js, scenes.js, rules-engine.js
  ├── playback.js → state-engine.js, rules-engine.js, intensity-ramp.js, dynamic-pacing.js,
  │                 trigger-windows.js, safety.js, macros.js, subtitle.js, session-analytics.js,
  │                 funscript.js, live-control.js, fullscreen-hud.js
  ├── funscript.js → macros.js (device output)
  ├── live-control.js → intensity-ramp.js, dynamic-pacing.js, safety.js
  ├── tracking.js → state-engine.js, notify.js, history.js, session-analytics.js
  ├── suggestions.js → state.js, notify.js
  ├── audio-engine.js (standalone)
  ├── capabilities.js → notify.js
  └── macro-ui.js → macros.js, state.js
```

Circular dependencies are resolved with lazy `import()` calls (currently 19 lazy imports, all justified by circular dep chains).

## Session Schema

```ts
interface Session {
  name: string;
  duration: number;             // seconds
  loopMode: 'none'|'count'|'minutes'|'forever';
  loopCount: number;
  runtimeMinutes: number;
  speechRate: number;
  masterVolume: number;
  backgroundColor: string;
  textColor: string;
  accentColor: string;
  theme: string;
  customThemes: Record<string, Theme>;
  tracking: TrackingSettings;
  advanced: AdvancedSettings;
  subtitleSettings: SubtitleSettings;
  funscriptSettings: FunscriptSettings;
  trackingFsOptions: TrackingFsOptions;
  playlists: { audio: string[], video: string[] };
  subtitleTracks: SubtitleTrack[];
  funscriptTracks: FunscriptTrack[];
  audioTracks: AudioTrack[];
  videoTracks: VideoTrack[];
  macroLibrary: Macro[];
  macroSlots: Record<1|2|3|4|5, string|null>;
  blocks: Block[];
  scenes: Scene[];
  rules: Rule[];
  triggers: Trigger[];
  rampSettings: RampSettings | null;
  pacingSettings: PacingSettings | null;
  safetySettings: SafetySettings | null;
}
```

## Adaptive Engine (state-engine.js)

The engagement score is a weighted combination of multiple signals:

```
engagement = normalize(
  attention × 0.70     ← webcam face detection (0–1)
  deviceLoad × 0.20    ← FunScript last sent position (0–1)
  intensity × 0.10     ← current intensity scale (0–1 mapped)
  + external signals   ← biofeedback adapter via setExternalSignal()
)
```

Smoothed with EMA (α = 0.05, ~3s time constant at 60fps).

The engagement score drives:
- Dynamic pacing (speed modulation)
- Rules engine metric evaluations
- Trigger window condition checks
- Safety auto-reduce decisions

## Safety Layer (safety.js)

The safety layer is always active and cannot be bypassed:

- `clampIntensity(v)` — hard cap at `safetySettings.maxIntensity` (default 2.0)
- `clampSpeed(v)` — hard cap at `safetySettings.maxSpeed` (default 4.0)
- Emergency cooldown — blocks restart for N seconds after `emergencyStop()`
- Auto-reduce — optionally drops intensity when attention < 0.2
- Warn threshold — displays a banner when intensity exceeds `warnAbove`

Both `setLiveIntensity()` and `setLiveSpeed()` in `live-control.js` route through safety clamps before writing to state.

## UI Rendering Pattern

The inspector panel is re-rendered on every state change that could affect it, using `renderInspector()` from `ui.js`. The inspector renders different content based on:

- `state.selectedBlockId` — renders block inspector
- `state.selectedSidebarType` — renders scenes/rules/triggers inspector
- `state.inspTab` — selects Block, Session, or Status tab

Settings forms use `syncSettingsForms()` to write from state → form, and `syncSessionFromSettings()` to write from form → state (triggered by the settings dialog `input` event).

## Testing

Run tests by opening `tests/index.html` in a browser. The test harness (`tests/harness.js`) is a minimal runner with no external dependencies.

Current coverage: 11 test files, ~250 assertions covering state normalizers, all module systems, and CRUD operations for every major entity type.
