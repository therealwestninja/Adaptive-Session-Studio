(() => {
  const STORAGE_KEY = 'adaptive-session-studio-v2';
  const PACKAGE_VERSION = 2;

  const themes = {
    midnight: { name: 'Midnight', backgroundColor: '#05070a', accentColor: '#7fb0ff', textColor: '#eef4fb' },
    ember: { name: 'Ember', backgroundColor: '#160909', accentColor: '#ff9f71', textColor: '#fff0ea' },
    moss: { name: 'Moss', backgroundColor: '#07130b', accentColor: '#9be7a1', textColor: '#eefcf1' },
    violet: { name: 'Violet', backgroundColor: '#100916', accentColor: '#c8a4ff', textColor: '#f4ebff' }
  };

  const defaultSession = () => ({
    packageVersion: PACKAGE_VERSION,
    name: 'adaptive_session',
    duration: 180,
    theme: 'midnight',
    masterVolume: 0.8,
    speechRate: 1,
    loopMode: 'count',
    loopCount: 1,
    runtimeMinutes: 10,
    backgroundColor: themes.midnight.backgroundColor,
    accentColor: themes.midnight.accentColor,
    textColor: themes.midnight.textColor,
    tracking: {
      enabled: false,
      autoPauseOnAttentionLoss: false,
      attentionThreshold: 5
    },
    playlists: {
      audio: [],
      video: []
    },
    blocks: []
  });

  const sampleSession = {
    packageVersion: PACKAGE_VERSION,
    name: 'grounded_focus_package',
    duration: 120,
    theme: 'midnight',
    masterVolume: 0.8,
    speechRate: 0.95,
    loopMode: 'count',
    loopCount: 2,
    runtimeMinutes: 8,
    backgroundColor: '#05070a',
    accentColor: '#7fb0ff',
    textColor: '#eef4fb',
    tracking: { enabled: false, autoPauseOnAttentionLoss: false, attentionThreshold: 5 },
    playlists: { audio: [], video: [] },
    blocks: [
      { id: uid(), type: 'text', label: 'Settle', start: 0, duration: 12, content: 'Settle in. Let your breathing slow.', fontSize: 1.2 },
      { id: uid(), type: 'tts', label: 'Opening cue', start: 14, duration: 10, content: 'You can take your time. There is no need to rush.', volume: 0.9, voiceName: '' },
      { id: uid(), type: 'text', label: 'Anchor words', start: 34, duration: 12, content: 'Steady.\nClear.\nPresent.', fontSize: 1.55 },
      { id: uid(), type: 'pause', label: 'Spacing', start: 52, duration: 8 },
      { id: uid(), type: 'tts', label: 'Closing cue', start: 68, duration: 12, content: 'Carry the same steadiness into your next action.', volume: 0.9, voiceName: '' }
    ]
  };

  const $ = (id) => document.getElementById(id);
  const refs = {
    sessionName: $('sessionName'), sessionDuration: $('sessionDuration'), themeSelect: $('themeSelect'), masterVolume: $('masterVolume'), speechRate: $('speechRate'),
    loopMode: $('loopMode'), loopCount: $('loopCount'), runtimeMinutes: $('runtimeMinutes'), backgroundColor: $('backgroundColor'), accentColor: $('accentColor'), textColor: $('textColor'),
    blockList: $('blockList'), blockEditor: $('blockEditor'), jsonPreview: $('jsonPreview'),
    audioTrackList: $('audioTrackList'), videoTrackList: $('videoTrackList'),
    timeDisplay: $('timeDisplay'), loopDisplay: $('loopDisplay'), activeBlockDisplay: $('activeBlockDisplay'), attentionDisplay: $('attentionDisplay'),
    previewStage: $('previewStage'), backgroundHost: $('backgroundHost'), overlayText: $('overlayText'), stageHud: $('stageHud'),
    trackingPreview: $('trackingPreview'), trackingEnabled: $('trackingEnabled'), autoPauseOnAttentionLoss: $('autoPauseOnAttentionLoss'), attentionThreshold: $('attentionThreshold')
  };

  let session = loadState();
  let selectedBlockId = session.blocks[0]?.id || null;
  let playback = makePlaybackState();
  let tracking = makeTrackingState();

  init();

  function init() {
    buildThemeOptions();
    bindUi();
    renderAll();
  }

  function buildThemeOptions() {
    refs.themeSelect.innerHTML = Object.entries(themes).map(([key, theme]) => `<option value="${key}">${escapeHtml(theme.name)}</option>`).join('');
  }

  function bindUi() {
    ['sessionName','sessionDuration','themeSelect','masterVolume','speechRate','loopMode','loopCount','runtimeMinutes','backgroundColor','accentColor','textColor'].forEach((key) => {
      refs[key].addEventListener('input', syncSessionFromInputs);
      refs[key].addEventListener('change', syncSessionFromInputs);
    });
    ['trackingEnabled','autoPauseOnAttentionLoss','attentionThreshold'].forEach((key) => {
      refs[key].addEventListener('input', syncTrackingFromInputs);
      refs[key].addEventListener('change', syncTrackingFromInputs);
    });

    $('newSessionBtn').addEventListener('click', () => {
      session = defaultSession();
      selectedBlockId = null;
      stopPlayback();
      saveAndRender();
    });
    $('loadSampleBtn').addEventListener('click', () => {
      session = structuredClone(sampleSession);
      selectedBlockId = session.blocks[0]?.id || null;
      stopPlayback();
      saveAndRender();
    });
    $('exportPackageBtn').addEventListener('click', exportPackage);
    $('importPackageInput').addEventListener('change', importPackageFile);
    $('toggleFullscreenBtn').addEventListener('click', toggleFullscreen);
    $('playBtn').addEventListener('click', playSession);
    $('pauseBtn').addEventListener('click', pausePlayback);
    $('stopBtn').addEventListener('click', stopPlayback);
    $('startTrackingBtn').addEventListener('click', startTracking);
    $('stopTrackingBtn').addEventListener('click', stopTracking);
    $('applyJsonBtn').addEventListener('click', applyPreview);
    $('formatJsonBtn').addEventListener('click', () => { refs.jsonPreview.value = prettyPackage(session); });
    $('duplicateBlockBtn').addEventListener('click', duplicateSelectedBlock);
    $('moveBlockUpBtn').addEventListener('click', () => moveSelectedBlock(-1));
    $('moveBlockDownBtn').addEventListener('click', () => moveSelectedBlock(1));
    $('deleteBlockBtn').addEventListener('click', deleteSelectedBlock);

    document.querySelectorAll('[data-add-block]').forEach((button) => {
      button.addEventListener('click', () => addBlock(button.dataset.addBlock));
    });

    $('addAudioTrackInput').addEventListener('change', (e) => addPlaylistFiles('audio', [...(e.target.files || [])]));
    $('addVideoTrackInput').addEventListener('change', (e) => addPlaylistFiles('video', [...(e.target.files || [])]));
  }

  function makePlaybackState() {
    return {
      running: false,
      paused: false,
      raf: null,
      startedAt: 0,
      pauseStartedAt: 0,
      totalPausedMs: 0,
      elapsedTotalSec: 0,
      completedLoops: 0,
      lastLoopIndex: -1,
      enteredBlockIds: new Set(),
      blockAudioMap: new Map(),
      playlistAudioEl: new Audio(),
      playlistVideoEl: document.createElement('video'),
      currentAudioTrackIndex: 0,
      currentVideoTrackIndex: 0,
      currentAudioSrc: '',
      currentVideoSrc: '',
      attentionLossStartedAt: null,
      autoPausedByTracking: false
    };
  }

  function makeTrackingState() {
    return {
      stream: null,
      running: false,
      detector: null,
      intervalId: null,
      lastAttentionState: 'off',
      lastFaceSeenAt: 0,
      supported: 'FaceDetector' in window
    };
  }

  function syncSessionFromInputs() {
    session.name = refs.sessionName.value.trim() || 'adaptive_session';
    session.duration = clampInt(refs.sessionDuration.value, 10, 86400, 180);
    session.theme = refs.themeSelect.value;
    session.masterVolume = clampFloat(refs.masterVolume.value, 0, 1, 0.8);
    session.speechRate = clampFloat(refs.speechRate.value, 0.5, 2, 1);
    session.loopMode = refs.loopMode.value;
    session.loopCount = clampInt(refs.loopCount.value, 1, 999, 1);
    session.runtimeMinutes = clampInt(refs.runtimeMinutes.value, 1, 1440, 10);
    session.backgroundColor = refs.backgroundColor.value;
    session.accentColor = refs.accentColor.value;
    session.textColor = refs.textColor.value;
    applyThemeVars();
    saveAndRender();
  }

  function syncTrackingFromInputs() {
    session.tracking.enabled = refs.trackingEnabled.checked;
    session.tracking.autoPauseOnAttentionLoss = refs.autoPauseOnAttentionLoss.checked;
    session.tracking.attentionThreshold = clampInt(refs.attentionThreshold.value, 1, 999, 5);
    saveAndRender();
  }

  function renderAll() {
    normalizeSession();
    fillInputs();
    applyThemeVars();
    renderBlockList();
    renderBlockEditor();
    renderPlaylist('audio');
    renderPlaylist('video');
    renderPreview();
    refs.jsonPreview.value = prettyPackage(session);
    refs.loopDisplay.textContent = loopDisplayText();
    refs.timeDisplay.textContent = `${formatTime(playback.elapsedTotalSec)} / ${targetTimeLabel()}`;
    refs.attentionDisplay.textContent = trackingLabel();
  }

  function fillInputs() {
    refs.sessionName.value = session.name || '';
    refs.sessionDuration.value = session.duration;
    refs.themeSelect.value = session.theme;
    refs.masterVolume.value = session.masterVolume;
    refs.speechRate.value = session.speechRate;
    refs.loopMode.value = session.loopMode;
    refs.loopCount.value = session.loopCount;
    refs.runtimeMinutes.value = session.runtimeMinutes;
    refs.backgroundColor.value = session.backgroundColor;
    refs.accentColor.value = session.accentColor;
    refs.textColor.value = session.textColor;
    refs.trackingEnabled.checked = !!session.tracking.enabled;
    refs.autoPauseOnAttentionLoss.checked = !!session.tracking.autoPauseOnAttentionLoss;
    refs.attentionThreshold.value = session.tracking.attentionThreshold;
  }

  function applyThemeVars() {
    document.documentElement.style.setProperty('--bg', session.backgroundColor);
    document.documentElement.style.setProperty('--accent', session.accentColor);
    document.documentElement.style.setProperty('--text', session.textColor);
    refs.previewStage.style.background = session.backgroundColor;
    refs.overlayText.style.color = session.textColor;
  }

  function renderBlockList() {
    refs.blockList.innerHTML = '';
    session.blocks.forEach((block) => {
      const li = document.createElement('li');
      li.className = `block-item ${block.id === selectedBlockId ? 'active' : ''}`;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'block-button';
      button.innerHTML = `<span class="block-title">${escapeHtml(block.label || titleCase(block.type))}</span><span class="block-meta">${escapeHtml(block.type)} · ${formatTime(block.start)} → ${formatTime(block.start + block.duration)}</span>`;
      button.addEventListener('click', () => {
        selectedBlockId = block.id;
        renderBlockList();
        renderBlockEditor();
      });
      li.appendChild(button);
      refs.blockList.appendChild(li);
    });
  }

  function renderBlockEditor() {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    if (!block) {
      refs.blockEditor.innerHTML = '<p class="muted">Select a block to edit its settings.</p>';
      return;
    }

    refs.blockEditor.innerHTML = `
      <label>Label<input data-field="label" type="text" value="${escapeHtml(block.label || '')}" /></label>
      <div class="block-field-grid">
        <label>Start (sec)<input data-field="start" type="number" min="0" step="1" value="${block.start}" /></label>
        <label>Duration (sec)<input data-field="duration" type="number" min="1" step="1" value="${block.duration}" /></label>
      </div>
      <label>Type<select data-field="type">${['text','tts','audio','video','pause'].map((type) => `<option value="${type}" ${block.type === type ? 'selected' : ''}>${titleCase(type)}</option>`).join('')}</select></label>
      ${typeSpecificEditor(block)}
    `;

    refs.blockEditor.querySelectorAll('[data-field]').forEach((input) => {
      input.addEventListener('input', handleBlockFieldChange);
      input.addEventListener('change', handleBlockFieldChange);
    });
    refs.blockEditor.querySelectorAll('[data-file-field]').forEach((input) => {
      input.addEventListener('change', handleBlockFileFieldChange);
    });
  }

  function typeSpecificEditor(block) {
    switch (block.type) {
      case 'text':
        return `
          <label>Content<textarea data-field="content" rows="5">${escapeHtml(block.content || '')}</textarea></label>
          <label>Font size multiplier<input data-field="fontSize" type="number" min="0.6" max="4" step="0.05" value="${block.fontSize ?? 1.2}" /></label>`;
      case 'tts':
        return `
          <label>Spoken content<textarea data-field="content" rows="5">${escapeHtml(block.content || '')}</textarea></label>
          <div class="block-field-grid">
            <label>Volume<input data-field="volume" type="number" min="0" max="1" step="0.05" value="${block.volume ?? 1}" /></label>
            <label>Voice name<input data-field="voiceName" type="text" value="${escapeHtml(block.voiceName || '')}" placeholder="Optional system voice name" /></label>
          </div>`;
      case 'audio':
        return `
          <label>Caption / note<textarea data-field="content" rows="3">${escapeHtml(block.content || '')}</textarea></label>
          <label>Volume<input data-field="volume" type="number" min="0" max="1" step="0.05" value="${block.volume ?? 1}" /></label>
          <label>Audio file<input data-file-field="dataUrl" type="file" accept="audio/*" /></label>
          <p class="small muted">${block.dataUrlName ? `Current: ${escapeHtml(block.dataUrlName)}` : 'No audio selected.'}</p>`;
      case 'video':
        return `
          <label>Caption / note<textarea data-field="content" rows="3">${escapeHtml(block.content || '')}</textarea></label>
          <div class="block-field-grid">
            <label>Mute audio<select data-field="mute"><option value="true" ${block.mute !== false ? 'selected' : ''}>Yes</option><option value="false" ${block.mute === false ? 'selected' : ''}>No</option></select></label>
            <label>Overlay text size<input data-field="fontSize" type="number" min="0.6" max="4" step="0.05" value="${block.fontSize ?? 1.1}" /></label>
          </div>
          <label>Visual file<input data-file-field="dataUrl" type="file" accept="video/*,image/*" /></label>
          <p class="small muted">${block.dataUrlName ? `Current: ${escapeHtml(block.dataUrlName)}` : 'No visual selected.'}</p>`;
      case 'pause':
      default:
        return '<p class="muted">Pause blocks leave the current playlist visuals running while the script timeline intentionally goes quiet.</p>';
    }
  }

  function handleBlockFieldChange(event) {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    if (!block) return;
    const field = event.target.dataset.field;
    let value = event.target.value;
    if (['start','duration'].includes(field)) value = clampInt(value, field === 'duration' ? 1 : 0, 86400, block[field] || 0);
    if (['volume','fontSize'].includes(field)) value = Number(value);
    if (field === 'mute') value = value === 'true';
    block[field] = value;
    saveAndRender();
  }

  async function handleBlockFileFieldChange(event) {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    const file = event.target.files?.[0];
    if (!block || !file) return;
    block.dataUrl = await fileToDataUrl(file);
    block.dataUrlName = file.name;
    block.mediaKind = file.type.startsWith('audio/') ? 'audio' : (file.type.startsWith('video/') ? 'video' : 'image');
    saveAndRender();
  }

  function addBlock(type) {
    const block = {
      id: uid(),
      type,
      label: `New ${titleCase(type)}`,
      start: estimateNextStart(),
      duration: type === 'pause' ? 5 : 10,
      content: type === 'tts' ? 'Write the spoken line here.' : (type === 'text' ? 'Write the on-screen text here.' : ''),
      volume: 1,
      fontSize: 1.2,
      mute: true,
      voiceName: ''
    };
    session.blocks.push(block);
    selectedBlockId = block.id;
    saveAndRender();
  }

  function duplicateSelectedBlock() {
    const block = session.blocks.find((b) => b.id === selectedBlockId);
    if (!block) return;
    const copy = structuredClone(block);
    copy.id = uid();
    copy.label = `${block.label || titleCase(block.type)} Copy`;
    copy.start = (block.start || 0) + 2;
    session.blocks.push(copy);
    selectedBlockId = copy.id;
    saveAndRender();
  }

  function moveSelectedBlock(direction) {
    const index = session.blocks.findIndex((b) => b.id === selectedBlockId);
    if (index < 0) return;
    const target = index + direction;
    if (target < 0 || target >= session.blocks.length) return;
    const [block] = session.blocks.splice(index, 1);
    session.blocks.splice(target, 0, block);
    saveAndRender();
  }

  function deleteSelectedBlock() {
    if (!selectedBlockId) return;
    session.blocks = session.blocks.filter((b) => b.id !== selectedBlockId);
    selectedBlockId = session.blocks[0]?.id || null;
    saveAndRender();
  }

  async function addPlaylistFiles(kind, files) {
    if (!files.length) return;
    for (const file of files) {
      const track = {
        id: uid(),
        name: file.name,
        dataUrl: await fileToDataUrl(file),
        mediaKind: kind === 'audio' ? 'audio' : (file.type.startsWith('image/') ? 'image' : 'video'),
        enabled: true,
        volume: 1,
        mute: kind === 'video' ? true : undefined
      };
      session.playlists[kind].push(track);
    }
    saveAndRender();
  }

  function renderPlaylist(kind) {
    const list = kind === 'audio' ? refs.audioTrackList : refs.videoTrackList;
    list.innerHTML = '';
    session.playlists[kind].forEach((track, index) => {
      const li = document.createElement('li');
      li.className = 'track-item';
      li.innerHTML = `
        <div class="track-top">
          <div>
            <strong>${escapeHtml(track.name)}</strong>
            <div class="track-meta">${kind === 'audio' ? 'Audio' : titleCase(track.mediaKind || 'video')} · ${track.enabled ? 'enabled' : 'disabled'}</div>
          </div>
          <div class="track-actions">
            <button type="button" data-act="up">↑</button>
            <button type="button" data-act="down">↓</button>
            <button type="button" data-act="remove">Remove</button>
          </div>
        </div>
        <div class="block-field-grid" style="margin-top:.6rem">
          <label>Enabled<select data-field="enabled"><option value="true" ${track.enabled ? 'selected' : ''}>Yes</option><option value="false" ${!track.enabled ? 'selected' : ''}>No</option></select></label>
          <label>Volume<input data-field="volume" type="number" min="0" max="1" step="0.05" value="${track.volume ?? 1}" /></label>
          ${kind === 'video' ? `<label>Mute track audio<select data-field="mute"><option value="true" ${track.mute !== false ? 'selected' : ''}>Yes</option><option value="false" ${track.mute === false ? 'selected' : ''}>No</option></select></label>` : '<div></div>'}
        </div>
      `;
      li.querySelectorAll('[data-act]').forEach((button) => {
        button.addEventListener('click', () => playlistAction(kind, index, button.dataset.act));
      });
      li.querySelectorAll('[data-field]').forEach((input) => {
        input.addEventListener('input', () => {
          const field = input.dataset.field;
          let value = input.value;
          if (field === 'enabled' || field === 'mute') value = value === 'true';
          if (field === 'volume') value = clampFloat(value, 0, 1, 1);
          track[field] = value;
          saveAndRender();
        });
      });
      list.appendChild(li);
    });
  }

  function playlistAction(kind, index, action) {
    const tracks = session.playlists[kind];
    if (action === 'remove') tracks.splice(index, 1);
    if (action === 'up' && index > 0) [tracks[index - 1], tracks[index]] = [tracks[index], tracks[index - 1]];
    if (action === 'down' && index < tracks.length - 1) [tracks[index + 1], tracks[index]] = [tracks[index], tracks[index + 1]];
    saveAndRender();
  }

  function renderPreview() {
    refs.overlayText.textContent = '';
    refs.overlayText.style.fontSize = 'clamp(1.4rem, 4vw, 3.5rem)';
    refs.backgroundHost.innerHTML = '';
    const visual = firstEnabledVisual();
    if (visual) mountVisualIntoHost(visual, refs.backgroundHost);
    refs.stageHud.textContent = playback.running ? (playback.paused ? 'Paused' : 'Playing') : 'Idle';
    refs.activeBlockDisplay.textContent = '—';
  }

  function playSession() {
    if (playback.running && playback.paused) {
      resumePlayback();
      return;
    }
    if (playback.running) return;

    stopPlaybackMediaOnly();
    playback = makePlaybackState();
    playback.running = true;
    playback.startedAt = performance.now();
    playback.playlistAudioEl.preload = 'auto';
    playback.playlistAudioEl.addEventListener('ended', handlePlaylistAudioEnded);
    playback.playlistVideoEl.playsInline = true;
    playback.playlistVideoEl.loop = false;
    playback.playlistVideoEl.addEventListener('ended', handlePlaylistVideoEnded);

    startPlaylistMedia();
    tick();
  }

  function pausePlayback() {
    if (!playback.running || playback.paused) return;
    playback.paused = true;
    playback.pauseStartedAt = performance.now();
    cancelAnimationFrame(playback.raf);
    playback.playlistAudioEl.pause();
    if (playback.playlistVideoEl.parentElement) playback.playlistVideoEl.pause();
    playback.blockAudioMap.forEach((audio) => audio.pause());
    if ('speechSynthesis' in window) window.speechSynthesis.pause();
    refs.stageHud.textContent = 'Paused';
  }

  function resumePlayback() {
    if (!playback.running || !playback.paused) return;
    playback.paused = false;
    playback.totalPausedMs += performance.now() - playback.pauseStartedAt;
    if (playback.currentAudioSrc) void playback.playlistAudioEl.play().catch(() => {});
    if (playback.playlistVideoEl.parentElement) void playback.playlistVideoEl.play().catch(() => {});
    playback.blockAudioMap.forEach((audio) => void audio.play().catch(() => {}));
    if ('speechSynthesis' in window) window.speechSynthesis.resume();
    refs.stageHud.textContent = 'Playing';
    tick();
  }

  function stopPlayback() {
    if (playback.raf) cancelAnimationFrame(playback.raf);
    stopPlaybackMediaOnly();
    playback = makePlaybackState();
    refs.stageHud.textContent = 'Idle';
    refs.overlayText.textContent = '';
    refs.activeBlockDisplay.textContent = '—';
    refs.timeDisplay.textContent = `00:00 / ${targetTimeLabel()}`;
    refs.loopDisplay.textContent = loopDisplayText();
    renderPreview();
  }

  function stopPlaybackMediaOnly() {
    try { playback.playlistAudioEl.pause(); playback.playlistAudioEl.src = ''; } catch {}
    try { playback.playlistVideoEl.pause(); playback.playlistVideoEl.src = ''; } catch {}
    playback.blockAudioMap?.forEach((audio) => { try { audio.pause(); audio.src = ''; } catch {} });
    playback.blockAudioMap?.clear?.();
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  }

  function tick() {
    if (!playback.running || playback.paused) return;
    const now = performance.now();
    playback.elapsedTotalSec = Math.max(0, (now - playback.startedAt - playback.totalPausedMs) / 1000);
    const duration = Math.max(1, session.duration);
    const loopIndex = Math.floor(playback.elapsedTotalSec / duration);
    const elapsedInLoop = playback.elapsedTotalSec % duration;

    if (hasReachedTargetRuntime(playback.elapsedTotalSec)) {
      stopPlayback();
      return;
    }

    if (loopIndex !== playback.lastLoopIndex) {
      playback.lastLoopIndex = loopIndex;
      playback.enteredBlockIds = new Set();
      playback.blockAudioMap.forEach((audio) => { try { audio.pause(); audio.src = ''; } catch {} });
      playback.blockAudioMap.clear();
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    }

    const activeBlocks = session.blocks.filter((block) => elapsedInLoop >= block.start && elapsedInLoop < block.start + block.duration);
    refs.timeDisplay.textContent = `${formatTime(playback.elapsedTotalSec)} / ${targetTimeLabel()}`;
    refs.loopDisplay.textContent = `${loopIndex + 1} / ${loopTargetLabel()}`;
    refs.activeBlockDisplay.textContent = activeBlocks.length ? activeBlocks.map((b) => b.label || titleCase(b.type)).join(', ') : '—';
    refs.stageHud.textContent = `Loop ${loopIndex + 1} · ${playback.paused ? 'Paused' : 'Playing'}`;

    applyActiveBlocks(activeBlocks);
    handleAttentionDrivenPause();

    playback.raf = requestAnimationFrame(tick);
  }

  function applyActiveBlocks(activeBlocks) {
    const textBlocks = activeBlocks.filter((b) => b.type === 'text');
    const videoBlock = activeBlocks.find((b) => b.type === 'video' && b.dataUrl);

    if (videoBlock) {
      mountVisualIntoHost(videoBlock, refs.backgroundHost, true);
      refs.overlayText.textContent = videoBlock.content || '';
      refs.overlayText.style.fontSize = `${(videoBlock.fontSize || 1.1) * 1.6}rem`;
    } else {
      const visual = firstEnabledVisual();
      refs.backgroundHost.innerHTML = '';
      if (visual) mountVisualIntoHost(visual, refs.backgroundHost);
      refs.overlayText.textContent = textBlocks.map((b) => b.content).filter(Boolean).join('\n\n');
      refs.overlayText.style.fontSize = `${(textBlocks[0]?.fontSize || 1.2) * 1.7}rem`;
    }

    activeBlocks.forEach((block) => {
      if (playback.enteredBlockIds.has(block.id)) return;
      playback.enteredBlockIds.add(block.id);
      if (block.type === 'tts' && block.content) speakBlock(block);
      if (block.type === 'audio' && block.dataUrl) playBlockAudio(block);
    });
  }

  function startPlaylistMedia() {
    const audioTrack = nextEnabledTrack('audio', 0);
    if (audioTrack) startAudioTrack(audioTrack.index, audioTrack.track);
    const videoTrack = nextEnabledTrack('video', 0);
    if (videoTrack) startVideoTrack(videoTrack.index, videoTrack.track);
  }

  function handlePlaylistAudioEnded() {
    const next = nextEnabledTrack('audio', playback.currentAudioTrackIndex + 1);
    if (!next) {
      const restart = nextEnabledTrack('audio', 0);
      if (restart) startAudioTrack(restart.index, restart.track);
      return;
    }
    startAudioTrack(next.index, next.track);
  }

  function handlePlaylistVideoEnded() {
    const next = nextEnabledTrack('video', playback.currentVideoTrackIndex + 1);
    if (!next) {
      const restart = nextEnabledTrack('video', 0);
      if (restart) startVideoTrack(restart.index, restart.track);
      return;
    }
    startVideoTrack(next.index, next.track);
  }

  function startAudioTrack(index, track) {
    playback.currentAudioTrackIndex = index;
    playback.currentAudioSrc = track.dataUrl;
    playback.playlistAudioEl.src = track.dataUrl;
    playback.playlistAudioEl.volume = (track.volume ?? 1) * session.masterVolume;
    void playback.playlistAudioEl.play().catch(() => {});
  }

  function startVideoTrack(index, track) {
    playback.currentVideoTrackIndex = index;
    playback.currentVideoSrc = track.dataUrl;
    refs.backgroundHost.innerHTML = '';
    if ((track.mediaKind || 'video') === 'image') {
      const img = document.createElement('img');
      img.src = track.dataUrl;
      img.alt = track.name;
      refs.backgroundHost.appendChild(img);
      // images persist until next track; advance using timeout based on loop duration fallback
      clearTimeout(refs.backgroundHost._imgTimer);
      refs.backgroundHost._imgTimer = setTimeout(handlePlaylistVideoEnded, 8000);
      return;
    }
    playback.playlistVideoEl.src = track.dataUrl;
    playback.playlistVideoEl.muted = track.mute !== false;
    playback.playlistVideoEl.volume = (track.volume ?? 1) * session.masterVolume;
    refs.backgroundHost.appendChild(playback.playlistVideoEl);
    void playback.playlistVideoEl.play().catch(() => {});
  }

  function playBlockAudio(block) {
    const audio = new Audio(block.dataUrl);
    audio.volume = (block.volume ?? 1) * session.masterVolume;
    playback.blockAudioMap.set(block.id, audio);
    void audio.play().catch(() => {});
  }

  function speakBlock(block) {
    if (!('speechSynthesis' in window)) return;
    const utterance = new SpeechSynthesisUtterance(block.content);
    utterance.rate = session.speechRate;
    utterance.volume = (block.volume ?? 1) * session.masterVolume;
    if (block.voiceName) {
      const voice = window.speechSynthesis.getVoices().find((v) => v.name === block.voiceName);
      if (voice) utterance.voice = voice;
    }
    window.speechSynthesis.speak(utterance);
  }

  function firstEnabledVisual() {
    return session.playlists.video.find((track) => track.enabled && track.dataUrl) || null;
  }

  function mountVisualIntoHost(source, host, isBlock = false) {
    host.innerHTML = '';
    const kind = source.mediaKind || 'video';
    if (kind === 'image') {
      const img = document.createElement('img');
      img.src = source.dataUrl;
      img.alt = source.name || source.label || 'Visual';
      host.appendChild(img);
      return;
    }
    const video = isBlock ? document.createElement('video') : playback.playlistVideoEl;
    if (isBlock) {
      video.src = source.dataUrl;
      video.muted = source.mute !== false;
      video.loop = true;
      video.playsInline = true;
      void video.play().catch(() => {});
    }
    host.appendChild(video);
  }

  async function startTracking() {
    if (tracking.running) return;
    try {
      tracking.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
      refs.trackingPreview.srcObject = tracking.stream;
      refs.trackingPreview.play().catch(() => {});
      tracking.running = true;
      tracking.lastAttentionState = 'starting';
      if ('FaceDetector' in window) tracking.detector = new window.FaceDetector({ fastMode: true, maxDetectedFaces: 1 });
      tracking.intervalId = setInterval(checkAttentionFrame, 900);
      refs.attentionDisplay.textContent = trackingLabel();
    } catch (error) {
      tracking.running = false;
      refs.attentionDisplay.textContent = 'Camera denied';
      console.error(error);
    }
  }

  function stopTracking() {
    if (tracking.intervalId) clearInterval(tracking.intervalId);
    tracking.intervalId = null;
    tracking.running = false;
    tracking.lastAttentionState = 'off';
    if (tracking.stream) tracking.stream.getTracks().forEach((track) => track.stop());
    tracking.stream = null;
    refs.trackingPreview.srcObject = null;
    refs.attentionDisplay.textContent = trackingLabel();
  }

  async function checkAttentionFrame() {
    if (!tracking.running || !refs.trackingPreview.videoWidth) return;
    try {
      if (tracking.detector) {
        const faces = await tracking.detector.detect(refs.trackingPreview);
        if (!faces.length) {
          tracking.lastAttentionState = 'no face';
        } else {
          const face = faces[0].boundingBox;
          const centerX = face.x + face.width / 2;
          const centerY = face.y + face.height / 2;
          const dx = Math.abs(centerX - refs.trackingPreview.videoWidth / 2) / refs.trackingPreview.videoWidth;
          const dy = Math.abs(centerY - refs.trackingPreview.videoHeight / 2) / refs.trackingPreview.videoHeight;
          tracking.lastAttentionState = (dx < 0.18 && dy < 0.2) ? 'attentive' : 'distracted';
          tracking.lastFaceSeenAt = Date.now();
        }
      } else {
        tracking.lastAttentionState = 'face API unavailable';
      }
      refs.attentionDisplay.textContent = trackingLabel();
    } catch (error) {
      tracking.lastAttentionState = 'tracking error';
      refs.attentionDisplay.textContent = trackingLabel();
      console.error(error);
    }
  }

  function handleAttentionDrivenPause() {
    if (!session.tracking.enabled || !session.tracking.autoPauseOnAttentionLoss || !tracking.running || !playback.running || playback.paused && !playback.autoPausedByTracking) {
      if (tracking.lastAttentionState === 'attentive') playback.attentionLossStartedAt = null;
      return;
    }

    const attentionGood = tracking.lastAttentionState === 'attentive' || tracking.lastAttentionState === 'starting';
    if (attentionGood) {
      playback.attentionLossStartedAt = null;
      if (playback.autoPausedByTracking && playback.paused) {
        playback.autoPausedByTracking = false;
        resumePlayback();
      }
      return;
    }

    if (!playback.attentionLossStartedAt) playback.attentionLossStartedAt = Date.now();
    const lostSec = (Date.now() - playback.attentionLossStartedAt) / 1000;
    if (lostSec >= session.tracking.attentionThreshold && !playback.paused) {
      playback.autoPausedByTracking = true;
      pausePlayback();
      refs.stageHud.textContent = 'Paused: attention lost';
    }
  }

  function trackingLabel() {
    if (!tracking.running) return 'Off';
    return titleCase(tracking.lastAttentionState);
  }

  function loopTargetLabel() {
    if (session.loopMode === 'count') return String(session.loopCount);
    if (session.loopMode === 'minutes') return `${session.runtimeMinutes} min`;
    if (session.loopMode === 'forever') return '∞';
    return '1';
  }

  function loopDisplayText() {
    return `1 / ${loopTargetLabel()}`;
  }

  function targetTimeLabel() {
    if (session.loopMode === 'minutes') return formatTime(session.runtimeMinutes * 60);
    if (session.loopMode === 'count') return formatTime(session.duration * session.loopCount);
    if (session.loopMode === 'forever') return '∞';
    return formatTime(session.duration);
  }

  function hasReachedTargetRuntime(elapsedSec) {
    if (session.loopMode === 'none') return elapsedSec >= session.duration;
    if (session.loopMode === 'count') return elapsedSec >= session.duration * session.loopCount;
    if (session.loopMode === 'minutes') return elapsedSec >= session.runtimeMinutes * 60;
    return false;
  }

  function nextEnabledTrack(kind, startIndex) {
    const tracks = session.playlists[kind];
    for (let i = startIndex; i < tracks.length; i += 1) {
      if (tracks[i].enabled && tracks[i].dataUrl) return { index: i, track: tracks[i] };
    }
    return null;
  }

  function exportPackage() {
    const blob = new Blob([prettyPackage(session)], { type: 'application/json' });
    const filename = `${slugify(session.name || 'adaptive-session')}.assp`;
    downloadBlob(blob, filename);
  }

  async function importPackageFile(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      session = upgradeImportedSession(parsed);
      selectedBlockId = session.blocks[0]?.id || null;
      stopPlayback();
      saveAndRender();
    } catch (error) {
      alert('Could not import that package file.');
      console.error(error);
    }
  }

  function applyPreview() {
    try {
      const parsed = JSON.parse(refs.jsonPreview.value);
      session = upgradeImportedSession(parsed);
      selectedBlockId = session.blocks[0]?.id || null;
      stopPlayback();
      saveAndRender();
    } catch (error) {
      alert('Preview contains invalid JSON.');
      console.error(error);
    }
  }

  function upgradeImportedSession(raw) {
    const base = defaultSession();
    if (raw.assets && !raw.playlists) {
      // legacy v1 import
      if (raw.assets.bgAudioDataUrl) {
        base.playlists.audio.push({ id: uid(), name: raw.assets.bgAudioName || 'Background audio', dataUrl: raw.assets.bgAudioDataUrl, mediaKind: 'audio', enabled: true, volume: 1 });
      }
      if (raw.assets.bgVisualDataUrl) {
        base.playlists.video.push({ id: uid(), name: raw.assets.bgVisualName || 'Background visual', dataUrl: raw.assets.bgVisualDataUrl, mediaKind: raw.assets.bgVisualKind === 'image' ? 'image' : 'video', enabled: true, volume: 1, mute: true });
      }
    }
    const upgraded = Object.assign(base, raw);
    upgraded.packageVersion = PACKAGE_VERSION;
    upgraded.playlists = upgraded.playlists || { audio: [], video: [] };
    upgraded.tracking = Object.assign(base.tracking, upgraded.tracking || {});
    upgraded.blocks = (upgraded.blocks || []).map((block) => ({
      id: block.id || uid(),
      type: block.type || 'text',
      label: block.label || titleCase(block.type || 'text'),
      start: Number(block.start || 0),
      duration: Number(block.duration || 5),
      content: block.content || '',
      volume: block.volume ?? 1,
      fontSize: block.fontSize ?? 1.2,
      voiceName: block.voiceName || '',
      mute: block.mute ?? true,
      dataUrl: block.dataUrl || '',
      dataUrlName: block.dataUrlName || '',
      mediaKind: block.mediaKind || (block.type === 'audio' ? 'audio' : 'video')
    }));
    upgraded.playlists.audio = (upgraded.playlists.audio || []).map((track) => ({ id: track.id || uid(), name: track.name || 'Audio track', dataUrl: track.dataUrl || '', mediaKind: 'audio', enabled: track.enabled !== false, volume: track.volume ?? 1 }));
    upgraded.playlists.video = (upgraded.playlists.video || []).map((track) => ({ id: track.id || uid(), name: track.name || 'Visual track', dataUrl: track.dataUrl || '', mediaKind: track.mediaKind || 'video', enabled: track.enabled !== false, volume: track.volume ?? 1, mute: track.mute ?? true }));
    normalizeSession(upgraded);
    return upgraded;
  }

  function toggleFullscreen() {
    if (!document.fullscreenElement) refs.previewStage.requestFullscreen?.(); else document.exitFullscreen?.();
  }

  function normalizeSession(target = session) {
    target.packageVersion = PACKAGE_VERSION;
    target.name = target.name || 'adaptive_session';
    target.duration = clampInt(target.duration, 10, 86400, 180);
    target.theme = target.theme || 'midnight';
    target.masterVolume = clampFloat(target.masterVolume, 0, 1, 0.8);
    target.speechRate = clampFloat(target.speechRate, 0.5, 2, 1);
    target.loopMode = ['none','count','minutes','forever'].includes(target.loopMode) ? target.loopMode : 'count';
    target.loopCount = clampInt(target.loopCount, 1, 999, 1);
    target.runtimeMinutes = clampInt(target.runtimeMinutes, 1, 1440, 10);
    target.backgroundColor = target.backgroundColor || themes[target.theme]?.backgroundColor || '#05070a';
    target.accentColor = target.accentColor || themes[target.theme]?.accentColor || '#7fb0ff';
    target.textColor = target.textColor || themes[target.theme]?.textColor || '#eef4fb';
    target.tracking = Object.assign({ enabled: false, autoPauseOnAttentionLoss: false, attentionThreshold: 5 }, target.tracking || {});
    target.playlists = target.playlists || { audio: [], video: [] };
    target.playlists.audio = target.playlists.audio || [];
    target.playlists.video = target.playlists.video || [];
    target.blocks = (target.blocks || []).sort((a, b) => a.start - b.start);
  }

  function estimateNextStart() {
    if (!session.blocks.length) return 0;
    return Math.max(...session.blocks.map((b) => b.start + b.duration + 2));
  }

  function saveAndRender() {
    saveState();
    renderAll();
  }

  function saveState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  }

  function loadState() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return structuredClone(sampleSession);
      return upgradeImportedSession(JSON.parse(saved));
    } catch {
      return structuredClone(sampleSession);
    }
  }

  function prettyPackage(data) {
    return JSON.stringify(data, null, 2);
  }

  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function uid() { return Math.random().toString(36).slice(2, 10); }
  function titleCase(value) { return String(value || '').replace(/[_-]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()); }
  function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c])); }
  function clampInt(value, min, max, fallback) { const n = Math.round(Number(value)); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback; }
  function clampFloat(value, min, max, fallback) { const n = Number(value); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback; }
  function slugify(value) { return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 64) || 'session'; }
  function formatTime(totalSec) {
    if (!Number.isFinite(totalSec)) return '∞';
    const sec = Math.max(0, Math.floor(totalSec));
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
})();
