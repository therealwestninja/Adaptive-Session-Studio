# Adaptive Session Studio

A self-contained local web app for designing and running passive audiovisual sessions with editable script blocks, media playlists, loop controls, and basic webcam attention tracking.

## What changed in this version

This package replaces the earlier single-session JSON workflow with a richer **session package** model:

- export/import `.assp` package files
- audio playlist with add/remove/reorder
- video playlist with add/remove/reorder
- per-video mute option
- loop by count, runtime minutes, forever, or single pass
- playback pause/resume now pauses script timing **and** active media playback
- webcam attention tracking panel
- optional auto-pause on attention loss
- legacy import support for older JSON session files

## Package format

The session export format is currently:

- **`.assp`** — a structured JSON-based package file

It is still one file, but it is more like a package container than a plain timeline JSON because it carries:

- session metadata
- tracking settings
- playlists
- script blocks
- embedded media assets as `data:` URLs

### Why use this instead of a bare JSON session

It gives you a cleaner upgrade path toward a future ZIP-based container while keeping the current app:

- fully local
- dependency-free
- easy to inspect and hand-edit
- easy to version and migrate

### Why not ZIP right now

A true ZIP session container is a reasonable next step, but it would add a dedicated archiving layer to the browser app. For this revision, the playback and editing features were prioritized first.

## How to run

### Simplest

Open `index.html` in a browser.

### Better for local media behavior

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`

## Main features

- local, dependency-free runtime
- session metadata editor
- editable script blocks
- audio playlist manager
- video playlist manager
- one-shot audio and visual blocks inside the script timeline
- per-track volume
- per-video mute control
- loop mode:
  - none
  - loop count
  - runtime minutes
  - forever
- browser TTS blocks
- fullscreen preview stage
- webcam attention/face tracking panel
- optional auto-pause on attention loss
- package preview and direct editing
- local autosave

## Tracking notes

The webcam tracker is intentionally lightweight.

It currently uses:

- browser webcam access
- `FaceDetector` when the browser supports it
- a simple attention proxy based on face presence and face centering

That means it is best described as:

- **face / attention approximation**, not true eye-tracking

On browsers without Face Detection support, the UI stays usable, but tracking falls back to limited status.

## Self-contained media

Media is still embedded directly into the package file as `data:` URLs.
That keeps the package portable and self-contained, but very large audio/video files will produce large package files.

## Suggested next upgrades

- true ZIP package container with manifest + asset files
- drag-and-drop timeline editing
- playlist crossfade controls
- layered simultaneous audio tracks
- better webcam heuristics or landmark-based tracking
- WebXR playback mode
- cue transitions and rule engine
