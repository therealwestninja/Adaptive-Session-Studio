// ── tests/playback.test.js ────────────────────────────────────────────────
// Tests for pure exports from js/playback.js that don't require DOM or
// a running session: resolveTemplateVars.

import { makeRunner } from './harness.js';
import { resolveTemplateVars, seekTo } from '../js/playback.js';
import { state, defaultSession, normalizeSession } from '../js/state.js';

export function runPlaybackTests() {
  const R  = makeRunner('playback.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  function reset() {
    state.session   = normalizeSession(defaultSession());
    state.runtime   = null;
    state.engineState = { attention: 0, engagement: 0, intensity: 1.0, speed: 1.0,
                          sessionTime: 0, totalSec: 0, loopCount: 0 };
    state.liveControl = { intensityScale: 1.0, speedScale: 1.0 };
  }

  // ── resolveTemplateVars ────────────────────────────────────────────────────
  t('resolveTemplateVars returns content unchanged when no {{ found', () => {
    reset();
    eq(resolveTemplateVars('Hello world'), 'Hello world');
  });

  t('resolveTemplateVars returns empty string for empty input', () => {
    reset();
    eq(resolveTemplateVars(''), '');
  });

  t('resolveTemplateVars returns null for null input', () => {
    reset();
    ok(resolveTemplateVars(null) == null);
  });

  t('resolveTemplateVars resolves {{loop}} to loop number', () => {
    reset();
    state.runtime = {
      sessionTime: 0, loopIndex: 2, totalLoops: 5,
      activeScene: null, injection: null,
    };
    const out = resolveTemplateVars('Loop {{loop}}');
    ok(out.includes('3'), `expected loop 3, got "${out}"`);
  });

  t('resolveTemplateVars resolves {{intensity}} as percentage', () => {
    reset();
    state.engineState.intensity = 0.75;
    const out = resolveTemplateVars('Level: {{intensity}}');
    ok(out.includes('%'), `expected % in "${out}"`);
    ok(out.includes('75'), `expected 75% in "${out}"`);
  });

  t('resolveTemplateVars resolves {{speed}}', () => {
    reset();
    state.engineState.speed = 1.5;
    const out = resolveTemplateVars('Speed: {{speed}}');
    ok(out.includes('1.50') || out.includes('1.5'), `expected 1.50× in "${out}"`);
  });

  t('resolveTemplateVars resolves user-defined number variable', () => {
    reset();
    state.session.variables = {
      score: { type: 'number', value: 42, description: '' }
    };
    const out = resolveTemplateVars('Score: {{score}}');
    ok(out.includes('42'), `expected 42 in "${out}"`);
  });

  t('resolveTemplateVars resolves user-defined boolean variable', () => {
    reset();
    state.session.variables = {
      active: { type: 'boolean', value: true, description: '' }
    };
    const out = resolveTemplateVars('Active: {{active}}');
    ok(out.includes('true'), `expected "true" in "${out}"`);
  });

  t('resolveTemplateVars leaves unknown {{vars}} unchanged', () => {
    reset();
    state.session.variables = {};
    const out = resolveTemplateVars('Value: {{unknown_var}}');
    ok(out.includes('{{unknown_var}}'), `expected placeholder preserved, got "${out}"`);
  });

  t('resolveTemplateVars resolves multiple vars in one string', () => {
    reset();
    state.engineState.intensity = 1.0;
    state.session.variables = { score: { type: 'number', value: 7, description: '' } };
    const out = resolveTemplateVars('Intensity: {{intensity}}, Score: {{score}}');
    ok(out.includes('100%'), 'intensity present');
    ok(out.includes('7'), 'score present');
  });

  t('resolveTemplateVars is case-insensitive for built-in vars', () => {
    reset();
    state.engineState.intensity = 0.5;
    const lower = resolveTemplateVars('{{intensity}}');
    const upper = resolveTemplateVars('{{INTENSITY}}');
    eq(lower, upper, 'case-insensitive for built-in vars');
  });

  t('resolveTemplateVars handles content with many {{ }} pairs efficiently', () => {
    reset();
    state.session.variables = { x: { type: 'number', value: 1, description: '' } };
    const content = '{{x}}, '.repeat(1000).slice(0, -2);
    let threw = false;
    try { resolveTemplateVars(content); } catch { threw = true; }
    ok(!threw, 'large content should not throw');
  });

  // ── resolveTemplateVars: additional edge cases ────────────────────────────
  t('resolveTemplateVars resolves {{time}} to formatted time', () => {
    reset();
    state.runtime = {
      sessionTime: 65, loopIndex: 0, totalLoops: 1,
      activeScene: null, injection: null,
    };
    const out = resolveTemplateVars('Time: {{time}}');
    ok(out.includes('01:05') || out.includes('01:0'), `expected 01:05, got "${out}"`);
  });

  t('resolveTemplateVars resolves {{scene}} to em-dash when no active scene', () => {
    reset();
    state.runtime = { sessionTime: 0, loopIndex: 0, totalLoops: 1,
                      activeScene: null, injection: null };
    const out = resolveTemplateVars('Scene: {{scene}}');
    ok(out.includes('—') || out.includes('-'), `expected dash, got "${out}"`);
  });

  t('resolveTemplateVars resolves {{scene}} to scene name when active', () => {
    reset();
    state.runtime = {
      sessionTime: 10, loopIndex: 0, totalLoops: 1,
      activeScene: { scene: { name: 'Intro', id: 's1' }, loopCount: 0 },
      injection: null,
    };
    const out = resolveTemplateVars('Scene: {{scene}}');
    ok(out.includes('Intro'), `expected "Intro", got "${out}"`);
  });

  t('resolveTemplateVars with string variable', () => {
    reset();
    state.session.variables = {
      mood: { type: 'string', value: 'intense', description: '' }
    };
    const out = resolveTemplateVars('Mood: {{mood}}');
    ok(out.includes('intense'), `expected "intense", got "${out}"`);
  });

  t('resolveTemplateVars does not resolve partial braces', () => {
    reset();
    const out = resolveTemplateVars('Hello {world}');
    eq(out, 'Hello {world}', 'single braces should not be touched');
  });


  // ── seekTo: NaN and clamping (regression) ────────────────────────────────
  t('seekTo with NaN pct does not corrupt runtime.startedAt', () => {
    reset();
    state.runtime = {
      startedAt: performance.now(), totalPausedMs: 0,
      paused: false, loopIndex: 0, totalLoops: 1,
      sessionTime: 0, analytics: null, injection: null,
      backgroundAudio: [], backgroundVideo: [], playingOneShots: [],
      _lastTick: performance.now(), triggered: new Set(), activeBlock: null,
      activeScene: null, speechUtterance: null, raf: 0,
    };
    const originalStart = state.runtime.startedAt;
    seekTo(NaN);
    ok(Number.isFinite(state.runtime.startedAt),
      `startedAt should remain finite after seekTo(NaN), got ${state.runtime.startedAt}`);
    // NaN should not change startedAt (seekTo returns early)
    ok(Math.abs(state.runtime.startedAt - originalStart) < 100,
      'startedAt should not change for NaN input');
    state.runtime = null;
  });

  t('seekTo with pct > 1 clamps to session end', () => {
    reset();
    state.runtime = {
      startedAt: performance.now(), totalPausedMs: 0,
      paused: false, loopIndex: 0, totalLoops: 1,
      sessionTime: 0, analytics: null, injection: null,
      backgroundAudio: [], backgroundVideo: [], playingOneShots: [],
      _lastTick: performance.now(), triggered: new Set(), activeBlock: null,
      activeScene: null, speechUtterance: null, raf: 0,
    };
    seekTo(1.5);  // should clamp to 1.0
    // startedAt should reflect a position at or before end of session
    ok(Number.isFinite(state.runtime.startedAt), 'startedAt must be finite after clamped seekTo');
    state.runtime = null;
  });


  // ── resolveTemplateVars: null/undefined runtime ───────────────────────────
  t('resolveTemplateVars with null runtime returns safe defaults', () => {
    reset();
    state.runtime = null;
    // Built-in vars resolve to defaults when no runtime
    const out = resolveTemplateVars('Loop {{loop}} Time {{time}}');
    ok(!out.includes('{{'), 'placeholders should be resolved even with null runtime');
    ok(typeof out === 'string');
  });

  t('resolveTemplateVars with undefined engineState is safe', () => {
    reset();
    state.engineState = null;
    let threw = false;
    try {
      const out = resolveTemplateVars('Intensity: {{intensity}} Speed: {{speed}}');
      ok(typeof out === 'string');
    } catch { threw = true; }
    ok(!threw, 'null engineState should not throw');
  });

  t('resolveTemplateVars boolean variable shows "false" not empty', () => {
    reset();
    state.session.variables = {
      flag: { type: 'boolean', value: false, description: '' }
    };
    const out = resolveTemplateVars('Flag: {{flag}}');
    ok(out.includes('false'), `expected "false", got "${out}"`);
  });


  // ── resolveTemplateVars: engagement and deviceLoad builtins ──────────────
  t('resolveTemplateVars resolves {{engagement}} as percentage', () => {
    reset();
    state.engineState = { attention:0.5, engagement:0.72, intensity:1.0, speed:1.0,
                          sessionTime:0, totalSec:0, loopCount:0, deviceLoad:0 };
    const out = resolveTemplateVars('Engagement: {{engagement}}');
    ok(out.includes('%'), `expected % sign in "${out}"`);
    ok(out.includes('72'), `expected 72 in "${out}"`);
  });

  t('resolveTemplateVars {{loop}} returns "1" on first loop', () => {
    reset();
    state.runtime = { sessionTime:0, loopIndex:0, totalLoops:1, activeScene:null, injection:null };
    const out = resolveTemplateVars('{{loop}}');
    ok(out === '1' || out.includes('1'), `expected 1 for first loop, got "${out}"`);
  });

  t('resolveTemplateVars with number variable value 0 shows "0" not empty', () => {
    reset();
    state.session.variables = { count: { type:'number', value:0, description:'' } };
    const out = resolveTemplateVars('Count: {{count}}');
    ok(out.includes('0'), `zero value should appear as "0", got "${out}"`);
  });

  t('resolveTemplateVars leaves text between {{}} intact', () => {
    reset();
    state.session.variables = {};
    const out = resolveTemplateVars('Start {{unknown_var}} End');
    ok(out.startsWith('Start'), `start preserved: "${out}"`);
    ok(out.endsWith('End'),   `end preserved: "${out}"`);
  });

  // ── seekTo: edge values ───────────────────────────────────────────────────
  t('seekTo(0) sets runtime to start of session', () => {
    reset();
    const now = performance.now();
    state.runtime = {
      startedAt: now, totalPausedMs: 0, paused: false,
      loopIndex:0, totalLoops:1, sessionTime:0, analytics:null, injection:null,
      backgroundAudio:[], backgroundVideo:[], playingOneShots:[],
      _lastTick:now, triggered:new Set(), activeBlock:null,
      activeScene:null, speechUtterance:null, raf:0,
    };
    seekTo(0);
    ok(Number.isFinite(state.runtime.startedAt), 'startedAt should remain finite');
    state.runtime = null;
  });


  // ── AI replace mode: blocks cleared before merging ───────────────────────
  t('resolveTemplateVars handles nested {{}} gracefully', () => {
    reset();
    state.session.variables = { score: { type:'number', value:42, description:'' } };
    const out = resolveTemplateVars('Score is {{score}} and high {{score}}');
    ok(out.includes('42'), `expected 42 in output, got: "${out}"`);
  });

  t('resolveTemplateVars with empty content returns empty string', () => {
    reset();
    const out = resolveTemplateVars('');
    eq(out, '', 'empty content should return empty string');
  });

  t('resolveTemplateVars with no variables returns content unchanged', () => {
    reset();
    state.session.variables = {};
    const out = resolveTemplateVars('Hello world, no vars here');
    eq(out, 'Hello world, no vars here');
  });

  t('resolveTemplateVars with undefined variable shows empty or placeholder', () => {
    reset();
    state.session.variables = {};
    const out = resolveTemplateVars('Value: {{undefined_var}}');
    ok(typeof out === 'string', 'must return a string even for undefined vars');
  });

  t('seekTo clamps pct > 1 to 1', () => {
    reset();
    const now = performance.now();
    state.runtime = {
      startedAt: now, totalPausedMs: 0, paused: false,
      loopIndex:0, totalLoops:1, sessionTime:0, analytics:null, injection:null,
      backgroundAudio:[], backgroundVideo:[], playingOneShots:[],
      _lastTick:now, triggered:new Set(), activeBlock:null,
      activeScene:null, speechUtterance:null, raf:0,
    };
    let threw = false;
    try { seekTo(1.5); } catch { threw = true; }
    ok(!threw, 'seekTo(1.5) should clamp gracefully, not throw');
    state.runtime = null;
  });


  return R.summary();
}
