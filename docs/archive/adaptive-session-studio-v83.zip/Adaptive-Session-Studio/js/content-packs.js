// ── content-packs.js ────────────────────────────────────────────────────────
// Phase 3 — Content Packs
//
// Pre-built session templates authors can load as starting points.
// Each pack is a complete normalizable session object with blocks, scenes,
// rules, state types, and suggested modes.
//
// To add a pack: push an object to CONTENT_PACKS following the schema below.
// Packs are applied via loadContentPack(id) which merges into the current
// session after a history snapshot, then calls persist() and re-renders.

import { state, persist, normalizeSession, uid, esc } from './state.js';
import { history } from './history.js';
import { notify } from './notify.js';

// ── Pack schema ───────────────────────────────────────────────────────────────
// { id, name, category, icon, description, suggestedMode, session: <partial> }
// session may include: blocks, scenes, rules, duration, variables, rampSettings

export const CONTENT_PACKS = [

  // ── Induction / Trance ────────────────────────────────────────────────────
  {
    id:            'induction-classic',
    name:          'Classic Induction',
    category:      'Induction & Trance',
    icon:          '🌀',
    suggestedMode: 'induction',
    description:   'A calm progressive relaxation and focus induction. Suitable for beginners. Text overlays + TTS guidance.',
    session: {
      name: 'Classic Induction',
      duration: 300,
      loopMode: 'none',
      speechRate: 0.85,
      scenes: [
        { name: 'Settle', start: 0,   end: 60,  stateType: 'calm',     color: '#5fa8d3', loopBehavior: 'once', nextSceneId: null },
        { name: 'Drop',   start: 60,  end: 180, stateType: 'build',    color: '#f0c040', loopBehavior: 'once', nextSceneId: null },
        { name: 'Depth',  start: 180, end: 270, stateType: 'peak',     color: '#7a1a2e', loopBehavior: 'once', nextSceneId: null },
        { name: 'Rise',   start: 270, end: 300, stateType: 'recovery', color: '#7dc87a', loopBehavior: 'once', nextSceneId: null },
      ],
      blocks: [
        { type: 'text',  label: 'Welcome',         start: 0,   duration: 15, content: 'Close your eyes.\nYou are safe.', fontSize: 1.3, _position: 'center' },
        { type: 'tts',   label: 'Breathing guide', start: 16,  duration: 20, content: 'Breathe in slowly for four counts. Hold. Now breathe out for six counts. Let each breath carry tension away.', volume: 0.85, voiceName: '' },
        { type: 'text',  label: 'Anchor',          start: 38,  duration: 20, content: 'Heavier.\nDrifting.\nSafe.', fontSize: 1.55, _position: 'center' },
        { type: 'pause', label: 'Silence',         start: 60,  duration: 15, content: '' },
        { type: 'tts',   label: 'Drop',            start: 77,  duration: 25, content: 'With each breath, you sink a little deeper. There is nothing you need to do right now. Simply allow.', volume: 0.80, voiceName: '' },
        { type: 'text',  label: 'Numbers',         start: 104, duration: 30, content: '10\n\n9\n\n8\n\n7\n\n6\n\n5', fontSize: 1.8, _position: 'center' },
        { type: 'tts',   label: 'Depth anchor',    start: 136, duration: 20, content: 'You are relaxed and focused. This is exactly where you are meant to be.', volume: 0.80, voiceName: '' },
        { type: 'pause', label: 'Deep silence',    start: 158, duration: 22, content: '' },
        { type: 'text',  label: 'Depth text',      start: 182, duration: 25, content: 'Deep.\nStill.\nPresent.', fontSize: 1.6, _position: 'center' },
        { type: 'tts',   label: 'Return',          start: 270, duration: 20, content: 'Slowly, awareness begins to return. At your own pace, begin to feel the room around you.', volume: 0.85, voiceName: '' },
        { type: 'text',  label: 'Rise',            start: 292, duration: 8,  content: 'Coming back.', fontSize: 1.2, _position: 'center' },
      ],
    },
  },

  // ── Conditioning ─────────────────────────────────────────────────────────
  {
    id:            'conditioning-foundation',
    name:          'Conditioning Foundation',
    category:      'Behavioral Conditioning',
    icon:          '⚙',
    suggestedMode: 'conditioning',
    description:   'Attention-reward loop. Builds focus and compliance through consistent positive reinforcement. Ideal first conditioning session.',
    session: {
      name: 'Conditioning Foundation',
      duration: 240,
      loopMode: 'count',
      loopCount: 2,
      speechRate: 0.90,
      variables: {
        loop_count: { type: 'number', value: 0, description: 'Tracks current repetition' },
      },
      scenes: [
        { name: 'Calibration', start: 0,   end: 45,  stateType: 'calm',  color: '#5fa8d3', loopBehavior: 'once', nextSceneId: null },
        { name: 'Training',    start: 45,  end: 195, stateType: 'build', color: '#f0c040', loopBehavior: 'loop', nextSceneId: null },
        { name: 'Integration', start: 195, end: 240, stateType: 'recovery', color: '#7dc87a', loopBehavior: 'once', nextSceneId: null },
      ],
      blocks: [
        { type: 'text', label: 'Opening',        start: 0,   duration: 15, content: 'Focus.\nBreathe.', fontSize: 1.4, _position: 'center' },
        { type: 'tts',  label: 'Instructions',   start: 17,  duration: 25, content: 'This session will respond to your attention. When you maintain focus, you will be rewarded. When your mind wanders, you will be redirected.', volume: 0.85 },
        { type: 'text', label: 'Attention cue',  start: 45,  duration: 20, content: '● Focus here', fontSize: 1.2, _position: 'center' },
        { type: 'tts',  label: 'Good',           start: 67,  duration: 8,  content: 'Good. Stay present.', volume: 0.80 },
        { type: 'text', label: 'Task',           start: 78,  duration: 40, content: 'Hold your attention steady.\nNotice any urge to drift — and return.', fontSize: 1.1, _position: 'center' },
        { type: 'pause', label: 'Silent hold',   start: 120, duration: 30, content: '' },
        { type: 'tts',  label: 'Halfway',        start: 152, duration: 10, content: 'Well done. Halfway through.', volume: 0.80 },
        { type: 'text', label: 'Push',           start: 164, duration: 30, content: 'Deeper.\nStay with it.', fontSize: 1.35, _position: 'center' },
        { type: 'tts',  label: 'Closing',        start: 200, duration: 15, content: 'The pattern is becoming part of you. Each session strengthens this.', volume: 0.85 },
        { type: 'text', label: 'End',            start: 230, duration: 8,  content: 'Complete.', fontSize: 1.4, _position: 'center' },
      ],
      rules: [
        { name: 'Reward sustained focus', enabled: true,
          condition: { metric: 'attention', op: '>=', value: 0.80 }, durationSec: 12, cooldownSec: 45,
          action: { type: 'setIntensity', param: 1.3 } },
        { name: 'Redirect on drift', enabled: true,
          condition: { metric: 'attention', op: '<', value: 0.25 }, durationSec: 5, cooldownSec: 30,
          action: { type: 'setIntensity', param: 0.3 } },
      ],
    },
  },

  // ── Partner / Training ────────────────────────────────────────────────────
  {
    id:            'partner-intro',
    name:          'Partner Introduction',
    category:      'Partner Sessions',
    icon:          '🤝',
    suggestedMode: 'training',
    description:   'First shared session for operator + primary user. Establishes the dynamic with clear guidance for both roles. Operator keeps manual control.',
    session: {
      name: 'Partner Introduction',
      duration: 180,
      loopMode: 'none',
      speechRate: 0.90,
      variables: {
        partner_name: { type: 'string', value: '', description: "Primary user's name (operator fills in)" },
      },
      scenes: [
        { name: 'Meeting',    start: 0,   end: 60,  stateType: 'calm',  color: '#5fa8d3', loopBehavior: 'once', nextSceneId: null },
        { name: 'Exploring',  start: 60,  end: 140, stateType: 'build', color: '#f0c040', loopBehavior: 'once', nextSceneId: null },
        { name: 'Completion', start: 140, end: 180, stateType: 'recovery', color: '#7dc87a', loopBehavior: 'once', nextSceneId: null },
      ],
      blocks: [
        { type: 'text', label: 'Welcome',     start: 0,   duration: 20, content: 'Welcome.\nSettle in together.', fontSize: 1.3, _position: 'center' },
        { type: 'tts',  label: 'Operator cue', start: 22,  duration: 30, content: 'Operator: take a moment to observe your partner. Adjust Live Controls to a comfortable starting point. There is no rush.', volume: 0.85 },
        { type: 'pause', label: 'Space',      start: 55,  duration: 10, content: '' },
        { type: 'text', label: 'Focus',       start: 67,  duration: 25, content: 'Present.\nOpen.', fontSize: 1.5, _position: 'center' },
        { type: 'tts',  label: 'Check in',   start: 94,  duration: 20, content: 'A gentle check-in. This is a partnership. Both of you set the pace together.', volume: 0.80 },
        { type: 'text', label: 'Midpoint',   start: 116, duration: 22, content: 'Stay with this.', fontSize: 1.2, _position: 'center' },
        { type: 'tts',  label: 'Close',      start: 142, duration: 20, content: 'Well done — both of you. Take a moment to acknowledge what you just shared.', volume: 0.85 },
        { type: 'text', label: 'End',        start: 165, duration: 12, content: 'Session complete.', fontSize: 1.3, _position: 'center' },
      ],
    },
  },

  // ── Solo / Surrender ──────────────────────────────────────────────────────
  {
    id:            'surrender-solo',
    name:          'Solo Surrender',
    category:      'Solo Sessions',
    icon:          '🌊',
    suggestedMode: 'surrender',
    description:   'High-trust solo experience. No pauses, full escalation. Set your safety parameters first, then let go.',
    session: {
      name: 'Solo Surrender',
      duration: 360,
      loopMode: 'none',
      speechRate: 0.80,
      scenes: [
        { name: 'Opening',  start: 0,   end: 60,  stateType: 'calm',     color: '#5fa8d3', loopBehavior: 'once', nextSceneId: null },
        { name: 'Building', start: 60,  end: 180, stateType: 'build',    color: '#f0c040', loopBehavior: 'once', nextSceneId: null },
        { name: 'Peak',     start: 180, end: 300, stateType: 'peak',     color: '#7a1a2e', loopBehavior: 'once', nextSceneId: null },
        { name: 'Return',   start: 300, end: 360, stateType: 'recovery', color: '#7dc87a', loopBehavior: 'once', nextSceneId: null },
      ],
      blocks: [
        { type: 'text',  label: 'Start',       start: 0,   duration: 20, content: 'This time is yours.\nLet go.', fontSize: 1.4, _position: 'center' },
        { type: 'tts',   label: 'Permission',  start: 22,  duration: 25, content: 'You have already done the hard part by showing up. Now you only have to be here — and experience.', volume: 0.80 },
        { type: 'pause', label: 'Silence',     start: 50,  duration: 15, content: '' },
        { type: 'text',  label: 'Surrender',   start: 67,  duration: 30, content: 'Sink.\nLet it take you.', fontSize: 1.6, _position: 'center' },
        { type: 'tts',   label: 'Building',    start: 100, duration: 20, content: 'Notice the build. You are allowed to want this.', volume: 0.75 },
        { type: 'pause', label: 'Open hold',   start: 122, duration: 55, content: '' },
        { type: 'text',  label: 'Peak anchor', start: 180, duration: 30, content: 'All the way.\nStay.', fontSize: 1.8, _position: 'center' },
        { type: 'pause', label: 'Peak hold',   start: 212, duration: 85, content: '' },
        { type: 'tts',   label: 'Return',      start: 302, duration: 22, content: 'Gently, begin to come back. Whatever you experienced — it was yours, completely.', volume: 0.80 },
        { type: 'text',  label: 'End',         start: 326, duration: 15, content: 'Well done.', fontSize: 1.4, _position: 'center' },
      ],
    },
  },

  // ── Mindfulness ───────────────────────────────────────────────────────────
  {
    id:            'grounding-reset',
    name:          'Grounding Reset',
    category:      'Mindfulness',
    icon:          '🧘',
    suggestedMode: 'mindfulness',
    description:   'Gentle come-down or reset. Calming anchors, low intensity, good after an intense session or a long day.',
    session: {
      name: 'Grounding Reset',
      duration: 180,
      loopMode: 'none',
      speechRate: 0.80,
      scenes: [
        { name: 'Grounding', start: 0,   end: 180, stateType: 'calm', color: '#5fa8d3', loopBehavior: 'once', nextSceneId: null },
      ],
      blocks: [
        { type: 'text',  label: 'Welcome back', start: 0,   duration: 18, content: 'You are safe.\nYou are here.', fontSize: 1.3, _position: 'center' },
        { type: 'tts',   label: 'Body scan',    start: 20,  duration: 30, content: 'Bring gentle attention to your body. Notice where you are holding tension. Without forcing anything, allow each breath to soften those places.', volume: 0.80 },
        { type: 'pause', label: 'Quiet',        start: 53,  duration: 20, content: '' },
        { type: 'text',  label: 'Anchors',      start: 75,  duration: 20, content: 'Grounded.\nPresent.\nOkay.', fontSize: 1.4, _position: 'center' },
        { type: 'tts',   label: 'Affirmation',  start: 97,  duration: 25, content: 'Whatever happened before this moment — it has passed. You are here now, and that is enough.', volume: 0.80 },
        { type: 'pause', label: 'Rest',         start: 124, duration: 35, content: '' },
        { type: 'text',  label: 'Closing',      start: 161, duration: 17, content: 'Rest.\nYou are done.', fontSize: 1.2, _position: 'center' },
      ],
    },
  },

  // ── Spiral Descent — Viz-Enhanced Induction ───────────────────────────────
  {
    id:            'spiral-descent',
    name:          'Spiral Descent',
    category:      'Induction & Trance',
    icon:          '🌀',
    suggestedMode: 'induction',
    description:   'A visual hypnotic induction using the Spiral animation block. The spiral deepens as the narration guides descent. Best experienced fullscreen.',
    session: {
      name: 'Spiral Descent',
      duration: 360,
      loopMode: 'none',
      speechRate: 0.80,
      notes: 'Uses the viz block type for a live hypnotic spiral during the drop phase. Run fullscreen for maximum effect.',
      scenes: [
        { name: 'Arrive',  start: 0,   end: 60,  stateType: 'calm',     color: '#5fa8d3', loopBehavior: 'once', nextSceneId: null },
        { name: 'Watch',   start: 60,  end: 180, stateType: 'build',    color: '#f0c040', loopBehavior: 'once', nextSceneId: null },
        { name: 'Drop',    start: 180, end: 300, stateType: 'peak',     color: '#7a1a2e', loopBehavior: 'once', nextSceneId: null },
        { name: 'Restore', start: 300, end: 360, stateType: 'recovery', color: '#7dc87a', loopBehavior: 'once', nextSceneId: null },
      ],
      blocks: [
        // Arrive — settle and prepare
        { type: 'text',  label: 'Welcome',       start: 0,   duration: 18, content: 'Find a comfortable position.\nClose your eyes.', fontSize: 1.3, _position: 'center' },
        { type: 'tts',   label: 'Settle',        start: 20,  duration: 30, content: 'Take three slow breaths. With each one, feel the tension leaving your shoulders, your jaw, your hands.', volume: 0.82, voiceName: '' },
        { type: 'pause', label: 'Silence',       start: 52,  duration: 10, content: '' },

        // Watch — spiral appears
        { type: 'viz',   label: 'Spiral begins', start: 62,  duration: 118,
          vizType: 'spiral', vizSpeed: 0.6, vizColor: '#c49a3c' },
        { type: 'tts',   label: 'Watch it',      start: 65,  duration: 25, content: 'When you are ready, open your eyes. Watch the spiral turn. There is nothing else you need to do right now.', volume: 0.78, voiceName: '' },
        { type: 'pause', label: 'Watching',      start: 93,  duration: 40, content: '' },
        { type: 'tts',   label: 'Soften',        start: 135, duration: 20, content: 'Let your eyes soften. Let the spiral carry your attention gently downward.', volume: 0.75, voiceName: '' },

        // Drop — deep trance
        { type: 'viz',   label: 'Deep spiral',   start: 182, duration: 118,
          vizType: 'spiral', vizSpeed: 0.35, vizColor: '#7a1a2e' },
        { type: 'tts',   label: 'Dropping',      start: 185, duration: 25, content: 'Deeper now. Each rotation takes you further in. You are safe. You are held.', volume: 0.72, voiceName: '' },
        { type: 'pause', label: 'Deep hold',     start: 212, duration: 60, content: '' },
        { type: 'text',  label: 'Deep text',     start: 274, duration: 24, content: 'Deep.', fontSize: 2.2, _position: 'center' },

        // Restore — come back
        { type: 'tts',   label: 'Return',        start: 302, duration: 22, content: 'Slowly, gently, awareness returns. At your own pace, become aware of the room. There is no rush.', volume: 0.80, voiceName: '' },
        { type: 'text',  label: 'End',           start: 338, duration: 18, content: 'Welcome back.', fontSize: 1.3, _position: 'center' },
      ],
    },
  },
];

// ── Apply a content pack to the current session ────────────────────────────────
// Replaces the session entirely (after a history snapshot) so the author has
// a complete starting point they can then customize.
export async function loadContentPack(packId) {
  const pack = CONTENT_PACKS.find(p => p.id === packId);
  if (!pack) { notify.warn(`Content pack "${packId}" not found.`); return false; }

  history.push();

  const fresh = normalizeSession({
    ...pack.session,
    // Assign fresh IDs to all blocks and scenes so the pack can be loaded multiple times
    blocks: (pack.session.blocks ?? []).map(b => ({ ...b, id: uid() })),
    scenes: (pack.session.scenes ?? []).map(s => ({ ...s, id: uid() })),
  });

  // Full session replacement — await all cleanup before mutating state so that
  // any re-renders triggered by the caller see the updated session, not the old one.
  await Promise.all([
    import('./playback.js').then(({ stopPlayback })        => stopPlayback({ silent: true })),
    import('./funscript.js').then(({ resetZoom })           => resetZoom?.()),
    import('./state-engine.js').then(({ resetStateEngine }) => resetStateEngine()),
    import('./rules-engine.js').then(({ clearRuleState })   => clearRuleState()),
  ]).catch(() => {});

  state.session              = fresh;
  state.selectedBlockId      = fresh.blocks[0]?.id ?? null;
  state.selectedSidebarType  = null;
  state.selectedSidebarIdx   = null;
  state.selectedSidebarId    = null;
  persist();

  // Apply the pack's suggested session mode (rules, ramp, pacing) if set
  if (pack.suggestedMode) {
    await import('./session-modes.js').then(({ applySessionMode }) => {
      applySessionMode(pack.suggestedMode);
    }).catch(() => {});
  }

  notify.success(`"${pack.name}" loaded. Customize it in the inspector.`);
  // Refresh sidebar (tracks), inspector, timeline, and idle screen with new session
  import('./ui.js').then(({ renderSidebar, renderInspector, syncSettingsForms }) => {
    renderSidebar();
    renderInspector();
    syncSettingsForms();
  }).catch(() => {});
  import('./funscript.js').then(({ drawTimeline }) => drawTimeline()).catch(() => {});
  import('./fullscreen-hud.js').then(({ renderIdleScreen }) => renderIdleScreen()).catch(() => {});

  // Track which packs have ever been loaded (for the Pack Explorer achievement)
  import('./user-profile.js').then(({ loadProfile, saveProfile }) => {
    const prof = loadProfile();
    const loaded = new Set(prof.packsLoaded ?? []);
    if (!loaded.has(packId)) {
      loaded.add(packId);
      prof.packsLoaded = [...loaded];
      saveProfile(prof);
      // Award packs_3 and all_packs based on count
      import('./achievements.js').then(({ ACHIEVEMENT_MAP }) => {
        import('./user-profile.js').then(({ loadProfile: lp, saveProfile: sp }) => {
          const p2   = lp();
          const earn = new Set(p2.achievements ?? []);
          const disp = state.session?.displayOptions ?? {};
          const grant = (id, msg) => {
            if (!earn.has(id)) {
              earn.add(id);
              p2.achievements = [...earn];
              p2.xp = (p2.xp ?? 0) + (ACHIEVEMENT_MAP[id]?.xp ?? 0);
              sp(p2);
              if (disp.toastAchievements !== false) {
                notify.success(msg, 5000);
              }
            }
          };
          if (loaded.size >= 3)                 grant('packs_3',   '📚 Achievement: Pack Curious');
          if (loaded.size >= CONTENT_PACKS.length) grant('all_packs', '📦 Achievement: Pack Explorer');
        }).catch(() => {});
      }).catch(() => {});
    }
  }).catch(() => {});
  return pack;
}

// ── Get packs grouped by category ────────────────────────────────────────────
export function getPacksByCategory() {
  const cats = {};
  for (const pack of CONTENT_PACKS) {
    if (!cats[pack.category]) cats[pack.category] = [];
    cats[pack.category].push(pack);
  }
  return cats;
}

// ── Render the content packs picker ──────────────────────────────────────────
export function renderContentPacksPicker(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;

  const byCategory = getPacksByCategory();

  el.innerHTML = `
    <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:10px;
      font-family:'Playfair Display',Georgia,serif;font-style:italic">
      Session Templates
    </div>
    <p style="font-size:11px;color:var(--text2);line-height:1.6;margin-bottom:12px">
      Load a pre-built session as your starting point. Your current session will be
      saved to the undo history — press Ctrl+Z to get it back.
    </p>
    ${Object.entries(byCategory).map(([cat, packs]) => `
      <div style="margin-bottom:14px">
        <div style="font-size:9px;color:rgba(196,154,60,0.5);text-transform:uppercase;
          letter-spacing:.12em;margin-bottom:7px;display:flex;align-items:center;gap:6px">
          ${cat}<span style="flex:1;height:0.5px;background:rgba(196,154,60,0.12);display:block"></span>
        </div>
        ${packs.map(pack => `
          <div style="padding:9px 11px;margin-bottom:5px;border-radius:8px;cursor:pointer;
            background:rgba(255,255,255,0.02);border:0.5px solid rgba(255,255,255,0.06);
            transition:background 0.15s,border-color 0.15s"
            class="pack-card" data-pack-id="${pack.id}"
            onmouseover="this.style.background='rgba(196,154,60,0.06)';this.style.borderColor='rgba(196,154,60,0.18)'"
            onmouseout="this.style.background='rgba(255,255,255,0.02)';this.style.borderColor='rgba(255,255,255,0.06)'">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
              <span style="font-size:15px">${esc(pack.icon)}</span>
              <span style="font-size:12px;font-weight:600;color:var(--text)">${esc(pack.name)}</span>
              <span style="margin-left:auto;font-size:9px;color:rgba(196,154,60,0.5);
                letter-spacing:.05em;text-transform:uppercase">${esc(pack.suggestedMode)}</span>
            </div>
            <div style="font-size:10.5px;color:var(--text2);line-height:1.5;padding-left:23px">
              ${esc(pack.description)}
            </div>
          </div>`).join('')}
      </div>`).join('')}`;

  el.querySelectorAll('.pack-card').forEach(card => {
    card.addEventListener('click', async () => {
      if (card.dataset.loading) return;          // guard double-click
      card.dataset.loading = '1';
      card.style.opacity   = '0.6';
      try {
        // loadContentPack is now async — await it so state.session is updated
        // before the re-renders below fire.
        const pack = await loadContentPack(card.dataset.packId);
        if (pack) {
          const { renderSidebar, renderInspector, syncSettingsForms,
                  syncTransportControls, applyCssVars } = await import('./ui.js').catch(() => ({}));
          renderSidebar?.(); renderInspector?.(); syncSettingsForms?.();
          syncTransportControls?.(); applyCssVars?.();
          if (pack.suggestedMode) {
            notify.info(`Mode set to "${pack.suggestedMode}" — customize in Session tab.`);
          }
        }
      } finally {
        delete card.dataset.loading;
        card.style.opacity = '';
      }
    });
  });
}
