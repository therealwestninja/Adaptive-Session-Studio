// ── tests/state.test.js ───────────────────────────────────────────────────
// Tests for pure functions in js/state.js:
//   normalizeBlock, normalizeSession, normalizeAudioTrack,
//   normalizeVideoTrack, normalizeFunscriptTrack, normalizeSubtitleTrack,
//   normalizeMacro, clampInt, fmt, uid

import { makeRunner } from './harness.js';
import {
  normalizeBlock, normalizeSession, normalizeAudioTrack, normalizeVideoTrack,
  normalizeFunscriptTrack, normalizeSubtitleTrack, normalizeMacro,
  clampInt, fmt, uid, sampleSession,
} from '../js/state.js';

export function runStateTests() {
  const { test, assertEqual, assertDeep, assert } = makeRunner('state.js normalizers');
  const R = makeRunner('state.js normalizers');
  const t = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const deep = R.assertDeep.bind(R);
  const ok = R.assert.bind(R);

  // ── clampInt ───────────────────────────────────────────────────────────
  t('clampInt clamps low', () => eq(clampInt(-5, 0, 100, 50), 0));
  t('clampInt clamps high', () => eq(clampInt(200, 0, 100, 50), 100));
  t('clampInt rounds', () => eq(clampInt(9.7, 0, 100, 50), 10));
  t('clampInt uses fallback for NaN', () => eq(clampInt('abc', 0, 100, 42), 42));
  t('clampInt passes through valid value', () => eq(clampInt(55, 0, 100, 0), 55));

  // ── fmt ───────────────────────────────────────────────────────────────
  t('fmt formats zero', () => eq(fmt(0), '00:00'));
  t('fmt formats 90 seconds', () => eq(fmt(90), '01:30'));
  t('fmt formats negative (clamps to 0)', () => eq(fmt(-10), '00:00'));
  t('fmt pads minutes', () => eq(fmt(65), '01:05'));
  t('fmt formats large value', () => eq(fmt(3600), '60:00'));

  // ── uid ───────────────────────────────────────────────────────────────
  t('uid returns string starting with b_', () => ok(uid().startsWith('b_')));
  t('uid produces unique values', () => ok(uid() !== uid()));
  t('uid has expected length', () => ok(uid().length >= 10));

  // ── normalizeBlock ────────────────────────────────────────────────────
  t('normalizeBlock preserves existing id', () => {
    const b = normalizeBlock({ id: 'my-id', type: 'text', label: 'A', start: 0, duration: 5 });
    eq(b.id, 'my-id');
  });
  t('normalizeBlock generates id when missing', () => {
    const b = normalizeBlock({ type: 'text' });
    ok(b.id && b.id.startsWith('b_'));
  });
  t('normalizeBlock clamps start to 0 minimum', () => {
    const b = normalizeBlock({ start: -5 });
    eq(b.start, 0);
  });
  t('normalizeBlock clamps duration to 1 minimum', () => {
    const b = normalizeBlock({ duration: 0 });
    eq(b.duration, 1);
  });
  t('normalizeBlock preserves content', () => {
    const b = normalizeBlock({ content: 'hello world' });
    eq(b.content, 'hello world');
  });
  t('normalizeBlock defaults type to text', () => {
    const b = normalizeBlock({});
    eq(b.type, 'text');
  });
  t('normalizeBlock defaults _position to center', () => {
    const b = normalizeBlock({});
    eq(b._position, 'center');
  });

  // ── normalizeAudioTrack ───────────────────────────────────────────────
  t('normalizeAudioTrack preserves existing id', () => {
    const t2 = normalizeAudioTrack({ id: 'au-1', name: 'test', dataUrl: '', volume: 0.5 });
    eq(t2.id, 'au-1');
  });
  t('normalizeAudioTrack generates id when missing', () => {
    const t2 = normalizeAudioTrack({ name: 'no-id' });
    ok(t2.id && t2.id.startsWith('b_'));
  });
  t('normalizeAudioTrack clamps volume 0–2', () => {
    eq(normalizeAudioTrack({ volume: -1 }).volume, 0);
    eq(normalizeAudioTrack({ volume: 10 }).volume, 2);
  });
  t('normalizeAudioTrack defaults _muted to false', () => {
    ok(normalizeAudioTrack({})._muted === false);
  });
  t('normalizeAudioTrack preserves _muted:true', () => {
    ok(normalizeAudioTrack({ _muted: true })._muted === true);
  });

  // ── normalizeVideoTrack ───────────────────────────────────────────────
  t('normalizeVideoTrack preserves existing id', () => {
    const t2 = normalizeVideoTrack({ id: 'vid-1', name: 'v' });
    eq(t2.id, 'vid-1');
  });
  t('normalizeVideoTrack generates id when missing', () => {
    ok(normalizeVideoTrack({ name: 'v' }).id.startsWith('b_'));
  });
  t('normalizeVideoTrack defaults mediaKind to video', () => {
    eq(normalizeVideoTrack({}).mediaKind, 'video');
  });
  t('normalizeVideoTrack accepts image mediaKind', () => {
    eq(normalizeVideoTrack({ mediaKind: 'image' }).mediaKind, 'image');
  });
  t('normalizeVideoTrack rejects unknown mediaKind', () => {
    eq(normalizeVideoTrack({ mediaKind: 'gif' }).mediaKind, 'video');
  });

  // ── normalizeFunscriptTrack ───────────────────────────────────────────
  t('normalizeFunscriptTrack generates id', () => {
    ok(normalizeFunscriptTrack({}).id.startsWith('b_'));
  });
  t('normalizeFunscriptTrack preserves id', () => {
    eq(normalizeFunscriptTrack({ id: 'fs-1' }).id, 'fs-1');
  });
  t('normalizeFunscriptTrack sorts actions by time', () => {
    const track = normalizeFunscriptTrack({ actions: [
      { at: 500, pos: 100 }, { at: 0, pos: 0 }, { at: 250, pos: 50 },
    ]});
    eq(track.actions[0].at, 0);
    eq(track.actions[1].at, 250);
    eq(track.actions[2].at, 500);
  });
  t('normalizeFunscriptTrack filters non-finite actions', () => {
    const track = normalizeFunscriptTrack({ actions: [
      { at: 0, pos: 0 }, { at: NaN, pos: 50 }, { at: 500, pos: 'x' },
    ]});
    eq(track.actions.length, 1);
  });
  t('normalizeFunscriptTrack clamps pos 0–100', () => {
    const track = normalizeFunscriptTrack({ actions: [
      { at: 0, pos: -10 }, { at: 500, pos: 200 },
    ]});
    eq(track.actions[0].pos, 0);
    eq(track.actions[1].pos, 100);
  });
  t('normalizeFunscriptTrack defaults _disabled to false', () => {
    ok(normalizeFunscriptTrack({})._disabled === false);
  });

  // ── normalizeSubtitleTrack ────────────────────────────────────────────
  t('normalizeSubtitleTrack generates stable id', () => {
    const t2 = normalizeSubtitleTrack({});
    ok(t2.id && t2.id.startsWith('b_'));
  });
  t('normalizeSubtitleTrack preserves existing id', () => {
    eq(normalizeSubtitleTrack({ id: 'sub-1' }).id, 'sub-1');
  });
  t('normalizeSubtitleTrack filters invalid events (end <= start)', () => {
    const t2 = normalizeSubtitleTrack({ events: [
      { start: 0, end: 5, text: 'ok' },
      { start: 10, end: 5, text: 'bad end' },
      { start: 3, end: 3, text: 'zero duration' },
    ]});
    eq(t2.events.length, 1);
    eq(t2.events[0].text, 'ok');
  });
  t('normalizeSubtitleTrack defaults _disabled to false', () => {
    ok(normalizeSubtitleTrack({})._disabled === false);
  });

  // ── normalizeMacro ────────────────────────────────────────────────────
  t('normalizeMacro generates id', () => {
    ok(normalizeMacro({}).id.startsWith('b_'));
  });
  t('normalizeMacro preserves id', () => {
    eq(normalizeMacro({ id: 'mac-1' }).id, 'mac-1');
  });
  t('normalizeMacro defaults name to Macro', () => {
    eq(normalizeMacro({}).name, 'Macro');
  });
  t('normalizeMacro sorts actions', () => {
    const m = normalizeMacro({ actions: [{ at: 200, pos: 100 }, { at: 0, pos: 0 }]});
    eq(m.actions[0].at, 0);
  });

  // ── normalizeSession — CRITICAL regression: empty blocks must be preserved ──
  t('normalizeSession preserves blocks:[] (does NOT replace with sample)', () => {
    const s = normalizeSession({ blocks: [] });
    ok(Array.isArray(s.blocks), 'blocks should be array');
    eq(s.blocks.length, 0, 'empty array must stay empty');
  });
  t('normalizeSession uses sample blocks when blocks field is absent', () => {
    const s = normalizeSession({});
    ok(s.blocks.length > 0, 'should fall back to sample blocks');
  });
  t('normalizeSession uses sample blocks when blocks is not an array', () => {
    const s = normalizeSession({ blocks: 'invalid' });
    ok(s.blocks.length > 0);
  });
  t('normalizeSession normalizes nested audio tracks (assigns ids)', () => {
    const s = normalizeSession({
      playlists: { audio: [{ name: 'track', dataUrl: '', volume: 1 }] }
    });
    ok(s.playlists.audio[0].id && s.playlists.audio[0].id.startsWith('b_'));
  });
  t('normalizeSession normalizes nested subtitle tracks (assigns ids)', () => {
    const s = normalizeSession({
      subtitleTracks: [{ name: 'subs', events: [] }]
    });
    ok(s.subtitleTracks[0].id && s.subtitleTracks[0].id.startsWith('b_'));
  });
  t('normalizeSession merges advanced defaults', () => {
    const s = normalizeSession({ advanced: { stageBlur: 10 } });
    eq(s.advanced.stageBlur, 10);
    ok('crossfadeSeconds' in s.advanced, 'crossfadeSeconds should be merged from default');
  });
  t('normalizeSession preserves custom themes', () => {
    const s = normalizeSession({ customThemes: { myTheme: { name: 'My' } } });
    ok('myTheme' in s.customThemes);
  });
  t('defaultSession() does not include dead deviceConnected field', () => {
    // The field was removed from defaultSession. New sessions must not carry it.
    const s = normalizeSession({});
    ok(!('deviceConnected' in s.funscriptSettings),
      'fresh session must not have deviceConnected');
  });
  t('normalizeSession preserves funscriptSettings.speed from import', () => {
    // Unknown extra fields in funscriptSettings survive the spread (by design).
    // What matters is that known fields are correctly merged.
    const s = normalizeSession({ funscriptSettings: { speed: 2.5 } });
    eq(s.funscriptSettings.speed, 2.5, 'speed must be preserved from import');
  });

  return R.summary();
}
