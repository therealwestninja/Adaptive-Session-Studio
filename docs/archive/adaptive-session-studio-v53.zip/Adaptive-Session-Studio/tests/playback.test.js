// ── tests/playback.test.js ────────────────────────────────────────────────
// Tests for pure exports from js/playback.js that don't require DOM or
// a running session: resolveTemplateVars.

import { makeRunner } from './harness.js';
import { resolveTemplateVars } from '../js/playback.js';
import { state, defaultSession, normalizeSession } from '../js/state.js';

export function runPlaybackTests() {
  const R  = makeRunner('playback.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  function reset() {
    state.session   = normalizeSession(defaultSession());
    state.runtime   = null;
    state.engineState = { attention: 0, engagement: 0, intensity: 1.0, speed: 1.0,
                          sessionTime: 0, totalSec: 0, loopCount: 0 };
    state.liveControl = { intensityScale: 1.0, speedScale: 1.0 };
  }

  // ── resolveTemplateVars ────────────────────────────────────────────────────
  t('resolveTemplateVars returns content unchanged when no {{ found', () => {
    reset();
    eq(resolveTemplateVars('Hello world'), 'Hello world');
  });

  t('resolveTemplateVars returns empty string for empty input', () => {
    reset();
    eq(resolveTemplateVars(''), '');
  });

  t('resolveTemplateVars returns null for null input', () => {
    reset();
    ok(resolveTemplateVars(null) == null);
  });

  t('resolveTemplateVars resolves {{loop}} to loop number', () => {
    reset();
    state.runtime = {
      sessionTime: 0, loopIndex: 2, totalLoops: 5,
      activeScene: null, injection: null,
    };
    const out = resolveTemplateVars('Loop {{loop}}');
    ok(out.includes('3'), `expected loop 3, got "${out}"`);
  });

  t('resolveTemplateVars resolves {{intensity}} as percentage', () => {
    reset();
    state.engineState.intensity = 0.75;
    const out = resolveTemplateVars('Level: {{intensity}}');
    ok(out.includes('%'), `expected % in "${out}"`);
    ok(out.includes('75'), `expected 75% in "${out}"`);
  });

  t('resolveTemplateVars resolves {{speed}}', () => {
    reset();
    state.engineState.speed = 1.5;
    const out = resolveTemplateVars('Speed: {{speed}}');
    ok(out.includes('1.50') || out.includes('1.5'), `expected 1.50× in "${out}"`);
  });

  t('resolveTemplateVars resolves user-defined number variable', () => {
    reset();
    state.session.variables = {
      score: { type: 'number', value: 42, description: '' }
    };
    const out = resolveTemplateVars('Score: {{score}}');
    ok(out.includes('42'), `expected 42 in "${out}"`);
  });

  t('resolveTemplateVars resolves user-defined boolean variable', () => {
    reset();
    state.session.variables = {
      active: { type: 'boolean', value: true, description: '' }
    };
    const out = resolveTemplateVars('Active: {{active}}');
    ok(out.includes('true'), `expected "true" in "${out}"`);
  });

  t('resolveTemplateVars leaves unknown {{vars}} unchanged', () => {
    reset();
    state.session.variables = {};
    const out = resolveTemplateVars('Value: {{unknown_var}}');
    ok(out.includes('{{unknown_var}}'), `expected placeholder preserved, got "${out}"`);
  });

  t('resolveTemplateVars resolves multiple vars in one string', () => {
    reset();
    state.engineState.intensity = 1.0;
    state.session.variables = { score: { type: 'number', value: 7, description: '' } };
    const out = resolveTemplateVars('Intensity: {{intensity}}, Score: {{score}}');
    ok(out.includes('100%'), 'intensity present');
    ok(out.includes('7'), 'score present');
  });

  t('resolveTemplateVars is case-insensitive for built-in vars', () => {
    reset();
    state.engineState.intensity = 0.5;
    const lower = resolveTemplateVars('{{intensity}}');
    const upper = resolveTemplateVars('{{INTENSITY}}');
    eq(lower, upper, 'case-insensitive for built-in vars');
  });

  t('resolveTemplateVars handles content with many {{ }} pairs efficiently', () => {
    reset();
    state.session.variables = { x: { type: 'number', value: 1, description: '' } };
    const content = '{{x}}, '.repeat(1000).slice(0, -2);
    let threw = false;
    try { resolveTemplateVars(content); } catch { threw = true; }
    ok(!threw, 'large content should not throw');
  });

  return R.summary();
}
