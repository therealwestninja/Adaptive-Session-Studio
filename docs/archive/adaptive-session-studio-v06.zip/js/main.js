// ── main.js ────────────────────────────────────────────────────────────────
// App entry point: event wiring, keyboard shortcuts, initialization.

import { state, persist, fmt, $id, uid, clampInt, fileToDataUrl,
         normalizeBlock, normalizeSession, sampleSession, defaultSession,
         applyCssVars, applyTheme } from './state.js';

import { startPlayback, stopPlayback, pausePlayback, resumePlayback,
         seekTo, skipBy, emergencyStop } from './playback.js';

import { parseAss } from './subtitle.js';

import { importFunScriptFile, initTimeline, drawTimeline,
         refreshTimelineVisibility, connectDevice, disconnectDevice } from './funscript.js';

import { renderSidebar, renderInspector, syncSettingsForms,
         syncSessionFromSettings, renderThemeGrid,
         saveCustomTheme, deleteCustomTheme } from './ui.js';

import { makeTrackingModule } from './tracking.js';

import { injectMacro, getSlotMacro, toggleFsPause } from './macros.js';

import { renderMacroLibrary, initMacroLibraryEvents } from './macro-ui.js';

import { initFullscreenHud } from './fullscreen-hud.js';

// Expose for inspector button handlers
window._funscriptModule = { connectDevice, disconnectDevice };

// ── Block operations ─────────────────────────────────────────────────────────
function duplicateBlock() {
  const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
  if (!block) return;
  const copy = { ...structuredClone(block), id: uid(), start: block.start + block.duration + 1, label: `${block.label} copy` };
  state.session.blocks.push(copy);
  state.selectedBlockId = copy.id;
  persist(); renderSidebar(); renderInspector();
}

function deleteBlock() {
  if (!state.selectedBlockId) return;
  state.session.blocks = state.session.blocks.filter(b => b.id !== state.selectedBlockId);
  state.selectedBlockId = state.session.blocks[0]?.id || null;
  persist(); renderSidebar(); renderInspector();
}

window._appDuplicateBlock = duplicateBlock;
window._appDeleteBlock    = deleteBlock;

// ── Transport controls ───────────────────────────────────────────────────────
$id('playBtn').addEventListener('click', () => {
  if (!state.runtime)            startPlayback();
  else if (state.runtime.paused) resumePlayback();
  else                           pausePlayback();
});
$id('stopBtn').addEventListener('click', stopPlayback);
$id('skipBackBtn').addEventListener('click',  () => skipBy(-10));
$id('skipFwdBtn').addEventListener('click',   () => skipBy(10));

$id('loopToggle').addEventListener('click', () => {
  const modes  = ['none', 'count', 'forever'];
  const labels = { none: '↺ Off', count: '↺ Loop', forever: '↺ ∞' };
  const idx = modes.indexOf(state.session.loopMode);
  state.session.loopMode = modes[(idx + 1) % modes.length];
  const btn = $id('loopToggle');
  btn.textContent = labels[state.session.loopMode];
  btn.classList.toggle('active', state.session.loopMode !== 'none');
  persist();
});

const mvSlider = $id('masterVolumeSlider');
mvSlider.value = state.session.masterVolume;
mvSlider.addEventListener('input', e => {
  state.session.masterVolume = Number(e.target.value);
  state.runtime?.backgroundAudio.forEach(a => a.volume = state.session.masterVolume * state.session.advanced.playlistAudioVolume);
  persist();
});

$id('progressBar').addEventListener('click', e => {
  const r = e.currentTarget.getBoundingClientRect();
  seekTo((e.clientX - r.left) / r.width);
});

$id('fullscreenBtn').addEventListener('click', () => {
  if (!document.fullscreenElement) $id('mainStage').requestFullscreen?.();
  else document.exitFullscreen?.();
});

// ── Session actions ──────────────────────────────────────────────────────────
$id('newSessionBtn').addEventListener('click', () => {
  state.session = defaultSession(); state.selectedBlockId = null;
  stopPlayback(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms();
  $id('tTotal').textContent = fmt(state.session.duration); persist();
});

$id('loadSampleBtn').addEventListener('click', () => {
  state.session = sampleSession(); state.selectedBlockId = state.session.blocks[0]?.id || null;
  stopPlayback(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms();
  $id('tTotal').textContent = fmt(state.session.duration); persist();
});

$id('exportPackageBtn').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(state.session, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${state.session.name || 'session'}.assp`;
  a.click(); URL.revokeObjectURL(a.href);
});

$id('importPackageInput').addEventListener('change', async e => {
  const file = e.target.files?.[0]; if (!file) return;
  try {
    state.session = normalizeSession(JSON.parse(await file.text()));
    state.selectedBlockId = state.session.blocks[0]?.id || null;
    stopPlayback(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms(); persist();
  } catch (err) { alert(`Import failed: ${err.message}`); }
  e.target.value = '';
});

// ── Media file inputs ────────────────────────────────────────────────────────
$id('addAudioInput').addEventListener('change', async e => {
  for (const f of e.target.files)
    state.session.playlists.audio.push({ name: f.name, dataUrl: await fileToDataUrl(f), volume: 1, _muted: false });
  persist(); renderSidebar(); e.target.value = '';
});

$id('addVideoInput').addEventListener('change', async e => {
  for (const f of e.target.files)
    state.session.playlists.video.push({ name: f.name, dataUrl: await fileToDataUrl(f), mediaKind: f.type.startsWith('image/') ? 'image' : 'video', mute: true, volume: 1 });
  persist(); renderSidebar(); e.target.value = '';
});

$id('addAssInput').addEventListener('change', async e => {
  const file = e.target.files?.[0]; if (!file) return;
  const rawText = await file.text();
  const parsed  = parseAss(rawText);
  state.session.subtitleTracks.push({ name: file.name, rawAss: rawText, styles: parsed.styles, events: parsed.events, _disabled: false });
  persist(); renderSidebar(); e.target.value = '';
});

$id('addFunscriptInput').addEventListener('change', async e => {
  for (const f of e.target.files) await importFunScriptFile(f);
  renderSidebar(); renderInspector(); drawTimeline(); e.target.value = '';
});

// ── Block add buttons ────────────────────────────────────────────────────────
document.querySelectorAll('[data-add-block]').forEach(btn => {
  btn.addEventListener('click', () => {
    const type = btn.dataset.addBlock;
    const nextStart = state.session.blocks.length ? Math.max(...state.session.blocks.map(b => b.start + b.duration)) + 2 : 0;
    const block = normalizeBlock({ id: uid(), type, label: `New ${type}`, start: nextStart, duration: type === 'pause' ? 5 : 10 });
    state.session.blocks.push(block);
    state.selectedBlockId = block.id; state.selectedSidebarType = 'block';
    persist(); renderSidebar(); renderInspector();
  });
});

$id('sortBlocksBtn').addEventListener('click', () => {
  state.session.blocks.sort((a, b) => a.start - b.start); persist(); renderSidebar();
});

// ── Delegated events ─────────────────────────────────────────────────────────
document.addEventListener('click', e => {
  const itab = e.target.closest('.insp-tab');
  if (itab) { state.inspTab = itab.dataset.tab; document.querySelectorAll('.insp-tab').forEach(t => t.classList.toggle('active', t === itab)); renderInspector(); return; }

  const stab = e.target.closest('.settings-tab');
  if (stab) {
    state.settingsTab = stab.dataset.stab;
    document.querySelectorAll('.settings-tab').forEach(t => t.classList.toggle('active', t === stab));
    document.querySelectorAll('.settings-section').forEach(s => s.classList.toggle('active', s.dataset.section === state.settingsTab));
    if (state.settingsTab === 'macros') renderMacroLibrary();
    return;
  }

  const tc = e.target.closest('[data-theme-key]');
  if (tc) { applyTheme(tc.dataset.themeKey); syncSettingsForms(); return; }

  const muteBtn = e.target.closest('[data-mute-kind]');
  if (muteBtn) {
    const kind = muteBtn.dataset.muteKind, idx = Number(muteBtn.dataset.muteIdx);
    if (kind === 'audio')     state.session.playlists.audio[idx]._muted   = !state.session.playlists.audio[idx]._muted;
    if (kind === 'subtitle')  state.session.subtitleTracks[idx]._disabled  = !state.session.subtitleTracks[idx]._disabled;
    if (kind === 'funscript') state.session.funscriptTracks[idx]._disabled = !state.session.funscriptTracks[idx]._disabled;
    persist(); renderSidebar(); drawTimeline(); return;
  }

  const delBtn = e.target.closest('[data-del-kind]');
  if (delBtn) {
    const kind = delBtn.dataset.delKind, idx = Number(delBtn.dataset.delIdx);
    if (kind === 'audio')    state.session.playlists.audio.splice(idx, 1);
    if (kind === 'video')    state.session.playlists.video.splice(idx, 1);
    if (kind === 'subtitle') state.session.subtitleTracks.splice(idx, 1);
    if (kind === 'funscript') { state.session.funscriptTracks.splice(idx, 1); drawTimeline(); }
    state.selectedSidebarType = null; state.selectedSidebarIdx = null;
    persist(); renderSidebar(); renderInspector(); return;
  }

  const sbItem = e.target.closest('[data-sb-type]');
  if (sbItem && !e.target.closest('[data-mute-kind],[data-del-kind]')) {
    const type = sbItem.dataset.sbType, idx = sbItem.dataset.sbIdx !== undefined ? Number(sbItem.dataset.sbIdx) : null, bid = sbItem.dataset.blockId;
    state.selectedSidebarType = type; state.selectedSidebarIdx = idx;
    if (type === 'block' && bid) {
      state.selectedBlockId = bid; state.inspTab = 'overlay';
      document.querySelectorAll('.insp-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === 'overlay'));
    }
    renderSidebar(); renderInspector(); return;
  }
});

// ── Settings dialog ──────────────────────────────────────────────────────────
let _tracking = null;
$id('settingsBtn').addEventListener('click', () => { syncSettingsForms(); renderMacroLibrary(); $id('settingsDialog').showModal(); _tracking = makeTrackingModule(); });
const closeSettings = () => { syncSessionFromSettings(); applyCssVars(); $id('settingsDialog').close(); };
$id('closeSettings').addEventListener('click', closeSettings);
$id('settingsDoneBtn').addEventListener('click', closeSettings);
$id('settingsDialog').addEventListener('input', e => { if (e.target.id === 's_jsonPreview') return; syncSessionFromSettings(); applyCssVars(); renderThemeGrid(); });
$id('saveCustomThemeBtn')?.addEventListener('click', saveCustomTheme);
$id('deleteCustomThemeBtn')?.addEventListener('click', deleteCustomTheme);
$id('startTrackingBtn').addEventListener('click', () => _tracking?.start());
$id('stopTrackingBtn').addEventListener('click',  () => _tracking?.stop());
$id('s_connectDevice')?.addEventListener('click', () => connectDevice($id('s_deviceWsUrl')?.value || 'ws://localhost:12345'));
$id('s_disconnectDevice')?.addEventListener('click', disconnectDevice);
$id('applyJsonBtn').addEventListener('click', () => { try { state.session = normalizeSession(JSON.parse($id('s_jsonPreview').value)); state.selectedBlockId = state.session.blocks[0]?.id||null; stopPlayback(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms(); } catch(err){alert(`Invalid JSON: ${err.message}`);}});
$id('formatJsonBtn').addEventListener('click', () => { try { $id('s_jsonPreview').value = JSON.stringify(JSON.parse($id('s_jsonPreview').value),null,2); } catch(err){alert(`Invalid JSON: ${err.message}`);}});

// ── FunScript timeline ───────────────────────────────────────────────────────
const fsCanvas = $id('fsCanvas');
if (fsCanvas) {
  initTimeline(fsCanvas);
  new ResizeObserver(() => { fsCanvas.width = fsCanvas.offsetWidth; drawTimeline(state.runtime?.sessionTime ?? null); }).observe(fsCanvas.parentElement);
}
$id('fsEditToggle')?.addEventListener('click', () => {
  state.fsEditMode = !state.fsEditMode;
  const btn = $id('fsEditToggle'); btn.classList.toggle('active', state.fsEditMode); btn.textContent = state.fsEditMode ? '✎ Editing' : '✎ Edit';
  drawTimeline(state.runtime?.sessionTime ?? null);
});
$id('fsCollapseBtn')?.addEventListener('click', () => {
  const c = $id('fsCanvas'), collapsed = c.style.display === 'none';
  c.style.display = collapsed ? '' : 'none'; $id('fsCollapseBtn').textContent = collapsed ? '↑' : '↓';
});

// ── Keyboard shortcuts (per README) ─────────────────────────────────────────
let _lastEscTime   = 0;
let _shiftAlone    = false; // true if Shift pressed without another key

document.addEventListener('keydown', e => {
  const inField = e.target.matches('input,textarea,select');
  if (inField && e.key !== 'Escape' && !e.ctrlKey) return;

  // If any non-modifier key pressed while Shift held → not standalone
  if (e.shiftKey && e.key !== 'Shift') _shiftAlone = false;

  switch (e.key) {
    case 'Shift':
      _shiftAlone = true; // may be cleared by subsequent key
      break;

    case ' ':
      e.preventDefault();
      if (!state.runtime)            startPlayback();
      else if (state.runtime.paused) resumePlayback();
      else                           pausePlayback();
      break;

    // Arrow keys: L/R = ±10s, U/D = ±30s  (per README)
    case 'ArrowLeft':  e.preventDefault(); skipBy(-10); break;
    case 'ArrowRight': e.preventDefault(); skipBy(10);  break;
    case 'ArrowUp':    e.preventDefault(); skipBy(30);  break;
    case 'ArrowDown':  e.preventDefault(); skipBy(-30); break;

    // Graceful stop + exit fullscreen
    case 'Enter':
    case 'F12':
      e.preventDefault();
      stopPlayback();
      document.exitFullscreen?.().catch(() => {});
      break;

    // ESC: single = graceful stop, double within 1.2s = emergency stop
    case 'Escape': {
      const now = Date.now();
      if (now - _lastEscTime < 1200) {
        e.preventDefault(); emergencyStop(); _lastEscTime = 0;
      } else {
        _lastEscTime = now;
        stopPlayback();
        document.exitFullscreen?.().catch(() => {});
      }
      break;
    }

    // Macro injection slots 1–5 (per README)
    case '1': case '2': case '3': case '4': case '5': {
      if (inField) break;
      _shiftAlone = false;
      const macro = getSlotMacro(Number(e.key));
      if (macro) { e.preventDefault(); injectMacro(macro.id); }
      break;
    }

    // Editor shortcuts
    case 'd': case 'D':
      if (!inField && state.selectedBlockId) duplicateBlock(); break;
    case 'f': case 'F':
      if (!inField) {
        if (!document.fullscreenElement) $id('mainStage').requestFullscreen?.();
        else document.exitFullscreen?.();
      }
      break;
    case 'e': case 'E':
      if (!inField) {
        state.fsEditMode = !state.fsEditMode;
        const btn = $id('fsEditToggle');
        btn?.classList.toggle('active', state.fsEditMode);
        if (btn) btn.textContent = state.fsEditMode ? '✎ Editing' : '✎ Edit';
        drawTimeline(state.runtime?.sessionTime ?? null);
      }
      break;
    case 'Delete': case 'Backspace':
      if (!inField && state.selectedBlockId) { e.preventDefault(); deleteBlock(); }
      break;
    case 's':
      if (e.ctrlKey) { e.preventDefault(); $id('exportPackageBtn').click(); }
      break;
  }
});

// Shift keyup: if no other key was pressed during hold → toggle FS pause
document.addEventListener('keyup', e => {
  if (e.key === 'Shift' && _shiftAlone) {
    _shiftAlone = false;
    if (state.runtime) toggleFsPause();
  }
});

// ── Macro library ─────────────────────────────────────────────────────────────
initMacroLibraryEvents();

// ── Fullscreen HUD ────────────────────────────────────────────────────────────
initFullscreenHud();

// ── Slider live value labels ──────────────────────────────────────────────────
const sliderLabels = [
  ['s_speechRate',         's_speechRateVal', v => v],
  ['s_playlistAudioVolume','s_pavVal',        v => v],
  ['s_playlistVideoVolume','s_pvvVal',        v => v],
  ['s_fsSpeed',            's_fsSpeedVal',    v => `${v}×`],
];
sliderLabels.forEach(([sliderId, labelId, fmt]) => {
  const slider = $id(sliderId), label = $id(labelId);
  if (!slider || !label) return;
  slider.addEventListener('input', () => { label.textContent = fmt(parseFloat(slider.value).toFixed(2).replace(/\.?0+$/, '')); });
});

// ── Init ──────────────────────────────────────────────────────────────────────
applyCssVars();
renderSidebar();
renderInspector();
$id('tTotal').textContent = fmt(state.session.duration);
const _lb = $id('loopToggle');
const _ll = { none: '↺ Off', count: '↺ Loop', forever: '↺ ∞' };
_lb.textContent = _ll[state.session.loopMode] || '↺ Loop';
_lb.classList.toggle('active', state.session.loopMode !== 'none');
drawTimeline();

// Dismiss safety banner
$id('safetyDismiss')?.addEventListener('click', () => {
  const banner = $id('safetyBanner');
  if (banner) { banner.style.opacity = '0'; setTimeout(() => banner.remove(), 400); }
});
