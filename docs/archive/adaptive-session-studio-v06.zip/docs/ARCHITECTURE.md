# Architecture

This document describes the codebase structure of Adaptive Session Studio v4 for developers and contributors.

---

## High-Level Design

The application is a **single-page web application** built with vanilla ES modules — no framework, no build tool, no bundler. It runs directly from the filesystem (or a trivial static server) in Chrome or Edge.

The architecture follows a **unidirectional data flow**:

```
User action
    ↓
Event handler (main.js or ui.js)
    ↓
Mutates state.session or state (runtime flags)
    ↓
persist() — saves to localStorage
    ↓
Render functions — update DOM from state
    ↓
Browser paints
```

During playback, a second data flow runs in a requestAnimationFrame loop:

```
RAF tick (playback.js)
    ↓
Compute sessionTime from clock
    ↓
Evaluate blocks, FunScript position, subtitle cues
    ↓
Update DOM (overlayText, subtitleText, progress bar)
    ↓
Send device position via WebSocket
    ↓
Next RAF frame
```

---

## File Map

```
index.html              HTML shell — layout, all dialogs, <script type="module">
css/
  style.css             All styles (design tokens, components, fullscreen HUD, macro library)
js/
  state.js              Session model, mutable app state, normalizers, theme helpers, persist()
  playback.js           RAF engine, block dispatch, media layer control, transport UI
  funscript.js          FunScript parser/exporter, timeline canvas, device WebSocket output
  macros.js             Macro presets, library CRUD, injection engine, FS-only pause, safe-skip
  macro-ui.js           Macro library UI: list, slot assignments, editor, mini preview canvas
  subtitle.js           .ass/.ssa parser, cue display, .ass exporter
  tracking.js           Webcam FaceDetector loop, attention state, FS/macro triggers
  fullscreen-hud.js     Fullscreen overlay HUD rendering and auto-hide logic
  ui.js                 Sidebar rendering, inspector panel, settings dialog forms
  main.js               Event wiring, keyboard shortcuts, file inputs, init
docs/                   All documentation (this file and others)
README.md               Project overview and quick reference
```

---

## Module Dependency Graph

```
main.js
  ├── state.js
  ├── playback.js
  │     ├── state.js
  │     ├── subtitle.js
  │     ├── funscript.js
  │     ├── macros.js
  │     └── fullscreen-hud.js
  ├── subtitle.js
  │     └── state.js
  ├── funscript.js
  │     └── state.js
  ├── macros.js
  │     ├── state.js
  │     └── funscript.js  (interpolatePosition, sendDevicePosition)
  ├── macro-ui.js
  │     ├── state.js
  │     └── macros.js
  ├── ui.js
  │     ├── state.js
  │     ├── subtitle.js   (downloadAss)
  │     └── funscript.js  (downloadFunScript, refreshTimelineVisibility)
  ├── tracking.js
  │     ├── state.js
  │     ├── playback.js   (pausePlayback, resumePlayback)
  │     └── macros.js     (toggleFsPause, injectMacro, getSlotMacro)
  └── fullscreen-hud.js
        ├── state.js
        └── macros.js     (allMacros, getSlotMacro, BUILTIN_MACROS)
```

**No circular dependencies.** `state.js` is the leaf (imports nothing). `funscript.js` and `subtitle.js` import only from `state.js`.

---

## state.js — The Central Store

### `state.session`

The persistent session document. Serialised to localStorage and `.assp` exports. Shape defined by `defaultSession()`. Always normalised through `normalizeSession()` on load or import.

Key fields:
- `blocks` — array of block objects (type, start, duration, content, etc.)
- `playlists.audio` / `playlists.video` — background media track arrays
- `subtitleTracks` — parsed .ass tracks with `{ rawAss, styles, events }`
- `funscriptTracks` — parsed FunScript data with `{ actions, _color, _disabled }`
- `macroLibrary` — user-saved macro objects
- `macroSlots` — `{ 1: macroId | null, ... 5: macroId | null }`
- `funscriptSettings` — `{ speed, invert, range }`
- `trackingFsOptions` — `{ pauseFsOnLoss, injectMacroOnLoss, lossInjectSlot, ... }`

### `state` (runtime flags)

Not persisted. Reset on page load.

| Field | Type | Description |
|-------|------|-------------|
| `runtime` | object \| null | Active playback state (RAF handle, timers, media elements) |
| `injection` | object \| null | Active macro injection sequence |
| `fsPaused` | boolean | Whether FunScript output is paused via Shift |
| `selectedBlockId` | string \| null | Currently selected block |
| `selectedSidebarType` | string \| null | 'audio' \| 'video' \| 'block' \| 'subtitle' \| 'funscript' |
| `selectedSidebarIdx` | number \| null | Index within the selected type's array |
| `inspTab` | string | 'overlay' \| 'session' \| 'status' |
| `settingsTab` | string | Current settings dialog tab |
| `fsEditMode` | boolean | Whether FunScript timeline is in edit mode |
| `deviceSocket` | WebSocket \| null | Active Intiface connection |
| `_lastEscTime` | number | Timestamp of last ESC press for double-ESC detection |
| `_editingMacroId` | string \| null | Macro currently open in the editor |

---

## playback.js — The RAF Engine

### `runtime` object

Created by `startPlayback()`, destroyed by `stopPlayback()`. Holds:

```js
{
  startedAt,        // performance.now() when playback began
  pauseStartedAt,   // performance.now() when paused
  totalPausedMs,    // cumulative pause duration in ms
  paused,           // boolean
  pausedByAttention,// paused by webcam tracker (vs. user)
  sessionTime,      // current position in seconds within the loop
  loopIndex,        // which loop iteration (0-based)
  totalLoops,       // null = forever
  triggered,        // Set of 'loopIndex:blockId' keys (one-shot block control)
  raf,              // requestAnimationFrame handle
  backgroundAudio,  // array of HTMLAudioElement (playlist)
  backgroundVideo,  // array of HTMLVideoElement/HTMLImageElement (playlist)
  playingOneShots,  // array of HTMLAudioElement (one-shot audio blocks)
}
```

### Clock

Session time is computed from wall clock, not an accumulator:

```js
const elapsed = performance.now() - runtime.startedAt - runtime.totalPausedMs;
runtime.sessionTime = (elapsed / 1000) % session.duration;
runtime.loopIndex   = Math.floor(elapsed / 1000 / session.duration);
```

This makes seeks trivial: adjust `startedAt` and the clock self-corrects next tick.

### One-shot trigger control

Each block fires at most once per loop iteration. The `triggered` Set stores `'${loopIndex}:${blockId}'` strings. On a new loop, the loopIndex increments and all keys become stale.

---

## funscript.js — FunScript Engine

### Interpolation

`interpolatePosition(actions, timeMs, inverted, range)` performs linear interpolation using binary search:

1. Binary search for the surrounding action pair `[lo, hi]`.
2. Linearly interpolate `pos` between `lo.pos` and `hi.pos`.
3. Apply invert and range scaling.

The result is a 0–100 value sent to the device each tick.

### Timeline Canvas

The canvas draws:
- Block bands (semi-transparent fills)
- Time grid lines (every 10s)
- Subtitle cue bars (bottom 4px)
- FunScript curves (polyline through action points)
- Action points (filled circles, larger when hovered/selected)
- Playhead (vertical amber line)
- Track legend (bottom left)

Canvas coordinates:
- x: `(at_ms / total_ms) × canvas_width`
- y: `canvas_height − 8 − (pos / 100) × (canvas_height − 16)` (inverted: 0 = bottom)

Edit mode events use `hitTest()` (O(n) over all points) to find the nearest point within 8px radius.

### Device Output

`sendDevicePosition(pos01)` sends a Buttplug v3 `LinearCmd`:

```js
[{ LinearCmd: {
  Id: 1,
  DeviceIndex: _deviceIndex,
  Vectors: [{ Index: 0, Duration: 150, Position: pos01 }]
}}]
```

Duration 150ms means the device smoothly moves to the target position in 150ms. This is called every RAF tick (~16ms at 60fps), so the device receives ~60 commands/second with a 150ms movement window, producing continuous smooth motion.

---

## macros.js — Injection Engine

### Injection Sequence

`injectMacro(macroId)` builds a blended action sequence:

1. **Ease-in** (350ms): `fromPos → macro.actions[0].pos`, 8 interpolated steps using cubic ease-in/out.
2. **Macro body**: all macro actions, timestamps offset by 350ms, timestamps divided by `funscriptSettings.speed`.
3. **Ease-out** (350ms): `macro.actions[-1].pos → toPos`, 8 interpolated steps.

The blended sequence is stored in `state.injection.actions`. Each tick, `getInjectionPosition()` calls `interpolatePosition()` on this sequence using elapsed time since injection start. When `elapsed >= totalMs`, the injection is cleared.

### Safe-Skip

`safeEaseTo0(onDone)` runs a separate RAF loop that eases from `fsState.lastSentPos` to 0 over 300ms, then calls `onDone` (which performs the seek). This runs independently of the main playback RAF.

---

## ui.js — Rendering

UI rendering is **imperative and pull-based** — render functions read from `state` and set `innerHTML`. There is no virtual DOM or reactive system.

The main render functions:

| Function | Renders |
|----------|---------|
| `renderSidebar()` | All sidebar sections (calls 5 sub-functions) |
| `renderInspector()` | Inspector panel body (dispatches to 3 tab renderers) |
| `renderOverlayTab()` | Block inspector or FS/subtitle inspector |
| `renderStatusTab()` | Live playback stats cards |
| `renderSessionTab()` | Session-level properties |
| `renderMacroLibrary()` | Macro list, slot assignments, inline editor |
| `syncSettingsForms()` | Fills settings dialog form values from `state.session` |
| `syncSessionFromSettings()` | Reads settings dialog back into `state.session` |

### Event delegation

Rather than attaching listeners to dynamically rendered elements, `ui.js` uses event delegation in `attachOverlayTabEvents()` — a single listener on the inspector body handles all `[data-field]`, `[data-file-field]`, and `.pos-btn` elements inside it.

Similarly, `main.js` uses a single `document.addEventListener('click', ...)` handler for sidebar items, mute toggles, delete buttons, inspector tabs, settings tabs, and theme chips.

---

## CSS Architecture

`style.css` is a single flat stylesheet with named sections:

- **Design tokens** — CSS custom properties in `:root`
- **Reset** — minimal box-sizing and element defaults
- **App shell** — flex layout for topbar + workspace
- **Sidebar** — sections, items, badges, dot colors
- **Center** — stage, overlay text, subtitle text, HUD elements, FS timeline
- **Transport** — progress bar, buttons, loop pill
- **Inspector** — tabs, body, group labels, stat cards, position grid
- **Settings dialog** — modal shell, tab bar, section visibility, theme grid
- **Fullscreen HUD** — `:fullscreen` pseudo-class rules, slot pills, auto-hide
- **Macro Library** — list rows, slot assignments, editor table

Custom properties set on `:root` for session theming:
- `--stage-bg` — stage background colour
- `--stage-text` — overlay text colour
- `--stage-accent` — accent colour (progress bar, etc.)
- `--stage-blur` — background blur amount
- `--overlay-font` — CSS font stack for text overlays

---

## Data Flow: Import

```
User selects .assp file
    ↓
FileReader.readAsDataURL → file.text()
    ↓
JSON.parse()
    ↓
normalizeSession()  — merges with defaultSession(), validates types
    ↓
state.session = result
    ↓
persist() — saves to localStorage
    ↓
applyCssVars(), renderSidebar(), renderInspector(), syncSettingsForms()
```

---

## Data Flow: Playback Tick

```
requestAnimationFrame
    ↓
tickPlayback() (playback.js)
    ├── compute sessionTime, loopIndex
    ├── find activeBlock
    ├── handleActiveBlock()
    │     ├── show/hide overlayText
    │     └── trigger TTS / one-shot audio / one-shot video
    ├── updateSubtitleCue()  (subtitle.js)
    │     └── update #subtitleText
    ├── FunScript position
    │     ├── getInjectionPosition()  (macros.js) — if injection active
    │     ├── getCurrentPosition()   (funscript.js) — main tracks
    │     ├── updatePositionIndicator()
    │     └── sendDevicePosition()
    ├── drawTimeline()  (funscript.js)
    ├── updateTransportUI()
    ├── refreshLiveStatus()  — updates status tab DOM if visible
    └── tickHud()  (fullscreen-hud.js)
```

---

## Known Limitations

1. **No reactivity** — all rendering is manual and imperative. Adding a new session field requires updating `defaultSession`, `normalizeSession`, `syncSettingsForms`, `syncSessionFromSettings`, and often `renderInspector`. A reactive state system (even a simple signal/computed model) would reduce this coupling.

2. **Base64 media** — embedding media as data URLs produces large `.assp` files and keeps all media in memory simultaneously. A ZIP-based container format (like EPUB or ODP) with separate media files is the right long-term solution.

3. **Single audio context** — audio is created with `new Audio()` elements per track. For complex mixing, a Web Audio API graph would give better control (cross-fading, EQ, compressor).

4. **No undo/redo** — changes are applied immediately. An undo stack (storing session snapshots or command objects) would be valuable for the session editor.

5. **Canvas timeline is not virtualised** — all FunScript points are drawn every frame. With thousands of points this will be slow. Consider decimating the curve for display at the current zoom level.

6. **FunScript loop handling** — the FunScript position is computed as `sessionTime * 1000` with no loop-aware offset. If you want a FunScript longer than the session to continue across loops without resetting, this would require tracking `totalElapsedMs` separately.

7. **Intiface handshake** — only the `RequestServerInfo` / `DeviceAdded` messages are handled. A production implementation would handle `ServerInfo` version negotiation, `ScanningFinished`, error messages, and device capability enumeration.
