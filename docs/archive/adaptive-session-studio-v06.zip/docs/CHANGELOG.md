# Changelog

All notable changes are documented here. The format follows [Keep a Changelog](https://keepachangelog.com/).

---

## [v4.0.0] — 2026-04-11

Complete redesign and major feature addition over v3.

### Added

- **New UI architecture** — Multi-file ES module codebase replacing the single-file IIFE. Files: `state.js`, `playback.js`, `funscript.js`, `macros.js`, `macro-ui.js`, `subtitle.js`, `tracking.js`, `fullscreen-hud.js`, `ui.js`, `main.js`.
- **Macro Library** — 8 built-in FunScript presets (thrust in, pull out, pump, piston, prod, poke, stroke, rub). User-created macros with inline action-point editor and mini canvas preview. Sort by name, duration, or type. Import/export individual macros as `.funscript` files.
- **Macro injection engine** — Keys 1–5 inject a macro into any running FunScript with cubic ease-in/out blending. Injection HUD indicator on stage. Configurable slot assignments. Works standalone (no background FunScript required).
- **FunScript-only pause** — Shift key pauses/resumes device output independently of the session clock, audio, and text overlays. Indicator on stage.
- **Safe-skip easing** — Arrow key skips ease device output to zero over 300ms before jumping to the new position, preventing abrupt device movements.
- **Emergency stop** — ESC × 2 immediately sends `StopAllDevices` to Intiface, cancels all audio, and stops the session. Distinct from single-ESC graceful stop.
- **Webcam → FunScript integration** — Options to pause FunScript on attention loss, inject macros on attention loss and return, independently of session pause.
- **Fullscreen HUD** — Auto-hiding overlay in fullscreen mode showing session name, time/loop counter, macro slot assignments, keyboard hint, and ESC × 2 reminder. Hides after 2.5s of cursor inactivity.
- **FunScript timeline canvas** — Interactive canvas rendering FunScript curves, session block bands, subtitle cue markers, and live playhead. Supports add/drag/delete point editing in edit mode (E key).
- **FunScript position meter** — Vertical bar on stage showing current output position (0–100%) colour-coded by intensity.
- **Multi-track FunScript** — Multiple `.funscript` files can be loaded simultaneously; output is the maximum position across all active tracks.
- **Dedicated Settings dialog** — Six-tab modal (Appearance, Playback, FunScript, Macros, Subtitles, Webcam, Advanced) replacing scattered inline form fields.
- **Inspector panel** — Context-sensitive right panel with Overlay, Session, and Status tabs. Status tab shows live time, loop, and active block during playback.
- **Position grid** — Text overlay blocks can be placed at 9 positions (3×3 grid) in the inspector.
- **Dusk and Slate themes** — Two new built-in themes added (total: 6).
- **Live slider labels** — Range sliders in settings show their current value next to the control.
- **Safety banner** — Dismissible safety reminder bar at the top of the UI.
- **README.md and full documentation suite** — INSTALL, SAFETY, 8 how-to guides, FAQ, CHANGELOG, CONTRIBUTING, ARCHITECTURE, DEVELOPER, LEGAL.

### Changed

- **Keyboard shortcuts revised** — Arrow keys now skip ±10s (left/right) and ±30s (up/down) per README spec. Enter and F12 added as graceful stop keys. Shift changed from keydown toggle to standalone keyup detection to prevent conflict with Shift+number macros.
- **Loop toggle** — Cycles between Off / Loop / ∞ with updated button label.
- **`.ass` import** — Fixed double `file.text()` read bug (text was read twice, second read always returned empty string).
- **Position indicator** — `updatePositionIndicator` now shows/hides the meter container based on whether active FunScript tracks exist.
- **Session model** — Added `macroLibrary`, `macroSlots`, `trackingFsOptions`, `funscriptSettings.speed/invert/range` fields. Package version bumped to 4.

### Fixed

- `_lastSentPos` mutable export replaced with `fsState` object to avoid stale binding in ES module imports.
- `.ass` file timestamp parsing now handles both `.` and `,` as centisecond separators.
- Inspector session tab duration changes now update the transport bar `tTotal` display.
- Webcam tracking module now correctly handles the return-from-loss event with a single-fire flag (`returnInjected`) to prevent repeated macro injection.

---

## [v3.0.0] — (prior version, ChatGPT-generated)

### Features present in v3

- Single-file architecture (`index.html`, `styles.css`, `app.js`)
- Theme selector (midnight, ember, moss, violet) with custom theme builder
- Advanced Settings dialog
- Script timeline table with inline start/end/duration editing
- Subtitle-style timing tools (nudge ±0.5s, stretch, clone near cursor)
- Timeline overview minimap
- Webcam attention tracking with FaceDetector API
- Auto-pause/resume on attention loss
- Playlist audio and video tracks
- TTS block type with voice name field
- One-shot audio/video blocks
- Pause blocks
- Import/export `.assp` packages
- JSON preview/apply panel
- localStorage persistence
- Loop modes: none, count, minutes, forever

### Not present in v3

- FunScript support (added in v4)
- Macro Library (added in v4)
- Dedicated Settings modal with tabs (was inline form)
- Inspector panel (was inline block editor)
- FunScript timeline canvas (added in v4)
- Subtitle (.ass) support (added in v4)
- Emergency stop (added in v4)
- Fullscreen HUD (added in v4)
- Position meter (added in v4)

---

## Version Numbering

Versions follow `MAJOR.MINOR.PATCH`:
- **MAJOR** — breaking changes to the `.assp` package format or fundamental UI paradigm
- **MINOR** — significant new features, backward-compatible
- **PATCH** — bug fixes and small improvements
