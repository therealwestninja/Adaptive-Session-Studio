// ── user-profile.js ────────────────────────────────────────────────────────
// User Profiling System — ROADMAP Phase 3.12 (Local Only)
//
// Builds and maintains a persistent local profile derived from session analytics.
// Stores: session history, preferred intensity, attention stability, engagement
// trend, total runtime, and streak tracking.
//
// Storage: IndexedDB key 'ass-profile-v1' (migrated from localStorage on first load)
// All data is local-only. No network calls. Export/import optional.

import { state, fmt, esc } from './state.js';
import { getStoredAnalytics, clearStoredAnalytics } from './session-analytics.js';
import { notify } from './notify.js';
import { idbGet, idbSet, idbDel } from './idb-storage.js';

const PROFILE_KEY = 'ass-profile-v1';

// ── Profile shape ─────────────────────────────────────────────────────────────
export function defaultProfile() {
  return {
    version:          1,
    // Identity (Phase 4 — user can set these in the profile panel)
    displayName:      '',           // user's chosen name (optional)
    avatarEmoji:      '🧘',         // single emoji avatar
    goals:            '',           // free-text session goals / preferences
    primaryUse:       'self',       // 'self' | 'self-for-partner' | 'partner-trains-me' | 'i-train-partner' | 'other'
    role:             'primary',    // 'primary' | 'operator'
    sessionCount:     0,
    totalRuntimeSec:  0,
    lastSessionAt:    null,
    streak:           0,         // consecutive days with at least one session
    lastStreakDate:   null,       // date string YYYY-MM-DD
    // Derived from analytics history (rolling average over last 10 sessions)
    avgAttentionStability: null, // 0–1: 1 = never lost attention
    avgEngagementPct:      null, // 0–100: average engagement score
    preferredIntensityAvg: null, // average FS output percentage
    preferredIntensityMax: null, // average peak FS output
    // Responsiveness: how quickly user re-engages after attention loss
    avgReengagementSec: null,
    // Trend flags
    intensityTrend: 'stable',    // 'rising' | 'falling' | 'stable'
    attentionTrend: 'stable',
  };
}

// ── Load / save ───────────────────────────────────────────────────────────────
// In-memory cache so synchronous callers get consistent data
let _profileCache = null;

// Eagerly hydrate cache from IDB (with localStorage migration on first run)
(async () => {
  let p = await idbGet(PROFILE_KEY);
  if (!p) {
    // Migrate from localStorage if present
    try {
      const lsRaw = localStorage.getItem(PROFILE_KEY);
      if (lsRaw) {
        p = { ...defaultProfile(), ...JSON.parse(lsRaw) };
        await idbSet(PROFILE_KEY, p);
        localStorage.removeItem(PROFILE_KEY);
      }
    } catch {}
  }
  _profileCache = p ? { ...defaultProfile(), ...p } : defaultProfile();
})();

export function loadProfile() {
  return _profileCache ?? defaultProfile();
}

export function saveProfile(profile) {
  _profileCache = profile;
  idbSet(PROFILE_KEY, profile).catch(() => {}); // fire-and-forget
}

export function clearProfile() {
  _profileCache = defaultProfile();
  idbDel(PROFILE_KEY).catch(() => {});
}

// ── Rebuild profile from analytics history ────────────────────────────────────
export function rebuildProfile() {
  const history = getStoredAnalytics();
  if (!history.length) return defaultProfile();

  // Start from defaults but preserve any user-set identity fields
  const existing = loadProfile();
  const profile = defaultProfile();
  // Carry over identity fields the user has personalised
  profile.displayName  = existing?.displayName  || '';
  profile.avatarEmoji  = existing?.avatarEmoji  || '🧘';
  profile.goals        = existing?.goals        || '';

  profile.sessionCount    = history.length;
  profile.totalRuntimeSec = history.reduce((s, h) => s + (h.totalSec ?? 0), 0);
  profile.lastSessionAt   = history[0]?.timestamp ?? null;

  // Use up to the last 10 sessions for rolling averages
  const recent = history.slice(0, 10);

  // Attention stability: 1 - (lossEvents / sessionDuration)
  const stabilityScores = recent
    .filter(h => h.totalSec > 0)
    .map(h => Math.max(0, 1 - (h.attentionLossEvents ?? 0) / (h.totalSec / 60)));
  if (stabilityScores.length) {
    profile.avgAttentionStability = +(stabilityScores.reduce((a, b) => a + b, 0) / stabilityScores.length).toFixed(2);
  }

  // FS intensity preference
  const fsAvgSamples = recent.filter(h => h.fsAvg !== null).map(h => h.fsAvg);
  const fsMaxSamples = recent.filter(h => h.fsMax !== null).map(h => h.fsMax);
  if (fsAvgSamples.length) {
    profile.preferredIntensityAvg = Math.round(fsAvgSamples.reduce((a, b) => a + b, 0) / fsAvgSamples.length);
    profile.preferredIntensityMax = Math.round(fsMaxSamples.reduce((a, b) => a + b, 0) / fsMaxSamples.length);
  }

  // Re-engagement speed: total loss time / loss events
  const reengageSamples = recent
    .filter(h => (h.attentionLossEvents ?? 0) > 0)
    .map(h => (h.attentionLossTotalSec ?? 0) / h.attentionLossEvents);
  if (reengageSamples.length) {
    profile.avgReengagementSec = +(reengageSamples.reduce((a, b) => a + b, 0) / reengageSamples.length).toFixed(1);
  }

  // Streak: count consecutive calendar days with sessions
  profile.streak       = _computeStreak(history);
  profile.lastStreakDate = _todayStr();

  // Trends: compare first vs second half of recent sessions
  if (recent.length >= 4) {
    const half = Math.floor(recent.length / 2);
    const older = recent.slice(half);
    const newer = recent.slice(0, half);

    const avgFs = arr => arr.filter(h => h.fsAvg !== null).reduce((s, h) => s + h.fsAvg, 0) / (arr.filter(h => h.fsAvg !== null).length || 1);
    const avgStab = arr => arr.filter(h => h.totalSec > 0).reduce((s, h) => s + Math.max(0, 1 - (h.attentionLossEvents ?? 0) / (h.totalSec / 60)), 0) / arr.length;

    const fsDelta   = avgFs(newer)   - avgFs(older);
    const stabDelta = avgStab(newer) - avgStab(older);

    profile.intensityTrend = fsDelta >  5 ? 'rising' : fsDelta < -5 ? 'falling' : 'stable';
    profile.attentionTrend = stabDelta > 0.05 ? 'rising' : stabDelta < -0.05 ? 'falling' : 'stable';
  }

  saveProfile(profile);
  return profile;
}

function _todayStr() {
  const d = new Date();
  // Use local year/month/day, zero-padded, to avoid UTC-day vs local-day mismatch
  // around midnight (e.g. 11 PM local = next UTC day).
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function _timestampToLocalDateStr(ts) {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function _computeStreak(history) {
  if (!history.length) return 0;
  const days = [...new Set(history.map(h => _timestampToLocalDateStr(h.timestamp)))].sort().reverse();
  let streak  = 0;
  let expected = _todayStr();
  for (const day of days) {
    if (day === expected) {
      streak++;
      const d = new Date(expected);
      d.setDate(d.getDate() - 1);
      expected = _timestampToLocalDateStr(d.getTime());
    } else {
      break;
    }
  }
  return streak;
}

// ── Habit Training (ROADMAP Phase 3.13) ──────────────────────────────────────
// Returns a difficulty level (1–5) derived from session history, and streak.
// Used to suggest gradual escalation in session settings.

export function computeDifficultyLevel(profile) {
  if (!profile || profile.sessionCount < 2) return 1;

  let level = 1;

  // Streak bonus: consistent practice → higher baseline
  if (profile.streak >= 7)  level += 1;
  if (profile.streak >= 30) level += 1;

  // Attention stability → readiness for longer/harder sessions
  if ((profile.avgAttentionStability ?? 0) >= 0.8) level += 0.5;
  if ((profile.avgAttentionStability ?? 0) >= 0.95) level += 0.5;

  // Rising intensity trend → user is ready for more
  if (profile.intensityTrend === 'rising') level += 0.5;

  return Math.min(5, Math.round(level));
}

// ── Adaptive Difficulty Curves (ROADMAP Phase 3.11) ──────────────────────────
// Returns suggested ramp settings based on profile data. Callers can apply
// these directly or present them to the user as a recommendation.

export function getAdaptiveRampSuggestion() {
  // Use saved profile if available (faster); rebuild from analytics otherwise.
  // rebuildProfile() is authoritative — call it and save so loadProfile() stays current.
  const profile = rebuildProfile();
  saveProfile(profile);
  const level   = computeDifficultyLevel(profile);

  // Scale intensity from profile's preferred range with level bonus
  const baseAvg = (profile.preferredIntensityAvg ?? 50) / 100;
  const basePeak= (profile.preferredIntensityMax ?? 80) / 100;

  // Progressive overload: each level adds ~10% headroom
  const levelBonus = (level - 1) * 0.1;

  return {
    enabled:   true,
    mode:      profile.avgAttentionStability !== null ? 'adaptive' : 'time',
    startVal:  Math.max(0.2, Math.min(1.0, baseAvg - 0.1)),
    endVal:    Math.min(2.0, basePeak + levelBonus),
    curve:     level >= 4 ? 'exponential' : 'sine',
    steps:     [],
    blendMode: 'max',
    _note:     `Based on ${profile.sessionCount} session${profile.sessionCount !== 1 ? 's' : ''}, level ${level}/5`,
  };
}

// ── Habit Streak Milestones ─────────────────────────────────────────────────
export function getStreakMilestone(streak) {
  if (streak <= 0) return null;
  const milestones = [
    { days: 3,   message: '3-day streak 🔥 Building momentum' },
    { days: 7,   message: '1-week streak 🏆 A full week!' },
    { days: 14,  message: '2-week streak ⚡ Strong habit forming' },
    { days: 30,  message: '30-day streak 🌟 Incredible consistency' },
    { days: 100, message: '100-day streak 🎯 Elite practitioner' },
  ];
  return milestones.filter(m => streak === m.days).at(-1) ?? null;
}

// Returns a milestone message for a session count, or null.
export function getSessionCountMilestone(count) {
  const milestones = [
    { count: 1,   message: 'First session complete 🎉 Welcome!' },
    { count: 5,   message: '5 sessions 🌱 Getting into the groove' },
    { count: 10,  message: '10 sessions 💪 A real habit!' },
    { count: 25,  message: '25 sessions 🔑 You\'re experienced now' },
    { count: 50,  message: '50 sessions 🏅 Dedicated practitioner' },
    { count: 100, message: '100 sessions 🌟 Century achieved!' },
  ];
  return milestones.filter(m => count === m.count).at(-1) ?? null;
}

// Returns a milestone message for total runtime in seconds, or null.
export function getRuntimeMilestone(totalSec) {
  const milestones = [
    { sec: 3600,    message: 'First hour of sessions ⏱ Getting started' },
    { sec: 36_000,  message: '10 hours of sessions 🕐 Committed!' },
    { sec: 180_000, message: '50 hours of sessions 🏆 Deep practice' },
    { sec: 360_000, message: '100 hours of sessions 🌟 Century of time' },
  ];
  return milestones.filter(m => totalSec >= m.sec && totalSec < m.sec + 3600).at(-1) ?? null;
}
export function renderProfilePanel(containerId = 'profilePanel') {
  const el = document.getElementById(containerId);
  if (!el) return;

  const p = rebuildProfile();
  saveProfile(p);  // keep persisted profile in sync with latest analytics
  const history = getStoredAnalytics();
  const streakMilestone   = getStreakMilestone(p.streak);
  const countMilestone    = getSessionCountMilestone(p.sessionCount);
  const runtimeMilestone  = getRuntimeMilestone(p.totalRuntimeSec);
  // Show the most recently earned milestone (prefer streak > count > runtime)
  const milestone = streakMilestone ?? countMilestone ?? runtimeMilestone;

  const trendIcon = t => t === 'rising' ? '↑' : t === 'falling' ? '↓' : '→';
  const trendColor = t => t === 'rising' ? '#7dc87a' : t === 'falling' ? '#e05050' : 'var(--text3)';

  const recPill = (label, value, unit = '') => value === null ? '' : `
    <div style="background:rgba(255,255,255,0.04);border:0.5px solid rgba(255,255,255,0.08);
      border-radius:8px;padding:8px;text-align:center;min-width:72px">
      <div style="font-size:14px;font-weight:700;color:#f0f0e8">${value}${unit}</div>
      <div style="font-size:9.5px;color:rgba(255,255,255,0.3);text-transform:uppercase;letter-spacing:.06em">${label}</div>
    </div>`;

  el.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
      <button id="pp_emojiBtn" style="font-size:26px;background:rgba(255,255,255,0.06);border:0.5px solid rgba(255,255,255,0.1);
        border-radius:8px;width:44px;height:44px;cursor:pointer;flex-shrink:0" title="Change emoji avatar">
        ${p.avatarEmoji || '🧘'}
      </button>
      <div style="flex:1;min-width:0">
        <input id="pp_displayName" type="text" maxlength="40" placeholder="Your name (optional)"
          value="${esc(p.displayName || '')}"
          style="width:100%;font-size:13px;font-weight:600;font-family:Syne,sans-serif;
            background:transparent;border:none;border-bottom:1px solid rgba(255,255,255,0.08);
            color:#f0f0e8;padding:2px 0;outline:none;caret-color:var(--accent)" />
        <div style="font-size:10px;color:rgba(255,255,255,0.25);margin-top:2px">My Profile</div>
      </div>
    </div>

    <div style="margin-bottom:10px">
      <div style="font-size:10px;color:rgba(255,255,255,0.3);letter-spacing:.07em;text-transform:uppercase;margin-bottom:4px">Primary use</div>
      <select id="pp_primaryUse" style="width:100%;font-size:11.5px;padding:5px 8px;
        background:rgba(255,255,255,0.05);border:0.5px solid rgba(255,255,255,0.1);
        border-radius:6px;color:var(--text)">
        <option value="self"${(p.primaryUse||'self')==='self'?' selected':''}>I am training myself for myself</option>
        <option value="self-for-partner"${p.primaryUse==='self-for-partner'?' selected':''}>I am training myself for my partner</option>
        <option value="partner-trains-me"${p.primaryUse==='partner-trains-me'?' selected':''}>My partner is training me</option>
        <option value="i-train-partner"${p.primaryUse==='i-train-partner'?' selected':''}>I am training my partner</option>
        <option value="other"${p.primaryUse==='other'?' selected':''}>Private / Demo Mode / Other</option>
      </select>
    </div>

    <div style="margin-bottom:14px">
      <div style="font-size:10px;color:rgba(255,255,255,0.3);letter-spacing:.07em;text-transform:uppercase;margin-bottom:4px">Which makes me…</div>
      <select id="pp_role" style="width:100%;font-size:11.5px;padding:5px 8px;
        background:rgba(255,255,255,0.05);border:0.5px solid rgba(255,255,255,0.1);
        border-radius:6px;color:var(--text)">
        <option value="primary"${(p.role||'primary')==='primary'?' selected':''}>The Primary User (subject of the session)</option>
        <option value="operator"${p.role==='operator'?' selected':''}>The Operator (I control sessions for someone else)</option>
      </select>
    </div>

    ${milestone ? `
    <div style="background:rgba(240,160,74,0.12);border:0.5px solid rgba(240,160,74,0.3);
      border-radius:8px;padding:8px 12px;margin-bottom:10px;font-size:11px;color:#f0a04a">
      ${milestone.message}
    </div>` : ''}

    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px">
      ${recPill('Sessions', p.sessionCount)}
      ${recPill('Runtime', fmt(p.totalRuntimeSec))}
      ${recPill('Streak', p.streak, p.streak === 1 ? ' day' : ' days')}
    </div>

    ${p.avgAttentionStability !== null ? `
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px">
        <span style="color:var(--text2)">Attention stability</span>
        <span>${Math.round(p.avgAttentionStability * 100)}%
          <span style="color:${trendColor(p.attentionTrend)}">${trendIcon(p.attentionTrend)}</span>
        </span>
      </div>
      <div style="height:4px;background:rgba(255,255,255,0.08);border-radius:2px">
        <div style="height:4px;border-radius:2px;background:#7dc87a;width:${Math.round(p.avgAttentionStability*100)}%"></div>
      </div>
    </div>` : ''}

    ${p.preferredIntensityAvg !== null ? `
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px">
        <span style="color:var(--text2)">Preferred intensity (avg / peak)</span>
        <span>${p.preferredIntensityAvg}% / ${p.preferredIntensityMax}%
          <span style="color:${trendColor(p.intensityTrend)}">${trendIcon(p.intensityTrend)}</span>
        </span>
      </div>
      <div style="height:4px;background:rgba(255,255,255,0.08);border-radius:2px">
        <div style="height:4px;border-radius:2px;background:#f0a04a;width:${p.preferredIntensityAvg}%"></div>
      </div>
    </div>` : ''}

    ${p.avgReengagementSec !== null ? `
    <div style="font-size:11px;color:var(--text2);margin-bottom:8px">
      Avg re-engagement time: <strong>${p.avgReengagementSec}s</strong>
    </div>` : ''}

    <div style="margin-bottom:10px">
      <div style="font-size:10px;color:rgba(255,255,255,0.3);letter-spacing:.07em;
        text-transform:uppercase;margin-bottom:4px">Goals &amp; notes</div>
      <textarea id="pp_goals" rows="3" maxlength="500"
        placeholder="What are you working toward? (optional)"
        style="width:100%;font-size:11px;resize:vertical;color:var(--text2);
          background:rgba(255,255,255,0.04);border:0.5px solid rgba(255,255,255,0.08);
          border-radius:6px;padding:6px 8px;box-sizing:border-box"
      >${esc(p.goals || '')}</textarea>
    </div>

    ${history.length ? `
    <details style="margin-top:10px">
      <summary style="cursor:pointer;font-size:10px;font-weight:600;letter-spacing:.08em;
        text-transform:uppercase;color:rgba(255,255,255,0.25);list-style:none">
        Session history (${history.length})
      </summary>
      <div style="margin-top:8px;max-height:180px;overflow-y:auto">
        ${history.slice(0, 10).map(h => `
          <div style="display:flex;justify-content:space-between;padding:4px 0;
            border-bottom:0.5px solid rgba(255,255,255,0.05);font-size:11px">
            <span style="color:var(--text2)">${esc(h.sessionName)}</span>
            <span style="color:var(--text3);font-size:10px">${h.completionState === 'interrupted' ? '⏹ ' : h.completionState === 'emergency' ? '🛑 ' : '✓ '}${fmt(h.totalSec)} · ${new Date(h.timestamp).toLocaleDateString()}</span>
          </div>`).join('')}
      </div>
    </details>` : `<p style="font-size:11px;color:var(--text3)">Complete a session to build your profile.</p>`}

    <button id="clearProfileBtn" style="margin-top:12px;font-size:11px;color:var(--danger);
      background:transparent;border:0.5px solid rgba(224,80,80,0.3);border-radius:6px;
      padding:5px 10px;cursor:pointer;width:100%">
      Clear profile data
    </button>`;

  // ── Wire identity field events ──────────────────────────────────────────
  document.getElementById('pp_displayName')?.addEventListener('input', e => {
    p.displayName = e.target.value.slice(0, 40);
    saveProfile(p);
  });
  document.getElementById('pp_goals')?.addEventListener('input', e => {
    p.goals = e.target.value.slice(0, 500);
    saveProfile(p);
  });
  document.getElementById('pp_primaryUse')?.addEventListener('change', e => {
    p.primaryUse = e.target.value;
    saveProfile(p);
  });
  document.getElementById('pp_role')?.addEventListener('change', e => {
    p.role = e.target.value;
    saveProfile(p);
  });
  // Emoji picker: cycle through a small curated set on each click
  const AVATAR_EMOJIS = ['🧘','🎯','🏋','⚡','🌊','🔥','🎸','🌙','🦋','🐉','✨','💎'];
  document.getElementById('pp_emojiBtn')?.addEventListener('click', () => {
    const idx = (AVATAR_EMOJIS.indexOf(p.avatarEmoji) + 1) % AVATAR_EMOJIS.length;
    p.avatarEmoji = AVATAR_EMOJIS[idx];
    saveProfile(p);
    const btn = document.getElementById('pp_emojiBtn');
    if (btn) btn.textContent = p.avatarEmoji;
  });

  document.getElementById('clearProfileBtn')?.addEventListener('click', async () => {
    const ok = await notify.confirm('Clear all profile and session history data?', { confirmLabel: 'Clear', danger: true });
    if (ok) {
      clearProfile();
      await clearStoredAnalytics();
      renderProfilePanel(containerId);
      notify.success('Profile cleared.');
    }
  });
}
