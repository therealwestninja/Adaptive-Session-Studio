# Adaptive Session Studio

**Adaptive Session Studio** is a self-contained web application for creating, running, and sharing audio-visual sessions designed for behavioral conditioning and modification. It supports both passive and interactive experiences and can integrate with compatible external devices.

It runs entirely locally — no installation or internet connection required. Just unzip and open `index.html` in a modern desktop browser.

---

## ⚠️ Safety Notice

This tool is designed to be used alongside other activities and can potentially cause physical or mental harm if used improperly.

- **Never leave a partner or connected device unattended.**
- Always use your best judgment. Act responsibly. Play safely.
- If anything feels unsafe or unclear, **STOP IMMEDIATELY** — press **ESC twice** for emergency stop.

---

## Features

- **Runs locally** — no installation or internet required
- **Subtitle support** — compatible with `.ass` / `.ssa` files, with import/export and style overrides
- **Import / Export / Share** — easily distribute sessions (`.assp` format)
- **Loop controls** — flexible playback looping (count, minutes, forever)
- **FunScript integration** — import, edit, and play `.funscript` files with timeline editor
- **Macro Library** — manage all your FunScript macros in one place
  - 8 built-in presets: thrust in, pull out, pump, piston, prod, poke, stroke, rub
  - Create, edit, save, and export custom macros
  - Sort by name, duration, or type
  - Assign macros to key slots 1–5 for live injection
- **Macro injection** — press **1–5** during playback to dynamically inject a short macro, mathematically eased in and out of any running FunScript
- **Device integration** — works with Buttplug.io-compatible devices via [Intiface Central](https://intiface.com/central/)
- **Webcam attention tracking**
  - Auto-pause/resume session based on attention detection
  - Optional FunScript pause on attention loss
  - Optional macro injection on attention loss and return
- **Session designer + playback engine** — all-in-one interface
- **Customizable themes** — 6 built-in themes plus custom theme builder
- **Fullscreen playback mode** — clean stage view with HUD showing time, loop, and macro slot hints

---

## Getting Started

### Quick Start

1. Open `index.html` in a modern desktop browser (Chrome or Edge recommended for best device API support).
2. Click **Sample** to start from the built-in example session, or **New** for a blank slate.
3. Add your content via the sidebar:
   - **Audio Tracks** — background audio, looped during the session
   - **Video / Image** — background visuals
   - **Script Blocks** — timed text, TTS narration, one-shot audio/video, or silence
   - **Subtitles .ass** — import subtitle files for timed caption overlays
   - **FunScript** — import `.funscript` files for haptic playback and editing
4. *(Optional)* Open **Settings → FunScript** to connect a device via Intiface Central.
5. *(Optional)* Open **Settings → Macros** to configure key slot assignments.
6. Press **F** or the fullscreen button to enter playback mode.
7. Use **Ctrl+S** or the **Export .assp** button to save and share your session.

---

## Keyboard Shortcuts

### Editor
| Key | Action |
|-----|--------|
| `D` | Duplicate selected block |
| `E` | Toggle FunScript timeline edit mode |
| `F` | Toggle fullscreen |
| `Delete` | Delete selected block |
| `Ctrl+S` | Export session (.assp) |

### Playback (works in fullscreen)
| Key | Action |
|-----|--------|
| `Space` | Play / Pause session |
| `Shift` | Play / Pause FunScript only |
| `1` – `5` | Inject macro from slot 1–5 (dynamically eased in/out) |
| `←` / `→` | Skip session ±10 seconds |
| `↑` / `↓` | Skip session ±30 seconds |
| `Enter` / `F12` | Graceful stop and exit fullscreen |
| `ESC` | Stop playback and exit fullscreen |
| `ESC` × 2 | **Emergency stop** — immediately halts everything including device |

> **Note:** When skipping with arrow keys, the FunScript output safely eases to zero at half-speed before the jump to avoid abrupt device movements.

---

## File Formats

| Extension | Description |
|-----------|-------------|
| `.assp` | Adaptive Session Studio Package — JSON containing the full session (blocks, playlists, subtitles, FunScripts, macros, settings) |
| `.ass` / `.ssa` | Advanced SubStation Alpha subtitle files |
| `.funscript` | FunScript haptic action files (JSON with `at`/`pos` action arrays) |

---

## Device Integration

Adaptive Session Studio communicates with haptic devices through [Intiface Central](https://intiface.com/central/), a free server application.

1. Download and run Intiface Central.
2. Start the server (default: `ws://localhost:12345`).
3. Open **Settings → FunScript** in the studio and click **Connect**.
4. Your device will appear when detected.

Compatible with any Buttplug.io-supported device.

---

## Session Package Format (.assp)

Sessions are saved as JSON files. The top-level structure:

```json
{
  "packageVersion": 4,
  "name": "session_name",
  "duration": 180,
  "theme": "midnight",
  "blocks": [...],
  "playlists": { "audio": [...], "video": [...] },
  "subtitleTracks": [...],
  "funscriptTracks": [...],
  "macroLibrary": [...],
  "macroSlots": { "1": null, "2": null, "3": null, "4": null, "5": null },
  "funscriptSettings": { "speed": 1.0, "invert": false, "range": 100 }
}
```

Media files are embedded as base64 data URLs, keeping packages self-contained.

---

## Coming Soon

- Remote control web app (for playback control, emergency stop from another device)
- ZIP-based container format with separate media files (for large sessions)
- Multi-track subtitle lanes in timeline
- Rule engine for attention-triggered session branching
