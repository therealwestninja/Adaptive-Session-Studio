# Changelog

All notable changes are documented here. The format follows [Keep a Changelog](https://keepachangelog.com/).

---

## [v4.3.8] — 2026-04-12

### Added — Multi-lane timeline (ROADMAP Phase 2.1 partial)

- **Overview lane canvas** (`overviewCanvas`) — A 32px canvas above the FunScript curve lane showing the full session at a glance: block bands (colour-coded by type), scene bands with edge handles, subtitle cue ticks at the bottom, a time grid that adapts step to session duration (10s / 30s / 60s), and the shared playhead. Drawn every time `drawTimeline` is called.

- **Scene start/end drag editing on timeline** — Hovering near a scene edge on the overview canvas shows an `ew-resize` cursor. Clicking and dragging moves the `start` or `end` of that scene in real time (6px hit tolerance). The FunScript lane redraws live during drag. `history.push()` fires on mousedown (before the first mutation). `persist()` fires on mouseup. If the scene inspector is open it re-renders after the drag completes.

- **"Timeline" label** — The timeline panel heading updated from "FunScript Timeline" to "Timeline" to reflect the multi-lane nature.

### Technical

- `initOverviewCanvas(el)` — sets up the canvas, wires mousedown/move/up/leave events
- `drawOverviewLane(playheadSec)` — pure draw function; called from `drawTimeline` and the scene drag handler
- `overviewX(sec)` / `overviewSecFromX(x)` — coordinate helpers mirroring `timeToX`/`canvasToTime` but for the overview coordinate space
- `_overviewHitTest(x)` — returns `{ sceneId, edge }` when within 6px of a scene edge, else null
- `ResizeObserver` in `main.js` now also resizes `overviewCanvas.width` on container resize

---



### Fixed

- **`scenes.js` duplicate `state.js` import** — two separate `import … from './state.js'` lines merged into one.

- **Sidebar click auto-switching to overlay tab** — clicking any non-block sidebar item (audio/video track, subtitle, funscript, scenes) now explicitly sets `state.inspTab = 'overlay'` and updates `aria-selected` on inspector tabs. Previously only block items switched the tab; track and scenes items could open the inspector while the wrong tab was visually active.

- **HUD macro injection `isActive` indicator** — `isActive = state.injection && false` (always false, dead code) replaced with `state.injection?.macroName === macro.name`. The macro slot pill now correctly lights up during injection.

- **`scenes.js` circular dependency avoided** — `syncTransportControls` is called after scene mutations via a lazy `import('./ui.js')` (not a static import), avoiding the `ui.js → scenes.js → ui.js` cycle.

### Added

- **Active scene in fullscreen HUD** — `updateHud()` appends `· Scene Name` to the time line when `runtime.activeScene` is set.

- **Active scene in Status inspector tab** — `refreshLiveStatus()` updates a new `s_sceneVal` stat card each tick. `renderStatusTab()` renders the Scene card only when the session has scenes defined.

- **Scene time in analytics** — `tickAnalytics` accumulates time per active scene (by `sceneId`) alongside block time. `finaliseAnalytics` builds a `sceneBreakdown` array. Post-session modal shows a "Time per scene" section with colored scene dots above the block breakdown.

- **Two new suggestion checks for scenes**:
  - `scene_overflow` (warn): fires when any scene's `end` exceeds session duration.
  - `scene_overlap_N` (info): fires when consecutive scenes overlap (first overlap only to avoid noise).

---



### Added — Scene System (ROADMAP Phase 3.3)

- **`scenes.js`** *(new)* — Full scene system: `addScene()`, `deleteScene(sceneId)`, `updateScene(sceneId, patch)` with undo; `skipToNextScene()` finds the next scene boundary from current playback time, wrapping to the first; `renderSceneInspector()` / `attachSceneInspectorEvents()` wires the inspector panel; `renderSceneList(containerId)` renders editable name, loop select, and delete per scene.

- **`state.js`** — `normalizeScene(s)` normalizer: stable `id`, `name`, `start`, `end`, `loopBehavior` (`once`|`loop`), `color`. `defaultSession()` gains `scenes: []`. `normalizeSession()` maps the array through `normalizeScene`.

- **`playback.js`** — `state.runtime.activeScene` updated each tick to the scene containing `sessionTime`. `skipToScene(sceneId)` exported: eases FS to 0 then jumps to `scene.start`. Removed dead `persist` and `setMasterVolume` imports.

- **`funscript.js`** — Scene bands drawn in `drawTimeline`: dashed left-edge line, tinted fill, name label at top of each range. Uses `ctx.setLineDash` for visual distinction from block bands.

- **`index.html`** — `nextSceneBtn` added to transport center (hidden when no scenes defined). `scenesSummary` div added to sidebar below FunScript section.

- **`ui.js`** — `syncTransportControls()` shows/hides `nextSceneBtn` based on `session.scenes.length`. `renderSidebar()` calls `renderScenesSummary()`. `renderOverlayTab()` routes `selectedSidebarType === 'scenes'`. `attachOverlayTabEvents()` calls `attachSceneInspectorEvents()` when the scenes panel is open. `updateSidebarSelection()` handles `scenes` type. All `import` statements consolidated at top (removed mid-file `refreshVolumes` import — ES module syntax violation).

- **`main.js`** — Imports `scenes.js` and `skipToScene`. `N` keyboard shortcut → `skipToNextScene()`. Keyboard shortcuts overlay updated. `nextSceneBtn` wired.

- **`tests/scenes.test.js`** *(new)* — 22 tests: `normalizeScene` (13: id generation, field defaults, clamping, color, loopBehavior validation), and scene CRUD (9: addScene appends, positions after last scene, rejects beyond duration; deleteScene removes by id, no-op on bad id; updateScene patches name and loopBehavior, no-op on bad id).

### Fixed

- **Dead imports cleaned** — `persist` and `setMasterVolume` removed from `playback.js` (were imported but never called in the file body). `fileToDataUrl` and `notify` added to top-level `ui.js` imports (replacing runtime lazy `import()` calls in `saveCustomTheme`, `deleteCustomTheme`, and `handleBlockFileChange`). `macro-ui.js` gains static `notify` import.

- **Hot-path lazy import eliminated** — `session-analytics.js` no longer calls `import('./macros.js')` every 30 RAF frames; `fsState` is now imported statically.

- **Scrub-preview imports** — `updateSubtitleCue` and `getCurrentPosition`/`updatePositionIndicator` added to existing static imports in `main.js`; the Shift+click scrub-preview handler now calls them directly.

- **Undo coverage** — `_snapOnce` debounce helper prevents history spam on rapid `input` events while still capturing one snapshot per field per edit session. Applied to: session name, duration, loop count; audio/video track name and volume; FS speed and range. All `change` events (loop mode select, FS invert, video mute) get direct `history.push()`. Sort-blocks action now undoable.

- **`drawTimeline` lazy import** — `fs_delete` handler in `ui.js` now calls statically-imported `drawTimeline` directly.

---

## [v4.3.5] — 2026-04-12

### Fixed

- **Lazy import elimination pass** — 13 unnecessary `import()` calls replaced with static imports:
  - `ui.js` → `notify.js` (4× in `saveCustomTheme` / `deleteCustomTheme`)
  - `ui.js` → `state.js` `fileToDataUrl` (in `handleBlockFileChange`)
  - `macro-ui.js` → `notify.js` (import error handler)
  - `session-analytics.js` → `macros.js` `fsState` — **critical**: this ran every 30 RAF frames
  - `main.js` → `subtitle.js` `updateSubtitleCue` and `funscript.js` `getCurrentPosition` / `updatePositionIndicator` (both already statically imported)

- **Undo coverage for all inspector events** — `_snapOnce(el)` WeakMap-based debounce helper added to `ui.js`. All inspector `input` handlers now create at most one history snapshot per field per edit session (cleared on `blur`). All `change` event handlers use direct `history.push()`. Sort-blocks now creates a history entry.

- **`drawTimeline` static import** — `import('./funscript.js')` call removed from `fs_delete` handler in `ui.js`; uses statically-imported `drawTimeline`.

- **`docs/2 NEXT-STEPS.md`** — Rewritten to accurately reflect v4.3.4 completed state. Remaining work re-prioritised.

---



### Added

- **Session Analytics** (`session-analytics.js`) — ROADMAP Phase 5.3. Collects per-block time, FunScript position samples (avg + peak), and webcam attention loss events during every playback session. Stores the last 10 summaries in `localStorage` (key `ass-analytics-v1`). Shows a post-session modal 500ms after natural stop with runtime, loop count, block time breakdown, FS output bars, and attention loss stats. Emergency stop and programmatic resets (new session / import / apply JSON) suppress the modal via `{ emergency: true }` and `{ silent: true }` flags on `stopPlayback`.

- **Last session panel in Status tab** — `renderStatusTab` now renders a collapsible "Last session" `<details>` block below the suggestions list, showing the most recent analytics summary directly in the inspector without opening a separate modal.

- **Attention analytics wired** — `tracking.js` `_onLost` and `_onReturn` now call `notifyAttentionLost` / `notifyAttentionReturned` via lazy import, incrementing `attentionLossEvents` and accumulating total loss duration in the analytics object.

### Fixed

- **Frame time accuracy** — `tickPlayback` now computes actual elapsed frame time (`performance.now()` delta, capped at 200ms to suppress tab-switch spikes) instead of the hardcoded `1/60` approximation. Block time accumulation in analytics is now exact.

- **`refreshLiveStatus` lazy import removed** — `fsState` is now imported statically at module load in `playback.js`, eliminating a `import('./macros.js')` dynamic call on every animation frame.

- **`s_fsPos` stat card shows live value** — Status tab now initialises the FS position card with `fsState.lastSentPos` instead of hardcoded `0%`, so opening the tab mid-session shows the real current value.

- **Crossfade setting wired** — toggling a playlist audio track mute during playback now calls `crossfade(id, null, sec)` / `crossfade(null, id, sec)` using `session.advanced.crossfadeSeconds`. The crossfade setting is now actually connected to playback behavior (previously stored but ignored). `crossfade()` in `audio-engine.js` updated to accept `null` for either side (one-sided fade).

- **Unused `clampInt` import** removed from `main.js` and `playback.js`.

- **Two new suggestion checks**:
  - `no_blocks` (warn): fires when the session has no content blocks at all.
  - `sub_short_*` (info): fires when a subtitle track's last cue ends more than 10% before the session loops.

---



### Fixed — Critical

- **`main.js` was missing all cross-module imports** — the app threw `ReferenceError` on first interaction for every call to `notify`, `history`, `renderSidebar`, `renderInspector`, `syncSettingsForms`, `makeTrackingModule`, `injectMacro`, `getSlotMacro`, `toggleFsPause`, and 13 other symbols. All 22 missing imports are now present. The app was completely non-functional as shipped in v4.3.2.

### Architecture — module graph de-bridged

All `window._*` runtime bridges replaced with proper ES module imports:

- **`window._stateModule`** (used by `history.js` to get `normalizeSession`) — removed. `history.js` now imports `normalizeSession` directly from `state.js`. Corresponding `window._stateModule = { normalizeSession }` assignment removed from `state.js`.

- **`window._funscriptModule`** (used by `ui.js` to call `connectDevice`/`disconnectDevice`) — removed. `ui.js` now imports both directly from `funscript.js`.

- **`window._appDuplicateBlock` / `window._appDeleteBlock`** — removed. Block operations extracted to new **`block-ops.js`** module with a `registerBlockOpRenderers(rs, ri)` hook to avoid the circular dependency (`main.js` → `ui.js` → `block-ops.js` ← `history.js`, `notify.js`, `state.js`). Both `ui.js` and `main.js` now import `duplicateBlock`/`deleteBlock` directly.

- **`window._appSyncTransport`** (used by `ui.js` session inspector to sync transport bar) — removed. `syncTransportControls()` moved to `ui.js` as a proper export. `main.js` imports it from `ui.js`. Session inspector calls it directly.

### Changed

- `loopToggle` click handler simplified: state mutation + `syncTransportControls()` replaces three inline DOM mutation lines.
- `refreshLiveStatus()` in `playback.js` now updates the `s_fsPos` stat card (FS output %) in the Status inspector tab during playback. Previously rendered but never updated.
- FS-pause panel button no longer triggers full `renderLiveControl()` re-render (which reset slider drag state). Now calls `_updateFsPauseBtn()` for a targeted text/class update. `toggleFsPause()` in `macros.js` calls this via lazy import so both Shift-key and panel-button paths stay in sync.
- Sidebar item clicks now call `updateSidebarSelection()` (targeted `.selected` class flip) instead of full `renderSidebar()` (rebuilds all 5 lists' innerHTML).

### Added

- `tests/block-ops.test.js` — 13 tests for `duplicateBlock` and `deleteBlock`: new block creation, id uniqueness, label suffix, start placement, selection transfer, single-block deletion, no-op on null selection, renderer callback invocation, and sibling block preservation.

---



### Added

- **Browser-native test suite** (`tests/`) — no bundler, no build step. Open `tests/index.html` via a local HTTP server to run all tests in any modern browser.

  - **`tests/harness.js`** — minimal ES module test runner (`makeRunner`, `test`, `assertEqual`, `assertDeep`, `assert`, `assertThrows`, `summary`, `renderResults`).
  - **`tests/state.test.js`** — 35 tests covering `clampInt`, `fmt`, `uid`, all six normalizers (`normalizeBlock`, `normalizeAudioTrack`, `normalizeVideoTrack`, `normalizeFunscriptTrack`, `normalizeSubtitleTrack`, `normalizeMacro`), and `normalizeSession` — including the critical regression: empty `blocks: []` must **not** be replaced by the sample session.
  - **`tests/funscript.test.js`** — 20 tests for `parseFunScript` (valid JSON, sorting, filtering, error on invalid input), `interpolatePosition` (midpoints, clamping, inversion, range scaling, single-point tracks), and `exportFunScript` round-trip.
  - **`tests/subtitle.test.js`** — 15 tests for `parseAss`: event count, text content, start/end as numeric seconds, style extraction, override tag stripping, `\N` newline escape, missing `[Events]` section, empty input, backwards timestamps, and both `.` and `,` centisecond separators.
  - **`tests/history.test.js`** — 18 tests for the history state machine: initial state, `push` / `canUndo` / `canRedo`, `undo` restores state, `redo` re-applies, multi-step undo/redo sequence, `clear`, and 60-entry MAX_HISTORY cap.
  - **`tests/SMOKE.md`** — 11-section manual smoke checklist covering session lifecycle, all track types, loop mode consistency across three surfaces, settings, undo/redo, playback, FunScript editor, and storage persistence.

---



### Fixed

- **Playlist track normalization on add** — `addAudioInput` and `addVideoInput` now push through `normalizeAudioTrack()` / `normalizeVideoTrack()`. Tracks added during the current session immediately have stable `id` fields, so sidebar mute, delete, and selection work without requiring a reload or re-import.

- **Subtitle track normalization on add** — `addAssInput` now pushes through `normalizeSubtitleTrack()`. Newly imported subtitle tracks get stable IDs matching the pattern used by audio, video, and FunScript tracks.

- **`refreshVolumes()` muted-track bug** — previously the function only set gain for non-muted tracks; muted tracks were left at their last played gain (i.e. still audible). Now explicitly zeroes muted track gains. Live mute toggling during playback now silences the track immediately.

- **Mute toggle now updates the live audio engine** — the sidebar mute handler calls `setTrackMuted(id, muted)` when the Web Audio API engine is active, using an 80ms ramp for a click-free transition. Falls back to `refreshVolumes()` when using HTMLAudioElement playback.

- **`history.push()` added to playlist mute and delete** — toggling mute or deleting any playlist/track item is now undoable via Ctrl+Z.

- **Transport controls drift after session changes** — added `syncTransportControls()` which syncs the loop toggle button text/active state, master volume slider value, and tTotal display from `state.session`. Called after: new session, load sample, import, apply JSON, settings close, undo/redo, and on init. Eliminates the stale loop button and volume slider bugs.

- **Session inspector loop mode / duration changes now sync transport bar** — changing loop mode or duration in the inspector calls `syncTransportControls()` via `window._appSyncTransport`, so the top-bar loop toggle and tTotal are immediately consistent.

- **Dead-end inspector for audio/video playlist tracks** — clicking an audio or video playlist item in the sidebar previously showed "Select a block or track from the sidebar." Now routes to dedicated inspector panels:
  - **Audio track inspector**: name field, volume input, mute toggle (uses delegation so live audio engine is updated), remove button.
  - **Video/image track inspector**: name field, kind display, mute-audio select, volume input, remove button (live-updates running video elements).

- **Subtitle and FunScript sidebar fully ID-based** — `renderSubtitleList` and `renderFunScriptList` now emit `data-track-id` on mute and delete buttons (not `data-mute-idx`/`data-del-idx`). Both list items carry `data-sb-track-id` for selection. Mute/delete handlers are ID-first with index fallback for legacy data. Subtitle selection highlight uses `selectedSidebarId` (was index). FunScript selection highlight same.

- **Subtitle and FunScript inspectors use ID-based track lookup** — `renderFunScriptInspector` and `renderSubtitleInspector` look up by `state.selectedSidebarId` with index fallback, preventing stale references after array mutation.

- **Dead `deviceConnected` field removed** — `funscriptSettings.deviceConnected` was persisted but never read or written. Removed from `defaultSession()`. Existing sessions with the field normalize safely (field is dropped on load).

### Changed

- `setMasterVolume()` in `audio-engine.js` documented as a staged helper (future per-call fade use). `setTrackMuted()` documented as the live mute path and now called from the sidebar/inspector mute flow.
- Init block in `main.js` consolidated: loop toggle init now goes through `syncTransportControls()` instead of inline one-off code.

---

## [v4.3.0] — 2026-04-11

### Added

- **Live Control Panel** (`live-control.js`) — Runtime performance sliders visible below the FunScript timeline during playback. **Intensity** (0–200%) scales all FunScript position output. **Speed** (0.25–4×) scales the FunScript clock independently of the session clock. **Variation** (0–100%) adds ±N% random jitter per tick for organic feel. Live FS Pause button mirrors the Shift key. Reset button restores all to default. Live output meter shows current position value with intensity-coded colour. Modifiers are non-persisted — they reset on page load.

- **FunScript multi-select** — Shift+click on the canvas timeline toggles individual points into a multi-selection set (rendered as larger outlined dots). Dragging any selected point moves **all** selected points by the same delta, preserving their relative positions. Shift+click on empty space extends selection. Plain click on empty space clears selection and adds a new point. `A` key selects all points on the active track in edit mode.

- **FunScript transform bar** — Appears in edit mode above the Live Control Panel. Inputs for **time scale** (multiply timestamps), **position scale** (multiply position values), **time offset** (shift in ms), **position offset** (add to position). Apply button transforms the current selection or the entire active track if nothing is selected. Select All and Clear Selection buttons. Point count displayed.

- **Smart Suggestions** (`suggestions.js`) — Heuristic session analysis shown in the inspector Status tab. Checks: blocks extending past session duration (with action button); overlapping text blocks; no background media; FunScript tracks shorter than session duration; silence gaps >30s; excessive short loops; TTS voices not yet loaded. Sessions with no issues show "Session looks good". Refresh button re-runs analysis. Startup check (`checkAndNotify`) fires critical warnings as toasts 3s after load.

- **Sidebar scroll preservation** — `renderSidebar()` saves and restores `scrollTop` of the sidebar inner panel so block list edits do not jump the user back to the top.

- **Crossfade** re-enabled — The Crossfade (sec) setting in Settings → Playback is now active (no longer "coming soon"). The Web Audio API engine supports `linearRampToValueAtTime` transitions; the setting controls the duration.

- **`A` keyboard shortcut** — Select all FunScript points on the active track (edit mode only).

### Changed

- `getCurrentPosition()` in `funscript.js` accepts an optional `timeMsOverride` parameter. When provided (by `getLiveSpeedMs()` from `live-control.js`), the live speed multiplier is applied on top of the session's base FunScript speed setting.
- Status tab in inspector now renders both playback stat cards and a session health suggestions section.
- Duplicate `funscript.js` import in `main.js` merged into a single clean import line.

---

## [v4.2.0] — 2026-04-11

Web Audio API engine, tracking state machine, sidebar stable IDs, keyboard shortcuts overlay, Shift+click scrub preview, accessibility improvements. See previous entries.

---


### Added

- **Web Audio API engine** (`audio-engine.js`) — All playlist audio tracks now route through an `AudioContext` graph with per-track `GainNode`s and a master gain stage. Replaces ad-hoc `new Audio()` elements for playlist layers. Real `linearRampToValueAtTime` crossfade between tracks. `refreshVolumes()` updates the graph live from the master volume slider. Graceful fallback to `HTMLAudioElement` on browsers without Web Audio. AudioContext is resumed on first user gesture to satisfy browser autoplay policy.

- **Tracking state machine** (`tracking.js` rewritten) — Seven explicit states: `idle → requesting → warming_up → detecting → lost → unavailable → error`. Single-instance guard: creating a new module stops any previous one. 1.5-second warmup grace period before automation fires. `_onLost()` and `_onReturn()` handlers fire exactly once per attention event (not repeatedly). A "Warming up…" spinner is shown in the webcam panel during warmup. State labels update the camera/face status fields in settings.

- **Sidebar stable IDs** — `normalizeAudioTrack` and `normalizeVideoTrack` now assign stable `uid()` `id` fields. Sidebar rendering uses `data-track-id` attributes. Delete and mute event delegation filters by `track.id` rather than array index — safe when arrays are reordered between render and click.

- **Keyboard shortcuts overlay** (`?` or `/` key) — Inline modal showing all keyboard shortcuts in two columns (Playback / Editor). Dismisses on ESC, click-outside, or pressing `?` again. Built with no external dependencies, styled to match the app design system.

- **Shift+click timeline scrub preview** — Clicking the progress bar while stopped with Shift held previews the session at that position without starting playback: subtitle cue, block text overlay (dimmed), FunScript position meter, and timeline playhead all update. Useful for checking timing without committing to full playback.

- **`trackingWarmup` spinner** — The webcam settings panel shows a spinning "Warming up…" indicator during the 1.5s FaceDetector stabilisation window.

- **ARIA accessibility** — Added `role="main"` to workspace, `role="region"` with label to the stage, `role="group"` with label to transport controls, `role="tablist"` / `role="tab"` with `aria-selected` to inspector tabs, `aria-label` to sidebar and inspector panels. `aria-selected` updated dynamically on tab switch.

- **Visible focus rings** — `:focus-visible` styles added for all interactive elements. Keyboard navigation through the UI now has clear amber/blue focus indicators. Input focus rings unchanged (border-color change). Sidebar items, position buttons, and inspector tabs have contained focus rings.

- **Larger hit targets** — Sidebar mute and delete micro-buttons increased from 14×14px to 20×20px.

- **Crossfade labelled "coming soon"** — The Crossfade setting in Settings → Playback is now visibly disabled with an italic label, so users understand it is not yet implemented rather than assuming it is broken.

- **`?` shortcut in README and docs** — Keyboard shortcut reference updated in README, NEXT-STEPS, and ARCHITECTURE.

### Changed

- `startPlayback` now uses `startPlaylistLayers().then()` since audio engine decode is async. The play button activates and the RAF loop starts after audio layers are ready.
- `pauseMedia` / `resumeMedia` / `stopPlayback` branch on `runtime.usingAudioEngine` to call the audio engine or fallback `HTMLAudioElement` methods accordingly.
- Tracking module no longer calls `alert()` on permission denial — uses lazy `import('./notify.js')` to avoid circular dependency.
- `selectedSidebarId` added to `state` to hold the stable track ID of the selected audio/video sidebar item alongside the existing index.

### Fixed

- Duplicate `safetyDismiss` event handler at the bottom of `main.js` removed.
- Webcam start now guards against double-start via single-instance pattern (`_activeModule`).

---

## [v4.1.0] — 2026-04-11

All 12 PATCH.md bugs fixed. Undo/redo, toast notifications, capability detection, safe persistence, deep import validation. See previous entry for full details.

---

---

## [v4.2.0] — 2026-04-12

### Added

- **Web Audio API engine** (`audio-engine.js`) — Playlist audio tracks now route through an `AudioContext` graph: each track has an `AudioBufferSourceNode` looping through its own `GainNode`, wired to a master `GainNode`. `linearRampToValueAtTime` enables smooth volume changes and crossfade calls. Graceful fallback to `HTMLAudioElement` on browsers without Web Audio. Master volume slider calls `refreshVolumes()` for live gain updates without restarting streams. `crossfade(outId, inId, sec)` exported for future track-swap UI.

- **Tracking state machine** (`tracking.js` rewritten) — 7 explicit states: `idle → requesting → warming_up → detecting → lost → unavailable → error`. Single-instance guard: creating a new module stops any existing one. 1.5s warmup grace period before attention automation fires (prevents false losses on camera open). Status labels auto-update from state metadata table. `trackingWarmup` spinner shown during warmup. `_onLost()` / `_onReturn()` each fire exactly once per loss event via boolean flags reset on state transition.

- **Keyboard shortcuts overlay** — Press `?` or `/` during editing to show a full overlay listing all shortcuts, grouped by Playback and Editor. Click background or press ESC (captured in a focused handler) to dismiss. Rendered entirely in JS without any HTML template.

- **Timeline scrub-preview** — `Shift+Click` on the progress bar previews a position without starting playback: updates progress indicator, time display, HUD text, subtitle cue, overlay text (at 45% opacity), and FunScript position meter. Full playback `seekTo()` still fires on plain click during playback.

- **Sidebar stable IDs for audio/video tracks** — `normalizeAudioTrack` and `normalizeVideoTrack` now assign a `uid()` if no `id` is present. Sidebar delete/mute buttons carry `data-track-id` attributes. Event delegation in `main.js` filters by `track.id` instead of splicing by index — safe even if the array is mutated between render and click. `selectedSidebarId` added to mutable state.

- **ARIA and accessibility** — `role="main"` on workspace, `role="region"` + `aria-live="polite"` on the stage, `role="tablist"` + `role="tab"` + `aria-selected` on inspector tabs, `aria-label` on sidebar, inspector, and all transport buttons. Inspector tab clicks now update `aria-selected`. Focus rings via `:focus-visible` with amber outline (not suppressed like `:focus` was before). Sidebar mute/delete hit targets enlarged from 14×14px to 20×20px.

- **Crossfade "coming soon" label** — The crossfade seconds input in Settings → Playback is now visually disabled with an italic label to prevent confusion (the setting was exposed but had no effect).

- **`@keyframes spin`** for the webcam warmup indicator.

### Fixed

- Duplicate `safetyDismiss` event listener removed from the bottom of `main.js` (was registered twice).
- `startPlaylistLayers` is now `async` and `await`ed before RAF loop begins — prevents the play button responding before audio buffers are decoded.
- `stopPlayback` branches on `runtime.usingAudioEngine` to call `stopAudioEngine()` instead of iterating `backgroundAudio` elements (which would be empty when the engine is active).

---

## [v4.1.0] — 2026-04-11

All 12 PATCH.md bugs fixed. Undo/redo, toast notifications, capability detection, safe persistence, deep import validation.

---

## [v4.0.0] — 2026-04-11

Complete redesign over v3. See full entry below.

---

---

## [v4.1.0] — 2026-04-11

### Fixed (PATCH.md — all 12 issues)

- **#1** `normalizeSession()` no longer replaces an intentionally empty `blocks: []` with the sample session. Only a missing or non-array `blocks` field falls back to the sample.
- **#2** Webcam tracking module is now stopped before a new one is created on settings re-open. The `<dialog>` `close` event releases the camera regardless of how the dialog was dismissed. `start()` guards against double-start.
- **#3** FunScript timeline drag now holds an object reference to the dragged action instead of an array index. The array is sorted only on `mouseup`, so dragging across neighbouring timestamps no longer edits the wrong point.
- **#4** Point selection is now `{ trackId, actionRef }` rather than a bare index. Multi-track sessions can no longer show false shared selection across tracks.
- **#5** Device connection now sends `RequestDeviceList` and `StartScanning` after the `ServerInfo` handshake. Handles `DeviceList`, `DeviceAdded`, `DeviceRemoved`, `ScanningFinished`, and `Error` messages. Status display updated: `Connecting…` → `Scanning…` → `Device: <name>` or `No device found`.
- **#6** Duplicate `id="deviceStatus"` replaced with class `.device-status-display`. `updateDeviceStatus()` uses `querySelectorAll` to update all instances. Settings panel and FunScript inspector both update correctly.
- **#7** One-shot video blocks now explicitly pause and clear `src` on all previous background video elements before replacing `runtime.backgroundVideo`. Detached media can no longer keep decoding/playing audio.
- **#8** Emergency stop HUD message (`🛑 EMERGENCY STOP`) is now set *after* `stopPlayback()` rather than before, so it is not immediately overwritten by the `Idle` reset. Persists for 4 seconds.
- **#9** Transport loop toggle now cycles all four modes: Off → Loop → Min → ∞. `minutes` mode was previously unreachable from the transport bar.
- **#10** All import handlers (`addAssInput`, `addFunscriptInput`, macro library import) are wrapped in `try/catch`. `importMacroFile()` validates JSON structure and action arrays before saving. `importFunScriptFile()` re-throws on invalid files. All errors shown via `notify.error()`.
- **#11** Skip button tooltips and FunScript settings hint corrected from ±5s to ±10s.
- **#12** Session name can now be cleared to an empty string (`||` → `??` in `syncSessionFromSettings`).

### Added

- **Undo / Redo** — `history.js` module: snapshot-based history with 60-step stack. `Ctrl+Z` to undo, `Ctrl+Y` / `Ctrl+Shift+Z` to redo. Undo/Redo buttons in topbar (disabled when stack is empty). Block field edits, duplicates, deletes, and JSON apply are all undoable. History cleared on new session / import.
- **Toast notification system** — `notify.js`: non-blocking toasts replace all `alert()` calls. Types: `info` (3.5s), `success` (3s), `warn` (5s), `error` (sticky, click to dismiss). `notify.confirm()` provides a styled async confirmation dialog replacing destructive `alert()`/confirm patterns.
- **Browser capability detection** — `capabilities.js`: detects FaceDetector, Web Speech API, fullscreen, Web Audio, IndexedDB at startup. Dims and disables controls that require unavailable features (`requires-face-detector` class). Warns on startup if critical features are missing (once, with 1.2s delay).
- **Safe persistence** — `persist()` now wraps `localStorage.setItem` in `try/catch`. `QuotaExceededError` shows a sticky `notify.error()` and sets a visible "⚠ Unsaved" badge in the topbar. Tracks `persistState.dirty`, `persistState.error`, `persistState.lastSaved`.
- **Storage budget check** — On startup (2s delay), checks localStorage usage. Warns via toast if >80% of estimated 5MB quota is used.
- **Deep import validation** — `normalizeSession()` now calls dedicated normalizers for every nested structure: `normalizeAudioTrack`, `normalizeVideoTrack`, `normalizeFunscriptTrack`, `normalizeSubtitleTrack`, `normalizeMacro`. All numeric fields are clamped; invalid entries are filtered rather than silently accepted.
- **`notify.confirm()` dialogs** — New Session and Load Sample now ask for confirmation before destroying unsaved work.
- **Import success feedback** — All import operations (session, audio, video, .ass, .funscript, macro) show a `notify.success()` with filename and item count.
- **Export success feedback** — Exporting a session shows a `notify.success()` with the downloaded filename.

### Changed

- `window._stateModule` now exposes `normalizeSession` so `history.js` can restore snapshots without a circular import.
- All `alert()` calls removed from the codebase and replaced with `notify.*` equivalents.
- `emergencyStop` calls `stopPlayback()` first, then sets the HUD, fixing the overwrite bug.
- Settings dialog `close` event (not just the close button) stops webcam tracking.

---

## [v4.0.0] — 2026-04-11

Complete redesign and major feature addition over v3. See previous entries below.

---

---

## [v4.0.0] — 2026-04-11

Complete redesign and major feature addition over v3.

### Added

- **New UI architecture** — Multi-file ES module codebase replacing the single-file IIFE. Files: `state.js`, `playback.js`, `funscript.js`, `macros.js`, `macro-ui.js`, `subtitle.js`, `tracking.js`, `fullscreen-hud.js`, `ui.js`, `main.js`.
- **Macro Library** — 8 built-in FunScript presets (thrust in, pull out, pump, piston, prod, poke, stroke, rub). User-created macros with inline action-point editor and mini canvas preview. Sort by name, duration, or type. Import/export individual macros as `.funscript` files.
- **Macro injection engine** — Keys 1–5 inject a macro into any running FunScript with cubic ease-in/out blending. Injection HUD indicator on stage. Configurable slot assignments. Works standalone (no background FunScript required).
- **FunScript-only pause** — Shift key pauses/resumes device output independently of the session clock, audio, and text overlays. Indicator on stage.
- **Safe-skip easing** — Arrow key skips ease device output to zero over 300ms before jumping to the new position, preventing abrupt device movements.
- **Emergency stop** — ESC × 2 immediately sends `StopAllDevices` to Intiface, cancels all audio, and stops the session. Distinct from single-ESC graceful stop.
- **Webcam → FunScript integration** — Options to pause FunScript on attention loss, inject macros on attention loss and return, independently of session pause.
- **Fullscreen HUD** — Auto-hiding overlay in fullscreen mode showing session name, time/loop counter, macro slot assignments, keyboard hint, and ESC × 2 reminder. Hides after 2.5s of cursor inactivity.
- **FunScript timeline canvas** — Interactive canvas rendering FunScript curves, session block bands, subtitle cue markers, and live playhead. Supports add/drag/delete point editing in edit mode (E key).
- **FunScript position meter** — Vertical bar on stage showing current output position (0–100%) colour-coded by intensity.
- **Multi-track FunScript** — Multiple `.funscript` files can be loaded simultaneously; output is the maximum position across all active tracks.
- **Dedicated Settings dialog** — Six-tab modal (Appearance, Playback, FunScript, Macros, Subtitles, Webcam, Advanced) replacing scattered inline form fields.
- **Inspector panel** — Context-sensitive right panel with Overlay, Session, and Status tabs. Status tab shows live time, loop, and active block during playback.
- **Position grid** — Text overlay blocks can be placed at 9 positions (3×3 grid) in the inspector.
- **Dusk and Slate themes** — Two new built-in themes added (total: 6).
- **Live slider labels** — Range sliders in settings show their current value next to the control.
- **Safety banner** — Dismissible safety reminder bar at the top of the UI.
- **README.md and full documentation suite** — INSTALL, SAFETY, 8 how-to guides, FAQ, CHANGELOG, CONTRIBUTING, ARCHITECTURE, DEVELOPER, LEGAL.

### Changed

- **Keyboard shortcuts revised** — Arrow keys now skip ±10s (left/right) and ±30s (up/down) per README spec. Enter and F12 added as graceful stop keys. Shift changed from keydown toggle to standalone keyup detection to prevent conflict with Shift+number macros.
- **Loop toggle** — Cycles between Off / Loop / ∞ with updated button label.
- **`.ass` import** — Fixed double `file.text()` read bug (text was read twice, second read always returned empty string).
- **Position indicator** — `updatePositionIndicator` now shows/hides the meter container based on whether active FunScript tracks exist.
- **Session model** — Added `macroLibrary`, `macroSlots`, `trackingFsOptions`, `funscriptSettings.speed/invert/range` fields. Package version bumped to 4.

### Fixed

- `_lastSentPos` mutable export replaced with `fsState` object to avoid stale binding in ES module imports.
- `.ass` file timestamp parsing now handles both `.` and `,` as centisecond separators.
- Inspector session tab duration changes now update the transport bar `tTotal` display.
- Webcam tracking module now correctly handles the return-from-loss event with a single-fire flag (`returnInjected`) to prevent repeated macro injection.

---

## [v3.0.0] — (prior version, ChatGPT-generated)

### Features present in v3

- Single-file architecture (`index.html`, `styles.css`, `app.js`)
- Theme selector (midnight, ember, moss, violet) with custom theme builder
- Advanced Settings dialog
- Script timeline table with inline start/end/duration editing
- Subtitle-style timing tools (nudge ±0.5s, stretch, clone near cursor)
- Timeline overview minimap
- Webcam attention tracking with FaceDetector API
- Auto-pause/resume on attention loss
- Playlist audio and video tracks
- TTS block type with voice name field
- One-shot audio/video blocks
- Pause blocks
- Import/export `.assp` packages
- JSON preview/apply panel
- localStorage persistence
- Loop modes: none, count, minutes, forever

### Not present in v3

- FunScript support (added in v4)
- Macro Library (added in v4)
- Dedicated Settings modal with tabs (was inline form)
- Inspector panel (was inline block editor)
- FunScript timeline canvas (added in v4)
- Subtitle (.ass) support (added in v4)
- Emergency stop (added in v4)
- Fullscreen HUD (added in v4)
- Position meter (added in v4)

---

## Version Numbering

Versions follow `MAJOR.MINOR.PATCH`:
- **MAJOR** — breaking changes to the `.assp` package format or fundamental UI paradigm
- **MINOR** — significant new features, backward-compatible
- **PATCH** — bug fixes and small improvements
