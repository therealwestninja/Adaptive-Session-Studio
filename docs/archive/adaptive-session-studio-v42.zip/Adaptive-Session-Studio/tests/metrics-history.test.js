// ── tests/metrics-history.test.js ─────────────────────────────────────────
// Tests for js/metrics-history.js — daily aggregate store, import, and chart.
// Uses _setMetricsCacheForTest to inject fixture data without IDB round-trips.

import { makeRunner } from './harness.js';
import {
  recordSessionInHistory, getDailyHistory,
  importExternalMetrics, clearMetricsHistory,
  renderMetricsChart, _setMetricsCacheForTest,
  metricsReady,
} from '../js/metrics-history.js';

export function runMetricsHistoryTests() {
  const R  = makeRunner('metrics-history.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // Wait for metricsReady before any test that touches IDB
  async function reset() {
    await metricsReady;
    _setMetricsCacheForTest([]);
  }

  // Minimal session summary fixture
  function makeSummary(overrides = {}) {
    return {
      timestamp:          Date.now(),
      sessionName:        'Test Session',
      totalSec:           60,
      fsAvg:              50,
      fsMax:              80,
      attentionLossEvents: 0,
      completionState:    'completed',
      ...overrides,
    };
  }

  // ── metricsReady ────────────────────────────────────────────────────────
  t('metricsReady is a Promise that resolves', async () => {
    await metricsReady;
    ok(true, 'resolved without error');
  });

  // ── recordSessionInHistory ──────────────────────────────────────────────
  t('recordSessionInHistory creates a day entry', async () => {
    await reset();
    await recordSessionInHistory(makeSummary());
    const days = await getDailyHistory();
    eq(days.length, 1);
    eq(days[0].sessionCount, 1);
  });

  t('recordSessionInHistory accumulates multiple sessions on the same day', async () => {
    await reset();
    const ts = Date.now();
    await recordSessionInHistory(makeSummary({ timestamp: ts, totalSec: 60 }));
    await recordSessionInHistory(makeSummary({ timestamp: ts, totalSec: 90 }));
    const days = await getDailyHistory();
    eq(days.length, 1, 'same day = same record');
    eq(days[0].sessionCount,    2);
    eq(days[0].totalRuntimeSec, 150);
  });

  t('recordSessionInHistory averages intensity across sessions', async () => {
    await reset();
    const ts = Date.now();
    await recordSessionInHistory(makeSummary({ timestamp: ts, fsAvg: 40 }));
    await recordSessionInHistory(makeSummary({ timestamp: ts, fsAvg: 60 }));
    const days = await getDailyHistory();
    eq(days[0].avgIntensityPct, 50, 'average of 40 and 60 = 50');
  });

  t('recordSessionInHistory counts completionState correctly', async () => {
    await reset();
    const ts = Date.now();
    await recordSessionInHistory(makeSummary({ timestamp: ts, completionState: 'completed' }));
    await recordSessionInHistory(makeSummary({ timestamp: ts, completionState: 'interrupted' }));
    await recordSessionInHistory(makeSummary({ timestamp: ts, completionState: 'emergency' }));
    const [day] = await getDailyHistory();
    eq(day.completedCount,    1);
    eq(day.interruptedCount,  1);
    eq(day.emergencyCount,    1);
  });

  t('recordSessionInHistory computes attention stability', async () => {
    await reset();
    // 0 loss events → perfect stability = 1
    await recordSessionInHistory(makeSummary({ totalSec: 60, attentionLossEvents: 0 }));
    const [day] = await getDailyHistory();
    ok(day.avgAttentionStability !== null);
    ok(day.avgAttentionStability >= 0 && day.avgAttentionStability <= 1);
    eq(day.avgAttentionStability, 1.00);
  });

  t('recordSessionInHistory is a no-op for null summary', async () => {
    await reset();
    await recordSessionInHistory(null);
    const days = await getDailyHistory();
    eq(days.length, 0);
  });

  t('getDailyHistory returns newest-first', async () => {
    await reset();
    _setMetricsCacheForTest([
      { date: '2026-03-01', sessionCount: 1, totalRuntimeSec: 60, source: 'app' },
      { date: '2026-04-01', sessionCount: 1, totalRuntimeSec: 60, source: 'app' },
    ]);
    const days = await getDailyHistory();
    ok(days[0].date > days[1].date, 'first entry should be more recent');
  });

  t('getDailyHistory respects maxDays limit', async () => {
    await reset();
    _setMetricsCacheForTest(
      Array.from({ length: 30 }, (_, i) => ({
        date: `2026-01-${String(i+1).padStart(2,'0')}`,
        sessionCount: 1, totalRuntimeSec: 30, source: 'app',
      }))
    );
    const days = await getDailyHistory(7);
    eq(days.length, 7);
  });

  // ── importExternalMetrics ──────────────────────────────────────────────
  t('importExternalMetrics returns imported count', async () => {
    await reset();
    const result = await importExternalMetrics([
      { date: '2026-03-10', totalRuntimeSec: 1800, sessionCount: 2 },
      { date: '2026-03-11', totalRuntimeSec: 900,  sessionCount: 1 },
    ], 'TestDevice');
    eq(result.imported, 2);
    eq(result.skipped,  0);
  });

  t('importExternalMetrics merges into existing day', async () => {
    await reset();
    _setMetricsCacheForTest([
      { date: '2026-03-10', sessionCount: 1, totalRuntimeSec: 600, source: 'app',
        avgIntensityPct: null, avgEngagement: null, avgAttentionStability: null,
        completedCount: 1, interruptedCount: 0, emergencyCount: 0 },
    ]);
    await importExternalMetrics([
      { date: '2026-03-10', totalRuntimeSec: 400, avgIntensityPct: 70 },
    ], 'device');
    const [day] = await getDailyHistory();
    eq(day.totalRuntimeSec, 1000, '600 + 400');
    eq(day.avgIntensityPct,  70, 'updated from import');
  });

  t('importExternalMetrics rejects records missing date', async () => {
    await reset();
    const result = await importExternalMetrics([
      { totalRuntimeSec: 300 }, // no date
    ], 'bad-source');
    eq(result.imported, 0);
    eq(result.skipped,  1);
    ok(result.errors.length > 0);
  });

  t('importExternalMetrics rejects malformed date strings', async () => {
    await reset();
    const result = await importExternalMetrics([
      { date: '10-03-2026', totalRuntimeSec: 300 }, // wrong format
    ], 'bad-date');
    eq(result.skipped, 1);
  });

  t('importExternalMetrics clamps engagement to 0-1', async () => {
    await reset();
    await importExternalMetrics([
      { date: '2026-03-15', avgEngagement: 1.8 }, // over-range
    ], 'src');
    const [day] = await getDailyHistory();
    ok(day.avgEngagement <= 1, 'engagement clamped to 1');
  });

  t('importExternalMetrics with empty array returns zero counts', async () => {
    await reset();
    const result = await importExternalMetrics([], 'empty');
    eq(result.imported, 0);
    eq(result.skipped,  0);
  });

  t('importExternalMetrics marks source on new day', async () => {
    await reset();
    await importExternalMetrics([
      { date: '2026-03-20', totalRuntimeSec: 300 },
    ], 'MyDevice');
    const [day] = await getDailyHistory();
    ok(day.source.includes('import'), `source should contain 'import', got: ${day.source}`);
  });

  // ── clearMetricsHistory ────────────────────────────────────────────────
  t('clearMetricsHistory empties the cache', async () => {
    await reset();
    _setMetricsCacheForTest([
      { date: '2026-04-01', sessionCount: 3, totalRuntimeSec: 900, source: 'app' },
    ]);
    await clearMetricsHistory();
    const days = await getDailyHistory();
    eq(days.length, 0);
  });

  // ── renderMetricsChart ─────────────────────────────────────────────────
  t('renderMetricsChart returns a string', async () => {
    await reset();
    const html = await renderMetricsChart(30);
    ok(typeof html === 'string' && html.length > 0);
  });

  t('renderMetricsChart returns empty-state message when no data', async () => {
    await reset();
    const html = await renderMetricsChart(30);
    ok(html.includes('No metrics data'), `expected empty-state, got: ${html.slice(0, 100)}`);
  });

  t('renderMetricsChart returns SVG when data is present', async () => {
    await reset();
    _setMetricsCacheForTest([
      { date: '2026-04-13', sessionCount: 2, totalRuntimeSec: 1800,
        completedCount: 2, interruptedCount: 0, emergencyCount: 0,
        avgEngagement: 0.7, avgIntensityPct: 60, avgAttentionStability: 0.9, source: 'app' },
    ]);
    const html = await renderMetricsChart(30);
    ok(html.includes('<svg'), 'should contain an SVG element');
    ok(html.includes('<rect'), 'should contain bar rectangles');
  });

  t('renderMetricsChart colors emergency days red', async () => {
    await reset();
    _setMetricsCacheForTest([
      { date: '2026-04-13', sessionCount: 1, totalRuntimeSec: 120,
        completedCount: 0, interruptedCount: 0, emergencyCount: 1,
        avgEngagement: null, avgIntensityPct: null, avgAttentionStability: null, source: 'app' },
    ]);
    const html = await renderMetricsChart(30);
    ok(html.includes('#e05050'), 'emergency days should use red color');
  });

  t('renderMetricsChart colors all-completed days green', async () => {
    await reset();
    _setMetricsCacheForTest([
      { date: '2026-04-13', sessionCount: 1, totalRuntimeSec: 600,
        completedCount: 1, interruptedCount: 0, emergencyCount: 0,
        avgEngagement: null, avgIntensityPct: null, avgAttentionStability: null, source: 'app' },
    ]);
    const html = await renderMetricsChart(30);
    ok(html.includes('#7dc87a'), 'completed days should use green color');
  });

  t('renderMetricsChart includes engagement polyline when engagement data present', async () => {
    await reset();
    _setMetricsCacheForTest([
      { date: '2026-04-12', sessionCount: 1, totalRuntimeSec: 300, completedCount: 1,
        interruptedCount: 0, emergencyCount: 0, avgEngagement: 0.6, avgIntensityPct: 55, avgAttentionStability: 0.8, source: 'app' },
      { date: '2026-04-13', sessionCount: 1, totalRuntimeSec: 600, completedCount: 1,
        interruptedCount: 0, emergencyCount: 0, avgEngagement: 0.8, avgIntensityPct: 70, avgAttentionStability: 0.9, source: 'app' },
    ]);
    const html = await renderMetricsChart(30);
    ok(html.includes('<polyline'), 'should include engagement polyline');
    ok(html.includes('#7fb0ff'),   'polyline should be blue');
  });

  // ── _setMetricsCacheForTest ────────────────────────────────────────────
  t('_setMetricsCacheForTest injects data synchronously', async () => {
    _setMetricsCacheForTest([
      { date: '2026-01-01', sessionCount: 5, totalRuntimeSec: 3600, source: 'app' },
    ]);
    const days = await getDailyHistory();
    eq(days[0].sessionCount, 5);
    await reset();
  });

  return R.summary();
}
