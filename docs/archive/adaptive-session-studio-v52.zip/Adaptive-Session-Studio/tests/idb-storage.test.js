// ── tests/idb-storage.test.js ─────────────────────────────────────────────
// Tests for idb-storage.js — runs in browser test environment where IndexedDB
// is available. Validates the full async key/value lifecycle.

import { makeRunner } from './harness.js';
import { idbGet, idbSet, idbDel, idbHas } from '../js/idb-storage.js';

export function runIdbStorageTests() {
  const R  = makeRunner('idb-storage.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // Use a test-specific key prefix to avoid colliding with real app data
  const KEY = 'test:idb-storage-suite';
  const KEY2 = 'test:idb-storage-suite-2';

  // ── idbSet / idbGet round-trip ────────────────────────────────────────
  t('idbSet then idbGet returns the same primitive string', async () => {
    await idbSet(KEY, 'hello');
    const val = await idbGet(KEY);
    eq(val, 'hello');
    await idbDel(KEY);
  });

  t('idbSet then idbGet returns the same object', async () => {
    const obj = { a: 1, b: [2, 3], c: true, d: null };
    await idbSet(KEY, obj);
    const val = await idbGet(KEY);
    eq(JSON.stringify(val), JSON.stringify(obj));
    await idbDel(KEY);
  });

  t('idbSet then idbGet returns the same number', async () => {
    await idbSet(KEY, 42.5);
    const val = await idbGet(KEY);
    eq(val, 42.5);
    await idbDel(KEY);
  });

  t('idbSet then idbGet returns the same array', async () => {
    await idbSet(KEY, [1, 'two', { three: 3 }]);
    const val = await idbGet(KEY);
    eq(JSON.stringify(val), JSON.stringify([1, 'two', { three: 3 }]));
    await idbDel(KEY);
  });

  // ── idbGet on missing key ─────────────────────────────────────────────
  t('idbGet returns null for a key that does not exist', async () => {
    await idbDel(KEY); // ensure clean state
    const val = await idbGet(KEY);
    eq(val, null);
  });

  // ── idbDel ───────────────────────────────────────────────────────────
  t('idbDel removes the key so idbGet returns null', async () => {
    await idbSet(KEY, 'to-delete');
    await idbDel(KEY);
    const val = await idbGet(KEY);
    eq(val, null);
  });

  t('idbDel on a non-existent key does not throw', async () => {
    await idbDel('test:nonexistent-key-xyz'); // must not throw
    ok(true, 'no exception thrown');
  });

  // ── idbHas ───────────────────────────────────────────────────────────
  t('idbHas returns false for missing key', async () => {
    await idbDel(KEY);
    ok(!(await idbHas(KEY)));
  });

  t('idbHas returns true after idbSet', async () => {
    await idbSet(KEY, 'present');
    ok(await idbHas(KEY));
    await idbDel(KEY);
  });

  // ── Overwrite ─────────────────────────────────────────────────────────
  t('idbSet overwrites a previously stored value', async () => {
    await idbSet(KEY, 'first');
    await idbSet(KEY, 'second');
    const val = await idbGet(KEY);
    eq(val, 'second');
    await idbDel(KEY);
  });

  // ── Multiple keys are independent ─────────────────────────────────────
  t('two distinct keys do not interfere', async () => {
    await idbSet(KEY,  'alpha');
    await idbSet(KEY2, 'beta');
    eq(await idbGet(KEY),  'alpha');
    eq(await idbGet(KEY2), 'beta');
    await idbDel(KEY);
    await idbDel(KEY2);
    eq(await idbGet(KEY), null, 'KEY should be gone');
    ok(await idbHas(KEY2) === false, 'KEY2 should be gone');
  });

  // ── Large value ───────────────────────────────────────────────────────
  t('idbSet handles a 500 KB JSON object', async () => {
    const large = { data: 'x'.repeat(500_000) };
    await idbSet(KEY, large);
    const val = await idbGet(KEY);
    ok(val?.data?.length === 500_000, 'large value survives round-trip');
    await idbDel(KEY);
  });

  // ── Concurrent operations ─────────────────────────────────────────────
  t('concurrent idbSet calls to different keys both succeed', async () => {
    await Promise.all([
      idbSet(KEY,  'alpha'),
      idbSet(KEY2, 'beta'),
    ]);
    const [a, b] = await Promise.all([idbGet(KEY), idbGet(KEY2)]);
    ok(a === 'alpha' && b === 'beta', `expected alpha/beta, got ${a}/${b}`);
    await idbDel(KEY);
    await idbDel(KEY2);
  });

  t('idbSet and idbDel on same key sequentially leave key absent', async () => {
    await idbSet(KEY, 'temporary');
    await idbDel(KEY);
    ok(!(await idbHas(KEY)), 'key should be absent after delete');
  });

  // ── Boolean and null-ish values ───────────────────────────────────────
  t('idbSet stores boolean true and idbGet returns it', async () => {
    await idbSet(KEY, true);
    const val = await idbGet(KEY);
    ok(val === true, `expected true, got ${val}`);
    await idbDel(KEY);
  });

  t('idbSet stores 0 (falsy number) correctly', async () => {
    await idbSet(KEY, 0);
    const val = await idbGet(KEY);
    ok(val === 0, `expected 0, got ${val}`);
    await idbDel(KEY);
  });

  t('idbSet stores empty string correctly', async () => {
    await idbSet(KEY, '');
    const val = await idbGet(KEY);
    ok(val === '', `expected empty string, got ${JSON.stringify(val)}`);
    await idbDel(KEY);
  });

  t('idbHas returns false after idbDel', async () => {
    await idbSet(KEY, 'present');
    await idbDel(KEY);
    ok(!(await idbHas(KEY)));
  });

  // ── Complex value round-trips ─────────────────────────────────────────────
  t('idbSet/idbGet round-trips a deeply nested object', async () => {
    const complex = {
      session: { name: 'test', blocks: [{ id: 'b1', start: 0, duration: 10 }] },
      meta: { created: '2026-01-01', tags: ['a', 'b', 'c'] },
    };
    await idbSet(KEY, complex);
    const result = await idbGet(KEY);
    ok(result?.session?.name === 'test', 'session name should survive round-trip');
    ok(result?.meta?.tags?.length === 3, 'tags array should survive round-trip');
    await idbDel(KEY);
  });

  t('idbSet/idbGet round-trips an array at top level', async () => {
    const arr = [1, 'two', { three: 3 }, null, true];
    await idbSet(KEY, arr);
    const result = await idbGet(KEY);
    ok(Array.isArray(result), 'should return array');
    ok(result.length === 5);
    ok(result[1] === 'two');
    await idbDel(KEY);
  });

  t('idbSet overwrites with different type (string→object)', async () => {
    await idbSet(KEY, 'first');
    await idbSet(KEY, { replaced: true });
    const result = await idbGet(KEY);
    ok(typeof result === 'object' && result?.replaced === true,
      'type change should work: string replaced by object');
    await idbDel(KEY);
  });

  t('idbHas is accurate after set+del+set cycle', async () => {
    await idbSet(KEY, 'cycle-1');
    ok(await idbHas(KEY), 'should exist after first set');
    await idbDel(KEY);
    ok(!(await idbHas(KEY)), 'should not exist after del');
    await idbSet(KEY, 'cycle-2');
    ok(await idbHas(KEY), 'should exist after second set');
    await idbDel(KEY);
  });

  t('idbDel multiple times on same key does not throw', async () => {
    await idbSet(KEY, 'multi-del');
    await idbDel(KEY);
    await idbDel(KEY); // second delete — must not throw
    ok(!(await idbHas(KEY)));
  });

  t('concurrent idbSet to same key — last write wins', async () => {
    await Promise.all([
      idbSet(KEY, 'first'),
      idbSet(KEY, 'second'),
    ]);
    const result = await idbGet(KEY);
    ok(result === 'first' || result === 'second',
      'one of the two values should win');
    await idbDel(KEY);
  });


  // ── Large values ──────────────────────────────────────────────────────────
  t('idbSet/idbGet round-trips a 10 000-char string', async () => {
    const big = 'x'.repeat(10_000);
    await idbSet(KEY, big);
    const result = await idbGet(KEY);
    eq(result.length, 10_000);
    await idbDel(KEY);
  });

  t('idbSet/idbGet round-trips a boolean false (falsy check)', async () => {
    await idbSet(KEY, false);
    const result = await idbGet(KEY);
    ok(result === false, `expected false, got ${result}`);
    await idbDel(KEY);
  });

  t('idbSet/idbGet round-trips the number 0', async () => {
    await idbSet(KEY, 0);
    const result = await idbGet(KEY);
    ok(result === 0, `expected 0, got ${result}`);
    await idbDel(KEY);
  });

  t('idbGet on unknown key throws or returns null-ish', async () => {
    // Key guaranteed not to exist
    let threw = false;
    let result;
    try { result = await idbGet('test:definitely-does-not-exist-xyz'); }
    catch { threw = true; }
    // Either threw or returned null/undefined — both are acceptable
    ok(threw || result == null, 'non-existent key should throw or return null');
  });


  return R.summary();
}
