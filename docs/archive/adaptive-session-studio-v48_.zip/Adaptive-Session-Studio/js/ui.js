// ── ui.js ──────────────────────────────────────────────────────────────────
// All DOM rendering: sidebar lists, inspector panel, settings dialog.

import { state, persist, fmt, esc, $id, uid, clampInt, themeMap, applyCssVars, applyTheme, builtinThemes, normalizeBlock, fileToDataUrl } from './state.js';
import { downloadAss } from './subtitle.js';
import { downloadFunScript, refreshTimelineVisibility,
         connectDevice, disconnectDevice, drawTimeline } from './funscript.js';
import { history } from './history.js';
import { renderSuggestions } from './suggestions.js';
import { duplicateBlock, deleteBlock } from './block-ops.js';
import { fsState } from './macros.js';
import { getStoredAnalytics } from './session-analytics.js';
import { notify } from './notify.js';
import { validateMediaFile } from './import-validate.js';
import { renderSceneInspector, attachSceneInspectorEvents } from './scenes.js';
import { addRule, updateRule, deleteRule, toggleRule,
         CONDITIONING_PRESETS, applyPreset } from './rules-engine.js';
import { renderModeSelector }               from './session-modes.js';
import { renderTriggersInspector,
         attachTriggersInspectorEvents }    from './trigger-windows.js';
import { renderAiAuthoringPanel }           from './ai-authoring.js';
import { renderVariablesPanel }             from './variables.js';
import { renderContentPacksPicker }         from './content-packs.js';
import { renderPatternPicker }              from './funscript-patterns.js';
import { renderProfilePanel } from './user-profile.js';

// ── Sidebar ─────────────────────────────────────────────────────────────────
const DOT_COLORS = ['#5fa0dc','#f0a04a','#7dc87a','#b084cc','#e07a5f','#64b5c8'];
const BLOCK_COLORS = { text:'#5fa0dc', tts:'#7dc87a', audio:'#f0a04a', video:'#b084cc', pause:'#555350', macro:'#ff8fc8' };
const BLOCK_ICONS  = { text:'T', tts:'◎', audio:'♪', video:'▶', pause:'⏸', funscript:'⚡', macro:'⚙', viz:'🌀' };

export function renderSidebar() {
  const inner = $id('sidebarInner') ?? document.querySelector('.sidebar-inner');
  const savedScroll = inner?.scrollTop ?? 0;
  renderAudioList();
  renderVideoList();
  renderBlockList();
  renderSubtitleList();
  renderFunScriptList();
  renderScenesSummary();
  renderRulesSummary();
  renderTriggersSummary();
  refreshTimelineVisibility();
  if (inner) inner.scrollTop = savedScroll;
}

function renderRulesSummary() {
  const el = $id('rulesSummary');
  if (!el) return;
  const count  = state.session.rules?.length ?? 0;
  const active = state.session.rules?.filter(r => r.enabled).length ?? 0;
  const isSelected = state.selectedSidebarType === 'rules';
  el.innerHTML = `<div class="sb-item${isSelected ? ' selected' : ''}"
    data-sb-type="rules" style="cursor:pointer">
    <div class="sb-item-dot" style="background:#c8a4ff;border-radius:2px"></div>
    <span class="sb-item-name">Rules</span>
    <span class="sb-item-badge">${active}/${count}</span>
  </div>`;
}

function renderScenesSummary() {
  const el = $id('scenesSummary');
  if (!el) return;
  const count = state.session.scenes?.length ?? 0;
  el.innerHTML = count
    ? `<div class="sb-item${state.selectedSidebarType === 'scenes' ? ' selected' : ''}"
         data-sb-type="scenes" style="cursor:pointer">
         <div class="sb-item-dot" style="background:#7dc87a;border-radius:2px"></div>
         <span class="sb-item-name">Scenes</span>
         <span class="sb-item-badge">${count}</span>
       </div>`
    : `<div class="sb-empty" style="cursor:pointer" data-sb-type="scenes">+ Add scenes</div>`;
}

// ── Targeted selection update ────────────────────────────────────────────────
// Updates only the .selected class on sidebar items without rebuilding any
// innerHTML. Call this after a selection change instead of full renderSidebar().
export function updateSidebarSelection() {
  // Blocks
  document.querySelectorAll('[data-block-id]').forEach(el => {
    el.classList.toggle('selected', el.dataset.blockId === state.selectedBlockId);
  });
  // Audio / video / subtitle / funscript / scenes tracks
  document.querySelectorAll('[data-sb-type]').forEach(el => {
    const type    = el.dataset.sbType;
    const trackId = el.dataset.sbTrackId;
    let selected  = false;
    if (type === 'audio' || type === 'video') {
      selected = state.selectedSidebarType === type && state.selectedSidebarId === trackId;
    } else if (type === 'subtitle' || type === 'funscript') {
      selected = state.selectedSidebarType === type && state.selectedSidebarId === trackId;
    } else if (type === 'block') {
      selected = el.dataset.blockId === state.selectedBlockId;
    } else if (type === 'scenes') {
      selected = state.selectedSidebarType === 'scenes';
    } else if (type === 'rules') {
      selected = state.selectedSidebarType === 'rules';
    } else if (type === 'triggers') {
      selected = state.selectedSidebarType === 'triggers';
    }
    el.classList.toggle('selected', selected);
  });
}

function renderAudioList() {
  const el = $id('audioList');
  if (!el) return;
  const tracks = state.session.playlists.audio;
  if (!tracks.length) { el.innerHTML = '<div class="sb-empty">No audio tracks</div>'; return; }
  el.innerHTML = tracks.map((t, i) => `
    <div class="sb-item${state.selectedSidebarType==='audio'&&state.selectedSidebarId===t.id?' selected':''}" data-sb-type="audio" data-sb-track-id="${t.id}">
      <div class="sb-item-dot" style="background:${DOT_COLORS[i%6]}"></div>
      <span class="sb-item-name">${esc(t.name||`Audio ${i+1}`)}</span>
      <button class="sb-item-mute${t._muted?' muted':''}" data-mute-kind="audio" data-track-id="${t.id}" title="${t._muted?'Unmute':'Mute'}">${t._muted?'✕':'●'}</button>
      <button class="sb-item-del" data-del-kind="audio" data-track-id="${t.id}" title="Remove">×</button>
    </div>`).join('');
}

function renderVideoList() {
  const el = $id('videoList');
  if (!el) return;
  const tracks = state.session.playlists.video;
  if (!tracks.length) { el.innerHTML = '<div class="sb-empty">No video tracks</div>'; return; }
  el.innerHTML = tracks.map((t, i) => `
    <div class="sb-item${state.selectedSidebarType==='video'&&state.selectedSidebarId===t.id?' selected':''}" data-sb-type="video" data-sb-track-id="${t.id}">
      <div class="sb-item-dot" style="background:${DOT_COLORS[(i+3)%6]}"></div>
      <span class="sb-item-name">${esc(t.name||`Video ${i+1}`)}</span>
      <span class="sb-item-badge">${t.mediaKind||'vid'}</span>
      <button class="sb-item-del" data-del-kind="video" data-track-id="${t.id}" title="Remove">×</button>
    </div>`).join('');
}

function renderBlockList() {
  const el = $id('blockList');
  if (!el) return;
  const sorted = [...state.session.blocks].sort((a, b) => a.start - b.start);
  if (!sorted.length) { el.innerHTML = '<div class="sb-empty">No blocks</div>'; return; }
  el.innerHTML = sorted.map(b => `
    <div class="sb-item${b.id===state.selectedBlockId?' selected':''}" data-sb-type="block" data-block-id="${b.id}">
      <div class="sb-item-dot" style="background:${BLOCK_COLORS[b.type]||'#888'}"></div>
      <span class="sb-item-name">${esc(b.label)}</span>
      <span style="font-size:10px;color:var(--text3)">${fmt(b.start)}</span>
    </div>`).join('');
}

function renderSubtitleList() {
  const el = $id('subtitleList');
  if (!el) return;
  const tracks = state.session.subtitleTracks;
  if (!tracks.length) { el.innerHTML = '<div class="sb-empty">No subtitle tracks</div>'; return; }
  el.innerHTML = tracks.map((t, i) => `
    <div class="sb-item${state.selectedSidebarType==='subtitle'&&state.selectedSidebarId===t.id?' selected':''}" data-sb-type="subtitle" data-sb-idx="${i}" data-sb-track-id="${t.id}">
      <div class="sb-item-dot" style="background:#5fa0dc;border-radius:2px"></div>
      <span class="sb-item-name">${esc(t.name)}</span>
      <span class="sb-item-badge">${t.events?.length||0}</span>
      <button class="sb-item-mute${t._disabled?' muted':''}" data-mute-kind="subtitle" data-track-id="${t.id}" title="${t._disabled?'Enable':'Disable'}">${t._disabled?'✕':'●'}</button>
      <button class="sb-item-del" data-del-kind="subtitle" data-track-id="${t.id}" title="Remove">×</button>
    </div>`).join('');
}

function renderFunScriptList() {
  const el = $id('funscriptList');
  if (!el) return;
  const tracks = state.session.funscriptTracks;
  if (!tracks.length) { el.innerHTML = '<div class="sb-empty">No FunScript tracks</div>'; return; }
  el.innerHTML = tracks.map((t, i) => {
    const heatmap = _buildFsHeatmap(t.actions ?? [], t._color || '#f0a04a');
    const variant = t.variant ? `<span style="font-size:9px;padding:1px 5px;border-radius:3px;
      background:rgba(255,255,255,0.05);border:0.5px solid rgba(255,255,255,0.08);
      color:rgba(255,255,255,0.35);margin-left:3px">${esc(t.variant)}</span>` : '';
    return `
    <div class="sb-item${state.selectedSidebarType==='funscript'&&state.selectedSidebarId===t.id?' selected':''}" data-sb-type="funscript" data-sb-idx="${i}" data-sb-track-id="${t.id}" style="flex-direction:column;align-items:stretch;padding-bottom:0">
      <div style="display:flex;align-items:center;gap:6px;padding-bottom:4px">
        <div class="sb-item-dot" style="background:${t._color||'#f0a04a'};border-radius:2px"></div>
        <span class="sb-item-name">${esc(t.name)}${variant}</span>
        <span class="sb-item-badge">${t.actions?.length||0} pts</span>
        <button class="sb-item-mute${t._disabled?' muted':''}" data-mute-kind="funscript" data-track-id="${t.id}" title="${t._disabled?'Enable':'Disable'}">${t._disabled?'✕':'●'}</button>
        <button class="sb-item-del" data-del-kind="funscript" data-track-id="${t.id}" title="Remove">×</button>
      </div>
      ${heatmap}
    </div>`;
  }).join('');
}

/** Build a speed-color heatmap SVG strip for a FunScript track.
 *  Inspired by ScriptPlayer+ — each pixel-column shows average stroke speed
 *  in that time segment, colour-coded from cool (slow) to hot (fast). */
function _buildFsHeatmap(actions, trackColor) {
  if (!actions.length) return '';
  const W = 200, H = 6;
  const totalMs = actions.at(-1)?.at ?? 1;
  const COLS = W;
  const msPerCol = totalMs / COLS;

  // Compute per-column max velocity (pos change per ms)
  const cols = new Float32Array(COLS).fill(0);
  for (let j = 1; j < actions.length; j++) {
    const dt  = actions[j].at - actions[j-1].at;
    if (dt <= 0) continue;
    const vel = Math.abs(actions[j].pos - actions[j-1].pos) / dt; // pos/ms
    const col = Math.min(COLS - 1, Math.floor(actions[j-1].at / msPerCol));
    if (vel > cols[col]) cols[col] = vel;
  }
  const maxVel = Math.max(...cols, 0.001);

  // Build coloured rects — from track color (slow) toward white (fast)
  const rects = [];
  for (let c = 0; c < COLS; c++) {
    if (cols[c] === 0) continue;
    const intensity = cols[c] / maxVel; // 0–1
    // Interpolate: low-speed=trackColor dim, high-speed=white-hot
    const alpha = 0.2 + intensity * 0.75;
    rects.push(`<rect x="${c}" y="0" width="1" height="${H}" fill="${trackColor}" opacity="${alpha.toFixed(2)}"/>`);
  }
  if (!rects.length) return '';
  return `<svg width="100%" height="${H}" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"
    xmlns="http://www.w3.org/2000/svg" style="display:block;border-radius:0 0 4px 4px;opacity:${actions.length > 5 ? 1 : 0.4}"
    title="Speed heatmap — brighter = faster strokes">
    <rect width="${W}" height="${H}" fill="rgba(0,0,0,0.3)"/>
    ${rects.join('')}
  </svg>`;
}

// ── Inspector ───────────────────────────────────────────────────────────────
export function renderInspector() {
  const body = $id('inspBody');
  if (!body) return;
  switch (state.inspTab) {
    case 'status':
      body.innerHTML = renderStatusTab();
      renderSuggestions('suggestionsList');
      body.querySelector('#refreshSuggestions')?.addEventListener('click', () => {
        renderSuggestions('suggestionsList');
      });
      _mountProfilePanel();
      break;
    case 'session':
      body.innerHTML = renderSessionTab();
      attachSessionTabEvents();
      renderModeSelector('sessionModeSelector');
      renderAiAuthoringPanel('aiAuthoringPanel');
      renderContentPacksPicker('contentPacksPanel');
      renderVariablesPanel('variablesPanel');
      break;
    default:        body.innerHTML = renderOverlayTab(); attachOverlayTabEvents(); break;
  }
}

function renderStatusTab() {
  const rt = state.runtime;
  const liveFsPos = `${Math.round(fsState.lastSentPos)}%`;
  const es = state.engineState;
  const playbackCards = rt
    ? `${statCard('Time',  `${fmt(rt.sessionTime)} / ${fmt(state.session.duration)}`, 's_timeVal')}
       ${statCard('Loop',  rt.totalLoops ? `${rt.loopIndex+1}/${rt.totalLoops}` : `${rt.loopIndex+1}/∞`, 's_loopVal')}
       ${statCard('Block', esc(rt.activeBlock?.label || '—'), 's_blockVal')}
       ${statCard('FS pos', liveFsPos, 's_fsPos')}
       ${state.session.scenes?.length ? statCard('Scene', esc(rt.activeScene?.scene.name || '—'), 's_sceneVal') : ''}
       ${statCard('Attention', es ? `${Math.round(es.attention * 100)}%` : '—', 's_attentionVal')}
       ${statCard('Engagement', es ? `${Math.round(es.engagement * 100)}%` : '—', 's_engageVal')}`
    : `<div class="insp-status">Not playing.</div>
       ${statCard('Time','—')}${statCard('Loop','—')}${statCard('Block','—')}`;

  return `${playbackCards}
    <div style="margin-top:10px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
        <div class="insp-group-label" style="margin:0">Session health</div>
        <button id="refreshSuggestions" style="font-size:10px;padding:2px 7px">↺ Refresh</button>
      </div>
      <div id="suggestionsList"></div>
    </div>
    ${_renderLastSessionSummary()}
    <div id="profilePanelInspector" style="margin-top:10px"></div>`;
}

async function _mountProfilePanel() {
  const el = document.getElementById('profilePanelInspector');
  if (el) await renderProfilePanel('profilePanelInspector');
}

function _renderLastSessionSummary() {
  const history = getStoredAnalytics();
  if (!history.length) return '';
  const last = history[0];
  const date = new Date(last.timestamp).toLocaleString(undefined, { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' });
  const blockRows = (last.blockBreakdown ?? []).slice(0, 4).map(b =>
    `<div style="display:flex;justify-content:space-between;font-size:10.5px;padding:2px 0;border-bottom:0.5px solid rgba(255,255,255,0.04)">
       <span style="color:var(--text2)">${esc(b.label)}</span>
       <span>${fmt(b.seconds)}</span>
     </div>`
  ).join('');
  const fsLine = last.fsAvg !== null
    ? `<div style="font-size:10.5px;color:var(--text2);margin-top:5px">FS avg <strong>${last.fsAvg}%</strong> · peak <strong>${last.fsMax}%</strong></div>`
    : '';
  const attLine = last.attentionLossEvents > 0
    ? `<div style="font-size:10.5px;color:#f0a04a;margin-top:3px">⚠ ${last.attentionLossEvents} attention loss · ${fmt(last.attentionLossTotalSec)}</div>`
    : '';
  return `
    <details style="margin-top:10px">
      <summary style="cursor:pointer;font-size:10px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:rgba(255,255,255,0.25);list-style:none;display:flex;justify-content:space-between">
        <span>Last session</span><span style="font-weight:400;text-transform:none;letter-spacing:0">${date}</span>
      </summary>
      <div style="margin-top:8px">
        <div style="display:flex;gap:6px;margin-bottom:6px">
          <div style="flex:1;background:rgba(255,255,255,0.04);border-radius:6px;padding:6px 8px;text-align:center">
            <div style="font-size:13px;font-weight:700;color:#f0f0e8">${fmt(last.totalSec)}</div>
            <div style="font-size:9.5px;color:rgba(255,255,255,0.3);text-transform:uppercase">Runtime</div>
          </div>
          <div style="flex:1;background:rgba(255,255,255,0.04);border-radius:6px;padding:6px 8px;text-align:center">
            <div style="font-size:13px;font-weight:700;color:#f0f0e8">${last.loopsCompleted}</div>
            <div style="font-size:9.5px;color:rgba(255,255,255,0.3);text-transform:uppercase">Loops</div>
          </div>
        </div>
        ${blockRows}
        ${fsLine}${attLine}
        <div style="font-size:10px;color:rgba(255,255,255,0.2);margin-top:6px;font-style:italic">${esc(last.sessionName)}</div>
      </div>
    </details>`;
}

function statCard(label, val, id = '') {
  return `<div class="stat-card"><div class="stat-label">${label}</div><div class="stat-val"${id?` id="${id}"`:''}>${val}</div></div>`;
}

function renderSessionTab() {
  const s = state.session;
  return `
    <div class="insp-group">
      <div class="insp-group-label">Identity</div>
      <label style="font-size:11px;color:var(--text2);margin-bottom:6px">Name<input type="text" id="si_name" value="${esc(s.name)}" /></label>
    </div>
    <div class="insp-group">
      <div class="insp-group-label">Timing</div>
      <div class="insp-row"><span>Duration (s)</span><input type="number" id="si_dur" value="${s.duration}" min="10" style="width:80px" /></div>
      <div class="insp-row"><span>Loop mode</span>
        <select id="si_loop" style="width:100px">
          ${['none','count','minutes','forever'].map(v=>`<option value="${v}"${s.loopMode===v?' selected':''}>${v}</option>`).join('')}
        </select>
      </div>
      <div class="insp-row"><span>Loop count</span><input type="number" id="si_lc" value="${s.loopCount}" min="1" style="width:80px" /></div>
    </div>
    <div class="insp-group">
      <div class="insp-group-label">Block actions</div>
      <div style="display:flex;gap:5px;flex-wrap:wrap">
        <button id="si_dup" style="flex:1;font-size:11px">Duplicate</button>
        <button id="si_del" style="flex:1;font-size:11px;color:var(--danger)">Delete</button>
        <button id="si_sort" style="width:100%;font-size:11px">Sort by start time</button>
      </div>
    </div>
    <div class="insp-group" id="sessionModeSelector"></div>
    <div class="insp-group">
      <div class="insp-group-label">Author notes</div>
      <textarea id="si_notes" rows="4"
        placeholder="Design intent, timing notes, credits…"
        style="width:100%;font-size:11px;resize:vertical;color:var(--text2)"
      >${esc(s.notes || '')}</textarea>
      <div style="font-size:10px;color:var(--text3);margin-top:3px">
        Saved with the session — not shown during playback.
        ${s.notes ? `${s.notes.length.toLocaleString()} / 10,000 chars` : ''}
      </div>
    </div>
    <div class="insp-group" id="aiAuthoringPanel"></div>
    <div class="insp-group" id="contentPacksPanel"></div>
    <div class="insp-group" id="variablesPanel"></div>`;
}

function attachSessionTabEvents() {
  $id('si_name')?.addEventListener('input', e => {
    _snapOnce(e.target);
    state.session.name = e.target.value;
    // Keep the menubar quick-edit in sync (don't override while user focuses it)
    const sni = $id('sessionNameInput');
    if (sni && document.activeElement !== sni) sni.value = state.session.name;
    persist();
  });
  $id('si_dur')?.addEventListener('input', e => {
    _snapOnce(e.target);
    state.session.duration = clampInt(e.target.value, 10, 86400, 180);
    persist(); syncTransportControls();
  });
  $id('si_loop')?.addEventListener('change', e => {
    history.push();
    state.session.loopMode = e.target.value;
    persist(); syncTransportControls();
  });
  $id('si_lc')?.addEventListener('input', e => {
    _snapOnce(e.target);
    state.session.loopCount = clampInt(e.target.value, 1, 100000, 1); persist();
  });
  $id('si_dup')?.addEventListener('click', duplicateBlock);
  $id('si_del')?.addEventListener('click', deleteBlock);
  $id('si_sort')?.addEventListener('click', () => {
    history.push();
    state.session.blocks.sort((a, b) => a.start - b.start); persist(); renderSidebar();
  });
  $id('si_notes')?.addEventListener('input', e => {
    _snapOnce(e.target);
    state.session.notes = e.target.value.slice(0, 10_000);
    // Update char counter without full re-render
    const hint = e.target.nextElementSibling;
    if (hint) {
      hint.textContent = state.session.notes
        ? `Saved with the session — not shown during playback. ${state.session.notes.length.toLocaleString()} / 10,000 chars`
        : 'Saved with the session — not shown during playback.';
    }
    persist();
  });
}

function renderOverlayTab() {
  const block = state.session.blocks.find(b => b.id === state.selectedBlockId);

  // Audio playlist track selected?
  if (state.selectedSidebarType === 'audio' && state.selectedSidebarId) {
    const track = state.session.playlists.audio.find(t => t.id === state.selectedSidebarId);
    return track ? renderAudioTrackInspector(track) : '<div class="insp-status">Track not found.</div>';
  }
  // Video/image playlist track selected?
  if (state.selectedSidebarType === 'video' && state.selectedSidebarId) {
    const track = state.session.playlists.video.find(t => t.id === state.selectedSidebarId);
    return track ? renderVideoTrackInspector(track) : '<div class="insp-status">Track not found.</div>';
  }
  // Scenes panel?
  if (state.selectedSidebarType === 'scenes') {
    return renderSceneInspector();
  }
  // Rules panel?
  if (state.selectedSidebarType === 'rules') {
    return renderRulesInspector();
  }
  if (state.selectedSidebarType === 'triggers') {
    return renderTriggersInspector();
  }
  // FunScript track selected?
  if (state.selectedSidebarType === 'funscript' && state.selectedSidebarId) {
    return renderFunScriptInspector();
  }
  // Subtitle track selected?
  if (state.selectedSidebarType === 'subtitle' && state.selectedSidebarId) {
    return renderSubtitleInspector();
  }

  if (!block) return '<div class="insp-status">Select a block or track from the sidebar.</div>';

  // ── Compact block timeline strip ────────────────────────────────────────
  // Shows all blocks proportionally on a duration bar, with the selected
  // block highlighted — gives authors instant visual context.
  const dur = state.session.duration || 1;
  const TYPE_COLORS = {
    text:  '#7fb0ff', tts:  '#7dc87a', audio: '#f0a04a',
    video: '#b084cc', pause: 'rgba(255,255,255,0.1)', macro: '#f0e04a',
  };
  const blockBars = state.session.blocks.map(b => {
    const x = (b.start / dur) * 100;
    const w = Math.max(0.5, (b.duration / dur) * 100);
    const isSelected = b.id === state.selectedBlockId;
    const fill = TYPE_COLORS[b.type] ?? '#888';
    return `<rect x="${x}%" width="${w}%" y="${isSelected ? 0 : 3}" height="${isSelected ? 14 : 8}"
              fill="${fill}" rx="1.5" opacity="${isSelected ? 1 : 0.55}"
              ${isSelected ? '' : ''} />`;
  }).join('');
  const positionStrip = `
    <div style="margin-bottom:10px">
      <svg width="100%" height="14" xmlns="http://www.w3.org/2000/svg"
           style="display:block;border-radius:3px;overflow:hidden">
        <rect width="100%" height="14" fill="rgba(255,255,255,0.04)" rx="3" />
        ${blockBars}
      </svg>
      <div style="display:flex;justify-content:space-between;font-size:9px;color:var(--text3);margin-top:2px">
        <span>0:00</span>
        <span style="color:var(--accent);font-weight:600">${fmt(block.start)}–${fmt(block.start + block.duration)}</span>
        <span>${fmt(dur)}</span>
      </div>
    </div>`;

  const colorTag = { text:'tag-blue', tts:'tag-green', audio:'tag-amber', video:'tag-purple', pause:'', macro:'tag-pink', viz:'tag-teal' }[block.type] || '';
  let html = `
    ${positionStrip}
    <div class="insp-block-name">${esc(block.label)}</div>
    <span class="tag ${colorTag}" style="margin-bottom:10px;display:inline-flex">${BLOCK_ICONS[block.type]||'?'} ${block.type}</span>
    <div class="insp-group">
      <div class="insp-group-label">Label</div>
      <input type="text" data-field="label" value="${esc(block.label)}" />
    </div>
    <div class="insp-group">
      <div class="insp-group-label">Timing</div>
      <div class="insp-row"><span>Start (s)</span><input type="number" data-field="start" value="${block.start}" min="0" step="1" style="width:80px"/></div>
      <div class="insp-row"><span>Duration (s)</span><input type="number" data-field="duration" value="${block.duration}" min="1" step="1" style="width:80px"/></div>
      <div class="insp-row"><span>End (s)</span><span style="color:var(--text3)">${block.start+block.duration}</span></div>
    </div>`;

  if (block.type === 'text') {
    html += `
      <div class="insp-group"><div class="insp-group-label">Content</div>
        <textarea data-field="content" rows="4" style="width:100%;font-size:11px;resize:vertical">${esc(block.content)}</textarea>
        <div style="font-size:10px;color:var(--text3);margin-top:3px;line-height:1.5">
          Template vars: <code>{{intensity}}</code> <code>{{speed}}</code> <code>{{loop}}</code> <code>{{time}}</code> <code>{{scene}}</code>
        </div>
      </div>
      <div class="insp-group"><div class="insp-group-label">Typography</div>
        <div class="insp-row"><span>Size</span><input type="number" data-field="fontSize" value="${block.fontSize||1.2}" min="0.5" max="5" step="0.05" style="width:80px"/></div>
      </div>
      <div class="insp-group"><div class="insp-group-label">Position</div>
        <div class="pos-grid">${['top-left','top','top-right','left','center','right','bottom-left','bottom','bottom-right'].map(p=>`<button class="pos-btn${(block._position||'center')===p?' active':''}" data-pos="${p}">${posLabel(p)}</button>`).join('')}</div>
      </div>`;
  } else if (block.type === 'tts') {
    // Rough speech duration: average speaking rate ~150 wpm ≈ 12.5 chars/sec
    const charCount    = (block.content || '').length;
    const wordCount    = (block.content || '').trim().split(/\s+/).filter(Boolean).length;
    const estSec       = wordCount ? Math.round(wordCount / 2.5) : 0; // ~150 wpm
    const rateHint     = charCount
      ? `${charCount} chars · ~${wordCount} words · ~${estSec}s at default rate`
      : 'No text yet';
    html += `
      <div class="insp-group"><div class="insp-group-label">Spoken text</div>
        <textarea data-field="content" rows="4" style="width:100%;font-size:11px;resize:vertical">${esc(block.content)}</textarea>
        <div style="font-size:10px;color:var(--text3);margin-top:3px;line-height:1.4">${rateHint}</div>
        <div style="font-size:10px;color:var(--text3);margin-top:2px;line-height:1.5">
          Template vars: <code>{{intensity}}</code> <code>{{speed}}</code> <code>{{loop}}</code> <code>{{time}}</code> <code>{{scene}}</code>
        </div>
      </div>
      <div class="insp-row"><span>Volume</span><input type="number" data-field="volume" value="${block.volume??1}" min="0" max="1" step="0.05" style="width:80px"/></div>
      <label style="font-size:11px;color:var(--text2)">Voice name<input type="text" data-field="voiceName" value="${esc(block.voiceName||'')}" placeholder="default" /></label>`;
  } else if (block.type === 'audio') {
    html += `
      <div class="insp-group"><div class="insp-group-label">File</div>
        <p style="font-size:11px;color:var(--text3);margin-bottom:4px">${block.dataUrlName?esc(block.dataUrlName):'No file'}</p>
        <label class="file-pick-btn">Browse…<input type="file" accept="audio/*" data-file-field="dataUrl" hidden /></label>
      </div>
      <div class="insp-row"><span>Volume</span><input type="number" data-field="volume" value="${block.volume??1}" min="0" max="1" step="0.05" style="width:80px"/></div>
      <label style="font-size:11px;color:var(--text2)">Notes<textarea data-field="content" rows="3" style="width:100%;font-size:11px;resize:vertical">${esc(block.content)}</textarea></label>`;
  } else if (block.type === 'video') {
    html += `
      <div class="insp-group"><div class="insp-group-label">File</div>
        <p style="font-size:11px;color:var(--text3);margin-bottom:4px">${block.dataUrlName?esc(block.dataUrlName):'No file'}</p>
        <label class="file-pick-btn">Browse…<input type="file" accept="video/*,image/*" data-file-field="dataUrl" hidden /></label>
      </div>
      <div class="insp-row"><span>Mute</span>
        <select data-field="mute" style="width:80px"><option value="true"${block.mute!==false?' selected':''}>Yes</option><option value="false"${block.mute===false?' selected':''}>No</option></select>
      </div>`;
  } else if (block.type === 'pause') {
    html += `<p style="font-size:11px;color:var(--text2);line-height:1.6">Pause block — stage stays quiet while playlist layers continue.</p>`;
  } else if (block.type === 'macro') {
    // Populate macro slot options from current session library + slots
    const macros = state.session.macroLibrary ?? [];
    const slots  = [1,2,3,4,5];
    html += `
      <div class="insp-group"><div class="insp-group-label">Macro trigger</div>
        <p style="font-size:11px;color:var(--text2);line-height:1.5;margin-bottom:8px">
          Injects a macro at the start of this block (once per loop).
        </p>
        <div class="insp-row"><span>Slot</span>
          <select data-field="macroSlot" style="width:80px">
            <option value="">—</option>
            ${slots.map(s => `<option value="${s}"${block.macroSlot===s?' selected':''}>${s}</option>`).join('')}
          </select>
        </div>
        ${macros.length ? `
        <div class="insp-row"><span>Macro (override slot)</span>
          <select data-field="macroId" style="width:130px">
            <option value="">Use slot</option>
            ${macros.map(m => `<option value="${m.id}"${block.macroId===m.id?' selected':''}>${esc(m.name)}</option>`).join('')}
          </select>
        </div>` : '<p style="font-size:10.5px;color:var(--text3)">No macros in library. Import or create one.</p>'}
      </div>`;

  } else if (block.type === 'viz') {
    const VIZ_TYPES = [
      { id: 'spiral',   label: '🌀 Spiral',   desc: 'Rotating Archimedes spiral — classic induction' },
      { id: 'pendulum', label: '〰 Pendulum',  desc: 'Harmonograph trace — entrancing and organic' },
      { id: 'tunnel',   label: '⭕ Tunnel',   desc: 'Concentric rings rushing inward — depth induction' },
      { id: 'pulse',    label: '💗 Pulse',    desc: 'Expanding rings — rhythm / heartbeat sync' },
      { id: 'vortex',   label: '🌪 Vortex',  desc: 'Multi-arm rotating star — peak / surrender scenes' },
    ];
    html += `
      <div class="insp-group">
        <div class="insp-group-label">Visualization</div>
        <p style="font-size:11px;color:var(--text2);line-height:1.5;margin-bottom:8px">
          Renders a hypnotic animation as the stage background during this block.
          Best used in induction or trance sessions with a 🌀 Guided Induction mode.
        </p>
        <div class="insp-row"><span>Pattern</span>
          <select data-field="vizType" style="width:130px">
            ${VIZ_TYPES.map(v => `<option value="${v.id}"${block.vizType===v.id?' selected':''}>${v.label}</option>`).join('')}
          </select>
        </div>
        <div class="insp-row"><span>Speed</span>
          <input type="number" data-field="vizSpeed" value="${block.vizSpeed??1}" min="0.25" max="4" step="0.25" style="width:70px"/>
          <span style="font-size:10px;color:var(--text3)">×</span>
        </div>
        <div class="insp-row"><span>Color</span>
          <input type="color" data-field="vizColor" value="${block.vizColor||'#c49a3c'}" style="width:40px;height:24px;border:none;background:none;cursor:pointer;padding:0"/>
          <span style="font-size:10px;color:var(--text3)">${block.vizColor||'#c49a3c'}</span>
        </div>
        <div style="margin-top:10px;padding:10px;background:rgba(255,255,255,0.02);border:0.5px solid rgba(255,255,255,0.06);border-radius:6px">
          <div style="font-size:10px;color:var(--text3);margin-bottom:6px">
            ${VIZ_TYPES.find(v=>v.id===block.vizType)?.desc ?? ''}
          </div>
          <canvas id="viz_preview" width="220" height="100"
            style="display:block;width:100%;border-radius:4px;background:#000"></canvas>
        </div>
      </div>`;


  html += `<div style="display:flex;gap:6px;margin-top:12px">
    <button id="ib_dup" style="flex:1;font-size:11px">Duplicate</button>
    <button id="ib_del" style="flex:1;font-size:11px;color:var(--danger)">Delete</button>
  </div>`;
  return html;
}

// Returns a human-readable file-size estimate from a base64 data URL.
// base64 encodes 3 bytes per 4 characters; the header prefix is negligible.
function _dataUrlSizeMB(dataUrl) {
  if (!dataUrl) return '0';
  const base64Len = dataUrl.length - (dataUrl.indexOf(',') + 1);
  const bytes = Math.round(base64Len * 0.75);
  return (bytes / 1_000_000).toFixed(1);
}

function renderAudioTrackInspector(track) {
  // Only render a preview player for validated data: URLs (normalizer already enforces this)
  const previewHtml = track.dataUrl
    ? `<div class="insp-group">
        <div class="insp-group-label">Preview</div>
        <audio controls src="${track.dataUrl}"
          style="width:100%;height:36px;margin-top:4px;accent-color:var(--accent,#7fb0ff)">
        </audio>
        <div style="font-size:10px;color:var(--text3);margin-top:3px">
          ~${_dataUrlSizeMB(track.dataUrl)} MB embedded
        </div>
      </div>`
    : `<div class="insp-group"><div style="font-size:11px;color:var(--text3)">No audio file loaded.</div></div>`;

  return `
    <div class="insp-block-name">♪ ${esc(track.name)}</div>
    <div class="insp-group">
      <div class="insp-group-label">Identity</div>
      <label style="font-size:11px;color:var(--text2)">Name<input type="text" id="ai_name" value="${esc(track.name)}" /></label>
    </div>
    ${previewHtml}
    <div class="insp-group">
      <div class="insp-group-label">Volume</div>
      <div class="insp-row">
        <span>Level</span>
        <input type="number" id="ai_volume" value="${track.volume ?? 1}" min="0" max="2" step="0.05" style="width:80px" />
      </div>
      <div class="insp-row">
        <span>Muted</span>
        <button id="ai_mute" class="sb-item-mute${track._muted?' muted':''}"
          data-mute-kind="audio" data-track-id="${track.id}"
          style="min-width:60px;padding:3px 8px;font-size:11px">
          ${track._muted ? '✕ Muted' : '● Active'}
        </button>
      </div>
    </div>
    <div style="display:flex;gap:5px;margin-top:8px">
      <button class="danger-btn" data-del-kind="audio" data-track-id="${track.id}"
        style="flex:1;font-size:11px;color:var(--danger)">Remove track</button>
    </div>`;
}

function renderVideoTrackInspector(track) {
  let previewHtml = '';
  if (track.dataUrl) {
    if (track.mediaKind === 'image') {
      previewHtml = `<div class="insp-group">
        <div class="insp-group-label">Preview</div>
        <img src="${track.dataUrl}"
          style="width:100%;max-height:130px;object-fit:contain;border-radius:4px;
                 background:rgba(0,0,0,0.4);display:block;margin-top:4px" />
        <div style="font-size:10px;color:var(--text3);margin-top:3px">
          ~${_dataUrlSizeMB(track.dataUrl)} MB embedded
        </div>
      </div>`;
    } else {
      previewHtml = `<div class="insp-group">
        <div class="insp-group-label">Preview</div>
        <video src="${track.dataUrl}" controls muted
          style="width:100%;max-height:130px;border-radius:4px;background:#000;display:block;margin-top:4px">
        </video>
        <div style="font-size:10px;color:var(--text3);margin-top:3px">
          ~${_dataUrlSizeMB(track.dataUrl)} MB embedded
        </div>
      </div>`;
    }
  } else {
    previewHtml = `<div class="insp-group"><div style="font-size:11px;color:var(--text3)">No media file loaded.</div></div>`;
  }

  return `
    <div class="insp-block-name">${track.mediaKind === 'image' ? '🖼' : '▶'} ${esc(track.name)}</div>
    <div class="insp-group">
      <div class="insp-group-label">Identity</div>
      <label style="font-size:11px;color:var(--text2)">Name<input type="text" id="vi_name" value="${esc(track.name)}" /></label>
      <div class="insp-row"><span>Kind</span><span style="color:var(--text3)">${track.mediaKind || 'video'}</span></div>
    </div>
    ${previewHtml}
    <div class="insp-group">
      <div class="insp-group-label">Playback</div>
      <div class="insp-row">
        <span>Mute audio</span>
        <select id="vi_mute" style="width:70px">
          <option value="true"${track.mute!==false?' selected':''}>Yes</option>
          <option value="false"${track.mute===false?' selected':''}>No</option>
        </select>
      </div>
      <div class="insp-row">
        <span>Volume</span>
        <input type="number" id="vi_volume" value="${track.volume ?? 1}" min="0" max="2" step="0.05" style="width:80px" />
      </div>
    </div>
    <div style="display:flex;gap:5px;margin-top:8px">
      <button data-del-kind="video" data-track-id="${track.id}"
        style="flex:1;font-size:11px;color:var(--danger)">Remove track</button>
    </div>`;
}

function renderRulesInspector() {
  const rules = state.session.rules ?? [];
  const METRICS = ['attention','intensity','speed','engagement','sessionTime','loopCount'];
  const OPS     = ['<','>','<=','>=','=='];
  const ACTIONS = ['pause','resume','stop','injectMacro','setIntensity','setSpeed','nextScene','gotoScene','setVar'];
  const METRIC_LABELS = { attention:'Attention', intensity:'Intensity', speed:'Speed',
    engagement:'Engagement', sessionTime:'Session time (s)', loopCount:'Loop count' };
  const ACTION_LABELS = { pause:'Pause', resume:'Resume', stop:'Stop',
    injectMacro:'Inject macro (slot)', setIntensity:'Set intensity', setSpeed:'Set speed',
    nextScene:'Next scene (sequential)', gotoScene:'Go to scene…', setVar:'Set variable' };

  const rulesHtml = rules.map(r => {
    // Build scene param selector for gotoScene
    let paramHtml = '';
    if (r.action.type === 'injectMacro' || r.action.type === 'setIntensity' || r.action.type === 'setSpeed') {
      paramHtml = `
        <div style="margin-top:4px;font-size:11px;color:var(--text2)">
          Param: <input type="number"
            class="rule-param" data-rule-id="${r.id}" value="${r.action.param ?? ''}"
            step="${r.action.type === 'injectMacro' ? '1' : '0.1'}"
            style="font-size:11px;width:80px"
            placeholder="${r.action.type === 'injectMacro' ? 'slot 1–5' : r.action.type === 'setIntensity' ? '0–2' : '0.25–4'}" />
          <span style="color:var(--text3)">${r.action.type === 'injectMacro' ? '(macro slot)' : r.action.type === 'setIntensity' ? '(0=off 1=100% 2=200%)' : '(×)'}</span>
        </div>`;
    } else if (r.action.type === 'gotoScene') {
      const sceneOpts = (state.session.scenes ?? []).map(s =>
        `<option value="${s.id}"${r.action.param === s.id ? ' selected' : ''}>${esc(s.name)}</option>`
      ).join('');
      paramHtml = `
        <div style="margin-top:4px;font-size:11px;color:var(--text2)">
          Target: <select class="rule-param rule-scene-param" data-rule-id="${r.id}"
            style="font-size:11px;width:130px">
            <option value="">— pick scene —</option>${sceneOpts}
          </select>
        </div>`;
    } else if (r.action.type === 'setVar') {
      const varNames = Object.keys(state.session.variables ?? {});
      const hint = varNames.length ? varNames.map(n => `${n}=…`).join(', ') : 'define variables in Session tab';
      paramHtml = `
        <div style="margin-top:4px;font-size:11px;color:var(--text2)">
          <input type="text" class="rule-param rule-str-param" data-rule-id="${r.id}"
            value="${esc(typeof r.action.param === 'string' ? r.action.param : '')}"
            placeholder="name=value" style="font-size:11px;width:160px" />
          <span style="color:var(--text3);font-size:10px"> e.g. ${esc(hint)}</span>
        </div>`;
    }
    return `
    <div class="rule-row" data-rule-id="${r.id}" style="
      background:rgba(255,255,255,0.03);border:0.5px solid rgba(255,255,255,0.07);
      border-radius:6px;padding:8px 10px;margin-bottom:6px">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
        <input type="checkbox" class="rule-enabled" data-rule-id="${r.id}"
          ${r.enabled ? 'checked' : ''} style="margin:0;cursor:pointer" />
        <input type="text" class="rule-name" data-rule-id="${r.id}" value="${esc(r.name)}"
          style="flex:1;font-size:11px;background:transparent;border:none;color:var(--text);min-width:0" />
        <button class="rule-del" data-rule-id="${r.id}"
          style="background:transparent;border:none;color:var(--danger,#e05050);cursor:pointer;font-size:14px;padding:0;line-height:1">×</button>
      </div>
      <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:4px;margin-bottom:4px;align-items:center;font-size:11px">
        <select class="rule-metric" data-rule-id="${r.id}" style="font-size:11px">
          ${METRICS.map(m => `<option value="${m}"${r.condition.metric===m?' selected':''}>${METRIC_LABELS[m]}</option>`).join('')}
        </select>
        <select class="rule-op" data-rule-id="${r.id}" style="font-size:11px;width:44px">
          ${OPS.map(o => `<option value="${o}"${r.condition.op===o?' selected':''}>${o}</option>`).join('')}
        </select>
        <input type="number" class="rule-val" data-rule-id="${r.id}" value="${r.condition.value}"
          step="0.05" style="font-size:11px;width:100%" />
      </div>
      <div style="display:grid;grid-template-columns:auto 1fr auto 1fr;gap:4px;font-size:11px;color:var(--text2)">
        <span style="align-self:center">for</span>
        <input type="number" class="rule-dur" data-rule-id="${r.id}" value="${r.durationSec}"
          min="0" step="0.5" style="font-size:11px" title="Duration (s) condition must hold" />
        <span style="align-self:center">s →</span>
        <select class="rule-action" data-rule-id="${r.id}" style="font-size:11px">
          ${ACTIONS.map(a => `<option value="${a}"${r.action.type===a?' selected':''}>${ACTION_LABELS[a]}</option>`).join('')}
        </select>
      </div>
      ${paramHtml}
      <div style="margin-top:4px;font-size:10.5px;color:var(--text3)">
        Cooldown: <input type="number" class="rule-cool" data-rule-id="${r.id}"
          value="${r.cooldownSec}" min="0" step="5" style="font-size:11px;width:60px" />s
      </div>
    </div>`;
  }).join('');

  return `
    <div class="insp-block-name">⚙ Rules</div>
    <p style="font-size:11px;color:var(--text2);line-height:1.6;margin-bottom:10px">
      Rules fire actions when metric conditions hold for a set duration.
      Active during playback only.
    </p>
    <div id="rulesListBody">${rulesHtml || '<div class="sb-empty">No rules yet.</div>'}</div>
    <button id="addRuleBtn" style="width:100%;font-size:11px;margin-top:6px">+ Add rule</button>
    <div style="margin-top:8px">
      <div class="insp-group-label">Conditioning presets</div>
      <select id="condPresetSelect" style="font-size:11px;width:100%;margin-top:4px">
        <option value="">— Apply a preset template —</option>
        ${CONDITIONING_PRESETS.map(p =>
          `<option value="${p.id}" title="${p.description}">${p.name}</option>`).join('')}
      </select>
    </div>
    <div style="margin-top:10px;padding:8px;background:rgba(255,255,255,0.03);border-radius:6px;font-size:10.5px;color:var(--text3);line-height:1.6">
      <strong style="color:var(--text2)">Metrics:</strong> attention (0–1), intensity (0–2), speed (0.25–4), engagement (0–1), sessionTime (s), loopCount<br>
      <strong style="color:var(--text2)">Actions:</strong> pause, resume, stop, injectMacro (slot 1–5), setIntensity, setSpeed, nextScene, gotoScene (scene id)
    </div>`;
}

function attachRulesInspectorEvents() {
  const body = $id('inspBody');
  if (!body) return;

  body.querySelector('#addRuleBtn')?.addEventListener('click', () => {
    addRule({ name: `Rule ${(state.session.rules?.length ?? 0) + 1}` });
    renderInspector();
  });

  body.querySelector('#condPresetSelect')?.addEventListener('change', e => {
    const presetId = e.target.value;
    if (!presetId) return;
    applyPreset(presetId);
    e.target.value = '';           // reset dropdown
    renderInspector();
    renderSidebar();
  });

  // Delegated events for all rule fields
  body.querySelectorAll('.rule-enabled').forEach(el => {
    el.addEventListener('change', () => { toggleRule(el.dataset.ruleId); renderSidebar(); });
  });
  body.querySelectorAll('.rule-del').forEach(el => {
    el.addEventListener('click', () => { deleteRule(el.dataset.ruleId); renderInspector(); renderSidebar(); });
  });

  const patchCondition = (el, field) => el.addEventListener('input', () => {
    const val = field === 'value' ? Number(el.value) : el.value;
    updateRule(el.dataset.ruleId, { condition: { [field]: val } });
  });
  body.querySelectorAll('.rule-name').forEach(el   => el.addEventListener('input', () => updateRule(el.dataset.ruleId, { name: el.value })));
  body.querySelectorAll('.rule-metric').forEach(el  => patchCondition(el, 'metric'));
  body.querySelectorAll('.rule-op').forEach(el      => patchCondition(el, 'op'));
  body.querySelectorAll('.rule-val').forEach(el     => patchCondition(el, 'value'));
  body.querySelectorAll('.rule-dur').forEach(el     => el.addEventListener('input', () => updateRule(el.dataset.ruleId, { durationSec: Number(el.value) })));
  body.querySelectorAll('.rule-cool').forEach(el    => el.addEventListener('input', () => updateRule(el.dataset.ruleId, { cooldownSec: Number(el.value) })));
  body.querySelectorAll('.rule-action').forEach(el  => el.addEventListener('change', () => {
    updateRule(el.dataset.ruleId, { action: { type: el.value, param: null } });
    renderInspector(); // re-render to show/hide param field
  }));
  body.querySelectorAll('.rule-param').forEach(el => {
    const evt = el.tagName === 'SELECT' ? 'change' : 'input';
    el.addEventListener(evt, () => {
      const isSceneParam = el.classList.contains('rule-scene-param');
      const isStrParam   = el.classList.contains('rule-str-param');
      const v = el.value === '' ? null
              : isSceneParam ? el.value
              : isStrParam   ? el.value
              : Number(el.value);
      updateRule(el.dataset.ruleId, { action: { param: v } });
    });
  });
}

function renderTriggersSummary() {
  const el = $id('triggersSummary');
  if (!el) return;
  const count   = state.session.triggers?.length ?? 0;
  const enabled = state.session.triggers?.filter(t => t.enabled).length ?? 0;
  const sel     = state.selectedSidebarType === 'triggers';
  el.innerHTML  = `<div class="sb-item${sel ? ' selected' : ''}"
    data-sb-type="triggers" style="cursor:pointer">
    <div class="sb-item-dot" style="background:#f0a04a;border-radius:2px"></div>
    <span class="sb-item-name">Triggers</span>
    <span class="sb-item-badge">${enabled}/${count}</span>
  </div>`;
}
  const track = state.selectedSidebarId
    ? state.session.funscriptTracks.find(t => t.id === state.selectedSidebarId)
    : state.session.funscriptTracks[state.selectedSidebarIdx];
  if (!track) return '<div class="insp-status">Track not found.</div>';
  const settings = state.session.funscriptSettings;
  return `
    <div class="insp-block-name">⚡ ${esc(track.name)}</div>
    <div class="insp-group">
      <div class="insp-group-label">Track info</div>
      <div class="insp-row"><span>Points</span><span style="color:var(--text)">${track.actions?.length||0}</span></div>
      <div class="insp-row"><span>Duration</span><span style="color:var(--text)">${fmt((track.actions?.at(-1)?.at||0)/1000)}</span></div>
      <div class="insp-row"><span>Range</span><span style="color:var(--text)">0–${track.range||100}</span></div>
      <div class="insp-row"><span>Variant</span>
        <select id="fs_variant" style="width:100px">
          <option value=""${track.variant===''?' selected':''}>— none —</option>
          <option value="Soft"${track.variant==='Soft'?' selected':''}>Soft</option>
          <option value="Standard"${track.variant==='Standard'?' selected':''}>Standard</option>
          <option value="Intense"${track.variant==='Intense'?' selected':''}>Intense</option>
          <option value="Custom"${track.variant==='Custom'?' selected':''}>Custom</option>
        </select>
      </div>
    </div>
    ${track.actions?.length > 1 ? `<div class="insp-group" style="padding:0;overflow:hidden">
      <div style="padding:8px 8px 5px;font-size:9px;text-transform:uppercase;letter-spacing:.08em;color:var(--text3)">Speed heatmap</div>
      ${(h => h ? h.replace('height="6"', 'height="18"').replace('viewBox="0 0 200 6"', 'viewBox="0 0 200 18"') : '<div style="padding:0 8px 8px;font-size:10px;color:var(--text3)">No data</div>')(_buildFsHeatmap(track.actions, track._color || '#f0a04a'))}
    </div>` : ''}
    <div class="insp-group">
      <div class="insp-group-label">Global FunScript settings</div>
      <div class="insp-row"><span>Speed</span>
        <input type="number" id="fs_speed" value="${settings.speed||1}" min="0.25" max="4" step="0.25" style="width:70px"/>
        <span style="font-size:10px;color:var(--text3)">×</span>
      </div>
      <div class="insp-row"><span>Invert</span>
        <select id="fs_invert" style="width:70px">
          <option value="false"${!settings.invert?' selected':''}>No</option>
          <option value="true"${settings.invert?' selected':''}>Yes</option>
        </select>
      </div>
      <div class="insp-row"><span>Range</span>
        <input type="number" id="fs_range" value="${settings.range||100}" min="1" max="100" step="1" style="width:70px"/>
      </div>
    </div>
    <div class="insp-group">
      <div class="insp-group-label">Device</div>
      <div class="device-status-display" style="font-size:11px;color:var(--text3);margin-bottom:6px">Disconnected</div>
      <div style="display:flex;flex-direction:column;gap:5px">
        <input type="text" id="fs_wsUrl" value="${esc(state.session.advanced?.deviceWsUrl ?? 'ws://localhost:12345')}" style="font-size:11px" placeholder="ws://localhost:12345" />
        <div style="display:flex;gap:5px">
          <button id="fs_connect" class="btn-primary" style="flex:1;font-size:11px">Connect</button>
          <button id="fs_disconnect" style="flex:1;font-size:11px">Disconnect</button>
        </div>
      </div>
    </div>
    <div style="display:flex;flex-direction:column;gap:5px;margin-top:4px">
      <button id="fs_export" style="font-size:11px">Export .funscript</button>
      <button id="fs_delete" style="font-size:11px;color:var(--danger)">Remove track</button>
    </div>
    <div id="fsPatternPicker" style="margin-top:14px;padding-top:12px;border-top:0.5px solid rgba(255,255,255,0.06)"></div>
    <div id="fsBpmPanel" style="margin-top:10px;padding-top:10px;border-top:0.5px solid rgba(255,255,255,0.06)">
      <div style="font-size:9px;color:rgba(196,154,60,0.5);text-transform:uppercase;letter-spacing:.10em;margin-bottom:8px;display:flex;align-items:center;gap:6px">
        BPM Generator <span style="flex:1;height:0.5px;background:rgba(196,154,60,0.12);display:block"></span>
      </div>
      <p style="font-size:10.5px;color:var(--text2);line-height:1.5;margin-bottom:10px">
        Generate a FunScript track synchronized to a musical tempo.
      </p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:6px">
        <label style="font-size:10px;color:var(--text2)">BPM
          <input id="bpm_bpm" type="number" value="80" min="30" max="240" step="1"
            style="width:100%;margin-top:2px;font-size:11px"/>
        </label>
        <label style="font-size:10px;color:var(--text2)">Duration (s)
          <input id="bpm_dur" type="number" value="60" min="5" max="600" step="5"
            style="width:100%;margin-top:2px;font-size:11px"/>
        </label>
        <label style="font-size:10px;color:var(--text2)">Shape
          <select id="bpm_shape" style="width:100%;margin-top:2px;font-size:11px">
            <option value="sine">Sine</option>
            <option value="square">Square</option>
            <option value="sawtooth">Sawtooth</option>
            <option value="bounce">Bounce</option>
          </select>
        </label>
        <label style="font-size:10px;color:var(--text2)">Subdivision
          <select id="bpm_bars" style="width:100%;margin-top:2px;font-size:11px">
            <option value="1">Quarter note</option>
            <option value="2">Eighth note</option>
            <option value="4">Sixteenth note</option>
          </select>
        </label>
        <label style="font-size:10px;color:var(--text2)">Peak pos (%)
          <input id="bpm_amp" type="number" value="90" min="10" max="100" step="5"
            style="width:100%;margin-top:2px;font-size:11px"/>
        </label>
        <label style="font-size:10px;color:var(--text2)">Base pos (%)
          <input id="bpm_base" type="number" value="10" min="0" max="90" step="5"
            style="width:100%;margin-top:2px;font-size:11px"/>
        </label>
      </div>
      <button id="bpm_generate" class="btn-accent" style="width:100%;font-size:11px">♩ Generate from BPM</button>
    </div>`;
}

function renderSubtitleInspector() {
  const track = state.selectedSidebarId
    ? state.session.subtitleTracks.find(t => t.id === state.selectedSidebarId)
    : state.session.subtitleTracks[state.selectedSidebarIdx];
  if (!track) return '<div class="insp-status">Track not found.</div>';
  return `
    <div class="insp-block-name">◌ ${esc(track.name)}</div>
    <div class="insp-group">
      <div class="insp-group-label">Track info</div>
      <div class="insp-row"><span>Cues</span><span style="color:var(--text)">${track.events?.length||0}</span></div>
      <div class="insp-row"><span>Styles</span><span style="color:var(--text)">${Object.keys(track.styles||{}).join(', ')||'Default'}</span></div>
    </div>
    <div style="display:flex;flex-direction:column;gap:5px;margin-top:4px">
      <button id="ass_export" style="font-size:11px">Export .ass</button>
      <button id="ass_delete" style="font-size:11px;color:var(--danger)">Remove track</button>
    </div>`;
}

function attachOverlayTabEvents() {
  const body = $id('inspBody');
  if (!body) return;

  // ── Scene inspector events ──────────────────────────────────────────────
  if (state.selectedSidebarType === 'scenes') {
    attachSceneInspectorEvents();
    return;
  }
  if (state.selectedSidebarType === 'rules') {
    attachRulesInspectorEvents();
    return;
  }
  if (state.selectedSidebarType === 'triggers') {
    attachTriggersInspectorEvents();
    return;
  }

  // ── Block field events ──────────────────────────────────────────────────
  body.querySelectorAll('[data-field]').forEach(el => {
    el.addEventListener('input',  handleBlockFieldChange);
    el.addEventListener('change', handleBlockFieldChange);
  });
  body.querySelectorAll('[data-file-field]').forEach(el => el.addEventListener('change', handleBlockFileChange));
  body.querySelectorAll('.pos-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
      if (!block) return;
      block._position = btn.dataset.pos;
      persist();
      body.querySelectorAll('.pos-btn').forEach(b => b.classList.toggle('active', b === btn));
    });
  });

  $id('ib_dup')?.addEventListener('click', duplicateBlock);
  $id('ib_del')?.addEventListener('click', deleteBlock);

  // ── Viz block preview canvas ─────────────────────────────────────────────
  const vizCanvas = $id('viz_preview');
  if (vizCanvas) {
    const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
    if (block?.type === 'viz') {
      import('./viz-blocks.js').then(({ mountVizBlock }) => {
        // Fit canvas to its display size
        const rect = vizCanvas.getBoundingClientRect();
        if (rect.width > 0) { vizCanvas.width = rect.width * devicePixelRatio; vizCanvas.height = rect.height * devicePixelRatio; }
        mountVizBlock(vizCanvas, block);
      }).catch(() => {});
      // Stop preview when inspector re-renders or block changes
      const observer = new MutationObserver(() => {
        if (!document.contains(vizCanvas)) {
          import('./viz-blocks.js').then(({ unmountVizBlock }) => unmountVizBlock(vizCanvas)).catch(() => {});
          observer.disconnect();
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
  }

  // ── Audio track inspector events ────────────────────────────────────────
  $id('ai_name')?.addEventListener('input', e => {
    const t = state.session.playlists.audio.find(a => a.id === state.selectedSidebarId);
    if (!t) return;
    _snapOnce(e.target);
    t.name = e.target.value;
    persist(); renderSidebar();
  });
  $id('ai_volume')?.addEventListener('input', e => {
    const t = state.session.playlists.audio.find(a => a.id === state.selectedSidebarId);
    if (!t) return;
    _snapOnce(e.target);
    t.volume = Math.min(2, Math.max(0, Number(e.target.value) || 0));
    persist();
    if (state.runtime?.usingAudioEngine) refreshVolumes();
  });

  // ── Video track inspector events ────────────────────────────────────────
  $id('vi_name')?.addEventListener('input', e => {
    const t = state.session.playlists.video.find(v => v.id === state.selectedSidebarId);
    if (!t) return;
    _snapOnce(e.target);
    t.name = e.target.value;
    persist(); renderSidebar();
  });
  $id('vi_mute')?.addEventListener('change', e => {
    const t = state.session.playlists.video.find(v => v.id === state.selectedSidebarId);
    if (!t) return;
    history.push();
    t.mute = e.target.value === 'true';
    persist();
    if (state.runtime) {
      state.runtime.backgroundVideo.forEach(el => { if (el.src === t.dataUrl) el.muted = t.mute; });
    }
  });
  $id('vi_volume')?.addEventListener('input', e => {
    const t = state.session.playlists.video.find(v => v.id === state.selectedSidebarId);
    if (!t) return;
    _snapOnce(e.target);
    t.volume = Math.min(2, Math.max(0, Number(e.target.value) || 0));
    persist();
    if (state.runtime) {
      const { session } = state;
      state.runtime.backgroundVideo.forEach(el => {
        if (el.src === t.dataUrl) el.volume = session.masterVolume * session.advanced.playlistVideoVolume * t.volume;
      });
    }
  });

  // ── FunScript inspector events ──────────────────────────────────────────
  renderPatternPicker('fsPatternPicker');
  $id('fs_variant')?.addEventListener('change', e => {
    const track = state.session.funscriptTracks.find(t => t.id === state.selectedSidebarId);
    if (!track) return;
    history.push();
    track.variant = e.target.value;
    persist(); renderSidebar();
  });

  $id('bpm_generate')?.addEventListener('click', async () => {
    const bpm      = parseInt($id('bpm_bpm')?.value   ?? 80, 10);
    const durSec   = parseInt($id('bpm_dur')?.value   ?? 60, 10);
    const shape    = $id('bpm_shape')?.value  ?? 'sine';
    const bars     = parseInt($id('bpm_bars')?.value  ?? 1, 10);
    const amplitude = parseInt($id('bpm_amp')?.value  ?? 90, 10);
    const baseline  = parseInt($id('bpm_base')?.value ?? 10, 10);

    const { generateFromBPM } = await import('./viz-blocks.js');
    const actions = generateFromBPM({ bpm, durationSec: durSec, shape, barsPerBeat: bars, amplitude, baseline });

    history.push();
    const TRACK_COLORS = ['#f0a04a','#5fa0dc','#7dc87a','#b084cc','#e07a5f','#64b5c8'];
    const newTrack = {
      id:       uid(),
      name:     `BPM ${bpm} ${shape}`,
      version:  1,
      inverted: false,
      range:    100,
      actions,
      _disabled: false,
      _color:   TRACK_COLORS[state.session.funscriptTracks.length % TRACK_COLORS.length],
      variant:  '',
    };
    state.session.funscriptTracks.push(newTrack);
    state.selectedSidebarType = 'funscript';
    state.selectedSidebarId   = newTrack.id;
    persist();
    renderSidebar();
    renderInspector();
    const { notify } = await import('./notify.js');
    notify.success(`Generated "${newTrack.name}" — ${actions.length} actions, ${durSec}s at ${bpm} BPM.`);
  });
  $id('fs_speed')?.addEventListener('input', e => {
    _snapOnce(e.target);
    state.session.funscriptSettings.speed = Number(e.target.value) || 1; persist();
  });
  $id('fs_invert')?.addEventListener('change', e => {
    history.push();
    state.session.funscriptSettings.invert = e.target.value === 'true'; persist();
  });
  $id('fs_range')?.addEventListener('input', e => {
    _snapOnce(e.target);
    state.session.funscriptSettings.range = clampInt(e.target.value, 1, 100, 100); persist();
  });
  $id('fs_connect')?.addEventListener('click', () => {
    const url = $id('fs_wsUrl')?.value?.trim() || state.session.advanced?.deviceWsUrl || 'ws://localhost:12345';
    connectDevice(url);
  });
  $id('fs_disconnect')?.addEventListener('click', () => disconnectDevice());
  // Persist URL changes from the inspector — keep in sync with Settings dialog
  $id('fs_wsUrl')?.addEventListener('change', e => {
    const url = e.target.value.trim();
    if (url) {
      state.session.advanced.deviceWsUrl = url;
      const sv = $id('s_deviceWsUrl');
      if (sv) sv.value = url;
      persist(); // persist is already statically imported in ui.js
    }
  });
  $id('fs_export')?.addEventListener('click', () => {
    const trackId = state.selectedSidebarId;
    if (trackId) downloadFunScript(trackId);
  });
  $id('fs_delete')?.addEventListener('click', () => {
    const trackId = state.selectedSidebarId;
    if (!trackId) return;
    history.push();
    state.session.funscriptTracks = state.session.funscriptTracks.filter(t => t.id !== trackId);
    state.selectedSidebarType = null; state.selectedSidebarIdx = null; state.selectedSidebarId = null;
    persist(); renderSidebar(); renderInspector();
    drawTimeline();
  });

  // ── Subtitle inspector events ───────────────────────────────────────────
  $id('ass_export')?.addEventListener('click', () => {
    const track = state.selectedSidebarId
      ? state.session.subtitleTracks.find(t => t.id === state.selectedSidebarId)
      : state.session.subtitleTracks[state.selectedSidebarIdx];
    if (track) downloadAss(state.session.subtitleTracks.indexOf(track));
  });
  $id('ass_delete')?.addEventListener('click', () => {
    const trackId = state.selectedSidebarId;
    if (!trackId) return;
    history.push();
    state.session.subtitleTracks = state.session.subtitleTracks.filter(t => t.id !== trackId);
    state.selectedSidebarType = null; state.selectedSidebarIdx = null; state.selectedSidebarId = null;
    persist(); renderSidebar(); renderInspector();
  });
}

function handleBlockFieldChange(e) {
  const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
  if (!block) return;
  // Snapshot before first keystroke in a field (debounced — only if field identity changes)
  if (handleBlockFieldChange._lastField !== e.target) {
    history.push();
    handleBlockFieldChange._lastField = e.target;
  }
  const field = e.target.dataset.field;
  let val = e.target.value;
  if (field === 'start' || field === 'duration') val = clampInt(val, field==='duration'?1:0, 86400, block[field]);
  if (field === 'fontSize' || field === 'volume') val = Number(val);
  if (field === 'mute') val = val === 'true';
  if (field === 'macroSlot') val = val === '' ? null : Number(val);
  if (field === 'vizSpeed') val = Math.max(0.25, Math.min(4, Number(val) || 1));
  block[field] = val;
  persist();
  // Re-render inspector for viz blocks so preview refreshes with new settings
  if (block.type === 'viz') { renderInspector(); return; }
  renderSidebar();
}
handleBlockFieldChange._lastField = null;

async function handleBlockFileChange(e) {
  const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
  const file  = e.target.files?.[0];
  if (!block || !file) return;
  try {
    validateMediaFile(file, file.type.startsWith('audio/') ? 'Audio' : file.type.startsWith('video/') ? 'Video' : 'Image');
  } catch (err) {
    notify.error(err.message);
    e.target.value = '';
    return;
  }
  block.dataUrl     = await fileToDataUrl(file);
  block.dataUrlName = file.name;
  block.mediaKind   = file.type.startsWith('audio/') ? 'audio' : file.type.startsWith('video/') ? 'video' : 'image';
  persist();
  renderInspector();
}

// ── Undo debounce helper ─────────────────────────────────────────────────────
// Snapshot at most once per (handler, element) pair. Prevents spamming history
// on rapid input events while still capturing the state before the first edit.
const _undoDebounce = new WeakMap();
function _snapOnce(el) {
  if (!_undoDebounce.has(el)) {
    history.push();
    _undoDebounce.set(el, true);
    // Clear after a short idle so the next distinct editing session gets a snapshot
    el.addEventListener('blur', () => _undoDebounce.delete(el), { once: true });
  }
}

// Syncs loop toggle, master volume slider, and tTotal from session state.
// Called by main.js after any session mutation; also called internally from
// session inspector changes that affect transport-bar values.
export function syncTransportControls() {
  const s  = state.session;
  const lb = $id('loopToggle');
  const ll = { none: '↺ Off', count: '↺ Loop', minutes: '↺ Min', forever: '↺ ∞' };
  if (lb) {
    lb.textContent = ll[s.loopMode] ?? '↺ Loop';
    lb.classList.toggle('active', s.loopMode !== 'none');
  }
  const mvSlider = $id('masterVolumeSlider');
  if (mvSlider) mvSlider.value = s.masterVolume;
  const tot = $id('tTotal');
  if (tot) tot.textContent = fmt(s.duration);
  // Show Next Scene button only when scenes are defined
  const nsBtn = $id('nextSceneBtn');
  if (nsBtn) nsBtn.style.display = (s.scenes?.length) ? '' : 'none';
  // Sync the header session-name quick-edit (don't override while the user is typing)
  const sni = $id('sessionNameInput');
  if (sni && document.activeElement !== sni) sni.value = s.name ?? '';
}

export function syncSettingsForms() {
  const s  = state.session;
  const v  = (id, val) => { const el = $id(id); if (el) el.value = val; };
  const c  = (id, val) => { const el = $id(id); if (el) el.checked = val; };
  v('s_sessionName', s.name);
  v('s_duration', s.duration);
  v('s_loopMode', s.loopMode);
  v('s_loopCount', s.loopCount);
  v('s_runtimeMinutes', s.runtimeMinutes);
  v('s_speechRate', s.speechRate);
  v('s_masterVolume', s.masterVolume);
  const mvLabel = $id('s_masterVolumeVal');
  if (mvLabel) mvLabel.textContent = `${Math.round((s.masterVolume ?? 0.8) * 100)}%`;
  v('s_playlistAudioVolume', s.advanced.playlistAudioVolume);
  v('s_playlistVideoVolume', s.advanced.playlistVideoVolume);
  v('s_crossfadeSeconds', s.advanced.crossfadeSeconds);
  v('s_backgroundColor', s.backgroundColor);
  v('s_textColor', s.textColor);
  v('s_accentColor', s.accentColor);
  v('s_stageBlur', s.advanced.stageBlur);
  v('s_fontFamily', s.advanced.fontFamily);
  v('s_assTextColor', s.subtitleSettings.textColor);
  v('s_assFontSize', s.subtitleSettings.fontSize);
  v('s_assPosition', s.subtitleSettings.position);
  v('s_assOverride', s.subtitleSettings.override);
  c('s_trackingEnabled', s.tracking.enabled);
  c('s_autoPauseOnAttentionLoss', s.tracking.autoPauseOnAttentionLoss);
  c('s_autoResumeOnAttentionReturn', s.advanced.autoResumeOnAttentionReturn);
  v('s_attentionThreshold', s.tracking.attentionThreshold);
  // Webcam → FS options
  const tfo = s.trackingFsOptions ?? {};
  c('s_pauseFsOnLoss',       tfo.pauseFsOnLoss       ?? false);
  c('s_injectMacroOnLoss',   tfo.injectMacroOnLoss   ?? false);
  v('s_lossInjectSlot',      tfo.lossInjectSlot      ?? 0);
  c('s_injectMacroOnReturn', tfo.injectMacroOnReturn ?? false);
  v('s_returnInjectSlot',    tfo.returnInjectSlot    ?? 0);
  // FunScript settings
  v('s_fsSpeed',  s.funscriptSettings.speed);
  v('s_fsRange',  s.funscriptSettings.range);
  c('s_fsInvert', s.funscriptSettings.invert);
  v('s_deviceWsUrl', s.advanced.deviceWsUrl ?? 'ws://localhost:12345');
  // Safety settings — use session values if set, otherwise fall back to defaults
  // so sliders always render at correct positions even before the user has saved any.
  const ss = s.safetySettings ?? {
    maxIntensity: 2.0, maxSpeed: 4.0, warnAbove: 1.5,
    emergencyCooldownSec: 30, autoReduceOnLoss: false, autoReduceTarget: 0.8,
  };
  v('s_safetyMaxInt',       ss.maxIntensity);
  v('s_safetyMaxSpd',       ss.maxSpeed);
  v('s_safetyWarn',         ss.warnAbove);
  v('s_safetyCool',         ss.emergencyCooldownSec);
  c('s_safetyAutoReduce',   ss.autoReduceOnLoss);
  v('s_safetyReduceTarget', ss.autoReduceTarget);
  // Update range labels
  const setL = (id, val, fmt) => { const el = $id(id); if (el) el.textContent = fmt(val); };
  setL('s_safetyMaxIntVal',       ss.maxIntensity,     v => `${Math.round(v*100)}%`);
  setL('s_safetyMaxSpdVal',       ss.maxSpeed,         v => `${v.toFixed(2)}×`);
  setL('s_safetyWarnVal',         ss.warnAbove,        v => `${Math.round(v*100)}%`);
  setL('s_safetyReduceTargetVal', ss.autoReduceTarget, v => `${Math.round(v*100)}%`);
  const row = $id('s_safetyReduceTargetRow');
  if (row) row.style.display = ss.autoReduceOnLoss ? '' : 'none';
  renderThemeGrid();
}

export function syncSessionFromSettings() {
  const gv = id => $id(id)?.value;
  const gc = id => $id(id)?.checked;
  const s  = state.session;
  s.name = gv('s_sessionName')?.trim() ?? s.name;
  // Keep the menubar quick-edit in sync
  const sni = $id('sessionNameInput');
  if (sni && document.activeElement !== sni) sni.value = s.name;
  s.duration = clampInt(gv('s_duration'), 10, 86400, s.duration);
  s.loopMode = gv('s_loopMode') || s.loopMode;
  s.loopCount = clampInt(gv('s_loopCount'), 1, 100000, s.loopCount);
  s.runtimeMinutes = clampInt(gv('s_runtimeMinutes'), 1, 100000, s.runtimeMinutes);
  s.speechRate = Number(gv('s_speechRate')) || s.speechRate;
  const mvVal = parseFloat(gv('s_masterVolume'));
  if (!isNaN(mvVal)) s.masterVolume = Math.max(0, Math.min(1, mvVal));
  s.advanced.playlistAudioVolume = Number(gv('s_playlistAudioVolume'));
  s.advanced.playlistVideoVolume = Number(gv('s_playlistVideoVolume'));
  s.advanced.crossfadeSeconds    = Number(gv('s_crossfadeSeconds'));
  s.backgroundColor = gv('s_backgroundColor') || s.backgroundColor;
  s.textColor   = gv('s_textColor')   || s.textColor;
  s.accentColor = gv('s_accentColor') || s.accentColor;
  s.advanced.stageBlur  = clampInt(gv('s_stageBlur'), 0, 24, s.advanced.stageBlur);
  s.advanced.fontFamily = gv('s_fontFamily')?.trim() || s.advanced.fontFamily;
  s.subtitleSettings.textColor = gv('s_assTextColor') || s.subtitleSettings.textColor;
  s.subtitleSettings.fontSize  = Number(gv('s_assFontSize')) || s.subtitleSettings.fontSize;
  s.subtitleSettings.position  = gv('s_assPosition') || s.subtitleSettings.position;
  s.subtitleSettings.override  = gv('s_assOverride')  || s.subtitleSettings.override;
  s.tracking.enabled = gc('s_trackingEnabled');
  s.tracking.autoPauseOnAttentionLoss = gc('s_autoPauseOnAttentionLoss');
  s.advanced.autoResumeOnAttentionReturn = gc('s_autoResumeOnAttentionReturn');
  s.tracking.attentionThreshold = clampInt(gv('s_attentionThreshold'), 1, 120, 5);
  // Webcam → FS options
  if (!s.trackingFsOptions) s.trackingFsOptions = {};
  s.trackingFsOptions.pauseFsOnLoss       = gc('s_pauseFsOnLoss');
  s.trackingFsOptions.injectMacroOnLoss   = gc('s_injectMacroOnLoss');
  s.trackingFsOptions.lossInjectSlot      = Number(gv('s_lossInjectSlot') ?? 0);
  s.trackingFsOptions.injectMacroOnReturn = gc('s_injectMacroOnReturn');
  s.trackingFsOptions.returnInjectSlot    = Number(gv('s_returnInjectSlot') ?? 0);
  // FunScript
  s.funscriptSettings.speed  = Number(gv('s_fsSpeed'))  || 1;
  s.funscriptSettings.range  = clampInt(gv('s_fsRange'), 1, 100, 100);
  s.funscriptSettings.invert = gc('s_fsInvert');
  const wsUrl = gv('s_deviceWsUrl')?.trim();
  if (wsUrl) s.advanced.deviceWsUrl = wsUrl;
  // Safety settings — only write if the section was populated (safetySettings may be null → use defaults)
  const maxInt = parseFloat(gv('s_safetyMaxInt'));
  if (!isNaN(maxInt)) {
    if (!s.safetySettings) s.safetySettings = {};
    s.safetySettings.maxIntensity      = Math.max(0, Math.min(2,    maxInt));
    s.safetySettings.maxSpeed          = Math.max(0.25, Math.min(4, parseFloat(gv('s_safetyMaxSpd'))  || 4));
    s.safetySettings.warnAbove         = Math.max(0, Math.min(2,    parseFloat(gv('s_safetyWarn'))    || 1.5));
    s.safetySettings.emergencyCooldownSec = Math.max(0, Number(gv('s_safetyCool')) || 30);
    s.safetySettings.autoReduceOnLoss  = gc('s_safetyAutoReduce');
    s.safetySettings.autoReduceTarget  = Math.max(0, Math.min(2,    parseFloat(gv('s_safetyReduceTarget')) || 0.8));
  }
  applyCssVars();
  persist();
}

export function renderThemeGrid() {
  const grid = $id('themeGrid');
  if (!grid) return;
  grid.innerHTML = Object.entries(themeMap()).map(([key, t]) => `
    <button class="theme-chip${state.session.theme===key?' active':''}" data-theme-key="${key}">
      <div class="theme-dot" style="background:${t.backgroundColor};border:2px solid ${t.accentColor}"></div>
      ${esc(t.name)}
    </button>`).join('');
}

export function saveCustomTheme() {
  const key = $id('s_customThemeKey')?.value.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, '-');
  const name= $id('s_customThemeName')?.value.trim() || key;
  if (!key) {
    notify.warn('Enter a theme key (e.g. "oceanic") first.');
    return;
  }
  state.session.customThemes[key] = {
    name,
    backgroundColor: $id('s_customThemeBg')?.value,
    accentColor:     $id('s_customThemeAccent')?.value,
    textColor:       $id('s_customThemeText')?.value,
  };
  applyTheme(key);
  persist();
  renderThemeGrid();
  notify.success(`Theme "${name}" saved.`);
}

export function deleteCustomTheme() {
  if (builtinThemes[state.session.theme]) {
    notify.warn('Built-in themes cannot be deleted. Select a custom theme first.');
    return;
  }
  const name = state.session.customThemes[state.session.theme]?.name ?? state.session.theme;
  delete state.session.customThemes[state.session.theme];
  applyTheme('midnight');
  persist();
  renderThemeGrid();
  notify.info(`Theme "${name}" deleted.`);
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function posLabel(p) {
  return { 'top-left':'↖', top:'↑', 'top-right':'↗', left:'←', center:'·', right:'→', 'bottom-left':'↙', bottom:'↓', 'bottom-right':'↘' }[p] || p;
}
