// ── session-modes.js ────────────────────────────────────────────────────────
// Session Mode Presets — ROADMAP Phase 14 (Exposure Therapy) & Phase 15 (Mindfulness)
//
// Each mode applies a coherent combination of:
//   - rampSettings (intensity escalation curve)
//   - pacingSettings (speed modulation)
//   - rules (behavioral conditioning)
//
// Applying a mode adds its rules (named with a prefix so they're identifiable)
// and sets ramp/pacing settings. Existing rules are preserved.

import { state, persist } from './state.js';
import { notify }         from './notify.js';
import { history }        from './history.js';
import { normalizeRule }  from './rules-engine.js';
import { renderRampPanel }   from './intensity-ramp.js';
import { renderPacingPanel } from './dynamic-pacing.js';

// ── Mode definitions ─────────────────────────────────────────────────────────

export const SESSION_MODES = [
  {
    id:          'exposure',
    name:        'Exposure Therapy',
    description: 'Gradual escalation with automatic fallback on overload. Steady intensity increase with attention-aware pausing.',
    icon:        '📈',
    rampSettings: {
      enabled:   true,
      mode:      'time',
      startVal:  0.3,
      endVal:    1.4,
      curve:     'exponential',
      steps:     [],
      blendMode: 'max',
    },
    pacingSettings: {
      enabled:      false,
      minSpeed:     0.75,
      maxSpeed:     1.25,
      smoothingSec: 6,
      curve:        'linear',
      lockDuringSec: 0,
    },
    rules: [
      { name: '[Exposure] Pause on attention loss', enabled: true,
        condition: { metric: 'attention', op: '<', value: 0.25 }, durationSec: 5, cooldownSec: 45,
        action: { type: 'pause', param: null } },
      { name: '[Exposure] Fallback intensity on overload', enabled: true,
        condition: { metric: 'engagement', op: '<', value: 0.2 }, durationSec: 10, cooldownSec: 60,
        action: { type: 'setIntensity', param: 0.5 } },
    ],
  },
  {
    id:          'mindfulness',
    name:        'Mindfulness / Focus',
    description: 'Low-intensity, stable experience. Rewards sustained attention and reduces intensity on distraction. Best for beginners or cooldown sessions.',
    icon:        '🧘',
    rampSettings: {
      enabled:   true,
      mode:      'engagement',
      startVal:  0.2,
      endVal:    0.8,
      curve:     'sine',
      steps:     [],
      blendMode: 'replace',
    },
    pacingSettings: {
      enabled:      true,
      minSpeed:     0.5,
      maxSpeed:     0.9,
      smoothingSec: 8,
      curve:        'sine',
      lockDuringSec: 3,
    },
    rules: [
      { name: '[Mindfulness] Pause on distraction', enabled: true,
        condition: { metric: 'attention', op: '<', value: 0.3 }, durationSec: 4, cooldownSec: 30,
        action: { type: 'pause', param: null } },
      { name: '[Mindfulness] Reduce intensity on drift', enabled: true,
        condition: { metric: 'engagement', op: '<', value: 0.35 }, durationSec: 6, cooldownSec: 45,
        action: { type: 'setIntensity', param: 0.3 } },
    ],
  },
  {
    id:          'focus',
    name:        'Deep Focus',
    description: 'Balanced adaptive session. Rewards sustained engagement, corrects attention breaks, escalates for peak performance.',
    icon:        '🎯',
    rampSettings: {
      enabled:   true,
      mode:      'adaptive',
      startVal:  0.5,
      endVal:    1.6,
      curve:     'sine',
      steps:     [],
      blendMode: 'max',
    },
    pacingSettings: {
      enabled:      true,
      minSpeed:     0.75,
      maxSpeed:     1.5,
      smoothingSec: 5,
      curve:        'exponential',
      lockDuringSec: 2,
    },
    rules: [
      { name: '[Focus] Pause on attention break', enabled: true,
        condition: { metric: 'attention', op: '<', value: 0.3 }, durationSec: 3, cooldownSec: 30,
        action: { type: 'pause', param: null } },
      { name: '[Focus] Escalate on peak engagement', enabled: true,
        condition: { metric: 'engagement', op: '>=', value: 0.85 }, durationSec: 12, cooldownSec: 90,
        action: { type: 'setIntensity', param: 1.4 } },
      { name: '[Focus] Recover from disengagement', enabled: true,
        condition: { metric: 'engagement', op: '<', value: 0.25 }, durationSec: 8, cooldownSec: 60,
        action: { type: 'setIntensity', param: 0.7 } },
    ],
  },
  {
    id:          'freerun',
    name:        'Free Run',
    description: 'No adaptive behavior. Manual control only. Clears all ramp/pacing settings.',
    icon:        '▶',
    rampSettings:   null,
    pacingSettings: null,
    rules: [],
  },

  // ── Purpose-built modes ───────────────────────────────────────────────────
  {
    id:          'induction',
    name:        'Guided Induction',
    description: 'Hypnosis and trance work. Very slow engagement ramp, no abrupt interruptions. Pauses gently on attention breaks to deepen the trance rather than breaking it.',
    icon:        '🌀',
    rampSettings: {
      enabled:   true,
      mode:      'engagement',
      startVal:  0.1,
      endVal:    0.7,
      curve:     'sine',
      steps:     [],
      blendMode: 'replace',
    },
    pacingSettings: {
      enabled:       true,
      minSpeed:      0.3,
      maxSpeed:      0.65,
      smoothingSec:  12,
      curve:         'sine',
      lockDuringSec: 8,
    },
    rules: [
      { name: '[Induction] Slow down on attention break', enabled: true,
        condition: { metric: 'attention', op: '<', value: 0.2 }, durationSec: 8, cooldownSec: 60,
        action: { type: 'setSpeed', param: 0.3 } },
      { name: '[Induction] Deepen on sustained focus', enabled: true,
        condition: { metric: 'attention', op: '>=', value: 0.8 }, durationSec: 15, cooldownSec: 90,
        action: { type: 'setIntensity', param: 0.8 } },
    ],
  },

  {
    id:          'conditioning',
    name:        'Behavioral Conditioning',
    description: 'Reward-and-correction loop. Escalates intensity for sustained compliance, reduces for breaks. Builds consistent behavioral patterns over repeat sessions.',
    icon:        '⚙',
    rampSettings: {
      enabled:   true,
      mode:      'adaptive',
      startVal:  0.4,
      endVal:    1.2,
      curve:     'exponential',
      steps:     [],
      blendMode: 'max',
    },
    pacingSettings: {
      enabled:       true,
      minSpeed:      0.8,
      maxSpeed:      1.6,
      smoothingSec:  4,
      curve:         'exponential',
      lockDuringSec: 2,
    },
    rules: [
      { name: '[Conditioning] Reward sustained attention', enabled: true,
        condition: { metric: 'attention', op: '>=', value: 0.75 }, durationSec: 10, cooldownSec: 45,
        action: { type: 'setIntensity', param: 1.2 } },
      { name: '[Conditioning] Correct attention break', enabled: true,
        condition: { metric: 'attention', op: '<', value: 0.3 }, durationSec: 4, cooldownSec: 30,
        action: { type: 'setIntensity', param: 0.4 } },
      { name: '[Conditioning] Escalate on peak compliance', enabled: true,
        condition: { metric: 'engagement', op: '>=', value: 0.9 }, durationSec: 12, cooldownSec: 90,
        action: { type: 'setIntensity', param: 1.5 } },
    ],
  },

  {
    id:          'training',
    name:        'Operator-Led Training',
    description: 'Designed for partner sessions. Conservative automatic behavior — operator controls intensity and pacing manually via Live Controls. Auto-safety pauses only on complete attention loss.',
    icon:        '🎛',
    rampSettings: {
      enabled:   true,
      mode:      'time',
      startVal:  0.3,
      endVal:    0.9,
      curve:     'linear',
      steps:     [],
      blendMode: 'replace',
    },
    pacingSettings: {
      enabled:       false,
      minSpeed:      0.5,
      maxSpeed:      2.0,
      smoothingSec:  3,
      curve:         'linear',
      lockDuringSec: 0,
    },
    rules: [
      { name: '[Training] Safety pause on loss', enabled: true,
        condition: { metric: 'attention', op: '<', value: 0.15 }, durationSec: 6, cooldownSec: 60,
        action: { type: 'pause', param: null } },
    ],
  },

  {
    id:          'surrender',
    name:        'Deep Surrender',
    description: 'High-trust, full-escalation solo mode. Continuous climb with no automatic pauses. Surrender to the experience — use the emergency stop if you need to break.',
    icon:        '🌊',
    rampSettings: {
      enabled:   true,
      mode:      'time',
      startVal:  0.2,
      endVal:    2.0,
      curve:     'exponential',
      steps:     [],
      blendMode: 'max',
    },
    pacingSettings: {
      enabled:       true,
      minSpeed:      0.5,
      maxSpeed:      2.0,
      smoothingSec:  6,
      curve:         'exponential',
      lockDuringSec: 0,
    },
    rules: [],
  },
];

// ── Apply a session mode ──────────────────────────────────────────────────────
export function applySessionMode(modeId) {
  const mode = SESSION_MODES.find(m => m.id === modeId);
  if (!mode) {
    notify.error(`Unknown session mode: ${modeId}`);
    return;
  }

  history.push();

  // Apply ramp settings
  state.session.rampSettings = mode.rampSettings ? { ...mode.rampSettings } : null;

  // Apply pacing settings
  state.session.pacingSettings = mode.pacingSettings ? { ...mode.pacingSettings } : null;

  // Track which mode is active so suggestions and other systems can read it
  state.session.mode = modeId;

  // Remove any previous mode rules (identified by stable _modeSource metadata,
  // not display-name prefix — so renamed rules are still cleaned up correctly).
  if (!state.session.rules) state.session.rules = [];
  state.session.rules = state.session.rules.filter(r => !r._modeSource);

  // Add new mode rules, tagged with the mode id so future mode switches can find them.
  for (const ruleDef of (mode.rules ?? [])) {
    state.session.rules.push(normalizeRule({ ...ruleDef, _modeSource: modeId }));
  }

  persist();
  notify.success(`Session mode applied: ${mode.icon} ${mode.name}`);
  return mode;
}

// ── Mode selector HTML ────────────────────────────────────────────────────────
export function renderModeSelector(containerId = 'sessionModeSelector') {
  const el = document.getElementById(containerId);
  if (!el) return;

  el.innerHTML = `
    <div class="insp-group-label" style="margin-bottom:8px">Session Mode</div>
    <p style="font-size:11px;color:var(--text2);line-height:1.6;margin-bottom:10px">
      Applies a preset combination of intensity ramp, pacing, and behavioral rules.
      Existing mode rules are replaced; custom rules are preserved.
    </p>
    <div style="display:flex;flex-direction:column;gap:6px">
      ${SESSION_MODES.map(m => `
        <div style="background:rgba(255,255,255,0.03);border:0.5px solid rgba(255,255,255,0.07);
          border-radius:8px;padding:8px 10px">
          <div style="display:flex;align-items:center;justify-content:space-between">
            <span style="font-size:11px;font-weight:600;color:var(--text)">${m.icon} ${m.name}</span>
            <button class="mode-apply-btn" data-mode-id="${m.id}"
              style="font-size:11px;padding:3px 10px">Apply</button>
          </div>
          <p style="font-size:10.5px;color:var(--text3);line-height:1.5;margin-top:4px">${m.description}</p>
        </div>`).join('')}
    </div>`;

  el.querySelectorAll('.mode-apply-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const mode = applySessionMode(btn.dataset.modeId);
      // Re-render affected panels
      import('./ui.js').then(({ renderInspector, renderSidebar, syncTransportControls }) => {
        renderSidebar();
        renderInspector();
        syncTransportControls();
      });
      renderRampPanel('rampPanel');
      renderPacingPanel('pacingPanel');
    });
  });
}
