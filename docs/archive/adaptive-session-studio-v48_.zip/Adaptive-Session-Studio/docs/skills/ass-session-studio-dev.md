---
name: ass-session-studio-dev
description: Use this skill when working on the Adaptive Session Studio (ASS) codebase — adding features, fixing bugs, writing tests, or extending session content. Triggers when the user mentions ASS modules by name (state.js, funscript.js, playback.js, etc.), asks to add block types, session modes, content packs, FunScript patterns, suggestions, or rules, or references the .assp format. Also triggers when asked to create visualization blocks, viz animations, BPM generators, or sensor bridge integrations. Use this skill even for adjacent tasks like updating ROADMAP.md, CHANGELOG.md, or test suites.
---

# Adaptive Session Studio — Developer Skill

A browser-native, single-file-served adult session design platform. No bundler, no framework — plain ES modules loaded directly by the browser via a local Apache/Python server.

## Architecture at a Glance

```
js/           38 ES modules, plain browser ESM
tests/        26 test suites, 945+ tests, browser-run harness
css/          style.css (~1,570 lines) — design tokens + component classes
docs/         CHANGELOG.md, ROADMAP.md, guides/
index.html    Single-page app shell
```

**Key constraint:** All modules are `type="module"` in the browser. No Node runtime in production. Tests run in `tests/index.html` (browser) and are syntax-checked by `node --check js/*.js`.

---

## Module Map (38 modules)

### Core Engine
| Module | Role |
|--------|------|
| `state.js` | Session state, normalizers (`normalizeBlock`, `normalizeScene`, `normalizeFunscriptTrack`), IDB persistence via `persist()` |
| `playback.js` | RAF loop, block execution, scene transitions, emergency stop |
| `state-engine.js` | Real-time metric fusion (attention × engagement × intensity) |
| `rules-engine.js` | Behavioral scripting — condition→action rules |
| `trigger-windows.js` | Timed interaction windows with success/failure branches |
| `safety.js` | Hard limits, emergency cooldown, auto-reduce |

### UI & Rendering
| Module | Role |
|--------|------|
| `ui.js` | Sidebar, inspector tabs, `renderFunScriptList()` with heatmap, `handleBlockFieldChange()` |
| `funscript.js` | Multi-lane canvas timeline — overview + FS curve + device state |
| `fullscreen-hud.js` | Fullscreen overlay HUD, `vizStageCanvas` mount point |
| `main.js` | Bootstrap, DOM event wiring, keyboard handler |

### Content & Adaptability
| Module | Role |
|--------|------|
| `content-packs.js` | 5 pre-built session templates, `loadContentPack()`, `renderContentPacksPicker()` |
| `session-modes.js` | 8 modes (exposure/mindfulness/focus/freerun/induction/conditioning/training/surrender) |
| `state-blocks.js` | Calm/Build/Peak/Recovery profiles, `applyStateProfile()` |
| `variables.js` | User-defined `{{varName}}` runtime variables, `setVar` action |
| `suggestions.js` | Real-time session health, `analyzeSession()` |
| `ai-authoring.js` | Claude API session generation — knows all Phase 5 schema |

### FunScript & Devices
| Module | Role |
|--------|------|
| `funscript.js` | Parse/export/interpolate FunScript, Buttplug WebSocket device |
| `funscript-patterns.js` | 10 pre-generated patterns + `generateFromBPM()` |
| `viz-blocks.js` | 5 Canvas animations (`mountVizBlock`, `unmountVizBlock`) + BPM generator |
| `sensor-bridge.js` | WebSocket biometric input → engagement engine |
| `macros.js` | FunScript macro library, slots, injection engine |

### Analytics & Profile
| Module | Role |
|--------|------|
| `session-analytics.js` | Post-session data, `showPostSessionModal()` |
| `metrics-history.js` | Daily metrics IDB, SVG chart, CSV/JSON import |
| `user-profile.js` | Profile panel (oxblood/gold aesthetic), milestones |

---

## Key Patterns

### Adding a new block type (e.g. `foo`)

1. **`state.js`** — Add `foo` fields to `normalizeBlock()`:
   ```js
   fooParam: block?.fooParam ?? defaultValue,
   ```
2. **`ui.js`** — Add `BLOCK_ICONS['foo'] = '⬛'` and a `tag-*` color in `colorTag`. Add `} else if (block.type === 'foo') {` branch in `renderOverlayTab()`.
3. **`index.html`** — Add `<button data-add-block="foo">⬛</button>` to the track panel.
4. **`playback.js`** — Import renderer, add `if (block.type === 'foo') { ... }` in `_executeBlock()`.
5. **`state.test.js`** — Add `normalizeBlock` round-trip tests for all new fields.

### Adding a session mode

In `session-modes.js`, push to `SESSION_MODES`:
```js
{
  id: 'my-mode', name: 'My Mode', icon: '⬛',
  description: '...',
  rampSettings: { enabled: true, mode: 'time', ... },
  pacingSettings: { enabled: true, ... },
  rules: [
    { name: '[MyMode] ...', enabled: true,
      condition: { metric: 'attention', op: '<', value: 0.3 },
      durationSec: 5, cooldownSec: 30,
      action: { type: 'pause', param: null },
      _modeSource: undefined  // added by applySessionMode()
    }
  ],
}
```
Add tests to `tests/session-modes.test.js`.

### Adding a content pack

In `content-packs.js`, push to `CONTENT_PACKS`:
```js
{
  id: 'my-pack', name: 'My Pack', category: 'Category',
  icon: '⬛', suggestedMode: 'induction',
  description: '...',
  session: {
    name: '...', duration: 300, loopMode: 'none',
    scenes: [{ name: 'Settle', start: 0, end: 60, stateType: 'calm', ... }],
    blocks: [{ type: 'text', label: '...', start: 0, duration: 15, content: '...' }],
    variables: { score: { type: 'number', value: 0, description: '' } },
  },
}
```

### Adding a suggestion

In `suggestions.js` → `analyzeSession()`, before the `all_good` check:
```js
if (someCondition) {
  suggestions.push({
    id: 'my_suggestion_id',
    severity: 'warn',  // 'warn' | 'info'
    title: 'Short title',
    detail: 'Longer explanation with actionable advice.',
  });
}
```
Add tests to `tests/suggestions.test.js`.

### Adding a FunScript pattern

In `funscript-patterns.js`, push to `FUNSCRIPT_PATTERNS`:
```js
{
  id: 'my-pattern', name: 'My Pattern',
  category: 'Steady',  // Steady | Natural | Escalating | Calming
  icon: '⬛', description: '...',
  inverted: false, range: 100,
  actions: sample(t => /* position 0–100 */, 60_000, 100),
}
```

---

## State Shape (critical fields)

```js
state.session = {
  name, duration, loopMode, loopCount, speechRate, masterVolume,
  blocks: [{ id, type, label, start, duration, content, fontSize,
             volume, voiceName, dataUrl, dataUrlName, mediaKind, mute, _position,
             macroSlot, macroId,
             vizType, vizSpeed, vizColor }],   // viz block fields
  scenes: [{ id, name, start, end, loopBehavior, color, nextSceneId, stateType }],
  rules:  [{ id, enabled, name, condition, durationSec, cooldownSec, action, _modeSource }],
  triggers: [{ id, enabled, name, atSec, windowDurSec, cooldownSec, condition,
               successAction, failureAction }],
  variables: { varName: { type, value, description } },
  funscriptTracks: [{ id, name, version, inverted, range, actions, _disabled, _color, variant }],
  // + audioTracks, videoTracks, subtitleTracks, macroLibrary, macroSlots
  rampSettings, pacingSettings, safetySettings,
  funscriptSettings: { speed, invert, range },
  mode,  // session mode id
}

state.runtime = {
  sessionTime, loopIndex, totalLoops, paused, activeBlock, activeScene,
  triggered, playingOneShots, backgroundAudio, backgroundVideo,
  analytics, speechUtterance, injection,
}

state.engineState = { attention, engagement, intensity, speed }
state.liveControl = { intensityScale, speedScale, variation, randomness }
```

---

## Test Infrastructure

Tests run in the browser via `tests/index.html`. Each suite:
```js
// tests/my-feature.test.js
import { makeRunner } from './harness.js';
export function runMyFeatureTests() {
  const R = makeRunner('my-feature.js');
  const t = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  t('description', () => { ok(true); });

  return R.summary();  // returns Promise<{ passed, failed, name }>
}
```

Register in `tests/index.html`:
```html
import { runMyFeatureTests } from './my-feature.test.js';
// ... in Promise.all:
runMyFeatureTests(),
```

Syntax is checked with `node --check js/*.js && node --check tests/*.test.js`.

---

## Design System

CSS design tokens in `css/style.css`:

```css
/* Surfaces */
--bg, --surface, --surface2–5
/* Accents */
--accent (#e8963a amber), --danger (#d94f4f)
/* Profile/modal palette */
--ox (#7a1a2e oxblood), --gold (#c49a3c), --ivory, --ivory2
/* Oxblood variants: --ox-dim, --ox-br, --ox-glow */
/* Gold variants: --gold-dim, --gold-br, --gold-glow */
/* Typography */
--font (Space Grotesk), --mono (JetBrains Mono)
--serif (Playfair Display), --dmono (DM Mono)
/* State block colors */
calm=#5fa8d3, build=#f0c040, peak=#7a1a2e(oxblood), recovery=#7dc87a
```

Block type tags: `.tag-blue` (text), `.tag-green` (tts), `.tag-amber` (audio), `.tag-purple` (video), `.tag-pink` (macro), `.tag-teal` (viz).

---

## Critical Invariants

1. **`setVar` must be in all action type allowlists** — `state.js` inline normalizers AND `rules-engine.js` AND `trigger-windows.js`. Past bug: was missing from `state.js`, silently reset to `pause`/`none` on import.
2. **All async `render*` functions must be `await`ed** — `renderProfilePanel`, `renderMetricsChart` etc. are async. Missing `await` causes UI race conditions.
3. **FunScript pattern actions must be clamped to [0,100]** — `clamp()` before pushing any action.
4. **New block fields need to be in `normalizeBlock()`** — otherwise imports strip them.
5. **`history.push()` before any mutation that should be undoable.**

---

## Common Commands

```bash
# Syntax check everything
node --check js/*.js && node --check tests/*.test.js

# Count tests
grep -c "^  t(" tests/*.test.js | awk -F: '{sum+=$2} END{print sum " tests"}'

# Package for delivery
cd /home/claude && zip -r output.zip Adaptive-Session-Studio/ -x "*.DS_Store" -q
```
