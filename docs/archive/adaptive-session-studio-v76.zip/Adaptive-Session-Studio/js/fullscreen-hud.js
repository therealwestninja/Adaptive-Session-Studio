// ── fullscreen-hud.js ──────────────────────────────────────────────────────
// Fullscreen HUD v2: session info, live metric bars, scene/state-block
// indicator, macro slot pills, active variable chips, and live-control toasts.

import { state, fmt, esc, $id } from './state.js';
import { getSlotMacro }         from './macros.js';
import { getAllVariables }       from './variables.js';
import { stateTypeLabel }        from './state-blocks.js';

let _mouseIdleTimer = null;
let _toastTimer     = null;

const TOAST_SHOW_MS = 1400;

// ── Init ──────────────────────────────────────────────────────────────────────
export function initFullscreenHud() {
  const stage = $id('mainStage');
  if (!stage) return;

  stage.addEventListener('mousemove', () => {
    _showHud();
    clearTimeout(_mouseIdleTimer);
    const delay = (state.session?.hudOptions?.hideAfterSec ?? 2.5) * 1000;
    _mouseIdleTimer = setTimeout(_hideHud, delay);
  });

  document.addEventListener('fullscreenchange', () => {
    if (document.fullscreenElement === stage) {
      updateHud();
      _showHud();
      const delay = (state.session?.hudOptions?.hideAfterSec ?? 2.5) * 1000;
      _mouseIdleTimer = setTimeout(_hideHud, delay);
      stage.style.cursor = '';
    } else {
      _showHud();
      clearTimeout(_mouseIdleTimer);
    }
  });
}

function _showHud() {
  $id('fullscreenHud')?.classList.remove('fshud-hidden');
  const stage = $id('mainStage');
  if (stage && document.fullscreenElement === stage) stage.style.cursor = '';
}

function _hideHud() {
  $id('fullscreenHud')?.classList.add('fshud-hidden');
  const stage = $id('mainStage');
  if (stage && document.fullscreenElement === stage) stage.style.cursor = 'none';
}

// ── Full HUD update ───────────────────────────────────────────────────────────
export function updateHud() {
  if (!document.fullscreenElement) return;

  const rt  = state.runtime;
  const s   = state.session;
  const es  = state.engineState;
  const lc  = state.liveControl;
  const hud = s.hudOptions ?? {};  // graceful defaults if field missing

  // ── Title (always shown) ──────────────────────────────────────────────────
  const titleEl = $id('fsHudTitle');
  if (titleEl) titleEl.textContent = esc(s.name || 'Session');

  const timeEl = $id('fsHudTime');
  if (timeEl) {
    if (rt) {
      const loopStr = rt.totalLoops ? ` · Loop ${rt.loopIndex + 1}/${rt.totalLoops}` : '';
      timeEl.textContent = `${fmt(rt.sessionTime)} / ${fmt(s.duration)}${loopStr}`;
    } else {
      timeEl.textContent = `— / ${fmt(s.duration)}`;
    }
  }

  // ── Scene + state block indicator (toggleable) ────────────────────────────
  const sceneEl = $id('fsHudScene');
  if (sceneEl) {
    const showScene = hud.showScene !== false;
    const scene = rt?.activeScene?.scene;
    if (showScene && scene) {
      const tag = scene.stateType ? ` ${stateTypeLabel(scene.stateType)}` : '';
      sceneEl.textContent = `${esc(scene.name)}${tag}`;
      sceneEl.style.display = '';
    } else {
      sceneEl.style.display = 'none';
    }
  }

  // ── Metric bars (toggleable) ──────────────────────────────────────────────
  const metricsEl = $id('fsHudMetrics');
  if (metricsEl) {
    const show = hud.showMetricBars !== false;
    metricsEl.style.display = show ? '' : 'none';
    if (show && es) {
      _setBar('fsBar_attention',  Math.round((es.attention  ?? 0) * 100));
      _setBar('fsBar_engagement', Math.round((es.engagement ?? 0) * 100));
      const intPct = lc
        ? Math.round(((lc.intensityScale ?? 1) * (es.intensity ?? 1)) / 2 * 100)
        : Math.round((es.intensity ?? 0) * 50);
      _setBar('fsBar_intensity', Math.min(100, intPct));
    }
  }

  // ── Macro slot pills (toggleable) ─────────────────────────────────────────
  const pillsSection = $id('fsHudMacroSection');
  const pillsEl = $id('fsHudSlotPills');
  const showMacros = hud.showMacroSlots !== false;
  if (pillsSection) pillsSection.style.display = showMacros ? '' : 'none';
  if (showMacros && pillsEl) {
    pillsEl.innerHTML = [1, 2, 3, 4, 5].map(slot => {
      const macro = getSlotMacro(slot);
      if (!macro) return '';
      const active = state.injection?.macroName === macro.name;
      return `<div class="fshud-slot-pill${active ? ' active' : ''}">
        <span class="fshud-slot-key">${slot}</span>
        <span class="fshud-slot-name">${esc(macro.name)}</span>
      </div>`;
    }).join('');
  }

  // ── Variable chips (toggleable) ───────────────────────────────────────────
  const varsEl = $id('fsHudVars');
  if (varsEl) {
    const showVars = hud.showVariables !== false;
    if (!showVars) { varsEl.style.display = 'none'; }
    else {
      const vars = getAllVariables();
      const chips = Object.entries(vars).filter(([, v]) => {
        if (v.type === 'number')  return v.value !== 0;
        if (v.type === 'boolean') return v.value === true;
        if (v.type === 'string')  return v.value !== '';
        return false;
      });
      if (chips.length) {
        varsEl.style.display = '';
        varsEl.innerHTML = chips.map(([n, v]) =>
          `<div class="fshud-var-chip">${esc(n)} <span>${esc(String(v.value))}</span></div>`
        ).join('');
      } else {
        varsEl.style.display = 'none';
      }
    }
  }

  // ── Keyboard hint (toggleable) ────────────────────────────────────────────
  const hintEl = $id('fsHudHint');
  if (hintEl) hintEl.style.display = hud.showHint ? '' : 'none';
}

// ── Tick ──────────────────────────────────────────────────────────────────────
export function tickHud() {
  if (!document.fullscreenElement) return;
  updateHud();
}

// ── Live control toast ────────────────────────────────────────────────────────
// Shown briefly when [ ] , . R are pressed during fullscreen.
export function showLiveControlToast(message) {
  const el = $id('liveControlToast');
  if (!el) return;
  el.textContent = message;
  el.style.display = 'block';
  // Restart animation
  el.style.animation = 'none';
  void el.offsetWidth; // reflow
  el.style.animation  = '';
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => { el.style.display = 'none'; }, TOAST_SHOW_MS);
}

// ── Idle screen ───────────────────────────────────────────────────────────────
// Replaces the plain "Space to play" with contextual session info.
export function renderIdleScreen() {
  const el = $id('idleHint');
  if (!el) return;
  const s = state.session;

  // If rich idle screen is disabled, show the minimal hint
  if (s.displayOptions?.richIdleScreen === false) {
    el.innerHTML = `<svg width="26" height="26" viewBox="0 0 26 26" fill="none">
      <circle cx="13" cy="13" r="12" stroke="currentColor" stroke-width="1" opacity=".25"/>
      <path d="M11 8.5l7 4.5-7 4.5V8.5z" fill="currentColor" opacity=".3"/>
    </svg><span>Space to play</span>`;
    return;
  }

  const blockCount   = s.blocks?.length ?? 0;
  const sceneCount   = s.scenes?.length ?? 0;
  const hasFunscript = (s.funscriptTracks?.length ?? 0) > 0;
  const modeName     = s.mode ? s.mode.replace(/-/g, ' ') : null;

  el.innerHTML = `
    <div class="stage-idle-title">${esc(s.name || 'Untitled Session')}</div>
    <div class="stage-idle-meta">
      ${fmt(s.duration)}&nbsp;·&nbsp;${blockCount} block${blockCount !== 1 ? 's' : ''}${
      sceneCount   ? `&nbsp;·&nbsp;${sceneCount} scene${sceneCount !== 1 ? 's' : ''}` : ''}${
      hasFunscript ? '&nbsp;·&nbsp;haptic' : ''}${
      modeName     ? `&nbsp;·&nbsp;${esc(modeName)}` : ''}
    </div>
    <div class="stage-idle-hint">
      <span class="stage-idle-key">Space</span> to begin
    </div>`;
}

// ── Helper ────────────────────────────────────────────────────────────────────
function _setBar(id, pct) {
  const el = $id(id);
  if (el) el.style.width = `${Math.max(0, Math.min(100, pct))}%`;
}
