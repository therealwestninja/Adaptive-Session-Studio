# Adaptive Session Studio

**Adaptive Session Studio** is a self-contained, browser-based authoring and playback environment for creating audio-visual conditioning sessions. It supports timed text overlays, text-to-speech narration, background video and audio playlists, `.ass` subtitle files, `.funscript` haptic scripts, a live macro injection system, and optional webcam attention tracking — all running entirely locally with no server or installation required.

---

## ⚠️ Safety First

This tool can integrate with physical haptic devices and produce continuous automated stimulation. Improper use can cause physical or psychological harm.

- **Never leave a partner or a connected device unattended.**
- Use **ESC × 2** (press Escape twice quickly) to immediately halt all output at any time.
- Read [docs/SAFETY.md](docs/SAFETY.md) before using device integration features.
- If anything feels unsafe or wrong, **stop immediately**.

---

## Quick Start

1. Unzip the package and open `index.html` in Chrome or Edge.
2. Click **Sample** to load a built-in example session.
3. Press **F** for fullscreen, then **Space** to play.
4. Press **ESC** to stop.

Full instructions → [docs/guides/01-quick-start.md](docs/guides/01-quick-start.md)

---

## Documentation

| Document | Description |
|---|---|
| [docs/INSTALL.md](docs/INSTALL.md) | System requirements and setup |
| [docs/SAFETY.md](docs/SAFETY.md) | Safety guidelines and emergency procedures |
| [docs/guides/01-quick-start.md](docs/guides/01-quick-start.md) | Getting up and running in minutes |
| [docs/guides/02-building-sessions.md](docs/guides/02-building-sessions.md) | Creating and editing sessions |
| [docs/guides/03-funscript-and-devices.md](docs/guides/03-funscript-and-devices.md) | FunScript playback and device integration |
| [docs/guides/04-subtitles.md](docs/guides/04-subtitles.md) | Working with .ass subtitle files |
| [docs/guides/05-macro-library.md](docs/guides/05-macro-library.md) | The macro library and live injection |
| [docs/guides/06-webcam-tracking.md](docs/guides/06-webcam-tracking.md) | Attention tracking and automation |
| [docs/guides/07-import-export.md](docs/guides/07-import-export.md) | Sharing and distributing sessions |
| [docs/guides/08-themes-and-settings.md](docs/guides/08-themes-and-settings.md) | Appearance, themes, and all settings |
| [docs/FAQ.md](docs/FAQ.md) | Frequently asked questions |
| [docs/CHANGELOG.md](docs/CHANGELOG.md) | Version history |
| [docs/CONTRIBUTING.md](docs/CONTRIBUTING.md) | How to contribute |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Codebase structure for developers |
| [docs/DEVELOPER.md](docs/DEVELOPER.md) | Developer and maintainer notes |
| [docs/LEGAL.md](docs/LEGAL.md) | License, disclaimers, third-party credits |

---

## Features at a Glance

- **Runs locally** — no server, no account, no internet required after initial font load
- **Session designer** — timed blocks for text, TTS narration, one-shot audio/video, and silence
- **Background layers** — looping audio and video/image playlists
- **Subtitles** — import `.ass` / `.ssa` files with full style and position override support
- **FunScript** — multi-track haptic playback with interactive canvas timeline editor
- **Macro Library** — 8 built-in presets + custom macros, assignable to keys 1–5 for live injection
- **Injection engine** — mathematically blends a macro into any running FunScript with ease in/out
- **Device integration** — Buttplug.io / Intiface Central compatible
- **Webcam tracking** — attention-based auto-pause, FunScript pause, and macro triggering
- **Themes** — 6 built-in dark themes, fully customisable
- **Import/Export** — self-contained `.assp` packages (JSON + base64 media)

---

## Keyboard Shortcuts

| Key | Action |
|---|---|
| `Space` | Play / Pause session |
| `Shift` | Play / Pause FunScript only |
| `1` – `5` | Inject macro from slot |
| `←` `→` | Skip ±10 seconds |
| `↑` `↓` | Skip ±30 seconds |
| `Enter` / `F12` | Graceful stop + exit fullscreen |
| `ESC` | Stop + exit fullscreen |
| `ESC × 2` | **Emergency stop** |
| `F` | Toggle fullscreen |
| `E` | Toggle FunScript edit mode |
| `D` | Duplicate selected block |
| `Delete` | Delete selected block |
| `Ctrl+S` | Export session |
