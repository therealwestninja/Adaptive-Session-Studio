// ── audio-engine.js ────────────────────────────────────────────────────────
// Web Audio API engine for playlist audio tracks.
// Provides proper gain staging, per-track volume, master volume control,
// and linear crossfade between tracks.
//
// One-shot audio blocks (type:'audio') still use HTMLAudioElement directly
// since they are triggered imperatively and need no mixing. Only the
// looping playlist tracks route through this graph.

import { state } from './state.js';

// ── Graph topology ─────────────────────────────────────────────────────────
//
//  BufferSource × N ──► TrackGain × N ──► MasterGain ──► Destination
//
// Each playlist audio track has:
//   - An AudioBuffer (decoded from base64 data URL)
//   - A looping AudioBufferSourceNode
//   - A GainNode (track volume × mute × master)
//
// The MasterGain reflects session.masterVolume × session.advanced.playlistAudioVolume

let _ctx = null;
let _masterGain = null;
const _tracks = [];   // [{ id, sourceNode, gainNode, buffer }]

// ── Init / teardown ─────────────────────────────────────────────────────────
function ensureContext() {
  if (_ctx && _ctx.state !== 'closed') return _ctx;
  _ctx = new (window.AudioContext || window.webkitAudioContext)();
  _masterGain = _ctx.createGain();
  _masterGain.connect(_ctx.destination);
  return _ctx;
}

export async function startAudioEngine() {
  const ctx = ensureContext();
  if (ctx.state === 'suspended') await ctx.resume();

  // Decode and start all non-muted playlist audio tracks
  const { session } = state;
  const masterVol = session.masterVolume * session.advanced.playlistAudioVolume;
  _masterGain.gain.setValueAtTime(masterVol, ctx.currentTime);

  for (const track of session.playlists.audio) {
    if (track._muted) continue;
    await _startTrack(track, ctx);
  }
}

async function _startTrack(track, ctx) {
  try {
    const buffer = await _decodeTrack(track, ctx);
    const gainNode  = ctx.createGain();
    gainNode.gain.setValueAtTime(track.volume ?? 1, ctx.currentTime);
    gainNode.connect(_masterGain);

    const sourceNode = ctx.createBufferSource();
    sourceNode.buffer = buffer;
    sourceNode.loop = true;
    sourceNode.connect(gainNode);
    sourceNode.start(0);

    _tracks.push({ id: track.id, sourceNode, gainNode, buffer });
  } catch (err) {
    console.warn(`[AudioEngine] Failed to start track "${track.name}":`, err);
  }
}

async function _decodeTrack(track, ctx) {
  // Convert base64 data URL to ArrayBuffer
  const dataUrl = track.dataUrl;
  if (!dataUrl) throw new Error('No data URL');
  const base64 = dataUrl.split(',')[1];
  const binary  = atob(base64);
  const bytes   = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return ctx.decodeAudioData(bytes.buffer);
}

// ── Pause / Resume ──────────────────────────────────────────────────────────
export function pauseAudioEngine() {
  _ctx?.suspend();
}

export function resumeAudioEngine() {
  _ctx?.resume();
}

// ── Stop all ────────────────────────────────────────────────────────────────
export function stopAudioEngine() {
  for (const t of _tracks) {
    try { t.sourceNode.stop(); t.sourceNode.disconnect(); t.gainNode.disconnect(); } catch {}
  }
  _tracks.length = 0;
  // Don't close the context — closing prevents reuse and throws if already closed
  // Just suspend it so the browser releases resources
  if (_ctx && _ctx.state !== 'closed') {
    _ctx.suspend();
  }
}

// ── Master volume (live) ────────────────────────────────────────────────────
export function setMasterVolume(vol, fadeSec = 0) {
  if (!_masterGain) return;
  const targetVol = vol * (state.session.advanced.playlistAudioVolume ?? 0.7);
  if (fadeSec > 0) {
    _masterGain.gain.linearRampToValueAtTime(targetVol, _ctx.currentTime + fadeSec);
  } else {
    _masterGain.gain.setValueAtTime(targetVol, _ctx.currentTime);
  }
}

// ── Track mute toggle (live) ────────────────────────────────────────────────
export function setTrackMuted(trackId, muted) {
  const t = _tracks.find(t => t.id === trackId);
  if (!t) return;
  const target = muted ? 0 : (state.session.playlists.audio.find(a => a.id === trackId)?.volume ?? 1);
  t.gainNode.gain.linearRampToValueAtTime(target, _ctx.currentTime + 0.08);
}

// ── Crossfade between two tracks ────────────────────────────────────────────
// Fades out the outgoing track's gain and fades in the incoming track's gain
// over `durationSec` seconds. Used when the user reorders or swaps tracks.
export function crossfade(outgoingId, incomingId, durationSec = 0.6) {
  if (!_ctx) return;
  const now = _ctx.currentTime;
  const out = _tracks.find(t => t.id === outgoingId);
  const inc = _tracks.find(t => t.id === incomingId);
  if (out) {
    out.gainNode.gain.setValueAtTime(out.gainNode.gain.value, now);
    out.gainNode.gain.linearRampToValueAtTime(0, now + durationSec);
  }
  if (inc) {
    inc.gainNode.gain.setValueAtTime(0, now);
    inc.gainNode.gain.linearRampToValueAtTime(
      state.session.playlists.audio.find(a => a.id === incomingId)?.volume ?? 1,
      now + durationSec
    );
  }
}

// ── Refresh volumes from session state ─────────────────────────────────────
// Called when master volume slider moves during playback.
export function refreshVolumes() {
  if (!_masterGain || !_ctx) return;
  const { session } = state;
  const masterVol = session.masterVolume * session.advanced.playlistAudioVolume;
  _masterGain.gain.setValueAtTime(masterVol, _ctx.currentTime);
  for (const t of _tracks) {
    const track = session.playlists.audio.find(a => a.id === t.id);
    if (track && !track._muted) {
      t.gainNode.gain.setValueAtTime(track.volume ?? 1, _ctx.currentTime);
    }
  }
}

// ── Engine available check ───────────────────────────────────────────────────
export function audioEngineAvailable() {
  return !!(window.AudioContext || window.webkitAudioContext);
}
