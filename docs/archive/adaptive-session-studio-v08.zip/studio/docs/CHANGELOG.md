# Changelog

All notable changes are documented here. The format follows [Keep a Changelog](https://keepachangelog.com/).

---

## [v4.2.0] — 2026-04-11

### Added

- **Web Audio API engine** (`audio-engine.js`) — All playlist audio tracks now route through an `AudioContext` graph with per-track `GainNode`s and a master gain stage. Replaces ad-hoc `new Audio()` elements for playlist layers. Real `linearRampToValueAtTime` crossfade between tracks. `refreshVolumes()` updates the graph live from the master volume slider. Graceful fallback to `HTMLAudioElement` on browsers without Web Audio. AudioContext is resumed on first user gesture to satisfy browser autoplay policy.

- **Tracking state machine** (`tracking.js` rewritten) — Seven explicit states: `idle → requesting → warming_up → detecting → lost → unavailable → error`. Single-instance guard: creating a new module stops any previous one. 1.5-second warmup grace period before automation fires. `_onLost()` and `_onReturn()` handlers fire exactly once per attention event (not repeatedly). A "Warming up…" spinner is shown in the webcam panel during warmup. State labels update the camera/face status fields in settings.

- **Sidebar stable IDs** — `normalizeAudioTrack` and `normalizeVideoTrack` now assign stable `uid()` `id` fields. Sidebar rendering uses `data-track-id` attributes. Delete and mute event delegation filters by `track.id` rather than array index — safe when arrays are reordered between render and click.

- **Keyboard shortcuts overlay** (`?` or `/` key) — Inline modal showing all keyboard shortcuts in two columns (Playback / Editor). Dismisses on ESC, click-outside, or pressing `?` again. Built with no external dependencies, styled to match the app design system.

- **Shift+click timeline scrub preview** — Clicking the progress bar while stopped with Shift held previews the session at that position without starting playback: subtitle cue, block text overlay (dimmed), FunScript position meter, and timeline playhead all update. Useful for checking timing without committing to full playback.

- **`trackingWarmup` spinner** — The webcam settings panel shows a spinning "Warming up…" indicator during the 1.5s FaceDetector stabilisation window.

- **ARIA accessibility** — Added `role="main"` to workspace, `role="region"` with label to the stage, `role="group"` with label to transport controls, `role="tablist"` / `role="tab"` with `aria-selected` to inspector tabs, `aria-label` to sidebar and inspector panels. `aria-selected` updated dynamically on tab switch.

- **Visible focus rings** — `:focus-visible` styles added for all interactive elements. Keyboard navigation through the UI now has clear amber/blue focus indicators. Input focus rings unchanged (border-color change). Sidebar items, position buttons, and inspector tabs have contained focus rings.

- **Larger hit targets** — Sidebar mute and delete micro-buttons increased from 14×14px to 20×20px.

- **Crossfade labelled "coming soon"** — The Crossfade setting in Settings → Playback is now visibly disabled with an italic label, so users understand it is not yet implemented rather than assuming it is broken.

- **`?` shortcut in README and docs** — Keyboard shortcut reference updated in README, NEXT-STEPS, and ARCHITECTURE.

### Changed

- `startPlayback` now uses `startPlaylistLayers().then()` since audio engine decode is async. The play button activates and the RAF loop starts after audio layers are ready.
- `pauseMedia` / `resumeMedia` / `stopPlayback` branch on `runtime.usingAudioEngine` to call the audio engine or fallback `HTMLAudioElement` methods accordingly.
- Tracking module no longer calls `alert()` on permission denial — uses lazy `import('./notify.js')` to avoid circular dependency.
- `selectedSidebarId` added to `state` to hold the stable track ID of the selected audio/video sidebar item alongside the existing index.

### Fixed

- Duplicate `safetyDismiss` event handler at the bottom of `main.js` removed.
- Webcam start now guards against double-start via single-instance pattern (`_activeModule`).

---

## [v4.1.0] — 2026-04-11

All 12 PATCH.md bugs fixed. Undo/redo, toast notifications, capability detection, safe persistence, deep import validation. See previous entry for full details.

---

---

## [v4.2.0] — 2026-04-12

### Added

- **Web Audio API engine** (`audio-engine.js`) — Playlist audio tracks now route through an `AudioContext` graph: each track has an `AudioBufferSourceNode` looping through its own `GainNode`, wired to a master `GainNode`. `linearRampToValueAtTime` enables smooth volume changes and crossfade calls. Graceful fallback to `HTMLAudioElement` on browsers without Web Audio. Master volume slider calls `refreshVolumes()` for live gain updates without restarting streams. `crossfade(outId, inId, sec)` exported for future track-swap UI.

- **Tracking state machine** (`tracking.js` rewritten) — 7 explicit states: `idle → requesting → warming_up → detecting → lost → unavailable → error`. Single-instance guard: creating a new module stops any existing one. 1.5s warmup grace period before attention automation fires (prevents false losses on camera open). Status labels auto-update from state metadata table. `trackingWarmup` spinner shown during warmup. `_onLost()` / `_onReturn()` each fire exactly once per loss event via boolean flags reset on state transition.

- **Keyboard shortcuts overlay** — Press `?` or `/` during editing to show a full overlay listing all shortcuts, grouped by Playback and Editor. Click background or press ESC (captured in a focused handler) to dismiss. Rendered entirely in JS without any HTML template.

- **Timeline scrub-preview** — `Shift+Click` on the progress bar previews a position without starting playback: updates progress indicator, time display, HUD text, subtitle cue, overlay text (at 45% opacity), and FunScript position meter. Full playback `seekTo()` still fires on plain click during playback.

- **Sidebar stable IDs for audio/video tracks** — `normalizeAudioTrack` and `normalizeVideoTrack` now assign a `uid()` if no `id` is present. Sidebar delete/mute buttons carry `data-track-id` attributes. Event delegation in `main.js` filters by `track.id` instead of splicing by index — safe even if the array is mutated between render and click. `selectedSidebarId` added to mutable state.

- **ARIA and accessibility** — `role="main"` on workspace, `role="region"` + `aria-live="polite"` on the stage, `role="tablist"` + `role="tab"` + `aria-selected` on inspector tabs, `aria-label` on sidebar, inspector, and all transport buttons. Inspector tab clicks now update `aria-selected`. Focus rings via `:focus-visible` with amber outline (not suppressed like `:focus` was before). Sidebar mute/delete hit targets enlarged from 14×14px to 20×20px.

- **Crossfade "coming soon" label** — The crossfade seconds input in Settings → Playback is now visually disabled with an italic label to prevent confusion (the setting was exposed but had no effect).

- **`@keyframes spin`** for the webcam warmup indicator.

### Fixed

- Duplicate `safetyDismiss` event listener removed from the bottom of `main.js` (was registered twice).
- `startPlaylistLayers` is now `async` and `await`ed before RAF loop begins — prevents the play button responding before audio buffers are decoded.
- `stopPlayback` branches on `runtime.usingAudioEngine` to call `stopAudioEngine()` instead of iterating `backgroundAudio` elements (which would be empty when the engine is active).

---

## [v4.1.0] — 2026-04-11

All 12 PATCH.md bugs fixed. Undo/redo, toast notifications, capability detection, safe persistence, deep import validation.

---

## [v4.0.0] — 2026-04-11

Complete redesign over v3. See full entry below.

---

---

## [v4.1.0] — 2026-04-11

### Fixed (PATCH.md — all 12 issues)

- **#1** `normalizeSession()` no longer replaces an intentionally empty `blocks: []` with the sample session. Only a missing or non-array `blocks` field falls back to the sample.
- **#2** Webcam tracking module is now stopped before a new one is created on settings re-open. The `<dialog>` `close` event releases the camera regardless of how the dialog was dismissed. `start()` guards against double-start.
- **#3** FunScript timeline drag now holds an object reference to the dragged action instead of an array index. The array is sorted only on `mouseup`, so dragging across neighbouring timestamps no longer edits the wrong point.
- **#4** Point selection is now `{ trackId, actionRef }` rather than a bare index. Multi-track sessions can no longer show false shared selection across tracks.
- **#5** Device connection now sends `RequestDeviceList` and `StartScanning` after the `ServerInfo` handshake. Handles `DeviceList`, `DeviceAdded`, `DeviceRemoved`, `ScanningFinished`, and `Error` messages. Status display updated: `Connecting…` → `Scanning…` → `Device: <name>` or `No device found`.
- **#6** Duplicate `id="deviceStatus"` replaced with class `.device-status-display`. `updateDeviceStatus()` uses `querySelectorAll` to update all instances. Settings panel and FunScript inspector both update correctly.
- **#7** One-shot video blocks now explicitly pause and clear `src` on all previous background video elements before replacing `runtime.backgroundVideo`. Detached media can no longer keep decoding/playing audio.
- **#8** Emergency stop HUD message (`🛑 EMERGENCY STOP`) is now set *after* `stopPlayback()` rather than before, so it is not immediately overwritten by the `Idle` reset. Persists for 4 seconds.
- **#9** Transport loop toggle now cycles all four modes: Off → Loop → Min → ∞. `minutes` mode was previously unreachable from the transport bar.
- **#10** All import handlers (`addAssInput`, `addFunscriptInput`, macro library import) are wrapped in `try/catch`. `importMacroFile()` validates JSON structure and action arrays before saving. `importFunScriptFile()` re-throws on invalid files. All errors shown via `notify.error()`.
- **#11** Skip button tooltips and FunScript settings hint corrected from ±5s to ±10s.
- **#12** Session name can now be cleared to an empty string (`||` → `??` in `syncSessionFromSettings`).

### Added

- **Undo / Redo** — `history.js` module: snapshot-based history with 60-step stack. `Ctrl+Z` to undo, `Ctrl+Y` / `Ctrl+Shift+Z` to redo. Undo/Redo buttons in topbar (disabled when stack is empty). Block field edits, duplicates, deletes, and JSON apply are all undoable. History cleared on new session / import.
- **Toast notification system** — `notify.js`: non-blocking toasts replace all `alert()` calls. Types: `info` (3.5s), `success` (3s), `warn` (5s), `error` (sticky, click to dismiss). `notify.confirm()` provides a styled async confirmation dialog replacing destructive `alert()`/confirm patterns.
- **Browser capability detection** — `capabilities.js`: detects FaceDetector, Web Speech API, fullscreen, Web Audio, IndexedDB at startup. Dims and disables controls that require unavailable features (`requires-face-detector` class). Warns on startup if critical features are missing (once, with 1.2s delay).
- **Safe persistence** — `persist()` now wraps `localStorage.setItem` in `try/catch`. `QuotaExceededError` shows a sticky `notify.error()` and sets a visible "⚠ Unsaved" badge in the topbar. Tracks `persistState.dirty`, `persistState.error`, `persistState.lastSaved`.
- **Storage budget check** — On startup (2s delay), checks localStorage usage. Warns via toast if >80% of estimated 5MB quota is used.
- **Deep import validation** — `normalizeSession()` now calls dedicated normalizers for every nested structure: `normalizeAudioTrack`, `normalizeVideoTrack`, `normalizeFunscriptTrack`, `normalizeSubtitleTrack`, `normalizeMacro`. All numeric fields are clamped; invalid entries are filtered rather than silently accepted.
- **`notify.confirm()` dialogs** — New Session and Load Sample now ask for confirmation before destroying unsaved work.
- **Import success feedback** — All import operations (session, audio, video, .ass, .funscript, macro) show a `notify.success()` with filename and item count.
- **Export success feedback** — Exporting a session shows a `notify.success()` with the downloaded filename.

### Changed

- `window._stateModule` now exposes `normalizeSession` so `history.js` can restore snapshots without a circular import.
- All `alert()` calls removed from the codebase and replaced with `notify.*` equivalents.
- `emergencyStop` calls `stopPlayback()` first, then sets the HUD, fixing the overwrite bug.
- Settings dialog `close` event (not just the close button) stops webcam tracking.

---

## [v4.0.0] — 2026-04-11

Complete redesign and major feature addition over v3. See previous entries below.

---

---

## [v4.0.0] — 2026-04-11

Complete redesign and major feature addition over v3.

### Added

- **New UI architecture** — Multi-file ES module codebase replacing the single-file IIFE. Files: `state.js`, `playback.js`, `funscript.js`, `macros.js`, `macro-ui.js`, `subtitle.js`, `tracking.js`, `fullscreen-hud.js`, `ui.js`, `main.js`.
- **Macro Library** — 8 built-in FunScript presets (thrust in, pull out, pump, piston, prod, poke, stroke, rub). User-created macros with inline action-point editor and mini canvas preview. Sort by name, duration, or type. Import/export individual macros as `.funscript` files.
- **Macro injection engine** — Keys 1–5 inject a macro into any running FunScript with cubic ease-in/out blending. Injection HUD indicator on stage. Configurable slot assignments. Works standalone (no background FunScript required).
- **FunScript-only pause** — Shift key pauses/resumes device output independently of the session clock, audio, and text overlays. Indicator on stage.
- **Safe-skip easing** — Arrow key skips ease device output to zero over 300ms before jumping to the new position, preventing abrupt device movements.
- **Emergency stop** — ESC × 2 immediately sends `StopAllDevices` to Intiface, cancels all audio, and stops the session. Distinct from single-ESC graceful stop.
- **Webcam → FunScript integration** — Options to pause FunScript on attention loss, inject macros on attention loss and return, independently of session pause.
- **Fullscreen HUD** — Auto-hiding overlay in fullscreen mode showing session name, time/loop counter, macro slot assignments, keyboard hint, and ESC × 2 reminder. Hides after 2.5s of cursor inactivity.
- **FunScript timeline canvas** — Interactive canvas rendering FunScript curves, session block bands, subtitle cue markers, and live playhead. Supports add/drag/delete point editing in edit mode (E key).
- **FunScript position meter** — Vertical bar on stage showing current output position (0–100%) colour-coded by intensity.
- **Multi-track FunScript** — Multiple `.funscript` files can be loaded simultaneously; output is the maximum position across all active tracks.
- **Dedicated Settings dialog** — Six-tab modal (Appearance, Playback, FunScript, Macros, Subtitles, Webcam, Advanced) replacing scattered inline form fields.
- **Inspector panel** — Context-sensitive right panel with Overlay, Session, and Status tabs. Status tab shows live time, loop, and active block during playback.
- **Position grid** — Text overlay blocks can be placed at 9 positions (3×3 grid) in the inspector.
- **Dusk and Slate themes** — Two new built-in themes added (total: 6).
- **Live slider labels** — Range sliders in settings show their current value next to the control.
- **Safety banner** — Dismissible safety reminder bar at the top of the UI.
- **README.md and full documentation suite** — INSTALL, SAFETY, 8 how-to guides, FAQ, CHANGELOG, CONTRIBUTING, ARCHITECTURE, DEVELOPER, LEGAL.

### Changed

- **Keyboard shortcuts revised** — Arrow keys now skip ±10s (left/right) and ±30s (up/down) per README spec. Enter and F12 added as graceful stop keys. Shift changed from keydown toggle to standalone keyup detection to prevent conflict with Shift+number macros.
- **Loop toggle** — Cycles between Off / Loop / ∞ with updated button label.
- **`.ass` import** — Fixed double `file.text()` read bug (text was read twice, second read always returned empty string).
- **Position indicator** — `updatePositionIndicator` now shows/hides the meter container based on whether active FunScript tracks exist.
- **Session model** — Added `macroLibrary`, `macroSlots`, `trackingFsOptions`, `funscriptSettings.speed/invert/range` fields. Package version bumped to 4.

### Fixed

- `_lastSentPos` mutable export replaced with `fsState` object to avoid stale binding in ES module imports.
- `.ass` file timestamp parsing now handles both `.` and `,` as centisecond separators.
- Inspector session tab duration changes now update the transport bar `tTotal` display.
- Webcam tracking module now correctly handles the return-from-loss event with a single-fire flag (`returnInjected`) to prevent repeated macro injection.

---

## [v3.0.0] — (prior version, ChatGPT-generated)

### Features present in v3

- Single-file architecture (`index.html`, `styles.css`, `app.js`)
- Theme selector (midnight, ember, moss, violet) with custom theme builder
- Advanced Settings dialog
- Script timeline table with inline start/end/duration editing
- Subtitle-style timing tools (nudge ±0.5s, stretch, clone near cursor)
- Timeline overview minimap
- Webcam attention tracking with FaceDetector API
- Auto-pause/resume on attention loss
- Playlist audio and video tracks
- TTS block type with voice name field
- One-shot audio/video blocks
- Pause blocks
- Import/export `.assp` packages
- JSON preview/apply panel
- localStorage persistence
- Loop modes: none, count, minutes, forever

### Not present in v3

- FunScript support (added in v4)
- Macro Library (added in v4)
- Dedicated Settings modal with tabs (was inline form)
- Inspector panel (was inline block editor)
- FunScript timeline canvas (added in v4)
- Subtitle (.ass) support (added in v4)
- Emergency stop (added in v4)
- Fullscreen HUD (added in v4)
- Position meter (added in v4)

---

## Version Numbering

Versions follow `MAJOR.MINOR.PATCH`:
- **MAJOR** — breaking changes to the `.assp` package format or fundamental UI paradigm
- **MINOR** — significant new features, backward-compatible
- **PATCH** — bug fixes and small improvements
