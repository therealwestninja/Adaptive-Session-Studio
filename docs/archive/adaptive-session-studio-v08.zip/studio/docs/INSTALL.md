# Installation and Setup

Adaptive Session Studio is a self-contained web application. There is no installation process beyond unzipping the package and opening a file in your browser.

---

## System Requirements

### Browser

| Browser | Support | Notes |
|---------|---------|-------|
| **Chrome 90+** | ✅ Recommended | Full support including FaceDetector API |
| **Edge 90+** | ✅ Recommended | Full support including FaceDetector API |
| Firefox 90+ | ⚠️ Partial | No FaceDetector; all other features work |
| Safari 16+ | ⚠️ Partial | No FaceDetector; limited Web Speech API |
| Mobile browsers | ❌ Not supported | UI is designed for desktop |

**Recommended:** Chrome or Edge on a desktop or laptop computer.

### Operating System

Windows, macOS, or Linux. No OS-specific installation required.

### Hardware

- **Minimum:** Any modern computer capable of running Chrome or Edge
- **For webcam tracking:** A working webcam, Chrome or Edge
- **For device integration:** [Intiface Central](https://intiface.com/central/) installed and running; a Buttplug.io-compatible device

---

## Setup

### Step 1 — Unzip

Unzip `adaptive-session-studio-v4.zip` to any folder on your computer. Keep the folder structure intact:

```
adaptive-session-studio/
├── index.html          ← open this
├── README.md
├── css/
│   └── style.css
├── js/
│   ├── main.js
│   ├── state.js
│   ├── playback.js
│   ├── funscript.js
│   ├── macros.js
│   ├── macro-ui.js
│   ├── subtitle.js
│   ├── tracking.js
│   ├── fullscreen-hud.js
│   └── ui.js
└── docs/
    └── ...
```

### Step 2 — Open in Browser

Double-click `index.html`, or drag it into a Chrome or Edge window.

> **Note:** The application loads Google Fonts (Syne, Inter) on first open if you have an internet connection. If you are offline, it falls back to system fonts gracefully.

### Step 3 — Optional: Allow File Access

Because the app uses ES modules (`type="module"` scripts), some browsers block it when opened directly from the filesystem via `file://`. If the app appears blank or the browser console shows CORS errors:

**Option A — Use Chrome with flags (simplest):**

Launch Chrome with `--allow-file-access-from-files`:

```
# Windows
chrome.exe --allow-file-access-from-files

# macOS
open -a "Google Chrome" --args --allow-file-access-from-files

# Linux
google-chrome --allow-file-access-from-files
```

**Option B — Use a local web server (recommended for development):**

```bash
# Python 3
python3 -m http.server 8080
# then open http://localhost:8080

# Node.js (if installed)
npx serve .
# then open http://localhost:3000
```

**Option C — Use VS Code Live Server extension** if you are editing the source.

---

## Device Integration Setup

To use Adaptive Session Studio with a haptic device:

1. Download and install **[Intiface Central](https://intiface.com/central/)** (free, Windows/macOS/Linux).
2. Open Intiface Central and start the server (default address: `ws://localhost:12345`).
3. Connect your device to your computer and let Intiface detect it.
4. In Adaptive Session Studio, open **Settings → FunScript**.
5. Confirm the WebSocket URL is `ws://localhost:12345` and click **Connect**.
6. The device name will appear in the status field when connected.

Refer to [docs/guides/03-funscript-and-devices.md](guides/03-funscript-and-devices.md) for detailed configuration.

---

## Webcam Setup

Webcam attention tracking requires no additional software. When you open **Settings → Webcam** and click **Start Webcam**, your browser will ask for camera permission. Grant it.

Tracking quality depends on:
- Lighting (face must be visible)
- Browser support (Chrome/Edge required for FaceDetector API)
- Camera resolution and frame rate

---

## Updating

Adaptive Session Studio has no auto-update mechanism. To update:

1. Download the new version zip.
2. Unzip to a new folder (or replace the old one).
3. Your sessions are stored in the browser's `localStorage` under the key `adaptive-session-studio-v4`. They persist across version updates as long as the storage key matches.
4. Export important sessions as `.assp` files before replacing your installation, as a backup.

---

## Troubleshooting

**The page is blank or shows a module error:**
→ Use a local web server (see Step 3, Option B above).

**Fonts look wrong:**
→ You may be offline. The app will use system fonts as fallback.

**Device does not respond:**
→ Check that Intiface Central is running and the server is started. Try clicking Disconnect and reconnecting.

**Webcam tracking says "Live preview only":**
→ Your browser does not support the FaceDetector API. Use Chrome or Edge for full tracking support.

**Session clock drifts during long sessions:**
→ Keep the browser tab in focus. Background tab throttling from the browser can cause RAF loop slowdown.

**Audio does not play:**
→ Browsers require a user interaction before playing audio. Click anywhere on the page before starting playback.
