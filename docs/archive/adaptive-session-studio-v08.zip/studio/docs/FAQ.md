# Frequently Asked Questions

---

## General

**Q: Does this require an internet connection?**

No. Once loaded, the app runs entirely in your browser with no network requests. The only internet dependency is the Google Fonts CDN (Syne, Inter), which is loaded when the page first opens. If you are offline, the app falls back to system fonts and works fully.

---

**Q: Does the app send any data anywhere?**

No. Sessions are stored only in your browser's localStorage and the `.assp` files you export. Webcam data is processed locally using browser APIs and never leaves your device. Device control is done via a local WebSocket connection to Intiface Central on your own machine.

---

**Q: Why does the page appear blank when I open it?**

This is usually caused by a browser blocking ES module scripts from `file://` URLs. The fix is to either:
- Launch Chrome with `--allow-file-access-from-files`
- Serve the folder with a local web server (`python3 -m http.server 8080`)

See [INSTALL.md](INSTALL.md) for detailed instructions.

---

**Q: Can I run multiple sessions simultaneously?**

No. The app is single-session. Open multiple browser tabs if you need to compare sessions, but only one can be playing at a time, and each tab has independent localStorage.

---

**Q: Is there a mobile version?**

The app is designed for desktop browsers. It will technically open on mobile but the layout is not adapted for small screens or touch input. A mobile remote control interface is planned for a future version.

---

## Sessions and Files

**Q: My session disappeared. What happened?**

Sessions auto-save to localStorage. localStorage can be cleared by:
- Using private/incognito mode
- Clearing browser data
- The browser itself (on some systems with low storage)

Always export important sessions as `.assp` files. localStorage is a working cache, not permanent storage.

---

**Q: Can I open an old v2 or v3 .assp file?**

Yes. The `normalizeSession()` function upgrades any older package version to the current format, filling missing fields from defaults. You may want to review settings after importing an old package.

---

**Q: The exported .assp file is very large. Why?**

Audio and video media are embedded as base64 data URLs in the JSON, which increases file size by approximately 33% over the original binary. A 50MB audio file becomes ~68MB in the package. This is the trade-off for self-containment. Future versions may support a ZIP-based container format with separate media files.

---

**Q: Can I share my session with someone who doesn't have the same device?**

Yes. Sessions play back perfectly without a connected device — FunScript curves are computed but device output is simply skipped if no device is connected. Recipients can enjoy the audio-visual session without any hardware.

---

## FunScript

**Q: My FunScript script doesn't seem to be playing.**

Check that:
1. The track is enabled (the ● button in the sidebar is not red/muted).
2. Intiface Central is running and a device is connected (Settings → FunScript).
3. The FunScript range is not set to 0.
4. The session is actually playing (not paused or stopped).
5. FunScript-only pause is not active — check for the "⏸ FunScript paused" indicator on stage.

---

**Q: Can I use a FunScript file that's longer than my session duration?**

Yes. The FunScript is indexed by session time in milliseconds. If the session duration is 120 seconds and your FunScript is 600 seconds long, only the first 120 seconds of the FunScript plays per loop. On subsequent loops, the FunScript restarts from 0.

To loop through a longer FunScript, set the session duration to match the FunScript duration.

---

**Q: The device movement feels jerky or out of sync.**

- Reduce FunScript speed (Settings → FunScript → Playback speed).
- Check your Intiface Central connection — a poor USB connection or low Bluetooth signal can cause latency.
- Ensure no other applications are controlling the device simultaneously.
- Check the device firmware is up to date.

---

**Q: What devices are supported?**

Any device supported by [Buttplug.io](https://buttplug.io/). This includes devices from many manufacturers via linear, vibration, and rotation control. Check the [Buttplug.io device list](https://iostindex.com/) for compatibility details.

---

## Subtitles

**Q: My .ass file imports but shows no cues.**

Check that:
1. The `[Events]` section exists in the file.
2. The `Format:` line in `[Events]` lists `Text` as a field.
3. Timestamps are in `h:mm:ss.cs` format (e.g., `0:00:04.00`).
4. End times are greater than start times.
5. The subtitle track is enabled (● not muted).
6. The current session time falls within a cue's start–end window.

---

**Q: Subtitle styling from my .ass file is not being applied.**

By default, Style override is set to "None", which means the app extracts colour information from the `.ass` Style definitions. However, inline override tags (`{\b1}`, `{\i1}`, `{\fn...}`, etc.) inside individual Dialogue lines are stripped before display. Only style-level colour and basic size are respected.

For full `.ass` rendering with fonts, borders, shadows, and positions, you would need a dedicated renderer. This app intentionally simplifies subtitle rendering for overlay clarity.

---

## Webcam

**Q: Webcam tracking says "Live preview only".**

Your browser does not support the FaceDetector API. Use Chrome or Edge on a desktop computer for full attention detection support.

---

**Q: The webcam is still active after I close the settings.**

Stop the webcam explicitly by clicking **Stop Webcam** before closing the settings. Closing the dialog does not release the camera. This is a known limitation — the webcam runs in a separate tracking module that persists across dialog open/close cycles.

---

## Macros

**Q: Pressing 1–5 doesn't inject macros.**

Keyboard shortcuts are suppressed when a text input field is focused. Click the stage area or outside any text field, then try the number keys.

Also confirm that a macro is assigned to the slot (Settings → Macros → Key slots).

---

**Q: Can I inject a macro without a FunScript track loaded?**

Yes. Macros play standalone — the device receives the macro's position sequence directly. You don't need a background FunScript track.

---

**Q: The macro injection feels abrupt.**

The easing window is 350ms. If this feels too short for your device's response characteristics, consider editing the macro to start and end at positions closer to the main track's current value. Presets like "Stroke" and "Poke" have smooth ramps that ease well in most contexts.
