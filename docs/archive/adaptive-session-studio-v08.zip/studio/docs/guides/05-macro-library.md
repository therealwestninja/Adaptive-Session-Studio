# Guide 5: Macro Library and Live Injection

The Macro Library is a collection of short FunScript bursts that can be triggered instantly during playback — injected into any running FunScript with smooth mathematical easing.

---

## What is Macro Injection?

When you press a number key (1–5) during playback, the assigned macro is **injected** into the current FunScript output:

1. The device eases from its current position to the macro's starting position (over ~350ms).
2. The macro plays at the configured speed.
3. The device eases back from the macro's ending position to where the main track would be.
4. The main FunScript resumes seamlessly.

This blending is done with a cubic ease-in/out curve so the transitions feel smooth and there are no abrupt jumps.

---

## Built-in Presets

Eight presets are included and cannot be deleted:

| Preset | Duration | Description |
|--------|----------|-------------|
| **Thrust in** | ~900ms | Slow build from bottom to full depth |
| **Pull out** | ~350ms | Fast withdrawal to zero |
| **Pump** | ~1.5s | Three quick full strokes |
| **Piston** | ~1.5s | Ten rapid short oscillations |
| **Prod** | ~400ms | Single sharp jab and return |
| **Poke** | ~500ms | Lighter, shorter prod (70% depth) |
| **Stroke** | ~2s | Slow, full stroke with pause at top |
| **Rub** | ~1.2s | Small-amplitude rapid oscillation (40–60% range) |

---

## Slot Assignments (Keys 1–5)

Each number key has a **slot** that maps to a macro. By default:

| Key | Default Macro |
|-----|---------------|
| 1 | Thrust in |
| 2 | Pull out |
| 3 | Pump |
| 4 | Piston |
| 5 | Prod |

To reassign a slot:

1. Open **Settings → Macros**.
2. In the **Key slots** section, use the dropdown next to each slot number to choose any macro from the library.
3. The assignment is saved immediately.

In fullscreen mode, the HUD shows which macro is assigned to each slot (visible on mouse movement).

---

## The Macro Library

Open **Settings → Macros** to manage your macro library.

### Sorting

Use the **Name**, **Duration**, and **Type** buttons to sort the list. "Type" groups built-in presets first, then custom macros.

### Inject Directly

The ▶ button next to any macro injects it immediately. Useful for testing during a session or triggering manually without using a slot assignment.

---

## Creating Custom Macros

1. Click **+ New** in the macro library panel.
2. A new macro with three default action points is created and opened in the editor.
3. Edit the **name**.
4. Add, edit, and delete action points in the table:
   - **At (ms)** — timestamp in milliseconds from the start of the macro
   - **Pos (0–100)** — position value at that time
5. The mini preview canvas shows the shape of your macro as you edit.
6. Click **Save** to store.

### Tips for Designing Macros

- Start and end at **0** for clean injection and release (otherwise the easing will bridge from/to whatever the main track is doing, which may feel odd).
- Keep macros **under 3 seconds** for responsive feel; longer macros can be used for deliberate, slow movements.
- Use the **Stroke** preset as a reference for a smooth start-0, end-0 pattern.
- Test macros with the ▶ inject button before assigning them to a slot.

---

## Importing Macros

Click **Import .funscript** to load any `.funscript` file as a macro. The file's actions are imported directly. Assign it to a slot for keyboard access.

---

## Exporting Macros

Click the ↓ button next to any macro to export it as a standard `.funscript` file. This file can be shared or used in other FunScript-compatible applications.

---

## FunScript Speed and Range

The global **speed** and **range** settings (in **Settings → FunScript** or the FunScript track inspector) also affect macro injection:

- **Speed:** The macro's timestamps are divided by the speed multiplier. A speed of 2.0× makes the macro play twice as fast.
- **Range:** All output positions (including macro positions) are scaled to 0–range before being sent to the device.
- **Invert:** Flips positions before output. Applies to macros too.

---

## During Playback

- Press **1–5** at any time during a session to inject the corresponding macro.
- The injection indicator (⚡ macro name) appears briefly near the bottom of the stage.
- Macros can be injected even when the main FunScript is paused via **Shift**.
- If you inject while another injection is in progress, the first is cancelled and the new one begins.
- Injection works even with no FunScript tracks loaded — the macro plays standalone.
