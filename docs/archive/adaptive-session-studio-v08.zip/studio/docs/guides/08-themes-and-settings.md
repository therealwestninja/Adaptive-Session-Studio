# Guide 8: Themes and Settings

---

## Themes

Six built-in themes set the stage background, accent colour, and text colour simultaneously:

| Theme | Background | Accent | Character |
|-------|-----------|--------|-----------|
| **Midnight** | Near-black | Soft blue | Deep, calm |
| **Ember** | Dark red | Warm orange | Intense, warm |
| **Moss** | Dark green | Soft green | Natural, grounded |
| **Violet** | Dark purple | Lavender | Dreamy, dissociative |
| **Dusk** | Dark blue-grey | Amber | Amber-lit, focused |
| **Slate** | Dark blue-black | Teal | Clinical, cool |

### Applying a Theme

Open **Settings → Appearance** and click any theme chip. The stage updates immediately.

### Custom Themes

1. Open **Settings → Appearance → Save custom theme**.
2. Give the theme a key (slug, e.g., `ocean`) and a display name.
3. Pick background, accent, and text colours.
4. Click **Save**. The theme appears in the theme picker.

To delete a custom theme: select it in the picker, then click **Delete**.

---

## All Settings

### Appearance

| Setting | Description |
|---------|-------------|
| Background | Stage background colour (hex) |
| Text colour | Overlay text colour |
| Accent colour | UI accent colour (progress bar, active states) |
| Stage blur | Blur amount applied to background video/image in pixels (0 = sharp) |
| Overlay font family | CSS font stack for text overlays and subtitles |

### Playback

| Setting | Description |
|---------|-------------|
| Session name | Used as the `.assp` export filename |
| Duration per loop | Length of one loop in seconds |
| Loop mode | None / Count / Minutes / Forever |
| Loop count | Number of loops (when mode = Count) |
| Runtime minutes | Total runtime in minutes (when mode = Minutes) |
| TTS speech rate | Speed multiplier for text-to-speech (0.5–2.0) |
| Playlist audio volume | Volume of background audio tracks (0–1) |
| Playlist video volume | Volume of video background tracks (0–1) |
| Crossfade time | Not yet implemented (reserved for future video crossfade) |

### FunScript

| Setting | Description |
|---------|-------------|
| Playback speed | Scales FunScript timestamps. 2.0 = twice as fast |
| Output range | Caps maximum device position (1–100) |
| Invert output | Flips positions: 100 − pos |
| Device WebSocket URL | Address of Intiface Central (default: ws://localhost:12345) |

### Macros

See [Guide 5: Macro Library](05-macro-library.md) for full details.

Key slot assignments, the macro list, and the inline macro editor are all in this tab.

### Subtitles

| Setting | Description |
|---------|-------------|
| Default text colour | Subtitle text colour when no .ass style applies |
| Font size | Size in rem units |
| Position | Bottom / Top / Centre |
| Style override | None / Colour only / Override all |

See [Guide 4: Subtitles](04-subtitles.md) for full details.

### Webcam

All attention tracking and FunScript integration options. See [Guide 6: Webcam Tracking](06-webcam-tracking.md).

### Advanced

- **JSON editor** — view and directly edit the full session JSON.

---

## Transport Bar

The transport bar at the bottom of the main interface provides:

| Control | Description |
|---------|-------------|
| 🔈 slider | Master volume (affects all audio: playlists, TTS, one-shot audio) |
| ■ | Stop |
| ⏪ | Skip back 10 seconds |
| ▶ / ⏸ | Play / Pause |
| ⏩ | Skip forward 10 seconds |
| ↺ | Cycle loop mode: Off → Loop → ∞ |
| Progress bar | Click anywhere to seek to that position |
| Time display | Current position / loop duration |
| Loop display | Current loop / total loops |

---

## Fullscreen Mode

Press **F** to enter fullscreen. The stage fills the screen.

The fullscreen HUD (shown on mouse movement, auto-hides after 2.5s) displays:
- Session name and current time
- Macro slot assignments (which macro is on each key)
- Keyboard controls reminder
- ESC × 2 emergency stop reminder

Move the mouse to show the HUD. It hides automatically to keep the stage clean.
