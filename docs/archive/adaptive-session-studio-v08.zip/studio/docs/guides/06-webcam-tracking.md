# Guide 6: Webcam Attention Tracking

Adaptive Session Studio can use your webcam to detect whether you are paying attention to the screen. Based on this, it can automatically pause the session, pause FunScript output, or trigger macros.

---

## How It Works

The tracking uses the browser's **FaceDetector API** (Chrome/Edge only) to detect a face in the webcam frame. When a face is detected, you are considered "attentive". When no face is detected for longer than the configured threshold, you are considered "inattentive".

In browsers without FaceDetector support (Firefox, Safari), the webcam still provides a live preview but attention detection does not function — all automation based on attention is unavailable.

---

## Setup

1. Open **Settings → Webcam**.
2. Click **Start Webcam**. Grant camera permission when the browser asks.
3. Your webcam feed appears in the settings panel with a face-detection box overlay (green rectangle when a face is found).
4. Configure your desired behaviour (see below).
5. Close the settings and begin your session. Tracking runs in the background.

---

## Session Pause Options

| Setting | Description |
|---------|-------------|
| **Enable attention tracking** | Master toggle. Must be on for any automation to work |
| **Auto-pause session on attention loss** | Pauses the session clock and all audio when attention is lost for the threshold duration |
| **Auto-resume when attention returns** | Automatically resumes the session when attention is detected again |
| **Loss threshold (sec)** | How many seconds of no-face detection before triggering the loss event |

**Recommended starting values:** threshold = 5 seconds, auto-pause on, auto-resume on.

---

## FunScript Integration Options

These settings let attention state affect haptic output independently of the session:

| Setting | Description |
|---------|-------------|
| **Pause FunScript on attention loss** | Stops FunScript device output (eases to zero) when attention is lost, without pausing the session clock |
| **Inject macro on attention loss** | Injects the chosen macro slot when attention loss is first detected |
| **Macro slot on loss** | Which slot (1–5) to use for the loss macro |
| **Inject macro when attention returns** | Injects the chosen macro slot when attention is regained |
| **Macro slot on return** | Which slot (1–5) to use for the return macro |

### Example: Attention-Gated FunScript

Configure:
- Pause FunScript on attention loss: **on**
- Attention loss threshold: **3 seconds**
- Auto-resume when attention returns: **on**

Result: FunScript device output only runs while you are looking at the screen. Look away for 3 seconds and the device eases to zero. Look back and output resumes from the current FunScript position.

### Example: Alert Macro on Distraction

Configure:
- Inject macro on attention loss: **on**
- Macro slot on loss: **Slot 2 (Pull out)**

Result: The first time attention is lost in a loss event (not repeated until attention is regained and lost again), the "Pull out" macro is injected — a physical signal that you looked away.

---

## Status Indicators

While the settings panel is open:

| Field | Meaning |
|-------|---------|
| Camera | "Live" (active), "Off" (stopped), "Denied" (permission refused) |
| Face | "Detected" / "Not detected" / "Live preview" (no FaceDetector) |
| Attention loss | How many seconds since a face was last seen |

---

## Limitations and Notes

**FaceDetector availability:** The API is only available in Chrome and Edge, and requires HTTPS or localhost. When opening via `file://` it may need the `--allow-file-access-from-files` flag. See [INSTALL.md](../INSTALL.md).

**False negatives:** The FaceDetector may lose your face if you tilt your head sharply, move fast, or are in poor lighting. Set a threshold of at least 3 seconds to avoid spurious triggers from momentary detection failures.

**Privacy:** The webcam feed is processed entirely in your browser. No video data is sent anywhere. The face detection is done locally using the browser's built-in API.

**Performance:** Running FaceDetector in a RAF loop has a small CPU cost. If you notice frame drops during playback on a low-powered machine, stop the webcam before playing.

**Stopping the webcam:** Click **Stop Webcam** in the settings. The camera is fully released (the browser indicator light turns off). Closing the settings dialog does not stop the webcam automatically — stop it explicitly before closing if you want the camera released.
