# Guide 4: Subtitles (.ass Files)

Adaptive Session Studio supports the Advanced SubStation Alpha (`.ass` / `.ssa`) subtitle format for timed caption overlays. This guide explains how to import, configure, override, and export subtitle tracks.

---

## What is .ass?

Advanced SubStation Alpha is a rich subtitle format that supports precise timing, multiple style definitions (font, colour, size, alignment, position), and override tags within individual lines. It is widely used for anime subtitles and fansub releases.

A minimal `.ass` file looks like this:

```
[Script Info]
ScriptType: v4.00+

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, ...
Style: Default,Arial,24,&H00FFFFFF&,...

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:04.00,0:00:08.00,Default,,0,0,0,,This is a subtitle cue
```

---

## Importing a Subtitle File

1. In the sidebar, under **Subtitles .ass**, click **+**.
2. Select a `.ass` or `.ssa` file.
3. The track appears with a cue count badge (e.g., "42 cues").
4. Toggle the ● button to enable or disable the track during playback.

Multiple subtitle tracks can be loaded. Adaptive Session Studio plays cues from the first enabled track that has an active cue at the current time.

---

## How Cues Are Displayed

During playback, when the session time falls within a cue's start–end window:

- The cue text is displayed overlaid on the stage, below the main text overlay.
- Override tags (`{\an8}`, `{\c&Hffffff&}`, `{\i1}`, etc.) are **stripped** before display — only the plain text is shown.
- The position, colour, and size are controlled by the **Subtitle Settings** (see below).

---

## Subtitle Settings

Open **Settings → Subtitles** to configure how subtitles appear:

| Setting | Description |
|---------|-------------|
| Default text colour | Hex colour for subtitle text when no style override is active |
| Font size | Size in rem units (1.4 = default) |
| Position | Bottom (default), Top, or Centre of the stage |
| Style override | Controls how much the app overrides the `.ass` file's own styling |

### Style Override Modes

| Mode | Behaviour |
|------|-----------|
| **None** | Use colours and sizes from the `.ass` file's Style definitions |
| **Colour only** | Override colour; use `.ass` font size |
| **Override all** | Ignore `.ass` styles entirely; use the settings above |

---

## Subtitle Timing and the Session Clock

Subtitle cue timestamps are relative to real time (hours:minutes:seconds.centiseconds from the start of the `.ass` file). The session clock maps these to session position.

**Important:** Subtitle cues play relative to the session time within a single loop, not wall-clock time. If your session loops, subtitle cues will replay from the beginning on each loop. Plan your `.ass` file's cue timing to match your session's duration.

If your `.ass` file was originally authored to match a specific video (e.g., a 10-minute clip), and your session loop is also 10 minutes (`duration: 600`), the timing will line up correctly.

---

## The Timeline View

When subtitle tracks are loaded, the FunScript timeline (if visible) shows blue bars at the bottom for each active cue. This helps you visualise subtitle cue density relative to your FunScript curves and session blocks.

---

## Exporting a Subtitle Track

To export a (possibly modified) subtitle track as a `.ass` file:

1. Click the track in the sidebar.
2. In the inspector, click **Export .ass**.

The exported file preserves the original raw `.ass` data. Modified style overrides from the settings panel are **not** baked into the exported `.ass` — they are applied only at playback time and stored in the `.assp` package's `subtitleSettings` field.

---

## .ass File Tips

**Creating .ass files:** Tools like [Aegisub](https://aegisub.org/) (free, cross-platform) are the standard editor for `.ass` subtitle files. It offers a waveform timeline, style editor, and live preview.

**Timing your subtitles:** If you want subtitles that match a specific audio track, load the audio in Aegisub, transcribe and time your captions there, then export the `.ass` file and import it into Adaptive Session Studio.

**Style definitions:** You can define multiple named styles in the `[V4+ Styles]` section and assign them to individual `Dialogue:` lines. When Override mode is "None", these styles are respected (colour-extracted and applied). When Override is "All", styles are ignored.

---

## In the .assp Package

When you export a session as `.assp`, all loaded subtitle tracks are stored including their raw `.ass` text. Re-importing the `.assp` restores the tracks exactly. This means sessions are fully self-contained even for complex subtitle-driven content.
