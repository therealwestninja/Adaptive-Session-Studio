# Guide 1: Quick Start

This guide gets you from zero to a playing session in under five minutes.

---

## Step 1 — Open the App

Open `index.html` in Chrome or Edge. You will see the main interface:

- **Left sidebar** — tracks, blocks, and subtitle/FunScript files
- **Centre** — the playback stage (black area)
- **Bottom** — the transport bar (play, skip, progress, volume)
- **Right** — the inspector panel (properties of the selected item)
- **Top bar** — session actions and settings

---

## Step 2 — Load the Sample Session

Click **Sample** in the top bar. The sidebar fills with a set of pre-built script blocks:

| Block | Time | Content |
|-------|------|---------|
| Settle | 0s | "Settle in. Let your breathing slow." |
| Opening (TTS) | 14s | Spoken narration |
| Anchor words | 34s | "Steady. Clear. Present." |
| Silence | 52s | 8-second pause |
| Closing (TTS) | 68s | Spoken narration |

The session runs for 120 seconds and loops twice.

---

## Step 3 — Play

Press **F** to go fullscreen, then press **Space** (or click the ▶ button) to start.

Text overlays will appear on the stage at their scheduled times. TTS narration will be spoken by your system's default voice.

Press **Space** again to pause. Press **ESC** to stop and exit fullscreen.

---

## Step 4 — Add Your Own Content

### Add a text overlay block

1. In the sidebar under **Script Blocks**, click **T Text**.
2. A new block is added at the end of the timeline.
3. Click the block in the sidebar to select it — the right inspector panel shows its properties.
4. Type your message in the **Content** field.
5. Adjust **Start** (when it appears) and **Duration** (how long it shows).
6. Use the position grid (↖ ↑ ↗ ← · → ↙ ↓ ↘) to place it on screen.

### Add background audio

1. In the sidebar under **Audio Tracks**, click **+**.
2. Choose an audio file (MP3, OGG, WAV, etc.).
3. The audio will loop continuously during the session.
4. Click the ● button next to the track to mute/unmute it.

### Add a background video

1. In the sidebar under **Video / Image**, click **+**.
2. Choose a video file (MP4, WebM) or image (JPG, PNG).
3. It will play/display as the stage background.

---

## Step 5 — Save Your Session

Click **Export .assp** in the top bar to download a `.assp` file. This file contains your entire session including any embedded media. You can re-import it with **Import** at any time.

Your session is also automatically saved to your browser's local storage as you work, so it will be there when you reopen the app — but `.assp` export is the reliable long-term backup.

---

## What's Next?

- Build more complex sessions → [Guide 2: Building Sessions](02-building-sessions.md)
- Add subtitles → [Guide 4: Subtitles](04-subtitles.md)
- Set up FunScript and a device → [Guide 3: FunScript and Devices](03-funscript-and-devices.md)
- Customise the look → [Guide 8: Themes and Settings](08-themes-and-settings.md)
