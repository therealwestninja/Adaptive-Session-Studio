# Guide 7: Import and Export

---

## The .assp Format

Adaptive Session Studio uses `.assp` (Adaptive Session Studio Package) as its primary file format. An `.assp` file is a JSON document containing the complete session, including all embedded media.

### What's in an .assp file

```json
{
  "packageVersion": 4,
  "name": "session_name",
  "duration": 180,
  "theme": "midnight",
  "customThemes": {},
  "masterVolume": 0.8,
  "speechRate": 1,
  "loopMode": "count",
  "loopCount": 1,
  "backgroundColor": "#05070a",
  "accentColor": "#7fb0ff",
  "textColor": "#eef4fb",
  "advanced": { "stageBlur": 0, "fontFamily": "...", "crossfadeSeconds": 0.6, ... },
  "tracking": { "enabled": false, "autoPauseOnAttentionLoss": false, "attentionThreshold": 5 },
  "trackingFsOptions": { "pauseFsOnLoss": false, ... },
  "subtitleSettings": { "textColor": "#ffffff", "fontSize": 1.4, "position": "bottom", "override": "none" },
  "funscriptSettings": { "speed": 1.0, "invert": false, "range": 100 },
  "playlists": {
    "audio": [{ "name": "track.mp3", "dataUrl": "data:audio/mpeg;base64,...", "volume": 1 }],
    "video": [...]
  },
  "subtitleTracks": [{ "name": "captions.ass", "rawAss": "...", "styles": {}, "events": [...] }],
  "funscriptTracks": [{ "name": "script.funscript", "actions": [...], "speed": 1.0, ... }],
  "macroLibrary": [{ "id": "...", "name": "Custom macro", "actions": [...] }],
  "macroSlots": { "1": null, "2": null, "3": "preset_pump", "4": null, "5": null },
  "blocks": [{ "id": "...", "type": "text", "label": "...", "start": 0, "duration": 10, "content": "..." }]
}
```

### Media embedding

Audio and video files are stored as base64 data URLs. This keeps packages self-contained (one file = everything), but makes packages large. A session with 50MB of audio will produce a ~68MB `.assp` file.

---

## Exporting a Session

Click **Export .assp** in the top bar. The browser downloads a file named `{session_name}.assp`.

Individual track exports:
- **FunScript tracks:** Click the track in the sidebar → inspector → **Export .funscript**
- **Subtitle tracks:** Click the track in the sidebar → inspector → **Export .ass**
- **Custom macros:** Settings → Macros → ↓ button next to any macro

---

## Importing a Session

Click **Import** in the top bar and select an `.assp` file. The current session is replaced.

The import normalises all fields, so older package versions (v2, v3) are automatically upgraded to v4 format with missing fields filled from defaults.

---

## Sharing Sessions

Because `.assp` files are self-contained, you can share them directly — by email, file sharing service, or any other means. The recipient opens the file with **Import** and gets the full session exactly as you built it.

**Note on media size:** Large packages (hundreds of MB) may be impractical to share over email. For large sessions, consider hosting on a file sharing service (Dropbox, Google Drive, etc.) and sharing a link.

---

## localStorage Auto-save

The current session is continuously auto-saved to the browser's `localStorage` under the key `adaptive-session-studio-v4`. This means:

- Your work is preserved if you close and reopen the browser tab.
- It is **not** a substitute for `.assp` export — localStorage can be cleared by the browser, private browsing mode, or reinstallation.
- Only one session is held in localStorage at a time (the most recent one).

Always export `.assp` files for sessions you want to keep.

---

## Manual JSON Editing

**Settings → Advanced** shows the full session JSON and allows direct editing. Click **Apply JSON** to load your changes, or **Format** to pretty-print.

This is useful for bulk edits (e.g., shifting all block start times by a fixed amount) that would be tedious through the UI.
