# Guide 3: FunScript and Devices

This guide covers importing and editing FunScript files, understanding the timeline editor, connecting a device, and using the macro injection system during playback.

---

## What is FunScript?

FunScript is an open standard for haptic position scripts. Each file contains a list of timed **actions**: a millisecond timestamp (`at`) and a position value (`pos`, 0–100). Software interpolates smoothly between points to produce continuous motion.

```json
{
  "version": 1,
  "inverted": false,
  "range": 100,
  "actions": [
    { "at": 0,    "pos": 0   },
    { "at": 500,  "pos": 100 },
    { "at": 1000, "pos": 0   }
  ]
}
```

Adaptive Session Studio supports multi-track playback: import multiple `.funscript` files and all active tracks are combined (using the maximum position at any moment).

---

## Importing FunScript Files

1. In the sidebar, under **FunScript ⚡**, click **+**.
2. Select one or more `.funscript` files.
3. Each file appears as a track in the sidebar with a colour dot and point count.
4. Click the ● toggle to mute/unmute a track without removing it.
5. Click the track to open it in the inspector (speed, invert, range, device controls).

---

## The FunScript Timeline

When at least one FunScript track is loaded, a canvas timeline panel appears between the stage and the transport bar.

### What the Timeline Shows

| Element | Meaning |
|---------|---------|
| Coloured curves | Position over time for each active track |
| Coloured dots on curves | Individual action points |
| Block bands | Session script blocks as background colour bands |
| Blue bars at bottom | Subtitle cue markers |
| Amber vertical line | Current playhead position during playback |
| Colour legend | Track name + colour at bottom left |

### Navigating the Timeline

The timeline spans the full session duration. During playback the playhead moves in real time.

### Edit Mode

Press **E** or click **✎ Edit** above the timeline to enter edit mode:

- **Click empty space** — add a new point to the first active track
- **Drag a point** — move it in time (left/right) and position (up/down)
- **Right-click a point** — delete it
- The amber tinted background indicates edit mode is active

Changes are saved automatically.

---

## Playback Settings

Open the inspector for a FunScript track (click it in the sidebar) to see:

| Setting | Description |
|---------|-------------|
| Speed | Multiplier applied to playback time. 0.5× = twice as slow, 2.0× = twice as fast |
| Invert | Flips position: `100 − pos`. Useful when a script's orientation does not match your device |
| Range | Output is scaled to 0–range, then sent to the device. Reduces maximum intensity |

Global FunScript settings are also in **Settings → FunScript**.

---

## Position Meter

A small vertical bar on the left edge of the stage shows the current FunScript position (0–100%) during playback, colour-coded:

- Blue (0–40%) — low intensity
- Amber (40–70%) — medium intensity
- Red (70–100%) — high intensity

---

## Device Integration

### Requirements

- [Intiface Central](https://intiface.com/central/) installed and running
- A Buttplug.io-compatible device connected to your computer

### Connecting

1. Open Intiface Central and start the server (default: `ws://localhost:12345`).
2. In Adaptive Session Studio, open **Settings → FunScript**.
3. Confirm the WebSocket URL matches your Intiface server address.
4. Click **Connect**. The status field shows "Connected" and then the device name once it is found.

### How Output Works

Every frame during playback, the application:

1. Calculates the interpolated position across all active FunScript tracks.
2. Applies speed, invert, and range modifiers.
3. Applies any active macro injection (with easing).
4. Sends a `LinearCmd` message to the device with a 150ms movement duration.

This produces smooth, continuous movement that follows the FunScript curves.

### Disconnecting

Click **Disconnect** in the settings, or close Intiface Central. The device will stop receiving commands.

---

## Safe Skip

When you press the arrow keys to skip the session forward or backward, the application:

1. Eases the device output to zero over ~300ms (at half-speed to avoid jarring movement).
2. Jumps the session clock to the target time.
3. Resumes normal FunScript playback from the new position.

This prevents abrupt mechanical jumps. It is always active when a device is connected.

---

## FunScript-Only Pause (Shift)

Press **Shift** alone (not as a modifier for another key) to pause or resume FunScript output independently of the session. The session clock, audio, and text overlays continue; only device output stops.

A **"⏸ FunScript paused"** indicator appears in the top-right of the stage when active.

---

## Exporting FunScript

To export a modified FunScript track as a standalone `.funscript` file:

1. Click the track in the sidebar to open it in the inspector.
2. Click **Export .funscript**.

The exported file is standard FunScript format and can be used in any compatible player.

---

## Next: Macro Library

The macro injection system lets you trigger short, blended FunScript bursts during playback. See [Guide 5: Macro Library](05-macro-library.md).
