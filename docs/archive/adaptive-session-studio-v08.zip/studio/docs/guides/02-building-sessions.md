# Guide 2: Building Sessions

A session is a timeline of **blocks** layered over **background media**. This guide explains every piece.

---

## The Session Model

Every session contains:

| Component | Description |
|-----------|-------------|
| **Blocks** | Timed events: text overlays, TTS narration, one-shot audio/video, or silence |
| **Audio Tracks** | Looping background audio (multiple tracks play simultaneously) |
| **Video / Image Tracks** | Looping background visuals (last track takes precedence) |
| **Subtitle Tracks** | Timed caption overlays from `.ass` files |
| **FunScript Tracks** | Haptic position curves from `.funscript` files |
| **Macro Library** | Short injectable FunScript bursts assigned to keys 1–5 |

---

## Block Types

### Text

Displays styled text over the stage.

| Field | Description |
|-------|-------------|
| Content | The text to display. Newlines are respected. |
| Start | When (in seconds from loop start) the block begins |
| Duration | How long it stays on screen |
| Font size | Size multiplier (1.0 = default, 2.0 = double) |
| Position | 3×3 grid: top-left, top, top-right, left, centre, right, bottom-left, bottom, bottom-right |

**Tips:**
- Use `\n` in the content for line breaks (or just press Enter in the text area).
- Keep text short for maximum readability during sessions.
- Use large font size (1.5–2.5) for affirmation-style overlays.

### TTS (Text-to-Speech)

Speaks text using the browser's Web Speech API. Triggered once at the block's start time.

| Field | Description |
|-------|-------------|
| Content | Text to be spoken |
| Volume | 0.0–1.0, multiplied by master volume |
| Voice name | Optional: the exact name of a system voice (leave blank for default) |

**Tips:**
- Test TTS voice quality in your system settings before building a session around it.
- Overlap TTS blocks with text blocks for combined visual + audio reinforcement.
- Rate (speed) is set globally in **Settings → Playback → TTS speech rate**.

### Audio (One-shot)

Plays an audio file once at the block's start time, then stops.

| Field | Description |
|-------|-------------|
| File | Browse to select an audio file |
| Volume | 0.0–1.0, multiplied by master volume |
| Notes | Internal memo (not displayed during playback) |

**Use cases:** chimes, alert tones, ambient stingers, music cues.

### Video (One-shot)

Replaces the background with a video clip or image for the block's duration.

| Field | Description |
|-------|-------------|
| File | Browse to select a video or image |
| Mute | Whether to suppress the video's own audio track |
| Notes | Internal memo |

**Note:** One-shot video replaces the playlist background during its duration, then the playlist resumes.

### Pause

Leaves the stage quiet (no text, no TTS, no one-shot media) while all looping background layers continue. Useful for breath space or transitions.

---

## The Timeline

Blocks are placed along a single time axis measured in **seconds from the start of each loop**. If the loop duration is 120 seconds, a block at `start: 90, duration: 20` runs from 00:90 to 01:50.

**Overlapping blocks:** Multiple blocks can be active simultaneously. When two Text blocks overlap, the later one takes priority for display. Two TTS blocks overlapping will both speak at the same time.

**Gaps:** Gaps between blocks leave the stage quiet (background layers still play).

---

## Editing Blocks

### In the Sidebar

- Click a block to select it and open it in the inspector.
- Block dots are colour-coded: blue = text, green = TTS, amber = audio, purple = video, grey = pause.
- The timestamp shown next to each block label is its start time.
- Click **Sort blocks by start time** at the bottom of the sidebar to re-order after editing.

### In the Inspector (Overlay Tab)

All block fields are editable live. Changes take effect immediately (and during playback if the block is currently active).

### Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `D` | Duplicate selected block |
| `Delete` | Delete selected block |

---

## Background Media

### Audio Tracks

- All audio tracks play simultaneously, looping for the full session duration.
- Each track has an independent mute toggle (● / ✕ button in the sidebar).
- Volume is controlled globally via master volume and the **playlist audio volume** setting.
- Adding multiple audio tracks is useful for layering: binaural tones + ambient sound + music.

### Video / Image Tracks

- Only one video/image is shown at a time; the last one in the list displays on top.
- Images are static backgrounds; videos loop.
- "Mute" suppresses the video's own audio (useful for music videos where you want a different audio track).

---

## Loop Settings

Configured in **Settings → Playback** or the **Session** tab of the inspector:

| Mode | Behaviour |
|------|-----------|
| **None** | Plays once, then stops |
| **Loop count** | Repeats N times |
| **Runtime minutes** | Loops until N minutes have elapsed |
| **Loop forever** | Loops indefinitely until stopped |

The **Duration** field sets the length of each single loop. All block start times are relative to this.

---

## Session Duration vs. Block Timing

Make sure all your blocks fit within the session duration:

- A block at `start: 100, duration: 30` in a 120-second session will be cut off after 20 seconds on each loop.
- Use **Sort by start time** to catch blocks that have drifted out of order during editing.

---

## Inspector: Session Tab

The **Session** tab of the inspector gives a compact view of session-level settings without opening the full Settings dialog:

- Session name (used as the export filename)
- Duration
- Loop mode and count
- Quick duplicate / delete / sort actions

---

## Saving Your Work

Sessions auto-save to localStorage on every change. Use **Export .assp** for a durable backup you can share or import on another computer.

See [Guide 7: Import and Export](07-import-export.md) for full details.
