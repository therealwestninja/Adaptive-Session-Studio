# Contributing

Thank you for your interest in improving Adaptive Session Studio. This document explains how to contribute effectively.

---

## Before You Start

- Read [ARCHITECTURE.md](ARCHITECTURE.md) to understand the codebase structure.
- Read [DEVELOPER.md](DEVELOPER.md) for setup instructions and coding conventions.
- Check the existing issues and planned features in [DEVELOPER.md](DEVELOPER.md) to avoid duplicating work.

---

## Types of Contributions

### Bug Reports

Open an issue (or contact the maintainer) with:

1. **What you expected to happen**
2. **What actually happened**
3. **Steps to reproduce** — be specific; include browser version, OS, and any relevant session content
4. **Console errors** — open the browser developer console (F12 → Console) and include any red error messages
5. **The `.assp` file** if the bug is session-specific (strip any sensitive content first)

### Feature Requests

Describe:
- The problem you are trying to solve (not just the proposed solution)
- How you currently work around it (if at all)
- Whether you are willing to implement it yourself

Check [DEVELOPER.md → Planned Features](DEVELOPER.md) first — your request may already be on the roadmap.

### Code Contributions

See the workflow below.

---

## Development Workflow

### 1. Fork and set up

Fork the repository (or unzip the release and create a local git repository):

```bash
git init
git add .
git commit -m "Initial v4.0.0"
```

### 2. Create a branch

```bash
git checkout -b feature/your-feature-name
# or
git checkout -b fix/the-bug-you-are-fixing
```

Use descriptive branch names: `feature/undo-redo`, `fix/webcam-double-stop`, `docs/faq-device-section`.

### 3. Make your changes

Follow the [coding conventions in DEVELOPER.md](DEVELOPER.md). Key rules:

- Call `esc()` on all user-supplied strings in HTML templates.
- Do not introduce external dependencies (no npm, no CDN libraries).
- Keep each module's responsibility clear — do not reach across module boundaries unnecessarily.
- Update `persist()` after any change to `state.session`.
- Update render functions after any change to `state` that affects the UI.

### 4. Test manually

There is no automated test suite. Test your change by:

- Loading a sample session and verifying the feature works as intended.
- Importing and exporting an `.assp` file and verifying it round-trips correctly.
- Testing the affected keyboard shortcuts.
- Checking the browser console for errors.
- Testing in both Chrome and Edge.

### 5. Update documentation

- If you added a feature: update the relevant guide in `docs/guides/`, the FAQ if applicable, and add an entry to `CHANGELOG.md`.
- If you changed a setting: update `docs/guides/08-themes-and-settings.md`.
- If you changed the session model: update `ARCHITECTURE.md` (the session field table) and `docs/guides/07-import-export.md`.
- If you changed the keyboard shortcuts: update `README.md`, `docs/guides/01-quick-start.md`, and the in-app fullscreen HUD hint text in `index.html`.

### 6. Submit

Open a pull request with:
- A clear description of what changed and why.
- Screenshots or recordings for UI changes.
- Any relevant issue numbers.

---

## Areas That Welcome Contribution

### Good first contributions

- **Improve .ass parsing** — handle edge cases in the ASS format (empty style sections, scripts without Format lines, non-standard BOM markers).
- **Improve error handling** — add friendly error messages for failed media imports, localStorage quota exceeded, invalid .funscript files.
- **Keyboard shortcut display** — a visible shortcuts overlay (triggered by `?` key) listing all shortcuts.
- **Export confirmation** — after exporting, briefly show what was exported and where.

### Intermediate contributions

- **Undo/redo** — session snapshot stack on block add/edit/delete.
- **Multiple session slots** — save/load multiple named sessions from localStorage.
- **FunScript timeline zoom** — zoom in/out on the timeline canvas with mouse wheel.
- **Block drag-to-reorder** — drag blocks in the sidebar to change their order (visual only; order doesn't affect playback, but it helps readability).

### Advanced contributions

- **ZIP-based .assp format** — refactor import/export to use a proper ZIP container with a `manifest.json` and separate media files. Libraries like JSZip are acceptable for this specific feature.
- **Web Audio API mixing** — replace `new Audio()` elements with a Web Audio API graph for proper volume envelopes, crossfade, and bus mixing.
- **Remote control companion** — a second HTML file (or minimal server) that exposes a simple play/pause/stop/emergency-stop API, accessible from a phone on the same network.

---

## What Not to Contribute

- **External dependencies** — do not add npm packages, CDN scripts, or frameworks. The no-dependency constraint is intentional.
- **Build tools** — no webpack, Vite, Rollup, etc. The codebase must remain openable directly in a browser.
- **TypeScript** — the codebase is plain JavaScript. Type annotations via JSDoc comments are welcome; a full TypeScript migration is not.
- **Content** — do not contribute session content (.assp files, audio, video, scripts) to the codebase itself.
- **Backdoors or telemetry** — the app must remain zero-network by design.

---

## Code Review Criteria

Contributions will be reviewed for:

1. **Correctness** — does it do what it says? Does it break existing behaviour?
2. **Safety** — does it handle user-supplied strings safely (`esc()`)? Does it risk device safety issues?
3. **Module boundaries** — does it respect the existing separation of concerns?
4. **Documentation** — are docs updated to match?
5. **Code style** — consistent with the existing codebase?
6. **Privacy** — does it introduce any network requests or data collection?

---

## Conduct

Be respectful. This project involves sensitive subject matter. Discussions about features, content, or design should remain constructive and focused on the software.
