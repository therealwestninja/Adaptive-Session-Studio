# Developer and Maintainer Notes

Notes for anyone working on the Adaptive Session Studio codebase. Read [ARCHITECTURE.md](ARCHITECTURE.md) first for the structural overview.

---

## Development Setup

No build tools are required. The codebase is plain ES modules.

```bash
# Clone or unzip the project, then:
python3 -m http.server 8080
# Open http://localhost:8080 in Chrome or Edge
```

For live-reload during development, use VS Code with the **Live Server** extension (right-click `index.html` → Open with Live Server).

**Do not use `file://` URLs for development.** ES module imports are blocked by CORS policy on `file://` in most browsers without special flags.

---

## Adding a New Block Type

Block types are dispatched in several places. When adding a new type (e.g., `'image'`):

1. **`state.js` `normalizeBlock()`** — ensure all fields used by the new type have defaults.

2. **`index.html`** — add an add-block button:
   ```html
   <button class="sb-chip" data-add-block="image">🖼 Image</button>
   ```

3. **`ui.js` `renderBlockList()`** — add a colour to `BLOCK_COLORS` and icon to `BLOCK_ICONS`.

4. **`ui.js` `renderOverlayTab()`** — add an `else if (block.type === 'image')` branch rendering the inspector fields for the new type.

5. **`playback.js` `handleActiveBlock()`** — add the trigger logic for the new type inside the one-shot section.

6. **`docs/guides/02-building-sessions.md`** — document the new type.

---

## Adding a New Session Field

When adding a new top-level field to the session model:

1. Add it to `defaultSession()` in `state.js` with its default value.
2. Add it to `normalizeSession()` in `state.js` — either as a spread (for sub-objects) or directly.
3. If it appears in the Settings dialog, add it to:
   - The HTML in `index.html` (input element with an `id`)
   - `syncSettingsForms()` in `ui.js` (read from session → fill form)
   - `syncSessionFromSettings()` in `ui.js` (read from form → write to session)
4. Bump `PACKAGE_VERSION` in `state.js` if the schema change is significant.

---

## Adding a New Settings Tab

1. Add a tab button in `index.html`:
   ```html
   <button class="settings-tab" data-stab="mytab">My Tab</button>
   ```
2. Add a section div:
   ```html
   <div class="settings-section" data-section="mytab"> ... </div>
   ```
3. If the tab needs initialisation when first opened, add a handler in `main.js`:
   ```js
   if (state.settingsTab === 'mytab') initMyTabStuff();
   ```
   This runs inside the settings tab click handler.

---

## Modifying the FunScript Timeline

The canvas is initialised by `initTimeline(canvasEl)` in `funscript.js`. `drawTimeline(playheadSec)` is called every tick from `playback.js` and on any event that changes what's displayed.

To add a new visual element to the timeline:
1. Add the draw call inside `drawTimeline()` in `funscript.js` at the appropriate z-order (drawn in source order).
2. Use the helpers `timeToX(ms)` and `posToY(pos)` for coordinate conversion.
3. Canvas colours should use hardcoded hex for timeline elements (they are not affected by the CSS theme).

---

## Modifying the Injection Engine

The injection sequence is built in `buildInjectionSequence()` in `macros.js`. It returns `{ actions, totalMs }`. The `EASE_MS` constant (350ms) controls the ease-in and ease-out window.

The easing function `easeInOut(t)` is a simple cubic. Swap it for a different curve if needed — `t` is always 0–1.

The injection output is read by `getInjectionPosition()` in `macros.js`, called from the playback tick. It returns `null` when the injection is complete, signalling the main FunScript to resume.

---

## Webcam Tracking Module

`makeTrackingModule()` in `tracking.js` returns `{ start, stop }`. A new module instance is created each time the Settings dialog is opened (`main.js`). This means webcam state (stream, RAF handle) is local to the module instance, not global.

**Gotcha:** If the user opens and closes the settings dialog multiple times without stopping the webcam, multiple tracking loops can run simultaneously. This is prevented by the `stop()` call inside `start()`:
```js
// Actually there is no auto-stop on re-open; this is a known limitation.
// TODO: store the tracking module instance and stop it before creating a new one.
```

Fix: store the tracking instance in `state` (not `main.js` local variable) and call `_tracking?.stop()` before creating a new one.

---

## Device Communication

The WebSocket to Intiface Central is stored in `state.deviceSocket`. Commands use Buttplug v3 JSON protocol.

Message types used:
- `RequestServerInfo` — handshake on connect
- `LinearCmd` — position command (sent each tick during playback)
- `StopAllDevices` — emergency stop

Message types **not yet handled** but should be for production use:
- `ServerInfo` — version validation, ensure server version compatibility
- `StartScanning` / `StopScanning` / `ScanningFinished` — device discovery UI
- `RequestDeviceList` — enumerate devices already paired with Intiface
- `Error` — Buttplug error responses
- Vibration / rotation control (currently only linear is used)

To add vibration support: check device capabilities on `DeviceAdded`, and send `VibrateCmd` for vibration devices instead of `LinearCmd`.

---

## Performance Notes

**RAF throttling:** `requestAnimationFrame` is throttled to ~4fps when the browser tab is in the background. Sessions running in a background tab will have their clock drift. There is no correction for this — if background playback matters, use the Web Audio API's clock as the time source instead of `performance.now()`.

**Canvas performance:** The FunScript timeline redraws every tick (~60fps). For long FunScripts with thousands of points, this can be expensive. Optimisations to consider:
- Cull points outside the visible time range.
- Only redraw the playhead (dirty-rect approach) when no edits are in progress.
- Cache the static curve layer (block bands, grid, curves) to an offscreen canvas.

**localStorage size:** Base64 media in the session can exhaust localStorage (typically 5–10MB limit). Large sessions will fail to auto-save silently. The `persist()` function does not handle this error. Consider catching the `QuotaExceededError` exception and warning the user.

---

## Testing

There is no automated test suite. Manual testing is the current approach.

Key areas to test after changes:
- Session import/export round-trip (export → import → verify all fields match)
- Playback: block timing accuracy across loops
- FunScript: interpolation accuracy, device output timing
- Macro injection: ease-in/out smoothness, correct position restoration after injection
- Emergency stop: all audio stops, device stops, clock resets
- Webcam: tracking correctly fires loss/return events without repeated triggers
- Settings dialog: all form values sync correctly both ways

---

## Planned Features (Future Work)

### Completed ✅
- **Undo/redo** — `history.js`, snapshot-based, 60-step, Ctrl+Z/Y
- **Deep import validation** — all nested session structures normalised in `state.js`
- **Safe persistence** — `QuotaExceededError` caught, badge + toast on failure
- **Browser capability detection** — `capabilities.js`, gates controls, warns on missing features
- **Notification system** — `notify.js`, replaces all `alert()` calls
- **Device discovery** — `RequestDeviceList` + `StartScanning` after handshake, full message handling

### Near-term

- **Multiple localStorage slots** — save/load multiple sessions without export
- **Keyboard shortcut reference card** — visible without entering fullscreen (press `?`)
- **Block drag-reorder** — drag sidebar blocks to reorder
- **Bulk time-shift** — select multiple blocks and offset all start times

### Medium-term

- **Remote control web app** — minimal companion page for phone-based play/pause/stop/emergency-stop
- **ZIP-based .assp container** — separate media files to reduce memory footprint
- **Web Audio API integration** — proper mixing graph (volume envelopes, crossfade, EQ, limiter)
- **Vibration device support** — extend device output to `VibrateCmd` for vibration devices
- **FunScript multi-select transform** — select multiple points and scale/offset in bulk
- **FunScript timeline zoom** — mouse-wheel zoom on the canvas timeline

### Long-term

- **Rule engine** — scriptable branching based on attention, loop count, time
- **MIDI input** — trigger blocks and macros from a MIDI controller
- **Auto-generate FunScript from audio** — beat/peak detection → position points
- **Session analytics** — post-session report (time per block, attention trends, loop count)
- **Companion mobile app** — React Native remote with emergency stop

---

## Code Style

- ES modules, no transpilation, no TypeScript. Files are plain `.js`.
- Function declarations preferred over arrow functions for top-level exports (aids readability in module scope).
- Arrow functions for inline callbacks and helpers.
- Template literals for HTML generation in `innerHTML` assignments.
- `esc()` helper from `state.js` must be called on all user-supplied strings before inserting into HTML.
- No third-party libraries. All DOM, canvas, WebSocket, and media work is native browser APIs.
- Comments at the top of each file describe its purpose. In-line comments for non-obvious logic only.

---

## Releasing a New Version

1. Update `PACKAGE_VERSION` in `state.js` and `STORAGE_KEY` if the schema has breaking changes.
2. Update `CHANGELOG.md`.
3. Run a manual test pass (see Testing above).
4. Zip the studio folder: `zip -r adaptive-session-studio-vX.Y.Z.zip studio/`.
5. Tag the release in version control.
