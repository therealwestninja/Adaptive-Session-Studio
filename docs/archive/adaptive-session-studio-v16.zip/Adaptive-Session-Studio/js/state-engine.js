// ── state-engine.js ────────────────────────────────────────────────────────
// Central runtime state manager. Normalizes inputs from tracking, playback,
// and live-control into a single coherent state object that the rules engine
// and UI can read without caring about the source.
//
// ROADMAP Phase 1 — State Engine (Core Runtime)
//
// Published state (state.engineState):
//   attention   0–1   from tracking module (0 = lost/idle, 1 = detected)
//   intensity   0–2   from liveControl.intensityScale
//   speed       0–4   from liveControl.speedScale
//   engagement  0–1   derived engagement score (see below)
//   sessionTime  sec  mirrors runtime.sessionTime
//   loopCount        mirrors runtime.loopIndex
//   fsPaused    bool  mirrors state.fsPaused
//   playing     bool  runtime is active and not paused

import { state } from './state.js';

// ── Engagement score derivation ─────────────────────────────────────────────
// engagement is a smoothed composite:
//   base = attention (0–1)
//   boosted when intensity is high and session is playing
// Smoothed with EMA (alpha = 0.05 per tick at ~60fps ≈ 3s time constant)
let _smoothedEngagement = 0;
const ENGAGEMENT_ALPHA  = 0.05;

function deriveEngagement(attention, intensity, playing) {
  if (!playing) return _smoothedEngagement; // freeze when paused/stopped
  const intensityBonus = Math.min(0.2, (intensity - 1) * 0.2); // 0 at 100%, +0.2 at 200%
  const raw  = Math.max(0, Math.min(1, attention + (attention > 0.5 ? intensityBonus : 0)));
  _smoothedEngagement = _smoothedEngagement + ENGAGEMENT_ALPHA * (raw - _smoothedEngagement);
  return +_smoothedEngagement.toFixed(3);
}

// ── Published engineState on state object ───────────────────────────────────
// Initialise so consumers can read safely before first tick
if (!state.engineState) {
  state.engineState = {
    attention:   0,
    intensity:   1,
    speed:       1,
    engagement:  0,
    sessionTime: 0,
    loopCount:   0,
    fsPaused:    false,
    playing:     false,
  };
}

// ── Attention feed ───────────────────────────────────────────────────────────
// tracking.js calls this every detection loop frame to update the attention
// value in the engine state without creating a direct dependency on ui.js.
let _currentAttention = 0;

export function setAttention(value) {
  _currentAttention = Math.max(0, Math.min(1, value));
}

export function getAttention() {
  return _currentAttention;
}

// ── Main tick — called every RAF frame from playback.js ────────────────────
export function tickStateEngine() {
  const { runtime, liveControl, session } = state;
  const lc      = liveControl ?? { intensityScale: 1, speedScale: 1 };
  const playing = !!(runtime && !runtime.paused);

  state.engineState = {
    attention:   _currentAttention,
    intensity:   lc.intensityScale,
    speed:       lc.speedScale,
    engagement:  deriveEngagement(_currentAttention, lc.intensityScale, playing),
    sessionTime: runtime?.sessionTime ?? 0,
    loopCount:   runtime?.loopIndex   ?? 0,
    fsPaused:    state.fsPaused,
    playing,
  };
}

// ── Metric accessor (used by rules engine) ──────────────────────────────────
export function getMetric(metric) {
  const es = state.engineState;
  switch (metric) {
    case 'attention':   return es.attention;
    case 'intensity':   return es.intensity;
    case 'speed':       return es.speed;
    case 'engagement':  return es.engagement;
    case 'sessionTime': return es.sessionTime;
    case 'loopCount':   return es.loopCount;
    default:            return 0;
  }
}

// ── Reset (on session load) ──────────────────────────────────────────────────
export function resetStateEngine() {
  _currentAttention   = 0;
  _smoothedEngagement = 0;
  state.engineState   = {
    attention: 0, intensity: 1, speed: 1, engagement: 0,
    sessionTime: 0, loopCount: 0, fsPaused: false, playing: false,
  };
}
