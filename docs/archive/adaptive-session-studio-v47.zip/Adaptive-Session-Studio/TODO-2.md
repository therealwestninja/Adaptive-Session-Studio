# Adaptive Session Studio v4.5.6 — Detailed Bug Report (next pass)

Checked build: `Adaptive-Session-Studio-v4.5.6.zip`

## What I checked this round
- Re-read the current v4.5.6 codebase for additional issues beyond the previous report
- Focused on state lifetime, UI ↔ engine mismatches, analytics/profile correctness, and HTML injection paths
- Verified the previously reported syntax/import blockers are not present in this build

## Summary
This pass turned up more **real bugs** beyond the earlier loop/timing issues. The most important new ones are:
- the **Suggestions** panel renders user-derived strings with `innerHTML` and **does not escape them**
- **session modes** identify old mode rules only by **name prefix**, so renamed mode rules survive and stack unexpectedly
- **analytics** over-report completed loops by counting the current in-progress loop as completed
- **profile streaks** are computed in **UTC days**, which can miscount streaks around local midnight
- one-shot block volume controls still have a **0/1 rendering mismatch** in the inspector

I’ve also repeated the still-open high-impact issues from the previous pass so the report stays complete.

---

## 1) Suggestions panel has an unescaped HTML injection path
**Severity:** High  
**Files:** `js/suggestions.js:31-38`, `js/suggestions.js:55-60`, `js/suggestions.js:69-76`, `js/suggestions.js:218-235`

### Why it breaks
`analyzeSession()` builds suggestion `title` and `detail` strings from user-controlled session content such as:
- block labels
- scene names
- track names

Examples:
```js
 detail: `"${overflowing[0].label}" ends at ...`
 detail: `"${overlapping[0][0].label}" and "${overlapping[0][1].label}" overlap ...`
```

Then `renderSuggestions()` injects those strings directly into `innerHTML`:
```js
<div ...>${s.title}</div>
<div ...>${s.detail}</div>
```

Those values are **not escaped** before HTML insertion.

### User-visible symptom
A crafted block label / scene name / track name can:
- break the suggestions panel markup
- inject arbitrary HTML into the inspector
- potentially execute script depending on browser/event context

### Likely fix
Escape `s.title`, `s.detail`, and `s.action.label` before interpolation, or build the panel with DOM nodes / `textContent` instead of `innerHTML`.

---

## 2) Session mode cleanup is brittle: renamed mode rules survive and stack
**Severity:** High  
**Files:** `js/session-modes.js:149-154`

### Why it breaks
When a mode is applied, old mode rules are removed only if their **name starts with a hard-coded prefix**:
```js
const modeNamePrefixes = ['[Exposure]', '[Mindfulness]', '[Focus]'];
state.session.rules = state.session.rules.filter(
  r => !modeNamePrefixes.some(p => r.name?.startsWith(p))
);
```

That means mode-generated rules are **not tracked by origin or metadata**, only by the display name.

### Real failure mode
1. Apply a mode
2. Rename one of its rules in the Rules UI
3. Apply another mode
4. The renamed old rule no longer matches the prefix filter, so it remains
5. New mode rules are added on top

Result: stale mode rules silently accumulate and can fire alongside the newly selected mode.

### User-visible symptom
Mode switching becomes unreliable over time. Users can end up with duplicated or contradictory automation while the UI claims the new mode has replaced the old one.

### Likely fix
Tag mode-generated rules with stable metadata, for example:
- `source: 'session-mode'`
- `modeId: 'focus'`

Then remove prior mode rules by metadata rather than name text.

---

## 3) Analytics counts the current partial loop as a completed loop
**Severity:** Medium  
**Files:** `js/session-analytics.js:75-77`

### Why it breaks
The final analytics summary uses:
```js
const loopsCompleted = runtime.loopIndex + 1;
```
But `loopIndex` is the **current zero-based loop**, not the number of fully finished loops.

So during the first loop:
- `loopIndex === 0`
- summary reports `loopsCompleted = 1`

Even if playback is stopped halfway through that first loop.

### User-visible symptom
Post-session analytics and profile summaries over-report completion, especially for sessions that were stopped early.

### Likely fix
Derive completed loops from elapsed runtime, for example:
- `Math.floor(totalSec / session.duration)` for fully completed loops
- or separately report both `loopsCompleted` and `currentLoop`

---

## 4) Profile streak logic uses UTC dates, so streaks can be wrong around local midnight
**Severity:** Medium  
**Files:** `js/user-profile.js:120-139`

### Why it breaks
Both `_todayStr()` and `_computeStreak()` use:
```js
new Date(...).toISOString().slice(0, 10)
```
That computes **UTC calendar dates**, not the user’s local day.

If a session happens late at night locally, it can land on the next UTC day and be counted against the wrong streak day.

### User-visible symptom
Users near midnight local time can see streaks:
- increment too early
- break incorrectly
- or appear one day off

### Likely fix
Compute streak days in local calendar time instead of UTC ISO dates.

---

## 5) One-shot block volume inspector still mishandles zero volume and has a UI/data mismatch
**Severity:** Medium  
**Files:** `js/ui.js:392`, `js/ui.js:400`, `js/playback.js:289`, `js/playback.js:298`

### Why it breaks
For TTS and one-shot audio blocks, the inspector renders volume using `|| 1`:
```js
value="${block.volume||1}"
```
So a legitimate stored volume of `0` is rendered back as `1` in the UI.

There is also a mismatch between data handling and inspector limits:
- playback uses `block.volume ?? 1`
- inspector uses `max="1"`
- elsewhere track volume controls allow up to `2`

### User-visible symptom
- imported or programmatically-set block volume `0` is shown incorrectly as `1`
- muted one-shot blocks appear unmuted in the inspector
- UI semantics differ between playlist tracks and one-shot block media

### Likely fix
Use nullish fallback instead:
```js
block.volume ?? 1
```
and decide whether one-shot block volume should genuinely be `0–1` or `0–2`, then keep playback + UI consistent.

---

## 6) Trigger-name attribute injection path is still open
**Severity:** Medium  
**Files:** `js/trigger-windows.js:202-209`

### Why it breaks
Trigger names are inserted into an `<input value="...">` without escaping:
```js
<input ... value="${tr.name}" />
```
A trigger name containing quotes or HTML-significant characters can break the attribute context.

### User-visible symptom
Malformed trigger names can corrupt the trigger inspector markup and create an injection path.

### Likely fix
Escape `tr.name` the same way other inspector inputs already do.

---

## 7) Rules still use loop-relative time for cooldowns, so they fail across loops
**Severity:** High  
**Files:** `js/rules-engine.js:142-144`, `js/state-engine.js:111-118`

### Why it breaks
Cooldowns are compared against `state.engineState.sessionTime`, which resets every loop.

### User-visible symptom
Rules can fire in loop 1 and then fail to fire again in later loops even when conditions still match.

### Likely fix
Track cooldown against an absolute monotonic runtime, not per-loop `sessionTime`.

---

## 8) Trigger windows still use loop-relative time for cooldown/open timing
**Severity:** High  
**Files:** `js/trigger-windows.js:109-110`, `js/trigger-windows.js:123`, `js/trigger-windows.js:130`

### Why it breaks
Trigger windows compare cooldown against loop-relative `sessionTime`, which resets every loop.

### User-visible symptom
Triggers can behave like one-shots or become delayed/stuck in later loops.

### Likely fix
Use an absolute playback clock for `lastFiredAt`, or explicitly reset timing state at loop boundaries if that is the intended model.

---

## 9) Trigger actions are still not fully configurable from the UI
**Severity:** High  
**Files:** `js/trigger-windows.js:202-247`, `js/trigger-windows.js:271-272`, `js/trigger-windows.js:84-92`

### Why it breaks
The trigger inspector lets users choose action types like:
- `injectMacro`
- `setIntensity`
- `setSpeed`

But it still does not provide parameter editors for those actions, and does not expose `cooldownSec` either.

So the UI can create trigger actions that look valid but cannot actually be configured into a fully working state.

### User-visible symptom
- macro injection can report success without a macro actually being injected
- set-intensity and set-speed actions fall back to defaults when `param` is null
- cooldown behavior cannot be edited from the inspector

### Likely fix
Mirror the Rules inspector behavior for trigger action params and cooldown.

---

## 10) `setIntensity(0)` is still impossible through rule/trigger action execution
**Severity:** Medium  
**Files:** `js/rules-engine.js:114`, `js/trigger-windows.js:91`

### Why it breaks
Both codepaths still use:
```js
Number(param) || 1
```
That treats `0` as false and replaces it with `1`.

### User-visible symptom
A rule or trigger configured to set intensity to `0` will instead set it to `1`.

### Likely fix
Use a nullish/finite check instead of `||`.

---

## 11) Browser-side Anthropic API key exposure is still present
**Severity:** High  
**Files:** `js/ai-authoring.js:59-67`, `js/ai-authoring.js:84-90`

### Why it breaks
The app still:
- stores the Anthropic key in browser `localStorage`
- sends it directly from the browser
- explicitly opts into direct browser access with:
```js
'anthropic-dangerous-direct-browser-access': 'true'
```

### User-visible symptom
Any XSS or malicious extension with page access can read the key. This remains a serious security risk.

### Likely fix
Move AI requests behind a server-side proxy and keep API keys out of the browser runtime.

---

## Lower-priority UX correctness issues

### Trigger enabled-count summary can go stale until a later full sidebar render
**Severity:** Low  
**Files:** `js/trigger-windows.js:260`, `js/ui.js:625-637`

Toggling a trigger in the inspector calls `toggleTrigger()` but does not immediately re-render the sidebar summary count. The underlying state updates, but the `enabled/total` badge can stay visually stale until another render path runs.

### One-shot block inspector volume caps differ from playlist track volume caps
**Severity:** Low  
**Files:** `js/ui.js:392`, `js/ui.js:400`, `js/ui.js:455`, `js/ui.js:491`

One-shot TTS/audio block volume inputs cap at `1`, while playlist track volume inputs cap at `2`. That may be intentional, but the UI currently does not make the distinction clear.

---

## Overall state after this pass
The codebase is improving, but I would still treat the following as the top-priority fixes:

1. Escape or DOM-build the **Suggestions** panel
2. Fix **rule/trigger cooldown timing** across loops
3. Fix **session mode rule ownership** so mode swaps are reliable
4. Fix **setIntensity(0)** handling
5. Close the remaining **trigger-name injection** path
6. Remove direct browser use of the **Anthropic API key**

