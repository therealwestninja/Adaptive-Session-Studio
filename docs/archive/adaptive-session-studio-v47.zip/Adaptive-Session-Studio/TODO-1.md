# Adaptive Session Studio — Detailed Bug Report

Checked build: `Adaptive-Session-Studio(1).zip`

## What I checked
- Parsed all JS files with `node --check`
- Cross-checked imports/exports across the module graph
- Reviewed startup, playback, audio, AI authoring, normalization, and inspector rendering paths
- Looked for runtime breakage, state corruption, and security issues

## Summary
I did **not** find the previous fatal syntax/import breaks in this copy. The project is in better shape, but there are still several real bugs and a few high-risk issues.

---

## 1) Unmuting an audio playlist track during playback can fail silently
**Severity:** High  
**Files:** `js/main.js:252-268`, `js/audio-engine.js:36-48`, `js/audio-engine.js:121-137`

### Why it breaks
When playback starts, `startAudioEngine()` only starts tracks that are **not muted**. If a track is muted at start, no source node is created for it.

Later, the sidebar mute toggle tries to “unmute” that track by calling `crossfade(..., incomingId, ...)`. But `crossfade()` only fades in tracks that already exist in `_tracks`. For a track that never started, `_tracks.find(t => t.id === incomingId)` returns nothing, so the track never becomes audible.

### User-visible symptom
- Start playback with an audio playlist track muted.
- Unmute it while playback is running.
- UI shows it as unmuted, but no sound starts.

### Likely fix
When unmuting a track during Web Audio playback, detect whether the track already has a live node. If not, call an exported “start single track” helper before fading in, or use `refreshVolumes()` plus track creation logic.

---

## 2) Playback startup has an async race that can crash after a quick stop/reset
**Severity:** High  
**Files:** `js/playback.js:70-104`, `js/playback.js:385-426`, `js/session-analytics.js:15-26`

### Why it breaks
`startPlayback()` creates `state.runtime`, then calls `startPlaylistLayers().then(...)`. Inside that `.then(...)`, it calls:
- `initAnalytics(state.runtime)`
- `updateRampPanelVisibility()`
- `updatePlayBtn(true)`
- `tickPlayback()`

If the user stops playback, imports a session, or starts a new session **before** `startPlaylistLayers()` finishes decoding media, `stopPlayback()` sets `state.runtime = null`.

When the pending promise resolves, the `.then(...)` callback still runs and passes `null` into `initAnalytics(runtime)`, which immediately writes `runtime.analytics = ...` and throws.

### User-visible symptom
Intermittent startup/stop crashes, especially with large audio files or rapid user interaction right after pressing Play.

### Likely fix
Capture the runtime instance locally:
```js
const runtime = state.runtime;
startPlaylistLayers().then(() => {
  if (state.runtime !== runtime || !runtime) return;
  initAnalytics(runtime);
  ...
});
```
Also consider cancelling or versioning in-flight starts.

---

## 3) AI “Replace session” does not actually clear ramp/pacing when the model returns `null`
**Severity:** Medium  
**Files:** `js/ai-authoring.js:149-179`

### Why it breaks
`applyGeneratedContent()` only assigns these fields when they are truthy:
- `generated.rampSettings`
- `generated.pacingSettings`

That means if the AI intentionally returns `null` to clear one of those sections, nothing happens and the old settings remain in place.

### User-visible symptom
Choose **Replace session**, generate a session with no ramp/pacing, and old adaptive settings can survive unexpectedly.

### Likely fix
Check for property presence instead of truthiness:
```js
if ('rampSettings' in generated) s.rampSettings = generated.rampSettings;
if ('pacingSettings' in generated) s.pacingSettings = generated.pacingSettings;
```

---

## 4) `normalizeSession()` injects sample blocks when `blocks` is missing
**Severity:** Medium  
**Files:** `js/state.js:226-228`

### Why it breaks
If `input.blocks` is not an array, `normalizeSession()` falls back to `sampleSession().blocks` instead of `defaultSession().blocks`.

That means malformed or partial imports can unexpectedly gain the demo content.

### User-visible symptom
- Import or apply a session object that omits `blocks`.
- Instead of getting an empty block list, the user gets the sample session’s blocks.

### Why this is inconsistent
`defaultSession()` defines `blocks: []`, so normalization should usually preserve that baseline unless there is a deliberate migration rule.

### Likely fix
Replace:
```js
: sampleSession().blocks,
```
with:
```js
: [],
```
or `base.blocks`.

---

## 5) HTML escaping is incomplete and can break inspector forms or allow markup injection
**Severity:** High  
**Files:** `js/state.js:20`, plus multiple renderers including:
- `js/ui.js:369`
- `js/ui.js:449`
- `js/ui.js:477`
- `js/ui.js:518`
- `js/ui.js:671`
- `js/scenes.js:95`
- `js/macro-ui.js:112`

### Why it breaks
The shared `esc()` helper escapes only:
- `&`
- `<`
- `>`

It does **not** escape quotes (`"` and `'`). But many strings are interpolated directly into HTML **attribute values**, for example:
```html
<input value="${esc(block.label)}" />
```
If a label/name contains a double quote, it can break the attribute and corrupt the DOM markup. In the worst case, that opens an XSS path because much of the UI is built with `innerHTML`.

### User-visible symptom
Names containing quotes can render incorrectly, truncate values, or create malformed inspector HTML.

### Likely fix
Use an attribute-safe escaper, or stop building form controls through `innerHTML` for user-provided values. At minimum, escape `"` and `'` too.

---

## 6) AI API key is stored in plain localStorage and direct browser access is explicitly enabled
**Severity:** High  
**Files:** `js/ai-authoring.js:61-85`

### Why it is risky
The app:
- stores the Anthropic API key in `localStorage`
- sends it directly from the browser
- sets `anthropic-dangerous-direct-browser-access: true`

That means any successful script injection, browser extension, shared machine access, or same-origin compromise can expose the raw API key.

### Impact
This is not just a theoretical concern because the same codebase also has HTML-injection weaknesses in inspector rendering.

### Likely fix
Move AI calls behind a server-side proxy and never persist the raw provider key in browser storage. If browser-only mode is unavoidable, store the key ephemerally and harden all HTML rendering paths.

---

## 7) Scene normalization does not enforce `end > start`
**Severity:** Medium  
**Files:** `js/state.js:104-111`

### Why it breaks
`normalizeScene()` clamps `start` and `end` independently, but does not guarantee that `end` is after `start`.

So inputs like:
```js
{ start: 100, end: 20 }
```
normalize into an invalid scene range.

### User-visible symptom
Imported/generated scenes can become impossible to enter, invisible on the timeline, or behave unpredictably in next-scene navigation and active-scene detection.

### Likely fix
Normalize `end` relative to `start`, for example:
```js
const start = ...;
const end = Math.max(start + 1, ...);
```
Also validate scene edits before persisting them.

---

## 8) AI-generated ramp/pacing objects are applied without normalization
**Severity:** Medium  
**Files:** `js/ai-authoring.js:172-176`

### Why it breaks
Generated `rampSettings` and `pacingSettings` are assigned directly into session state without using the module normalizers.

If the model returns malformed values, unsupported enum strings, or incomplete objects, later code may behave unpredictably.

### User-visible symptom
Random or inconsistent adaptive-behavior bugs after AI generation, especially if the model drifts from the requested schema.

### Likely fix
Normalize before assignment, either by:
- importing and using `normalizeRampSettings()` / `normalizePacingSettings()`, or
- adding inline sanitizers the same way `normalizeSession()` does.

---

## 9) The AI JSON extractor is too loose and can parse the wrong span
**Severity:** Medium  
**Files:** `js/ai-authoring.js:121-145`

### Why it breaks
Fallback extraction uses:
- first `{`
- last `}`

If the model emits any extra braces before or after the real payload, the extraction can grab an invalid or unintended span.

### User-visible symptom
Intermittent “unparseable content” failures even when the response visibly contains valid JSON.

### Likely fix
Use a stricter fenced-JSON expectation, a streaming JSON parser, or bracket balancing instead of `indexOf('{')` + `lastIndexOf('}')`.

---

## 10) “Replace session” in AI authoring is only a partial replace
**Severity:** Low / UX correctness  
**Files:** `js/ai-authoring.js:149-179`

### Why it is misleading
In replace mode, the code only replaces:
- blocks
- scenes
- rules

It does **not** reset unrelated session state such as themes, tracks, macros, advanced settings, tracking options, subtitle settings, or safety settings.

### User-visible symptom
A user chooses **Replace session** expecting a clean AI-authored session, but old non-content state persists.

### Likely fix
Either:
- relabel it as “Replace generated content”, or
- start from `defaultSession()` / a normalized skeleton and then apply generated fields.

---

## Lower-priority code smells worth cleaning up
These are not the strongest breakages, but they are worth noting.

### A) Unused variable in session mode application
**File:** `js/session-modes.js`  
`modeNames` is computed and never used. No runtime break, just dead code.

### B) `setApiKey()` accepts any truthy string
**File:** `js/ai-authoring.js`  
UI validation checks for `sk-ant-`, but the storage function itself does not. Programmatic callers can store junk values.

### C) `updateScene()` persists raw patches without normalization
**File:** `js/scenes.js`  
Direct patch assignment makes it easy for invalid timing data to enter state if any future UI/editor path sends unchecked numbers.

---

## Recommended fix order
1. Fix the audio unmute bug.
2. Guard the async playback startup race.
3. Fix escaping and stop injecting raw user strings into attribute HTML.
4. Remove direct-browser API key handling or isolate it behind a proxy.
5. Correct `normalizeSession()` fallback behavior.
6. Tighten scene and AI settings normalization.

---

## Quick verdict
This build looks **substantially healthier** than the previous one: no obvious syntax blockers, and the import/export graph is intact. The biggest remaining problems are now **runtime edge cases and security/integrity issues**, especially around:
- audio track lifecycle
- async playback startup
- HTML rendering of user-controlled strings
- browser-side API key handling
