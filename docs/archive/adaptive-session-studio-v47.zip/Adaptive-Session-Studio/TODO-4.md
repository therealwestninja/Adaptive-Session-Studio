# Adaptive Session Studio v4.5.6 — Security Patch Report for File Imports and Raw Data Ingestion

## Scope

This report focuses on every user-controlled import path that accepts JSON or other raw data formats and then feeds that data into live session state, playback, rendering, persistence, or browser/network APIs.

Reviewed import surfaces:

1. Session package import: `.assp`, `.json`
2. Settings JSON apply panel
3. FunScript track import: `.funscript`, JSON
4. Macro import: `.funscript`, JSON
5. Subtitle import: `.ass`, `.ssa`
6. Audio/video/image imports
7. Per-block media file replacement
8. Persistence reload from `localStorage` for imported session payloads

---

## Executive summary

The app currently treats imported files as trusted content far too early.

The biggest problems are:

- imported JSON is parsed and normalized with **no schema validation and no size limits**
- embedded media is accepted as **arbitrarily large base64 `data:` URLs**
- several imported names and strings can still flow into **unsafe `innerHTML` sinks**
- imported raw data can be persisted to `localStorage`, causing **quota failures, boot failures, and repeated broken-state reloads**
- FunScript and macro JSON imports do not cap action counts or numeric ranges, enabling **memory/CPU bombs and engine abuse**
- subtitle imports have no file-size or cue-count limits, enabling **parsing/rendering DoS**
- browser-side storage of the Anthropic key means any successful XSS becomes **credential theft**

The realistic attack classes are:

- denial of service / tab freeze / storage exhaustion
- stored XSS in the app origin
- same-origin data exfiltration
- theft of browser-stored API keys

I do **not** see an app-native path here for OS-level privilege escalation or browser sandbox escape.

---

## Import surface inventory

### 1) Session package import: `.assp` / `.json`

**Entry point:** `js/main.js:141-155`

- `file.text()` reads the entire file into memory.
- `JSON.parse(text)` parses the whole payload in one shot.
- `normalizeSession(raw)` accepts the parsed structure and turns it into live state.
- The imported session is then rendered and persisted.

Relevant code:

- `js/main.js:141-155`
- `js/state.js:215-325`

### 2) Settings JSON apply panel

**Entry point:** `js/main.js:682-697`

- The JSON editor content is parsed with `JSON.parse(raw)`.
- The result is immediately passed into `normalizeSession(...)`.
- This is effectively a second raw-session ingestion path.

Relevant code:

- `js/main.js:682-697`

### 3) FunScript track import

**Entry point:** `js/main.js:195-203`, `js/funscript.js:249-265`

- File contents are read as text.
- `JSON.parse(...)` is performed in `parseFunScript(...)`.
- Actions are mapped, filtered, sorted, and pushed into live session state.

Relevant code:

- `js/main.js:195-203`
- `js/funscript.js:213-225`
- `js/funscript.js:249-265`

### 4) Macro import

**Entry point:** `js/macro-ui.js:253-265`, `js/macros.js:174-194`

- A file is read as text.
- `JSON.parse(...)` is called directly.
- `actions` are converted and saved into `macroLibrary`.

Relevant code:

- `js/macro-ui.js:253-265`
- `js/macros.js:174-194`

### 5) Subtitle import: `.ass` / `.ssa`

**Entry point:** `js/main.js:177-193`, `js/subtitle.js:7-70`

- Entire subtitle file is read into memory.
- A custom parser tokenizes lines and builds `styles` and `events`.
- The raw source text is also preserved as `rawAss` in session state.

Relevant code:

- `js/main.js:177-193`
- `js/subtitle.js:7-70`

### 6) Audio/video/image imports

**Entry point:** `js/main.js:158-175`

- Each file is converted to a base64 data URL using `FileReader.readAsDataURL`.
- The resulting string is embedded directly into the session model.
- This can massively inflate memory usage and persistent storage use.

Relevant code:

- `js/main.js:158-175`
- `js/state.js:27`

### 7) Per-block media replacement

**Entry point:** `js/ui.js:867-875`

- A block-level file is read as a base64 data URL.
- That string is placed directly on the block object.

Relevant code:

- `js/ui.js:867-875`
- `js/state.js:27`

### 8) Persistence reload path

**Entry point:** `js/state.js:349-363`

- Previously imported state is later reloaded from `localStorage`.
- If imported content caused a bad persisted state, the breakage can recur on boot.

Relevant code:

- `js/state.js:349-363`

---

## Findings

## P1 — Unbounded session import enables JSON bombs, storage exhaustion, and repeated broken-state reloads

**Affected code:**
- `js/main.js:141-155`
- `js/state.js:215-325`
- `js/state.js:349-363`
- `js/state.js:363-375`

### Problem

The session import flow reads the entire file, parses the entire JSON payload, and normalizes it without imposing any hard caps on:

- total file size
- string lengths
- count of blocks, scenes, rules, triggers, subtitle tracks, FunScript tracks, macros
- total subtitle cue count
- total FunScript action count
- size of embedded `data:` media

`normalizeSession(...)` is a permissive shape normalizer, not a security validator. It will clamp some numeric fields, but it does not enforce structural budgets or reject oversized payloads.

Because imported content is then persisted, a malicious or simply oversized session can:

- freeze the tab during import
- fail to save cleanly due to `localStorage` quota
- partially save and then repeatedly fail after reload
- leave the user in a broken state every time the app boots until storage is cleared

### Impact

- reliable denial of service
- session corruption
- storage quota exhaustion
- recurring post-reload boot failures

### Patch

Add a dedicated `validateImportedSession(raw)` stage before `normalizeSession(raw)` that enforces:

- max import file size in bytes
- max decoded total embedded-media bytes
- max blocks/scenes/rules/triggers/tracks/macros
- max string lengths for labels, names, content, URLs, raw subtitle text
- max subtitle events and max FunScript actions per track

Recommended behavior:

- reject the import before normalization if any budget is exceeded
- surface a precise user-facing error message
- never persist partially accepted imported state

Also add a safe boot fallback around persisted-session parsing so a broken saved payload does not brick startup.

---

## P1 — Imported names and strings still have reachable XSS sinks via `innerHTML`

**Affected code:**
- `js/suggestions.js:218-239`
- import sources that populate names/labels: `js/main.js:141-203`, `js/macros.js:174-194`, `js/subtitle.js:7-70`, `js/funscript.js:249-265`

### Problem

The suggestions panel still injects unescaped values directly into `innerHTML`:

- `s.title`
- `s.detail`
- `s.action.label`

These suggestion strings are derived from current session content, including imported names like block labels, subtitle track names, scene names, and FunScript track names.

That means an attacker can craft a malicious imported file whose strings later flow into the suggestions system and render as executable HTML/script payloads.

This is especially dangerous because the app also stores sensitive same-origin data in `localStorage`, including the Anthropic API key.

### Impact

- stored XSS in the app origin
- same-origin local data exfiltration
- API key theft
- session data theft
- arbitrary same-origin requests on behalf of the user

### Patch

Replace string-concatenated `innerHTML` rendering in `suggestions.js` with one of these:

1. DOM node construction with `textContent`
2. a strict escape wrapper applied to every user-controlled field before interpolation

Preferred patch:

- build the card structure with `document.createElement`
- set visible text only with `textContent`
- avoid HTML interpolation for labels/details entirely

Also audit every imported string that can reach `innerHTML` in the UI and convert those renderers to safe text nodes where practical.

---

## P1 — Browser-side API key storage turns any XSS into credential theft

**Affected code:**
- `js/ai-authoring.js:58-67`

### Problem

The Anthropic API key is stored in browser-accessible `localStorage`.

Once any imported-content XSS lands, the attacker can read and exfiltrate the key. This is not an import bug by itself, but it sharply increases the blast radius of every import/rendering bug.

### Impact

- API key theft
- billing abuse
- exposure of future AI-authoring traffic from that browser profile

### Patch

Best fix:

- remove direct browser-side vendor API key storage
- proxy AI requests through a trusted backend
- keep the vendor key server-side only

If that is not yet possible:

- do not persist the key to `localStorage`
- store it in memory only for the current tab session
- clearly warn users that the current mode is insecure

---

## P1 — Raw media imports accept arbitrarily large base64 payloads and can act as session bombs

**Affected code:**
- `js/main.js:158-175`
- `js/ui.js:867-875`
- `js/state.js:27`
- `js/state.js:215-227`

### Problem

Audio, video, image, and block media files are read as `data:` URLs and embedded directly into the session model.

That has several security and stability consequences:

- base64 inflates file size
- imported sessions can become huge very quickly
- persistence to `localStorage` becomes fragile or impossible
- playback paths may attempt to decode massive media blobs at runtime
- malicious `.assp` files can contain huge embedded media without needing a ZIP wrapper

### Impact

- memory pressure
- `localStorage` quota exhaustion
- import and playback freezes
- repeated bad-state reloads if persisted

### Patch

Add hard limits for:

- single media file size before reading
- total embedded-media bytes per session
- maximum number of playlist/block media items

Prefer object URLs or IndexedDB-backed storage over embedding giant base64 strings into session JSON.

At minimum:

- reject media files above a safe threshold before `readAsDataURL`
- reject imported session JSON that contains oversize `data:` URLs

---

## P2 — FunScript track import has no action-count or numeric-range budgets

**Affected code:**
- `js/funscript.js:213-225`
- `js/funscript.js:249-265`

### Problem

`parseFunScript(...)` accepts any JSON object with an `actions` array, converts values with `Number(...)`, filters finite values, sorts, and returns them.

It does not enforce:

- max action count
- monotonic constraints beyond sort
- `at` upper bounds
- `pos` bounds
- per-track duration caps
- total imported tracks cap

A malicious file can include extremely large action arrays or extreme values that drive CPU-heavy sorting and playback processing.

### Impact

- import-time CPU spikes
- large memory use
- playback slowdowns
- device-output weirdness from out-of-range values

### Patch

Before accepting a FunScript import:

- reject files above a byte-size threshold
- reject action arrays above a fixed maximum
- clamp or reject `pos` outside 0-100
- reject negative `at`
- reject absurd durations
- cap total imported FunScript tracks and total cumulative action count

Apply the same validation to both track import and macro import.

---

## P2 — Macro import duplicates the same raw-JSON risks as FunScript import

**Affected code:**
- `js/macro-ui.js:253-265`
- `js/macros.js:174-194`

### Problem

Macro import reimplements the same basic parse/convert flow without meaningful budgets. It accepts an arbitrary JSON `actions` array, sorts it, and stores it in the macro library.

Macros are later used by injection logic, so oversized or pathological action arrays can affect runtime behavior long after import.

### Impact

- memory and CPU pressure
- bloated persistent session state
- runtime instability during macro injection

### Patch

Refactor macro import to use the same validated parser as FunScript import, with dedicated limits for macro duration and action count.

Good hardening step:

- introduce a shared `parseAndValidateActionScript(text, {kind})` utility
- use it from both `importFunScriptFile(...)` and `importMacroFile(...)`

---

## P2 — Subtitle import has no file-size, line-count, or cue-count limits

**Affected code:**
- `js/main.js:177-193`
- `js/subtitle.js:7-70`

### Problem

Subtitle files are read whole, split into lines, parsed into style/event objects, and then the full raw text is preserved in `rawAss`.

There are no caps on:

- file size
- line count
- event count
- text length per cue
- style count

A malicious `.ass`/`.ssa` can therefore consume large amounts of memory at import time and then create repeated O(n) scans during playback because cue lookup uses `.find(...)` over event arrays.

### Impact

- import-time memory and CPU pressure
- playback slowdown with large cue sets
- bloated persisted session state because raw subtitle text is kept verbatim

### Patch

Add subtitle import budgets for:

- max file bytes
- max line count
- max styles
- max events
- max cue text length

Also consider:

- dropping `rawAss` for very large files
- storing only parsed data unless exact round-trip export is required
- indexing cues for playback instead of linear searching every tick

---

## P2 — Settings JSON apply is a second unrestricted raw-session import path

**Affected code:**
- `js/main.js:682-697`

### Problem

The settings JSON panel is effectively a privileged internal import surface. It applies arbitrary JSON directly to `normalizeSession(...)` with the same lack of budgets and structural validation as `.assp` import.

Even if `.assp` import is hardened, this path would still allow oversized or malicious session payloads to be injected manually.

### Impact

- bypass of any protection added only to file import
- same DoS, storage, and rendering risks as session package import

### Patch

Route both `.assp/.json` import and JSON-apply through the same shared validator:

- `parseSessionJson(text)`
- `validateImportedSession(raw)`
- `applyImportedSession(validated)`

Do not maintain separate trust boundaries for “file import” and “JSON apply.”

---

## P2 — Persisted-session boot path lacks a safe recovery path for corrupt or oversized imported state

**Affected code:**
- `js/state.js:349-363`

### Problem

The app reloads saved state from `localStorage` and normalizes it. If the saved state is malformed, oversized, or was partially written after a quota event, startup can fail or recover inconsistently.

### Impact

- recurring boot failure
- hard-to-escape broken app state
- user data loss when manual storage clearing becomes the only recovery option

### Patch

Wrap persisted-session load in a guarded recovery flow:

- try parse + validate + normalize
- on failure, move the bad raw payload to a quarantine key
- restore a safe default session
- notify the user that recovery happened and offer export/download of the quarantined payload for debugging

---

## P3 — File type acceptance relies too much on extension and browser MIME hints

**Affected code:**
- `index.html:42`
- `index.html:130`
- `index.html:142`
- `index.html:488`
- `js/main.js:158-203`
- `js/ui.js:867-875`

### Problem

The app relies on file input `accept=` filters and filename suffixes for UX, but those are not security boundaries. A hostile file can still be selected or renamed.

The current parsers do not consistently verify content signatures or expected top-level structure before deeper processing.

### Impact

- misleading file acceptance
- confusing error handling
- easier adversarial file crafting

### Patch

For each import type, verify the actual content before full processing:

- session import: object with expected session-shaped top-level keys
- FunScript/macro import: object with bounded `actions` array
- ASS/SSA import: requires valid section headers and dialogue format
- media import: validate size and media kind before reading into memory

---

## P3 — Imported content is preserved too literally, increasing attack surface and persistence costs

**Affected code:**
- `js/main.js:187`
- `js/state.js:225-229`
- `js/ui.js:871-873`

### Problem

The app often stores raw imported content directly in session state:

- full base64 media blobs
- full raw subtitle text
- full imported action arrays

This makes the session file both a transport format and a storage container for large opaque payloads. That increases attack surface and makes validation harder.

### Impact

- oversized sessions
- quota failures
- hard-to-inspect attack payloads
- repeated decode/parsing costs after reload

### Patch

Separate the concepts of:

- logical session document
- large binary assets
- imported raw source artifacts

Prefer references plus bounded asset storage over embedding everything inline.

---

## Recommended patch plan

## 1) Build a single import-security layer

Create a shared module, for example:

- `js/import-validate.js`

It should expose validators such as:

- `parseSessionImport(text)`
- `validateImportedSession(raw)`
- `validateFunScript(raw)`
- `validateMacro(raw)`
- `validateSubtitleText(text)`
- `validateMediaFile(file)`
- `estimateEmbeddedMediaBytes(session)`

Every import path should call into this module before mutating app state.

---

## 2) Enforce hard budgets

Suggested categories to cap:

- total session JSON bytes
- total embedded-media bytes
- per-media-file bytes
- number of tracks
- number of blocks/scenes/rules/triggers
- subtitle event count
- FunScript/macro action count
- per-string max length

Reject imports that exceed limits. Do not silently truncate security-sensitive structures unless the user is explicitly informed.

Popup dialogue to ignore safety and import file(s) anyway.

---

## 3) Remove remaining unsafe HTML interpolation for imported content

Prioritize:

- `js/suggestions.js`

Then audit all `innerHTML` renderers that may consume imported strings, even indirectly.

---

## 4) Harden persistence and recovery

- validate before persist where practical
- add safe boot recovery for corrupt saved state
- quarantine invalid saved payloads instead of looping into broken startup

---

## 5) Eliminate browser-persisted vendor secrets

- remove Anthropic key from `localStorage`
- proxy AI calls through a backend if possible

---

## 6) Consider moving large assets out of session JSON

- store binary assets outside session JSON
- keep session exports bounded and inspectable
- avoid base64 blobs in normal autosave state

---

## Quick file-by-file patch checklist

### `js/main.js`
- gate `.assp/.json` import through strict validator
- gate subtitle/FunScript/media imports through size and structure validators
- reuse the same validator for JSON-apply

### `js/state.js`
- add validated load path for persisted session
- add import budget helpers
- fail safe on corrupt saved payloads

### `js/funscript.js`
- validate action counts and ranges before accepting
- reject pathological files early

### `js/macros.js`
- share validated action-script parser with FunScript import
- cap macro size/duration/action count

### `js/subtitle.js`
- cap subtitle size and cue counts
- validate structure before full parse
- consider not storing `rawAss` for large files

### `js/ui.js`
- validate block media replacement before `readAsDataURL`

### `js/suggestions.js`
- replace `innerHTML` interpolation with safe DOM/text rendering

### `js/ai-authoring.js`
- remove persistent browser storage of vendor API key

---

## Bottom line

Yes: an adversarial imported file is a credible threat for this app today.

The highest-priority patch work is:

1. strict validation and hard limits for every import path
2. removal of remaining imported-content XSS sinks
3. stopping browser-persisted API-key exposure
4. safer persistence and recovery behavior

Until those are fixed, a malicious `.assp`, `.json`, `.funscript`, `.ass/.ssa`, or oversized media file can plausibly cause:

- denial of service
- persistent broken state
- stored XSS
- local data/API-key theft

