// ── block-ops.js ───────────────────────────────────────────────────────────
// Block-level operations (duplicate, delete) factored out of main.js so
// ui.js can import them directly without creating a circular dependency.

import { state, persist, uid } from './state.js';
import { history }             from './history.js';
import { notify }              from './notify.js';

// These are set lazily the first time they're called so the module can load
// before renderSidebar/renderInspector are available.
let _renderSidebar  = null;
let _renderInspector = null;

export function registerBlockOpRenderers(rs, ri) {
  _renderSidebar   = rs;
  _renderInspector = ri;
}

export function duplicateBlock() {
  const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
  if (!block) return;
  history.push();
  const copy = { ...structuredClone(block), id: uid(),
                 start: block.start + block.duration + 1, label: `${block.label} copy` };
  state.session.blocks.push(copy);
  state.selectedBlockId = copy.id;
  persist();
  _renderSidebar?.();
  _renderInspector?.();
  notify.info(`Duplicated "${block.label}".`);
}

export function deleteBlock() {
  if (!state.selectedBlockId) return;
  const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
  if (!block) return;
  history.push();
  state.session.blocks = state.session.blocks.filter(b => b.id !== state.selectedBlockId);
  state.selectedBlockId = state.session.blocks[0]?.id || null;
  persist();
  _renderSidebar?.();
  _renderInspector?.();
  notify.info(`Deleted "${block.label}".`);
}
