// ── fullscreen-hud.js ──────────────────────────────────────────────────────
// Manages the fullscreen overlay HUD: session info, macro slot pills,
// controls hint, and auto-hide after 2s of cursor inactivity.

import { state, fmt, esc, $id } from './state.js';
import { allMacros, getSlotMacro, BUILTIN_MACROS } from './macros.js';

let _mouseIdleTimer = null;
let _hudVisible = true;
const HIDE_AFTER_MS = 2500;

export function initFullscreenHud() {
  const stage = $id('mainStage');
  if (!stage) return;

  // Show HUD on mouse move, hide after idle
  stage.addEventListener('mousemove', () => {
    showHud();
    clearTimeout(_mouseIdleTimer);
    _mouseIdleTimer = setTimeout(hideHud, HIDE_AFTER_MS);
  });

  // Always show HUD when entering fullscreen
  document.addEventListener('fullscreenchange', () => {
    if (document.fullscreenElement === stage) {
      updateHud();
      showHud();
      _mouseIdleTimer = setTimeout(hideHud, HIDE_AFTER_MS);
      // Enable cursor tracking for fullscreen
      stage.style.cursor = '';
    } else {
      showHud(); // reset when exiting
      clearTimeout(_mouseIdleTimer);
    }
  });
}

function showHud() {
  const hud = $id('fullscreenHud');
  if (hud) hud.classList.remove('fshud-hidden');
  const stage = $id('mainStage');
  if (stage && document.fullscreenElement === stage) stage.style.cursor = '';
  _hudVisible = true;
}

function hideHud() {
  const hud = $id('fullscreenHud');
  if (hud) hud.classList.add('fshud-hidden');
  const stage = $id('mainStage');
  if (stage && document.fullscreenElement === stage) stage.style.cursor = 'none';
  _hudVisible = false;
}

export function updateHud() {
  if (!document.fullscreenElement) return;

  const rt = state.runtime;
  const s  = state.session;

  // Title and time
  const title = $id('fsHudTitle');
  if (title) title.textContent = esc(s.name || 'Session');

  const time = $id('fsHudTime');
  if (time && rt) {
    const loopStr  = rt.totalLoops ? ` · Loop ${rt.loopIndex+1}/${rt.totalLoops}` : '';
    const sceneStr = rt.activeScene ? ` · ${esc(rt.activeScene.scene.name)}` : '';
    time.textContent = `${fmt(rt.sessionTime)} / ${fmt(s.duration)}${loopStr}${sceneStr}`;
  } else if (time) {
    time.textContent = `— / ${fmt(s.duration)}`;
  }

  // Slot pills — show active injection highlight
  const pillsEl = $id('fsHudSlotPills');
  if (pillsEl) {
    pillsEl.innerHTML = [1,2,3,4,5].map(slot => {
      const macro = getSlotMacro(slot);
      if (!macro) return '';
      // Check if this macro is actively being injected
      const isActive = state.injection?.macroName === macro.name;
      return `<div class="fshud-slot-pill${isActive?' active':''}">
        <span class="fshud-slot-key">${slot}</span>
        <span class="fshud-slot-name">${esc(macro.name)}</span>
      </div>`;
    }).join('');
  }
}

// Called each tick during playback
export function tickHud() {
  if (!document.fullscreenElement) return;
  updateHud();
}
