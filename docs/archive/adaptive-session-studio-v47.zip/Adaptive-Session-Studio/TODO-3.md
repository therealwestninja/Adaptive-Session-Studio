# Adaptive Session Studio v4.5.6 — Detailed Bug Report (deeper pass)

Checked build: `Adaptive-Session-Studio-v4.5.6.zip`

## What I checked this round
- Continued from the prior sandbox report instead of restarting from scratch
- Focused on mutation-heavy workflows: deleting media during playback, importing/replacing sessions, macro library lifetime, and analytics edge cases
- Re-verified that the earlier syntax/import blockers are still fixed in this build

## Summary
This pass turned up more **real runtime/state bugs** beyond the already-reported loop timing and escaping issues. The most important new findings are:
- deleting a playlist audio/video track **during playback does not actually stop/remove the live media**
- loading a new session / sample / import leaves **stale sidebar selection state**, so the inspector can point at removed tracks
- deleting a custom macro leaves **broken slot assignments and stale references** behind
- rules/triggers can report **“macro injected” even when nothing was injected**
- analytics **drops an in-progress attention-loss interval** if the session ends before attention returns

I’ve kept the still-open high-impact items from previous passes at the bottom so this stays useful as a consolidated report.

---

## 1) Deleting playlist tracks during playback does not stop the live media
**Severity:** High  
**Files:** `js/main.js:289-311`, `js/audio-engine.js:45-48`, `js/audio-engine.js:163-175`, `js/playback.js:112-145`

### Why it breaks
The delete handler removes tracks from `state.session`, re-renders the UI, and returns:
```js
if (kind === 'audio') state.session.playlists.audio = ...filter(...)
if (kind === 'video') state.session.playlists.video = ...filter(...)
persist(); renderSidebar(); renderInspector(); return;
```

But it does **not** tear down any already-running playback objects:
- playlist audio routed through Web Audio remains in `_tracks`
- fallback `HTMLAudioElement`s remain in `runtime.backgroundAudio`
- playlist videos/images remain in `runtime.backgroundVideo` and in `#bgHost`

`refreshVolumes()` only updates tracks that still exist in `session.playlists.audio`:
```js
const track = session.playlists.audio.find(a => a.id === t.id);
if (track) {
  t.gainNode.gain.setValueAtTime(...)
}
```
If the track was deleted, it is simply skipped — **not silenced or removed**.

### User-visible symptom
While playback is running, removing a playlist track from the sidebar can leave it:
- still audible
- still visible on the stage
- no longer controllable from the session model/UI

So the UI says the track is gone, but the runtime keeps playing it until full stop/restart.

### Likely fix
On delete, if playback is active:
- explicitly stop/remove the deleted audio node or `HTMLAudioElement`
- explicitly remove the deleted video/image element from `runtime.backgroundVideo` / `#bgHost`
- or rebuild playlist layers from current session state after deletion

---

## 2) New session / sample load / package import leaves stale sidebar selection behind
**Severity:** Medium  
**Files:** `js/main.js:112-128`, `js/main.js:141-155`, `js/ui.js:332-358`

### Why it breaks
These flows replace `state.session` and maybe set `selectedBlockId`, but they do **not** clear sidebar selection state:
```js
state.session = defaultSession();
state.selectedBlockId = null;
```
```js
state.session = sampleSession();
state.selectedBlockId = state.session.blocks[0]?.id || null;
```
```js
state.session = normalizeSession(raw);
state.selectedBlockId = state.session.blocks[0]?.id || null;
```

`state.selectedSidebarType`, `state.selectedSidebarId`, and `state.selectedSidebarIdx` are left untouched.

The inspector then still tries to render whatever old selection was active, for example:
```js
if (state.selectedSidebarType === 'audio' && state.selectedSidebarId) {
  const track = state.session.playlists.audio.find(t => t.id === state.selectedSidebarId);
  return track ? renderAudioTrackInspector(track) : '<div class="insp-status">Track not found.</div>';
}
```

### User-visible symptom
Example failure:
1. Select an audio track
2. Load a sample session or import another package
3. Inspector remains on the old sidebar selection
4. Overlay inspector shows “Track not found.” or otherwise points at stale state instead of the newly loaded content

This makes a successful import/load look partially broken.

### Likely fix
Whenever replacing the entire session, clear all selection state:
```js
state.selectedSidebarType = null;
state.selectedSidebarId = null;
state.selectedSidebarIdx = null;
state.selectedBlockId = ...
```
Then explicitly select the desired default view/block.

---

## 3) Deleting a custom macro leaves broken slot assignments and stale references
**Severity:** High  
**Files:** `js/macros.js:133-158`, `js/playback.js:299-304`, `js/rules-engine.js:104-110`, `js/trigger-windows.js:84-89`

### Why it breaks
Slot resolution is:
```js
export function getSlotMacro(slot) {
  const id = slots[slot];
  return id ? getMacro(id) : (BUILTIN_MACROS[slot - 1] || null);
}
```
If a slot points at a deleted custom macro, `id` is truthy, so the function returns `getMacro(id)` — which is now `null`.
It does **not** fall back to the built-in default.

And `removeMacro()` only removes the macro from `macroLibrary`:
```js
state.session.macroLibrary = state.session.macroLibrary.filter(m => m.id !== id);
```
It does not clean:
- `macroSlots`
- macro blocks using `block.macroId`
- rules using `injectMacro` with a direct macro id
- triggers using `injectMacro` with a direct macro id

### User-visible symptom
After deleting a custom macro:
- slot buttons can silently stop working
- macro blocks can silently stop injecting
- rules/triggers referencing that macro can silently no-op
- the UI may still look configured, but the action is dead

### Likely fix
On macro deletion:
- clear any `macroSlots[slot]` that reference the removed id
- optionally downgrade slot-based references back to the built-in default behavior
- clear or flag direct `macroId` references in blocks/rules/triggers
- surface a warning if a deleted macro was still in use

---

## 4) Rules and triggers can report “macro injected” even when no macro was injected
**Severity:** Medium  
**Files:** `js/rules-engine.js:104-110`, `js/trigger-windows.js:84-89`

### Why it breaks
Both action handlers notify success even when the resolved macro id is missing:

Rules:
```js
let macroId = typeof param === 'number' && param >= 1 && param <= 5
  ? getSlotMacro(param)?.id
  : param;
if (macroId) injectMacro(macroId);
notify.info(`Rule "${name}": injected macro`);
```

Triggers:
```js
let macroId = param;
if (typeof param === 'number' && param >= 1 && param <= 5) macroId = getSlotMacro(param)?.id;
if (macroId) injectMacro(macroId);
notify.info(`${label}: macro injected`);
```

So after a slot breaks or a macro is deleted, the action can no-op but still claim success.

### User-visible symptom
The user gets a reassuring toast saying a macro was injected, but nothing actually happens.
That makes debugging broken automation much harder.

### Likely fix
Only show the success toast when a valid macro id was resolved and injection actually started. Otherwise show a warning/error like:
- `slot 3 has no valid macro assigned`
- `macro "X" was deleted`

---

## 5) Analytics drops an in-progress attention-loss interval if the session ends before attention returns
**Severity:** Medium  
**Files:** `js/session-analytics.js:55-67`, `js/session-analytics.js:70-99`

### Why it breaks
Attention-loss duration is only accumulated on return:
```js
notifyAttentionLost()    => a._attentionLostAt = performance.now();
notifyAttentionReturned() => a.attentionLossTotalSec += ...; a._attentionLostAt = null;
```

But `finaliseAnalytics()` uses only the stored total:
```js
attentionLossTotalSec: Math.round(a.attentionLossTotalSec),
```
It does **not** fold in a currently open `_attentionLostAt` interval.

### Real failure mode
1. Attention is lost
2. `_attentionLostAt` is set
3. Session ends before attention returns
4. Final analytics omit the currently ongoing loss duration

### User-visible symptom
The post-session summary can under-report attention-loss time, sometimes by the entire final lost interval.
Event count may say there was a loss, but total lost time is too low.

### Likely fix
During finalization, if `_attentionLostAt !== null`, add:
```js
(performance.now() - a._attentionLostAt) / 1000
```
to the final total before storing the summary.

---

## 6) Built-in macro editor can silently create a saved copy before the user clicks “Save as copy”
**Severity:** Low-Medium  
**Files:** `js/macro-ui.js:146-190`

### Why it breaks
When editing a built-in macro, the working copy is immediately converted into a new custom macro id:
```js
let working = structuredClone(macro);
if (working.builtin) { working.id = uid(); working.builtin = false; }
```

The UI label says built-ins require **“Save as copy”**, but some editor actions save immediately anyway:
```js
working.actions.splice(idx, 1);
saveMacro(working);
```
```js
working.actions.push(...);
saveMacro(working);
```

### User-visible symptom
Editing a built-in macro can create a saved custom copy just by adding/removing points, even if the user never clicked **Save as copy**.
That is inconsistent with the UI and can clutter the macro library unexpectedly.

### Likely fix
Keep built-in edits in an unsaved working copy until the explicit save action. Avoid `saveMacro()` on add/delete until the user confirms.

---

# Previously reported issues still open
These are still present in this build and remain high-value fixes:

## 7) Suggestions panel has an unescaped HTML injection path
**Severity:** High  
**Files:** `js/suggestions.js:31-38`, `js/suggestions.js:55-60`, `js/suggestions.js:69-76`, `js/suggestions.js:218-235`

User-derived labels/names flow into suggestion `title` / `detail`, then into `innerHTML` without escaping.

## 8) Session mode cleanup is brittle: renamed mode rules survive and stack
**Severity:** High  
**Files:** `js/session-modes.js:149-154`

Mode-generated rules are removed by display-name prefix only, so renaming one lets it survive later mode changes.

## 9) Analytics counts the current partial loop as a completed loop
**Severity:** Medium  
**Files:** `js/session-analytics.js:75-77`

`loopsCompleted = runtime.loopIndex + 1` overcounts unfinished sessions.

## 10) Profile streak logic uses UTC dates, so streaks can be wrong around local midnight
**Severity:** Medium  
**Files:** `js/user-profile.js:120-139`

Day grouping uses `toISOString().slice(0,10)`, so local-day streaks can be wrong.

## 11) One-shot block volume inspector still mishandles zero volume and has a UI/data mismatch
**Severity:** Medium  
**Files:** `js/ui.js:392`, `js/ui.js:400`, `js/playback.js:289`, `js/playback.js:298`

Inspector uses `block.volume || 1`, so stored `0` renders back as `1`.

## 12) Trigger-name attribute injection path is still open
**Severity:** Medium  
**Files:** `js/trigger-windows.js:202-209`

Trigger names are inserted into an `<input value="...">` without escaping.

## 13) Rules still use loop-relative time for cooldowns, so they fail across loops
**Severity:** High  
**Files:** `js/rules-engine.js:132-144`, `js/state-engine.js:111-118`

Cooldowns are based on per-loop `sessionTime`, which resets every loop.

## 14) Trigger windows still use loop-relative time for cooldown/open timing
**Severity:** High  
**Files:** `js/trigger-windows.js:101-130`

Trigger window timing is also tied to resetting per-loop `sessionTime`.

## 15) Trigger actions are still not fully configurable from the UI
**Severity:** High  
**Files:** `js/trigger-windows.js:202-247`, `js/trigger-windows.js:271-272`, `js/trigger-windows.js:84-92`

The UI exposes action types like `injectMacro` / `setIntensity` / `setSpeed` but still does not expose their params or cooldown editor.

## 16) `setIntensity(0)` is still impossible through rule/trigger action execution
**Severity:** Medium  
**Files:** `js/rules-engine.js:114`, `js/trigger-windows.js:91`

`Number(param) || 1` turns `0` into `1`.

## 17) Browser-side Anthropic API key exposure is still present
**Severity:** High  
**Files:** `js/ai-authoring.js`

The API key remains stored and used in the client, which is fundamentally unsafe for a production/shared deployment.

