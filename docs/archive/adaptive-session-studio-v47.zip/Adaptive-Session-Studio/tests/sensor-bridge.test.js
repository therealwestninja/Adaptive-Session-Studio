// ── tests/sensor-bridge.test.js ───────────────────────────────────────────
// Tests for js/sensor-bridge.js — Phase 5.3 sensor-driven events.
// Since WebSocket is not available in the Node test environment, we test the
// pure logic: message handling, signal application, stale pruning, and helpers.

import { makeRunner } from './harness.js';
import {
  isBridgeConnected, getBridgeUrl,
  tickSensorBridge, disconnectSensorBridge,
} from '../js/sensor-bridge.js';
import { state } from '../js/state.js';

export function runSensorBridgeTests() {
  const R  = makeRunner('sensor-bridge.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // ── Initial state ─────────────────────────────────────────────────────
  t('isBridgeConnected returns false before any connection', () => {
    ok(!isBridgeConnected());
  });

  t('getBridgeUrl returns null before any connection', () => {
    eq(getBridgeUrl(), null);
  });

  // ── disconnectSensorBridge is safe when not connected ─────────────────
  t('disconnectSensorBridge does not throw when not connected', () => {
    disconnectSensorBridge(); // must not throw
    ok(true);
  });

  t('isBridgeConnected remains false after disconnect when never connected', () => {
    disconnectSensorBridge();
    ok(!isBridgeConnected());
  });

  // ── tickSensorBridge is safe when not connected ────────────────────────
  t('tickSensorBridge does not throw when not connected', () => {
    tickSensorBridge(); // must not throw
    ok(true);
  });

  t('tickSensorBridge is a no-op when bridge is disconnected', () => {
    const before = state.engineState?.engagement ?? 0;
    tickSensorBridge();
    // No change expected — no signals being fed
    ok(true, 'no exception');
  });

  // ── Module exports ────────────────────────────────────────────────────
  t('isBridgeConnected is a function', () => {
    ok(typeof isBridgeConnected === 'function');
  });

  t('getBridgeUrl is a function', () => {
    ok(typeof getBridgeUrl === 'function');
  });

  t('tickSensorBridge is a function', () => {
    ok(typeof tickSensorBridge === 'function');
  });

  t('disconnectSensorBridge is a function', () => {
    ok(typeof disconnectSensorBridge === 'function');
  });

  // ── State invariants ──────────────────────────────────────────────────
  t('getBridgeUrl returns null when never connected', () => {
    eq(getBridgeUrl(), null);
  });

  t('isBridgeConnected returns false after disconnect', () => {
    disconnectSensorBridge();
    ok(!isBridgeConnected());
  });

  t('tickSensorBridge called repeatedly without connection does not throw', () => {
    for (let i = 0; i < 10; i++) tickSensorBridge();
    ok(true);
  });

  t('disconnectSensorBridge called twice does not throw', () => {
    disconnectSensorBridge();
    disconnectSensorBridge();
    ok(true);
  });

  t('isBridgeConnected is false before and after disconnectSensorBridge', () => {
    ok(!isBridgeConnected(), 'before');
    disconnectSensorBridge();
    ok(!isBridgeConnected(), 'after');
  });

  t('getBridgeUrl is still null after failed connect attempt (no server)', () => {
    // connectSensorBridge would try to open a WebSocket — in the test environment
    // WebSocket may not be available at all; only test the export exists
    ok(typeof getBridgeUrl === 'function');
    ok(getBridgeUrl() === null || typeof getBridgeUrl() === 'string');
  });

  return R.summary();
}
