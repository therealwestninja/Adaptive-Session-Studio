// ── tests/safety.test.js ─────────────────────────────────────────────────
// Tests for normalizeSafetySettings, clampIntensity, clampSpeed

import { makeRunner } from './harness.js';
import { normalizeSafetySettings, defaultSafetySettings,
         clampIntensity, clampSpeed, tickSafety,
         recordEmergencyStop, isEmergencyCooldownActive,
         getEmergencyCooldownRemaining } from '../js/safety.js';
import { state } from '../js/state.js';

export function runSafetyTests() {
  const R  = makeRunner('safety.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // ── defaultSafetySettings ────────────────────────────────────────────
  t('defaultSafetySettings returns expected defaults', () => {
    const s = defaultSafetySettings();
    eq(s.maxIntensity,         2.0);
    eq(s.maxSpeed,             4.0);
    eq(s.emergencyCooldownSec, 30);
    eq(s.warnAbove,            1.5);
    ok(s.autoReduceOnLoss === false);
    eq(s.autoReduceTarget,     0.8);
  });

  // ── normalizeSafetySettings ──────────────────────────────────────────
  t('normalizeSafetySettings null → defaults', () => {
    const s = normalizeSafetySettings(null);
    eq(s.maxIntensity, 2.0);
    eq(s.maxSpeed, 4.0);
  });
  t('normalizeSafetySettings clamps maxIntensity 0-2', () => {
    eq(normalizeSafetySettings({ maxIntensity: -1 }).maxIntensity, 0);
    eq(normalizeSafetySettings({ maxIntensity:  5 }).maxIntensity, 2);
  });
  t('normalizeSafetySettings clamps maxSpeed 0.25-4', () => {
    eq(normalizeSafetySettings({ maxSpeed: 0 }).maxSpeed, 0.25);
    eq(normalizeSafetySettings({ maxSpeed: 10 }).maxSpeed, 4);
  });
  t('normalizeSafetySettings clamps warnAbove 0-2', () => {
    eq(normalizeSafetySettings({ warnAbove: 3 }).warnAbove, 2);
    eq(normalizeSafetySettings({ warnAbove: -1 }).warnAbove, 0);
  });
  t('normalizeSafetySettings clamps emergencyCooldownSec min 0', () => {
    eq(normalizeSafetySettings({ emergencyCooldownSec: -5 }).emergencyCooldownSec, 0);
  });
  t('normalizeSafetySettings preserves autoReduceOnLoss:true', () => {
    ok(normalizeSafetySettings({ autoReduceOnLoss: true }).autoReduceOnLoss === true);
  });
  t('normalizeSafetySettings defaults autoReduceOnLoss to false', () => {
    ok(normalizeSafetySettings({}).autoReduceOnLoss === false);
  });
  t('normalizeSafetySettings clamps autoReduceTarget 0-2', () => {
    eq(normalizeSafetySettings({ autoReduceTarget: 5 }).autoReduceTarget, 2);
    eq(normalizeSafetySettings({ autoReduceTarget: -1 }).autoReduceTarget, 0);
  });

  // ── clampIntensity ────────────────────────────────────────────────────
  function withSafetySettings(ss) {
    state.session = { ...state.session, safetySettings: ss };
  }

  t('clampIntensity passes through values below cap', () => {
    withSafetySettings({ maxIntensity: 2.0, warnAbove: 1.8 });
    eq(clampIntensity(1.2), 1.2);
  });
  t('clampIntensity caps at maxIntensity', () => {
    withSafetySettings({ maxIntensity: 1.2, warnAbove: 1.5 });
    eq(clampIntensity(1.8), 1.2);
  });
  t('clampIntensity with null safetySettings uses defaults', () => {
    withSafetySettings(null);
    // Default maxIntensity = 2.0 — should pass anything <= 2.0 unchanged
    eq(clampIntensity(1.9), 1.9);
  });

  // ── clampSpeed ────────────────────────────────────────────────────────
  t('clampSpeed passes through values below cap', () => {
    withSafetySettings({ maxSpeed: 4.0 });
    eq(clampSpeed(2.5), 2.5);
  });
  t('clampSpeed caps at maxSpeed', () => {
    withSafetySettings({ maxSpeed: 2.0, warnAbove: 1.5 });
    eq(clampSpeed(3.0), 2.0);
  });

  // ── Emergency cooldown ────────────────────────────────────────────────
  t('isEmergencyCooldownActive false before any emergency stop', () => {
    // Before any call — the last emergency time starts at -Infinity
    // (but previous tests may have called recordEmergencyStop; skip this test
    //  if we can't guarantee fresh state — just test the shape)
    ok(typeof isEmergencyCooldownActive() === 'boolean');
  });
  t('isEmergencyCooldownActive true immediately after recordEmergencyStop', () => {
    withSafetySettings({ emergencyCooldownSec: 30 });
    recordEmergencyStop();
    ok(isEmergencyCooldownActive() === true);
  });
  t('getEmergencyCooldownRemaining > 0 after emergency stop', () => {
    withSafetySettings({ emergencyCooldownSec: 30 });
    recordEmergencyStop();
    ok(getEmergencyCooldownRemaining() > 0 && getEmergencyCooldownRemaining() <= 30);
  });



// ── tickSafety ─────────────────────────────────────────────────────────────
  t('tickSafety is a no-op when autoReduceOnLoss is false', () => {
    state.session.safetySettings = normalizeSafetySettings({ autoReduceOnLoss: false });
    state.runtime = {};
    state.liveControl = { intensityScale: 1.5 };
    state.engineState = { attention: 0 }; // attention lost
    tickSafety(); // should not throw, should not change liveControl
    ok(state.liveControl.intensityScale === 1.5, 'should not reduce intensity');
    state.runtime = null;
  });

  t('tickSafety is a no-op when runtime is null', () => {
    state.session.safetySettings = normalizeSafetySettings({ autoReduceOnLoss: true });
    state.runtime = null;
    state.liveControl = { intensityScale: 1.5 };
    state.engineState = { attention: 0 };
    tickSafety(); // must not throw
    ok(true, 'no exception');
  });

  t('tickSafety is a no-op when liveControl is null', () => {
    state.session.safetySettings = normalizeSafetySettings({ autoReduceOnLoss: true });
    state.runtime = {};
    state.liveControl = null;
    state.engineState = { attention: 0 };
    tickSafety(); // must not throw
    ok(true, 'no exception');
    state.runtime = null;
  });

  return R.summary();
}
