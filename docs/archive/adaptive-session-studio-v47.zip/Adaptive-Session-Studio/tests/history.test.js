// ── tests/history.test.js ─────────────────────────────────────────────────
// Tests for js/history.js — push/undo/redo state transitions, canUndo/canRedo,
// clear, and depth() reporting.
//
// NOTE: history.js depends on state.js and persist(). In a browser test
// environment, state.js initializes cleanly (localStorage empty → sampleSession),
// and persist() writes to localStorage, which is acceptable here.
// The DOM helpers in _notifyChange (undo/redo button disable) will silently
// no-op since the test page does not include those elements.

import { makeRunner } from './harness.js';
import { history } from '../js/history.js';
import { state } from '../js/state.js';

export function runHistoryTests() {
  const R = makeRunner('history.js');
  const t = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  // Reset to a clean baseline before each group by clearing history
  // and setting a known session state. We use mutation of state.session
  // directly to keep tests isolated.

  function reset() {
    history.clear();
    // Give state.session a known baseline
    state.session = { ...state.session, name: 'baseline', loopMode: 'none' };
  }

  // ── Initial state ─────────────────────────────────────────────────────
  t('canUndo returns false on empty stack', () => {
    reset();
    ok(!history.canUndo());
  });
  t('canRedo returns false on empty stack', () => {
    reset();
    ok(!history.canRedo());
  });
  t('depth() returns zero past and future after clear', () => {
    reset();
    const d = history.depth();
    eq(d.past, 0);
    eq(d.future, 0);
  });

  // ── push ─────────────────────────────────────────────────────────────
  t('canUndo returns true after push', () => {
    reset();
    history.push();
    ok(history.canUndo());
  });
  t('canRedo returns false immediately after push', () => {
    reset();
    history.push();
    ok(!history.canRedo());
  });
  t('depth().past increments on push', () => {
    reset();
    history.push();
    history.push();
    eq(history.depth().past, 2);
  });
  t('push clears the redo stack', () => {
    reset();
    history.push();
    state.session = { ...state.session, name: 'step1' };
    history.undo();                   // creates a redo entry
    ok(history.canRedo(), 'sanity: redo should be available');
    history.push();                   // new action should clear redo
    ok(!history.canRedo(), 'redo stack must be cleared by push');
  });

  // ── undo ─────────────────────────────────────────────────────────────
  t('undo restores previous session state', () => {
    reset();
    const before = state.session.name;
    history.push();
    state.session = { ...state.session, name: 'mutated' };
    history.undo();
    eq(state.session.name, before, 'undo must restore name to pre-mutation value');
  });
  t('canRedo returns true after undo', () => {
    reset();
    history.push();
    state.session = { ...state.session, name: 'changed' };
    history.undo();
    ok(history.canRedo());
  });
  t('canUndo returns false after full undo', () => {
    reset();
    history.push();
    history.undo();
    ok(!history.canUndo());
  });
  t('undo is a no-op when stack is empty', () => {
    reset();
    const nameBefore = state.session.name;
    history.undo(); // must not throw
    eq(state.session.name, nameBefore);
  });
  t('depth().future increments after undo', () => {
    reset();
    history.push();
    history.push();
    history.undo();
    eq(history.depth().future, 1);
    eq(history.depth().past,   1);
  });

  // ── redo ─────────────────────────────────────────────────────────────
  t('redo restores undone state', () => {
    reset();
    history.push();
    state.session = { ...state.session, name: 'step-forward' };
    history.undo();
    history.redo();
    eq(state.session.name, 'step-forward');
  });
  t('canRedo returns false after redo consumes stack', () => {
    reset();
    history.push();
    history.undo();
    history.redo();
    ok(!history.canRedo());
  });
  t('redo is a no-op when stack is empty', () => {
    reset();
    const nameBefore = state.session.name;
    history.redo(); // must not throw
    eq(state.session.name, nameBefore);
  });

  // ── Multi-step undo/redo ──────────────────────────────────────────────
  t('multi-step undo/redo sequence is consistent', () => {
    reset();
    const names = ['alpha', 'beta', 'gamma'];
    for (const name of names) {
      history.push();
      state.session = { ...state.session, name };
    }
    // Undo all three
    history.undo(); // back to beta
    history.undo(); // back to alpha
    history.undo(); // back to baseline
    eq(state.session.name, 'baseline');
    // Redo to gamma in one shot
    history.redo();
    history.redo();
    history.redo();
    eq(state.session.name, 'gamma');
  });

  // ── clear ─────────────────────────────────────────────────────────────
  t('clear empties past stack', () => {
    reset();
    history.push();
    history.push();
    history.clear();
    ok(!history.canUndo());
    eq(history.depth().past, 0);
  });
  t('clear empties future stack', () => {
    reset();
    history.push();
    history.undo();
    ok(history.canRedo(), 'sanity');
    history.clear();
    ok(!history.canRedo());
    eq(history.depth().future, 0);
  });

  // ── MAX_HISTORY cap ───────────────────────────────────────────────────
  t('history stack does not exceed 60 entries', () => {
    reset();
    for (let i = 0; i < 70; i++) history.push();
    ok(history.depth().past <= 60, `past depth should be ≤60, got ${history.depth().past}`);
  });

  t('redo stack is also capped at 60 entries', () => {
    reset();
    // Push 65 entries so past is at 60
    for (let i = 0; i < 65; i++) history.push();
    // Undo them all — each undo should move one from past to future (capped at 60)
    for (let i = 0; i < 65; i++) history.undo();
    ok(history.depth().future <= 60, `future depth should be ≤60, got ${history.depth().future}`);
  });

  t('undo/redo round-trip preserves session name', () => {
    reset();
    state.session = { ...state.session, name: 'before' };
    history.push();
    state.session = { ...state.session, name: 'after' };
    history.undo();
    eq(state.session.name, 'before', 'undo should restore "before"');
    history.redo();
    eq(state.session.name, 'after', 'redo should restore "after"');
  });

  t('depth() reports accurate past and future counts', () => {
    reset();
    history.push(); // past=1
    history.push(); // past=2
    state.session = { ...state.session, name: 'step2' };
    history.undo(); // past=1, future=1
    eq(history.depth().past, 1);
    eq(history.depth().future, 1);
    history.undo(); // past=0, future=2
    eq(history.depth().past, 0);
    eq(history.depth().future, 2);
    history.redo(); // past=1, future=1
    eq(history.depth().past, 1);
    eq(history.depth().future, 1);
  });

  // ── Block mutation undo ───────────────────────────────────────────────────
  t('undo restores block count after a block is added', () => {
    reset();
    const originalCount = state.session.blocks.length;
    history.push();
    state.session.blocks = [...state.session.blocks, { id: 'new-b', type: 'text', label: 'New', start: 0, duration: 5, content: '' }];
    eq(state.session.blocks.length, originalCount + 1, 'sanity: block was added');
    history.undo();
    eq(state.session.blocks.length, originalCount, 'undo should restore original block count');
  });

  t('undo restores block label mutation', () => {
    reset();
    if (!state.session.blocks.length) return; // skip if session has no blocks
    const firstId = state.session.blocks[0].id;
    const origLabel = state.session.blocks[0].label;
    history.push();
    state.session.blocks[0].label = 'Changed Label';
    history.undo();
    const restored = state.session.blocks.find(b => b.id === firstId);
    ok(restored?.label === origLabel, 'undo should restore original block label');
  });

  t('history uses deep clone — mutating session after push does not corrupt history', () => {
    reset();
    history.push();
    const snapshotName = state.session.name;
    // Mutate state AFTER the push
    state.session.name = 'mutated-after-push';
    history.undo();
    eq(state.session.name, snapshotName, 'history snapshot should be isolated from later mutations');
  });

  t('redo after undo restores the mutated state', () => {
    reset();
    history.push();
    state.session = { ...state.session, name: 'after' };
    history.undo();
    history.redo();
    eq(state.session.name, 'after', 'redo should restore the mutated state');
  });

  t('multiple push calls create independent snapshots', () => {
    reset();
    history.push();
    state.session = { ...state.session, name: 'step1' };
    history.push();
    state.session = { ...state.session, name: 'step2' };
    history.undo();
    eq(state.session.name, 'step1');
    history.undo();
    eq(state.session.name, 'baseline');
  });

  return R.summary();
}
