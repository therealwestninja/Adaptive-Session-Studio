// ── tests/session-modes.test.js ──────────────────────────────────────────────
// Tests for SESSION_MODES definitions and applySessionMode() in session-modes.js

import { makeRunner } from './harness.js';
import { SESSION_MODES, applySessionMode } from '../js/session-modes.js';
import { state, defaultSession, normalizeSession } from '../js/state.js';

export function runSessionModesTests() {
  const R  = makeRunner('session-modes.js');
  const t  = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const ok = R.assert.bind(R);

  function reset() {
    state.session = normalizeSession(defaultSession());
    state.session.blocks = [];
    state.session.rules  = [];
  }

  // ── MODULE SHAPE ───────────────────────────────────────────────────────────
  t('SESSION_MODES is a non-empty array', () => {
    ok(Array.isArray(SESSION_MODES) && SESSION_MODES.length > 0);
  });

  t('each mode has required fields', () => {
    for (const m of SESSION_MODES) {
      ok(typeof m.id          === 'string' && m.id.length > 0,   `id missing on mode`);
      ok(typeof m.name        === 'string' && m.name.length > 0, `name missing on ${m.id}`);
      ok(typeof m.description === 'string',                       `description missing on ${m.id}`);
      ok(typeof m.icon        === 'string',                       `icon missing on ${m.id}`);
      ok(Array.isArray(m.rules),                                  `rules must be array on ${m.id}`);
    }
  });

  t('all four expected modes exist', () => {
    const ids = SESSION_MODES.map(m => m.id);
    ok(ids.includes('exposure'),    'exposure mode missing');
    ok(ids.includes('mindfulness'), 'mindfulness mode missing');
    ok(ids.includes('focus'),       'focus mode missing');
    ok(ids.includes('freerun'),     'freerun mode missing');
  });

  // ── applySessionMode — exposure ────────────────────────────────────────────
  t('applySessionMode exposure sets rampSettings', () => {
    reset();
    applySessionMode('exposure');
    ok(state.session.rampSettings !== null, 'rampSettings should be set');
    ok(state.session.rampSettings?.enabled === true, 'ramp should be enabled');
    eq(state.session.rampSettings?.mode, 'time');
  });

  t('applySessionMode exposure adds rules with [Exposure] prefix', () => {
    reset();
    applySessionMode('exposure');
    const exposureRules = state.session.rules.filter(r => r.name.startsWith('[Exposure]'));
    ok(exposureRules.length > 0, 'should have at least one Exposure rule');
  });

  t('applySessionMode preserves custom rules', () => {
    reset();
    state.session.rules = [{
      id: 'custom', name: 'My custom rule', enabled: true,
      condition: { metric: 'sessionTime', op: '>', value: 60 },
      durationSec: 1, cooldownSec: 0,
      action: { type: 'nextScene', param: null }
    }];
    applySessionMode('exposure');
    const custom = state.session.rules.find(r => r.id === 'custom');
    ok(custom !== undefined, 'custom rule should be preserved');
  });

  t('applying exposure again replaces existing Exposure rules, not duplicates them', () => {
    reset();
    applySessionMode('exposure');
    const count1 = state.session.rules.filter(r => r.name.startsWith('[Exposure]')).length;
    applySessionMode('exposure');
    const count2 = state.session.rules.filter(r => r.name.startsWith('[Exposure]')).length;
    eq(count1, count2, 'applying same mode twice should not double-up rules');
  });

  // ── applySessionMode — mindfulness ─────────────────────────────────────────
  t('applySessionMode mindfulness sets engagement ramp mode', () => {
    reset();
    applySessionMode('mindfulness');
    eq(state.session.rampSettings?.mode, 'engagement');
  });

  t('applySessionMode mindfulness enables pacing', () => {
    reset();
    applySessionMode('mindfulness');
    ok(state.session.pacingSettings?.enabled === true, 'pacing should be enabled');
  });

  // ── applySessionMode — freerun ─────────────────────────────────────────────
  t('applySessionMode freerun sets rampSettings to null', () => {
    reset();
    applySessionMode('exposure');
    ok(state.session.rampSettings?.enabled === true, 'sanity: exposure should enable ramp');
    applySessionMode('freerun');
    ok(state.session.rampSettings === null, 'freerun should null rampSettings');
    ok(state.session.pacingSettings === null, 'freerun should null pacingSettings');
  });

  t('applySessionMode freerun removes mode-specific rules', () => {
    reset();
    applySessionMode('mindfulness');
    const before = state.session.rules.filter(r => r.name.startsWith('[Mindfulness]')).length;
    ok(before > 0);
    applySessionMode('freerun');
    const after = state.session.rules.filter(r =>
      r.name.startsWith('[Mindfulness]') || r.name.startsWith('[Exposure]') || r.name.startsWith('[Focus]')
    ).length;
    eq(after, 0, 'freerun should remove all mode-prefixed rules');
  });

  // ── applySessionMode — unknown mode ────────────────────────────────────────
  t('applySessionMode returns undefined for unknown mode id', () => {
    reset();
    const result = applySessionMode('nonexistent_mode');
    // bare `return` with no notify in test env — result is undefined
    ok(result === undefined || result === null, `got ${result}`);
  });

  // ── Rule normalization ─────────────────────────────────────────────────────
  t('all mode rules normalize correctly', () => {
    for (const mode of SESSION_MODES) {
      for (const rule of mode.rules) {
        ok(typeof rule.name === 'string',                          `${mode.id} rule name invalid`);
        ok(typeof rule.condition?.metric === 'string',             `${mode.id} rule condition.metric missing`);
        ok(typeof rule.condition?.op === 'string',                 `${mode.id} rule condition.op missing`);
        ok(typeof rule.condition?.value === 'number',              `${mode.id} rule condition.value missing`);
        ok(typeof rule.action?.type === 'string',                  `${mode.id} rule action.type missing`);
      }
    }
  });

  return R.summary();
}
