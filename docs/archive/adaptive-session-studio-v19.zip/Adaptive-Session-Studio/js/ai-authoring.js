// ── ai-authoring.js ────────────────────────────────────────────────────────
// AI-Assisted Session Authoring — ROADMAP Phase 18
//
// Calls the Anthropic API (claude-sonnet-4-20250514) to generate session
// content (blocks, scenes, rules, ramp settings) from a natural-language
// description. All generated content is normalized before applying.

import { state, persist, normalizeBlock, normalizeScene } from './state.js';
import { notify }    from './notify.js';
import { history }   from './history.js';
import { normalizeRule }  from './rules-engine.js';
import { drawTimeline }   from './funscript.js';
import { renderRampPanel, renderPacingPanel } from './live-control.js';

// ── System prompt for session generation ─────────────────────────────────────
const SYSTEM_PROMPT = `You are a session design assistant for Adaptive Session Studio, a browser app for creating adaptive multimedia sessions with attention tracking and behavioral scripting.

You generate session configurations as JSON. The user describes a session experience and you produce structured content.

Respond ONLY with valid JSON — no markdown, no preamble, no explanation. Use this exact schema:

{
  "name": "session name",
  "duration": 180,
  "loopMode": "none",
  "blocks": [
    { "type": "text|tts|audio|pause|macro", "label": "label", "start": 0, "duration": 10, "content": "text or empty", "fontSize": 1.2, "volume": 1, "_position": "center", "macroSlot": null }
  ],
  "scenes": [
    { "name": "Scene name", "start": 0, "end": 60, "loopBehavior": "once", "color": "#5fa0dc" }
  ],
  "rules": [
    { "name": "rule name", "enabled": true, "condition": { "metric": "attention", "op": "<", "value": 0.4 }, "durationSec": 3, "cooldownSec": 30, "action": { "type": "pause", "param": null } }
  ],
  "rampSettings": {
    "enabled": true, "mode": "time", "startVal": 0.5, "endVal": 1.2, "curve": "sine", "steps": [], "blendMode": "max"
  },
  "pacingSettings": null
}

Rules:
- block types: "text" (overlay text), "tts" (spoken), "audio" (sound file), "pause" (silence), "macro" (trigger slot)
- all block start/duration values are in seconds; no overlapping required
- scenes represent named phases of the session
- rule metrics: attention, intensity, speed, engagement, sessionTime, loopCount
- rule action types: pause, resume, stop, injectMacro, setIntensity, setSpeed, nextScene
- ramp modes: time, engagement, adaptive, step
- ramp curves: linear, exponential, sine
- loopMode: none, count, forever
- keep sessions practical: 60–600 seconds, 3–12 blocks, 0–3 scenes, 0–3 rules
- For mindfulness/focus sessions: low ramp (0.2–0.8), engagement mode
- For training/challenge: time mode, exponential curve, add attention rules
- content field for "text" and "tts" blocks must be non-empty
- Do not invent file paths for audio blocks — leave content empty
- Omit rampSettings or pacingSettings if not relevant (set to null)`;

// ── Generate session from prompt ──────────────────────────────────────────────
export async function generateSession(prompt, opts = {}) {
  const { onProgress } = opts;
  onProgress?.('Connecting to Claude…');

  let responseText = '';
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model:      'claude-sonnet-4-20250514',
        max_tokens: 1500,
        system:     SYSTEM_PROMPT,
        messages:   [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error?.message ?? `HTTP ${response.status}`);
    }

    const data = await response.json();
    responseText = data.content?.filter(c => c.type === 'text').map(c => c.text).join('') ?? '';

    onProgress?.('Parsing response…');

    // Strip any accidental markdown code fences
    responseText = responseText.replace(/^```(?:json)?\s*/m, '').replace(/\s*```$/m, '').trim();
    const parsed = JSON.parse(responseText);
    return parsed;

  } catch (err) {
    if (err instanceof SyntaxError) {
      throw new Error(`AI returned invalid JSON. Raw: ${responseText.slice(0, 200)}`);
    }
    throw err;
  }
}

// ── Apply generated session content ──────────────────────────────────────────
export function applyGeneratedContent(generated, mode = 'merge') {
  history.push();
  const s = state.session;

  if (generated.name)     s.name     = generated.name;
  if (generated.duration) s.duration = Math.max(10, Math.round(generated.duration));
  if (generated.loopMode) s.loopMode = generated.loopMode;

  if (Array.isArray(generated.blocks)) {
    const newBlocks = generated.blocks.map((b, i) => normalizeBlock(b, i));
    s.blocks = mode === 'replace' ? newBlocks : [...s.blocks, ...newBlocks];
  }

  if (Array.isArray(generated.scenes)) {
    const newScenes = generated.scenes.map(sc => normalizeScene(sc));
    s.scenes = mode === 'replace' ? newScenes : [...s.scenes, ...newScenes];
  }

  if (Array.isArray(generated.rules)) {
    const newRules = generated.rules.map(r => normalizeRule(r));
    s.rules = mode === 'replace' ? newRules : [...(s.rules ?? []), ...newRules];
  }

  if (generated.rampSettings) {
    s.rampSettings = generated.rampSettings;
  }
  if (generated.pacingSettings) {
    s.pacingSettings = generated.pacingSettings;
  }

  persist();
}

// ── AI Authoring panel renderer ───────────────────────────────────────────────
export function renderAiAuthoringPanel(containerId = 'aiAuthoringPanel') {
  const el = document.getElementById(containerId);
  if (!el) return;

  el.innerHTML = `
    <div class="insp-group-label" style="margin-bottom:8px">✦ AI Session Generator</div>
    <p style="font-size:11px;color:var(--text2);line-height:1.6;margin-bottom:10px">
      Describe the session you want to create and Claude will generate blocks, scenes, and rules.
    </p>
    <textarea id="ai_prompt" rows="5" placeholder="e.g. A 5-minute mindfulness session with breathing cues, gentle text prompts, and rules to pause if attention is lost for 5 seconds. Three phases: settling in, focus practice, closing." style="width:100%;font-size:11px;resize:vertical;margin-bottom:8px"></textarea>
    <div style="display:flex;gap:6px;margin-bottom:6px">
      <label style="display:flex;align-items:center;gap:4px;font-size:11px;cursor:pointer;flex:1">
        <input type="radio" name="ai_mode" value="merge" checked /> Merge with existing
      </label>
      <label style="display:flex;align-items:center;gap:4px;font-size:11px;cursor:pointer;flex:1">
        <input type="radio" name="ai_mode" value="replace" /> Replace session
      </label>
    </div>
    <button id="ai_generateBtn" style="width:100%;font-size:11px;background:rgba(200,164,255,0.15);
      border:0.5px solid rgba(200,164,255,0.4);border-radius:6px;padding:7px;color:#c8a4ff;cursor:pointer">
      ✦ Generate with Claude
    </button>
    <div id="ai_status" style="font-size:10.5px;color:var(--text3);margin-top:6px;min-height:16px"></div>`;

  const statusEl = el.querySelector('#ai_status');
  const btn      = el.querySelector('#ai_generateBtn');

  btn?.addEventListener('click', async () => {
    const prompt = el.querySelector('#ai_prompt')?.value?.trim();
    const mode   = el.querySelector('input[name="ai_mode"]:checked')?.value ?? 'merge';

    if (!prompt) { notify.warn('Enter a description first.'); return; }

    btn.disabled    = true;
    btn.textContent = '⏳ Generating…';
    statusEl.textContent = '';

    try {
      const generated = await generateSession(prompt, {
        onProgress: msg => { statusEl.textContent = msg; },
      });

      applyGeneratedContent(generated, mode);

      // Refresh UI
      import('./ui.js').then(({ renderSidebar, renderInspector, syncTransportControls }) => {
        renderSidebar(); renderInspector(); syncTransportControls();
      });
      drawTimeline();
      renderRampPanel('rampPanel');
      renderPacingPanel('pacingPanel');

      const blockCount = generated.blocks?.length ?? 0;
      const ruleCount  = generated.rules?.length ?? 0;
      const sceneCount = generated.scenes?.length ?? 0;
      statusEl.textContent = `✓ Added ${blockCount} block${blockCount!==1?'s':''}, ${sceneCount} scene${sceneCount!==1?'s':''}, ${ruleCount} rule${ruleCount!==1?'s':''}.`;
      notify.success('Session generated successfully!');

    } catch (err) {
      statusEl.textContent = `✗ ${err.message}`;
      notify.error(`Generation failed: ${err.message}`);
    } finally {
      btn.disabled    = false;
      btn.textContent = '✦ Generate with Claude';
    }
  });
}
