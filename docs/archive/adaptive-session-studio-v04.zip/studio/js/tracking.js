// ── tracking.js ────────────────────────────────────────────────────────────
// Webcam attention tracking via FaceDetector API + visual overlay.

import { state, $id } from './state.js';
import { pausePlayback, resumePlayback } from './playback.js';

export function makeTrackingModule() {
  let stream = null, raf = 0, lastSeen = performance.now(), wasAutoPaused = false;
  let detector = null;
  if ('FaceDetector' in window) {
    try { detector = new FaceDetector({ fastMode: true, maxDetectedFaces: 1 }); } catch {}
  }

  const pv  = $id('trackingPreview');
  const oc  = $id('trackingOverlay');
  const ctx = oc?.getContext('2d');

  function setStatus(camera, face, lossText) {
    const cs = $id('cameraStatus');  if (cs) cs.textContent = camera ?? cs.textContent;
    const fs = $id('faceStatus');    if (fs) fs.textContent = face   ?? fs.textContent;
    const ad = $id('attentionLossDisplay'); if (ad && lossText != null) ad.textContent = lossText;
  }

  function resizeCanvas() {
    if (!oc || !pv) return;
    const r = pv.getBoundingClientRect();
    oc.width = r.width; oc.height = r.height;
  }

  async function start() {
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      pv.srcObject = stream;
      setStatus('Live', null, null);
      resizeCanvas();
      raf = requestAnimationFrame(loop);
    } catch (err) {
      setStatus('Denied', 'Unavailable', null);
      alert(`Could not start webcam: ${err.message}`);
    }
  }

  function stop() {
    cancelAnimationFrame(raf);
    if (stream) stream.getTracks().forEach(t => t.stop());
    stream = null;
    if (pv) pv.srcObject = null;
    ctx?.clearRect(0, 0, oc.width, oc.height);
    setStatus('Off', 'Unknown', '0.0s');
  }

  async function loop() {
    resizeCanvas();
    ctx?.clearRect(0, 0, oc.width, oc.height);
    let face = null;
    if (detector && pv?.readyState >= 2) {
      try { const faces = await detector.detect(pv); face = faces[0] || null; } catch {}
    }
    if (face) {
      drawFace(face.boundingBox);
      setStatus(null, 'Detected', '0.0s');
      lastSeen = performance.now();
      if (wasAutoPaused && state.session.advanced.autoResumeOnAttentionReturn && state.runtime?.pausedByAttention) {
        resumePlayback(true);
      }
      wasAutoPaused = false;
    } else {
      const loss = (performance.now() - lastSeen) / 1000;
      setStatus(null, detector ? 'Not detected' : 'Live preview', `${loss.toFixed(1)}s`);
      const { tracking } = state.session;
      if (tracking.enabled && tracking.autoPauseOnAttentionLoss && loss >= tracking.attentionThreshold && state.runtime && !state.runtime.paused) {
        pausePlayback(true);
        wasAutoPaused = true;
      }
    }
    raf = requestAnimationFrame(loop);
  }

  function drawFace(box) {
    if (!ctx || !pv) return;
    const sx = oc.width  / (pv.videoWidth  || 1);
    const sy = oc.height / (pv.videoHeight || 1);
    ctx.strokeStyle = state.session.accentColor || '#f0a04a';
    ctx.lineWidth = 2;
    ctx.strokeRect(box.x * sx, box.y * sy, box.width * sx, box.height * sy);
  }

  return { start, stop };
}
