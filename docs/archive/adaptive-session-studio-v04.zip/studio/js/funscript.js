// ── funscript.js ──────────────────────────────────────────────────────────
// FunScript import/export, timeline canvas editor, playback interpolation,
// and optional device output via Intiface Central WebSocket.

import { state, persist, $id, uid, fileToDataUrl } from './state.js';

// ── FunScript JSON format ──────────────────────────────────────────────────
// { "version": 1, "inverted": false, "range": 100,
//   "actions": [{"at": 0, "pos": 0}, {"at": 500, "pos": 100}, ...] }
// "at" = milliseconds from start, "pos" = 0-100

export function parseFunScript(text) {
  const raw = JSON.parse(text);
  const actions = (raw.actions || [])
    .map(a => ({ at: Number(a.at), pos: Number(a.pos) }))
    .filter(a => Number.isFinite(a.at) && Number.isFinite(a.pos))
    .sort((a, b) => a.at - b.at);
  return {
    version:  raw.version  ?? 1,
    inverted: raw.inverted ?? false,
    range:    raw.range    ?? 100,
    actions,
  };
}

export function exportFunScript(track) {
  const { version, inverted, range, actions } = track;
  return JSON.stringify({ version: version ?? 1, inverted: !!inverted, range: range ?? 100, actions }, null, 2);
}

// Linearly interpolate position at a given time (ms)
export function interpolatePosition(actions, timeMs, inverted = false, range = 100) {
  if (!actions || !actions.length) return 0;
  if (timeMs <= actions[0].at)                   return applyMods(actions[0].pos, inverted, range);
  if (timeMs >= actions[actions.length - 1].at)  return applyMods(actions[actions.length - 1].pos, inverted, range);
  let lo = 0, hi = actions.length - 1;
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (actions[mid].at <= timeMs) lo = mid; else hi = mid; }
  const t = (timeMs - actions[lo].at) / (actions[hi].at - actions[lo].at);
  const pos = actions[lo].pos + t * (actions[hi].pos - actions[lo].pos);
  return applyMods(pos, inverted, range);
}

function applyMods(pos, inverted, range) {
  const scaled = (pos / 100) * range;
  return Math.round(inverted ? range - scaled : scaled);
}

// ── File handling ──────────────────────────────────────────────────────────
export async function importFunScriptFile(file) {
  const text = await file.text();
  const parsed = parseFunScript(text);
  const track = {
    id: uid(),
    name: file.name.replace(/\.funscript$/i, ''),
    version:  parsed.version,
    inverted: parsed.inverted,
    range:    parsed.range,
    actions:  parsed.actions,
    _disabled: false,
    _color: TRACK_COLORS[state.session.funscriptTracks.length % TRACK_COLORS.length],
  };
  state.session.funscriptTracks.push(track);
  persist();
}

export function downloadFunScript(trackId) {
  const track = state.session.funscriptTracks.find(t => t.id === trackId);
  if (!track) return;
  const blob = new Blob([exportFunScript(track)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${track.name || 'funscript'}.funscript`;
  a.click(); URL.revokeObjectURL(a.href);
}

const TRACK_COLORS = ['#f0a04a', '#5fa0dc', '#7dc87a', '#b084cc', '#e07a5f', '#64b5c8'];

// ── Device connection (Intiface Central WebSocket) ─────────────────────────
export function connectDevice(wsUrl = 'ws://localhost:12345') {
  if (state.deviceSocket?.readyState === WebSocket.OPEN) { state.deviceSocket.close(); }
  try {
    const ws = new WebSocket(wsUrl);
    ws.onopen = () => {
      state.deviceSocket = ws;
      updateDeviceStatus('Connected', '#7dc87a');
      // Buttplug v3 handshake
      ws.send(JSON.stringify([{ RequestServerInfo: { Id: 1, ClientName: 'AdaptiveSessionStudio', MessageVersion: 3 } }]));
    };
    ws.onclose = () => { state.deviceSocket = null; updateDeviceStatus('Disconnected', null); };
    ws.onerror = () => { state.deviceSocket = null; updateDeviceStatus('Error', '#e05050'); };
    ws.onmessage = e => handleDeviceMessage(JSON.parse(e.data));
  } catch (err) {
    updateDeviceStatus('Failed', '#e05050');
  }
}

export function disconnectDevice() {
  state.deviceSocket?.close();
  state.deviceSocket = null;
  updateDeviceStatus('Disconnected', null);
}

function updateDeviceStatus(text, color) {
  const el = $id('deviceStatus');
  if (!el) return;
  el.textContent = text;
  el.style.color = color || 'var(--text3)';
}

let _deviceIndex = null;
function handleDeviceMessage(msgs) {
  for (const msg of msgs) {
    if (msg.ServerInfo)  { /* connected OK */ }
    if (msg.DeviceAdded) { _deviceIndex = msg.DeviceAdded.DeviceIndex; updateDeviceStatus(`Device: ${msg.DeviceAdded.DeviceName}`, '#7dc87a'); }
    if (msg.DeviceRemoved) { _deviceIndex = null; updateDeviceStatus('Device removed', '#e07a5f'); }
  }
}

// Send a linear position command (0-1) to connected device
export function sendDevicePosition(pos01) {
  if (!state.deviceSocket || state.deviceSocket.readyState !== WebSocket.OPEN || _deviceIndex === null) return;
  const cmd = [{ LinearCmd: { Id: 1, DeviceIndex: _deviceIndex, Vectors: [{ Index: 0, Duration: 150, Position: pos01 }] } }];
  state.deviceSocket.send(JSON.stringify(cmd));
}

// ── Timeline canvas ────────────────────────────────────────────────────────
// The FunScript timeline is a canvas element that:
//  • Renders all enabled funscript tracks as position curves
//  • Renders session blocks as background bands
//  • Renders subtitle cue markers
//  • Shows a playhead that updates during playback
//  • Supports adding, moving, deleting points in edit mode

const CANVAS_H = 110; // px
let _canvas = null;
let _ctx = null;
let _dragState = null;   // { trackId, pointIdx }
let _hoverPoint = null;  // { trackId, pointIdx }

export function initTimeline(canvasEl) {
  _canvas = canvasEl;
  _ctx = canvasEl.getContext('2d');
  canvasEl.style.cursor = 'crosshair';

  canvasEl.addEventListener('mousedown', onCanvasMouseDown);
  canvasEl.addEventListener('mousemove', onCanvasMouseMove);
  canvasEl.addEventListener('mouseup',   onCanvasMouseUp);
  canvasEl.addEventListener('contextmenu', onCanvasContextMenu);
  canvasEl.addEventListener('mouseleave', () => { _hoverPoint = null; drawTimeline(); });
}

function canvasToTime(x) {
  const dur = state.session.duration * 1000; // ms
  return (x / _canvas.width) * dur;
}

function timeToX(ms) {
  const dur = state.session.duration * 1000;
  return (ms / dur) * _canvas.width;
}

function posToY(pos) {
  // pos 0-100, y: 100 = bottom (CANVAS_H-8), 0 = top (8)
  return CANVAS_H - 8 - (pos / 100) * (CANVAS_H - 16);
}

function yToPos(y) {
  return Math.min(100, Math.max(0, Math.round(((CANVAS_H - 8 - y) / (CANVAS_H - 16)) * 100)));
}

function hitTest(x, y, radius = 8) {
  for (const track of state.session.funscriptTracks) {
    if (track._disabled) continue;
    for (let i = 0; i < track.actions.length; i++) {
      const a = track.actions[i];
      const px = timeToX(a.at);
      const py = posToY(a.pos);
      if (Math.hypot(x - px, y - py) < radius) return { trackId: track.id, pointIdx: i };
    }
  }
  return null;
}

function onCanvasMouseDown(e) {
  if (!state.fsEditMode) return;
  const rect = _canvas.getBoundingClientRect();
  const x = (e.clientX - rect.left) * (_canvas.width / rect.width);
  const y = (e.clientY - rect.top)  * (_canvas.height / rect.height);

  const hit = hitTest(x, y);
  if (hit) {
    _dragState = hit;
    state.selectedFsPointIdx = hit.pointIdx;
  } else {
    // Add new point to the first non-disabled track
    const track = state.session.funscriptTracks.find(t => !t._disabled);
    if (!track) return;
    const at  = Math.round(canvasToTime(x));
    const pos = yToPos(y);
    track.actions.push({ at, pos });
    track.actions.sort((a, b) => a.at - b.at);
    state.selectedFsPointIdx = track.actions.findIndex(a => a.at === at && a.pos === pos);
    persist();
    drawTimeline();
  }
}

function onCanvasMouseMove(e) {
  const rect = _canvas.getBoundingClientRect();
  const x = (e.clientX - rect.left) * (_canvas.width / rect.width);
  const y = (e.clientY - rect.top)  * (_canvas.height / rect.height);

  if (_dragState && state.fsEditMode) {
    const track = state.session.funscriptTracks.find(t => t.id === _dragState.trackId);
    if (track) {
      track.actions[_dragState.pointIdx].at  = Math.max(0, Math.round(canvasToTime(x)));
      track.actions[_dragState.pointIdx].pos = yToPos(y);
      track.actions.sort((a, b) => a.at - b.at);
    }
    drawTimeline(); return;
  }

  _hoverPoint = hitTest(x, y);
  _canvas.style.cursor = _hoverPoint ? 'grab' : (state.fsEditMode ? 'crosshair' : 'default');
  drawTimeline();
}

function onCanvasMouseUp() {
  if (_dragState) { persist(); }
  _dragState = null;
}

function onCanvasContextMenu(e) {
  e.preventDefault();
  if (!state.fsEditMode) return;
  const rect = _canvas.getBoundingClientRect();
  const x = (e.clientX - rect.left) * (_canvas.width / rect.width);
  const y = (e.clientY - rect.top)  * (_canvas.height / rect.height);
  const hit = hitTest(x, y);
  if (hit) {
    const track = state.session.funscriptTracks.find(t => t.id === hit.trackId);
    if (track) { track.actions.splice(hit.pointIdx, 1); persist(); drawTimeline(); }
  }
}

export function drawTimeline(playheadSec = null) {
  if (!_canvas || !_ctx) return;
  const { session } = state;
  const W = _canvas.width, H = CANVAS_H;
  _canvas.height = H;
  const ctx = _ctx;
  ctx.clearRect(0, 0, W, H);

  // Background
  ctx.fillStyle = '#0b0b0f';
  ctx.fillRect(0, 0, W, H);

  // Session block bands
  const blockColors = { text:'#5fa0dc', tts:'#7dc87a', audio:'#f0a04a', video:'#b084cc', pause:'#555350' };
  for (const b of session.blocks) {
    const x1 = timeToX(b.start * 1000);
    const x2 = timeToX((b.start + b.duration) * 1000);
    ctx.fillStyle = (blockColors[b.type] || '#888') + '22';
    ctx.fillRect(x1, 0, x2 - x1, H);
    ctx.fillStyle = (blockColors[b.type] || '#888') + '55';
    ctx.fillRect(x1, 0, 1, H);
  }

  // Time grid lines (every 10s)
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.lineWidth = 0.5;
  for (let t = 0; t <= session.duration; t += 10) {
    const x = timeToX(t * 1000);
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
  }

  // Subtitle cue markers
  for (const track of session.subtitleTracks) {
    if (track._disabled) continue;
    ctx.fillStyle = '#5fa0dc88';
    for (const ev of (track.events || [])) {
      const x = timeToX(ev.start * 1000);
      ctx.fillRect(x, H - 4, Math.max(2, timeToX(ev.end * 1000) - x), 4);
    }
  }

  // Funscript curves
  for (const track of session.funscriptTracks) {
    if (track._disabled || !track.actions.length) continue;
    const col = track._color || '#f0a04a';
    const settings = session.funscriptSettings;

    ctx.beginPath();
    ctx.strokeStyle = col + 'cc';
    ctx.lineWidth = 1.5;
    ctx.lineJoin = 'round';
    let first = true;
    for (const a of track.actions) {
      const pos = applyMods(a.pos, settings.invert, settings.range);
      const x = timeToX(a.at);
      const y = posToY(pos);
      if (first) { ctx.moveTo(x, y); first = false; } else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Points
    for (let i = 0; i < track.actions.length; i++) {
      const a = track.actions[i];
      const pos = applyMods(a.pos, settings.invert, settings.range);
      const x = timeToX(a.at);
      const y = posToY(pos);
      const isHovered = _hoverPoint?.trackId === track.id && _hoverPoint?.pointIdx === i;
      const isSelected = state.selectedFsPointIdx === i;
      ctx.beginPath();
      ctx.arc(x, y, isHovered || isSelected ? 5 : 3, 0, Math.PI * 2);
      ctx.fillStyle = isSelected ? '#ffffff' : (isHovered ? col : col + 'aa');
      ctx.fill();
      if (isSelected) { ctx.strokeStyle = col; ctx.lineWidth = 1; ctx.stroke(); }
    }
  }

  // Playhead
  if (playheadSec !== null) {
    const x = timeToX(playheadSec * 1000);
    ctx.strokeStyle = '#f0a04a';
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    // Time label
    ctx.fillStyle = '#f0a04a';
    ctx.font = '9px Inter, system-ui, sans-serif';
    ctx.fillText(formatMs(playheadSec * 1000), x + 3, 10);
  }

  // Edit mode overlay hint
  if (state.fsEditMode) {
    ctx.fillStyle = 'rgba(240,160,74,0.06)';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#f0a04a44';
    ctx.font = '10px Inter, system-ui, sans-serif';
    ctx.fillText('Edit mode — click to add, drag to move, right-click to delete', 8, 12);
  }

  // Legend
  let lx = 8;
  for (const track of session.funscriptTracks) {
    const col = track._color || '#f0a04a';
    ctx.fillStyle = col;
    ctx.fillRect(lx, H - 14, 8, 4);
    ctx.fillStyle = track._disabled ? '#555' : col;
    ctx.font = '9px Inter, system-ui, sans-serif';
    ctx.fillText(track.name, lx + 10, H - 11);
    lx += ctx.measureText(track.name).width + 24;
  }
}

function formatMs(ms) {
  const s = Math.floor(ms / 1000), min = Math.floor(s / 60);
  return `${String(min).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
}

// ── Position indicator ────────────────────────────────────────────────────
// Returns current 0-100 position across all active funscript tracks (max)
export function getCurrentPosition(sessionTimeSec) {
  const settings = state.session.funscriptSettings;
  const timeMs   = sessionTimeSec * 1000 * (1 / settings.speed);
  let maxPos = 0;
  for (const track of state.session.funscriptTracks) {
    if (track._disabled) continue;
    const pos = interpolatePosition(track.actions, timeMs, settings.invert, settings.range);
    if (pos > maxPos) maxPos = pos;
  }
  return maxPos;
}

export function updatePositionIndicator(pos) {
  const bar = $id('fsPositionBar');
  if (bar) {
    bar.style.height = `${pos}%`;
    bar.style.background = pos > 70 ? '#e05050' : pos > 40 ? '#f0a04a' : '#5fa0dc';
  }
  const label = $id('fsPositionLabel');
  if (label) label.textContent = `${pos}%`;
}

// ── Timeline show/hide ────────────────────────────────────────────────────
export function refreshTimelineVisibility() {
  const panel = $id('fsTimelinePanel');
  if (!panel) return;
  const hasTracks = state.session.funscriptTracks.length > 0;
  panel.style.display = hasTracks ? 'flex' : 'none';
}
