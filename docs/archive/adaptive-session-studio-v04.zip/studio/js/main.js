// ── main.js ────────────────────────────────────────────────────────────────
// App entry point: imports all modules, wires all events, initializes UI.

import { state, persist, fmt, $id, uid, clampInt, fileToDataUrl,
         normalizeBlock, normalizeSession, sampleSession, defaultSession,
         applyCssVars, applyTheme } from './state.js';

import { startPlayback, stopPlayback, pausePlayback, resumePlayback,
         seekTo, skipBy, updateTransportUI } from './playback.js';

import { parseAss } from './subtitle.js';

import { importFunScriptFile, initTimeline, drawTimeline,
         refreshTimelineVisibility, connectDevice, disconnectDevice } from './funscript.js';

import { renderSidebar, renderInspector, syncSettingsForms,
         syncSessionFromSettings, renderThemeGrid,
         saveCustomTheme, deleteCustomTheme } from './ui.js';

import { makeTrackingModule } from './tracking.js';

// Expose FunScript module for inspector button handlers
window._funscriptModule = { connectDevice, disconnectDevice };

// ── Block operations (exposed for inspector) ────────────────────────────────
function duplicateBlock() {
  const block = state.session.blocks.find(b => b.id === state.selectedBlockId);
  if (!block) return;
  const copy = { ...structuredClone(block), id: uid(), start: block.start + block.duration + 1, label: `${block.label} copy` };
  state.session.blocks.push(copy);
  state.selectedBlockId = copy.id;
  persist(); renderSidebar(); renderInspector();
}

function deleteBlock() {
  if (!state.selectedBlockId) return;
  state.session.blocks = state.session.blocks.filter(b => b.id !== state.selectedBlockId);
  state.selectedBlockId = state.session.blocks[0]?.id || null;
  persist(); renderSidebar(); renderInspector();
}

window._appDuplicateBlock = duplicateBlock;
window._appDeleteBlock    = deleteBlock;

// ── Transport ───────────────────────────────────────────────────────────────
$id('playBtn').addEventListener('click', () => {
  if (!state.runtime)            startPlayback();
  else if (state.runtime.paused) resumePlayback();
  else                           pausePlayback();
});
$id('stopBtn').addEventListener('click', stopPlayback);
$id('skipBackBtn').addEventListener('click', () => skipBy(-5));
$id('skipFwdBtn').addEventListener('click',  () => skipBy(5));

$id('loopToggle').addEventListener('click', () => {
  const modes = ['none', 'count', 'forever'];
  const idx = modes.indexOf(state.session.loopMode);
  state.session.loopMode = modes[(idx + 1) % modes.length];
  $id('loopToggle').classList.toggle('active', state.session.loopMode !== 'none');
  $id('loopToggle').textContent = { none:'↺ Loop off', count:'↺ Loop', forever:'↺ ∞' }[state.session.loopMode];
  persist();
});

// Master volume
const mvSlider = $id('masterVolumeSlider');
mvSlider.value = state.session.masterVolume;
mvSlider.addEventListener('input', e => {
  state.session.masterVolume = Number(e.target.value);
  state.runtime?.backgroundAudio.forEach(a => a.volume = state.session.masterVolume * state.session.advanced.playlistAudioVolume);
  persist();
});

// Progress bar seek
$id('progressBar').addEventListener('click', e => {
  const r = e.currentTarget.getBoundingClientRect();
  seekTo((e.clientX - r.left) / r.width);
});

// Fullscreen
$id('fullscreenBtn').addEventListener('click', () => {
  if (!document.fullscreenElement) $id('mainStage').requestFullscreen?.();
  else document.exitFullscreen?.();
});

// ── New / Sample / Import / Export ─────────────────────────────────────────
$id('newSessionBtn').addEventListener('click', () => {
  state.session = defaultSession();
  state.selectedBlockId = null;
  stopPlayback(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms();
  $id('tTotal').textContent = fmt(state.session.duration);
  persist();
});

$id('loadSampleBtn').addEventListener('click', () => {
  state.session = sampleSession();
  state.selectedBlockId = state.session.blocks[0]?.id || null;
  stopPlayback(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms();
  $id('tTotal').textContent = fmt(state.session.duration);
  persist();
});

$id('exportPackageBtn').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(state.session, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${state.session.name || 'session'}.assp`;
  a.click(); URL.revokeObjectURL(a.href);
});

$id('importPackageInput').addEventListener('change', async e => {
  const file = e.target.files?.[0];
  if (!file) return;
  try {
    const text = await file.text();
    state.session = normalizeSession(JSON.parse(text));
    state.selectedBlockId = state.session.blocks[0]?.id || null;
    stopPlayback(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms();
    persist();
  } catch (err) { alert(`Import failed: ${err.message}`); }
  e.target.value = '';
});

// ── Media file inputs ────────────────────────────────────────────────────────
$id('addAudioInput').addEventListener('change', async e => {
  for (const f of e.target.files) {
    state.session.playlists.audio.push({ name: f.name, dataUrl: await fileToDataUrl(f), volume: 1, _muted: false });
  }
  persist(); renderSidebar(); e.target.value = '';
});

$id('addVideoInput').addEventListener('change', async e => {
  for (const f of e.target.files) {
    state.session.playlists.video.push({ name: f.name, dataUrl: await fileToDataUrl(f), mediaKind: f.type.startsWith('image/')?'image':'video', mute: true, volume: 1 });
  }
  persist(); renderSidebar(); e.target.value = '';
});

$id('addAssInput').addEventListener('change', async e => {
  const file = e.target.files?.[0];
  if (!file) return;
  const text = await file.text();
  const parsed = parseAss(text);
  state.session.subtitleTracks.push({ name: file.name, rawAss: text, styles: parsed.styles, events: parsed.events, _disabled: false });
  persist(); renderSidebar();
  e.target.value = '';
});

$id('addFunscriptInput').addEventListener('change', async e => {
  for (const f of e.target.files) await importFunScriptFile(f);
  renderSidebar(); renderInspector(); drawTimeline();
  e.target.value = '';
});

// ── Block add buttons ────────────────────────────────────────────────────────
document.querySelectorAll('[data-add-block]').forEach(btn => {
  btn.addEventListener('click', () => {
    const type = btn.dataset.addBlock;
    const nextStart = state.session.blocks.length
      ? Math.max(...state.session.blocks.map(b => b.start + b.duration)) + 2 : 0;
    const block = normalizeBlock({ id: uid(), type, label: `New ${type}`, start: nextStart, duration: type==='pause'?5:10 });
    state.session.blocks.push(block);
    state.selectedBlockId = block.id;
    state.selectedSidebarType = 'block';
    persist(); renderSidebar(); renderInspector();
  });
});

$id('sortBlocksBtn').addEventListener('click', () => {
  state.session.blocks.sort((a, b) => a.start - b.start);
  persist(); renderSidebar();
});

// ── Sidebar interaction (event delegation) ──────────────────────────────────
document.addEventListener('click', e => {
  // Inspector tabs
  const itab = e.target.closest('.insp-tab');
  if (itab) {
    state.inspTab = itab.dataset.tab;
    document.querySelectorAll('.insp-tab').forEach(t => t.classList.toggle('active', t === itab));
    renderInspector(); return;
  }

  // Settings tabs
  const stab = e.target.closest('.settings-tab');
  if (stab) {
    state.settingsTab = stab.dataset.stab;
    document.querySelectorAll('.settings-tab').forEach(t => t.classList.toggle('active', t === stab));
    document.querySelectorAll('.settings-section').forEach(s => s.classList.toggle('active', s.dataset.section === state.settingsTab));
    return;
  }

  // Theme chips
  const tc = e.target.closest('[data-theme-key]');
  if (tc) { applyTheme(tc.dataset.themeKey); syncSettingsForms(); return; }

  // Mute/disable toggles
  const muteBtn = e.target.closest('[data-mute-kind]');
  if (muteBtn) {
    const kind = muteBtn.dataset.muteKind, idx = Number(muteBtn.dataset.muteIdx);
    if (kind === 'audio')     state.session.playlists.audio[idx]._muted      = !state.session.playlists.audio[idx]._muted;
    if (kind === 'subtitle')  state.session.subtitleTracks[idx]._disabled     = !state.session.subtitleTracks[idx]._disabled;
    if (kind === 'funscript') state.session.funscriptTracks[idx]._disabled    = !state.session.funscriptTracks[idx]._disabled;
    persist(); renderSidebar(); drawTimeline(); return;
  }

  // Delete buttons
  const delBtn = e.target.closest('[data-del-kind]');
  if (delBtn) {
    const kind = delBtn.dataset.delKind, idx = Number(delBtn.dataset.delIdx);
    if (kind === 'audio')    state.session.playlists.audio.splice(idx, 1);
    if (kind === 'video')    state.session.playlists.video.splice(idx, 1);
    if (kind === 'subtitle') state.session.subtitleTracks.splice(idx, 1);
    if (kind === 'funscript'){ state.session.funscriptTracks.splice(idx,1); drawTimeline(); }
    state.selectedSidebarType = null; state.selectedSidebarIdx = null;
    persist(); renderSidebar(); renderInspector(); return;
  }

  // Sidebar item selection
  const sbItem = e.target.closest('[data-sb-type]');
  if (sbItem && !e.target.closest('[data-mute-kind]') && !e.target.closest('[data-del-kind]')) {
    const type = sbItem.dataset.sbType;
    const idx  = sbItem.dataset.sbIdx !== undefined ? Number(sbItem.dataset.sbIdx) : null;
    const bid  = sbItem.dataset.blockId;
    state.selectedSidebarType = type;
    state.selectedSidebarIdx  = idx;
    if (type === 'block' && bid) {
      state.selectedBlockId = bid;
      // Switch inspector to overlay tab
      state.inspTab = 'overlay';
      document.querySelectorAll('.insp-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === 'overlay'));
    }
    renderSidebar(); renderInspector(); return;
  }
});

// ── Settings dialog ──────────────────────────────────────────────────────────
let _tracking = null;

$id('settingsBtn').addEventListener('click', () => {
  syncSettingsForms();
  $id('settingsDialog').showModal();
  _tracking = makeTrackingModule();
});

const closeSettings = () => { syncSessionFromSettings(); applyCssVars(); $id('settingsDialog').close(); };
$id('closeSettings').addEventListener('click', closeSettings);
$id('settingsDoneBtn').addEventListener('click', closeSettings);

$id('settingsDialog').addEventListener('input', e => {
  if (e.target.id === 's_jsonPreview') return;
  syncSessionFromSettings();
  applyCssVars();
  renderThemeGrid();
});

$id('saveCustomThemeBtn')?.addEventListener('click', saveCustomTheme);
$id('deleteCustomThemeBtn')?.addEventListener('click', deleteCustomTheme);

$id('startTrackingBtn').addEventListener('click', () => _tracking?.start());
$id('stopTrackingBtn').addEventListener('click',  () => _tracking?.stop());

$id('applyJsonBtn').addEventListener('click', () => {
  try {
    state.session = normalizeSession(JSON.parse($id('s_jsonPreview').value));
    state.selectedBlockId = state.session.blocks[0]?.id || null;
    stopPlayback(); applyCssVars(); renderSidebar(); renderInspector(); syncSettingsForms();
  } catch (err) { alert(`Invalid JSON: ${err.message}`); }
});
$id('formatJsonBtn').addEventListener('click', () => {
  try { $id('s_jsonPreview').value = JSON.stringify(JSON.parse($id('s_jsonPreview').value), null, 2); }
  catch (err) { alert(`Invalid JSON: ${err.message}`); }
});

// ── FunScript timeline controls ──────────────────────────────────────────────
const fsCanvas = $id('fsCanvas');
if (fsCanvas) {
  initTimeline(fsCanvas);
  // Observe parent width changes to resize canvas
  new ResizeObserver(() => {
    fsCanvas.width = fsCanvas.offsetWidth;
    drawTimeline(state.runtime?.sessionTime ?? null);
  }).observe(fsCanvas.parentElement);
}

$id('fsEditToggle')?.addEventListener('click', () => {
  state.fsEditMode = !state.fsEditMode;
  $id('fsEditToggle').classList.toggle('active', state.fsEditMode);
  $id('fsEditToggle').textContent = state.fsEditMode ? '✎ Editing' : '✎ Edit';
  drawTimeline(state.runtime?.sessionTime ?? null);
});

$id('fsCollapseBtn')?.addEventListener('click', () => {
  const panel = $id('fsTimelinePanel');
  const canvas = $id('fsCanvas');
  const collapsed = canvas.style.display === 'none';
  canvas.style.display = collapsed ? '' : 'none';
  $id('fsCollapseBtn').textContent = collapsed ? '↑' : '↓';
});

// ── Keyboard shortcuts ───────────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  // Ignore if in input/textarea
  if (e.target.matches('input,textarea,select')) return;

  const key = (e.ctrlKey ? 'ctrl+' : '') + (e.shiftKey ? 'shift+' : '') + e.key.toLowerCase();
  switch (key) {
    case ' ':
      e.preventDefault();
      if (!state.runtime)            startPlayback();
      else if (state.runtime.paused) resumePlayback();
      else                           pausePlayback();
      break;
    case 'escape':      stopPlayback(); break;
    case 'arrowleft':   skipBy(-5);     break;
    case 'arrowright':  skipBy(5);      break;
    case 'arrowup':     skipBy(30);     break;
    case 'arrowdown':   skipBy(-30);    break;
    case 'ctrl+s':      e.preventDefault();
      $id('exportPackageBtn').click(); break;
    case 'delete':
    case 'backspace':
      if (state.selectedBlockId) { e.preventDefault(); deleteBlock(); }
      break;
    case 'd':
      if (state.selectedBlockId) duplicateBlock();
      break;
    case 'f':
      if (!document.fullscreenElement) $id('mainStage').requestFullscreen?.();
      else document.exitFullscreen?.();
      break;
    case 'e':
      state.fsEditMode = !state.fsEditMode;
      $id('fsEditToggle')?.classList.toggle('active', state.fsEditMode);
      drawTimeline(state.runtime?.sessionTime ?? null);
      break;
  }
});

// ── Init ─────────────────────────────────────────────────────────────────────
applyCssVars();
renderSidebar();
renderInspector();
$id('tTotal').textContent = fmt(state.session.duration);
$id('loopToggle').classList.toggle('active', state.session.loopMode !== 'none');
drawTimeline();
