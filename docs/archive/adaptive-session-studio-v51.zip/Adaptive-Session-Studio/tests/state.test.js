// ── tests/state.test.js ───────────────────────────────────────────────────
// Tests for pure functions in js/state.js:
//   normalizeBlock, normalizeSession, normalizeAudioTrack,
//   normalizeVideoTrack, normalizeFunscriptTrack, normalizeSubtitleTrack,
//   normalizeMacro, clampInt, fmt, uid

import { makeRunner } from './harness.js';
import {
  normalizeBlock, normalizeSession, normalizeAudioTrack, normalizeVideoTrack,
  normalizeFunscriptTrack, normalizeSubtitleTrack, normalizeMacro,
  clampInt, fmt, uid, sampleSession, sessionReady, persistState, defaultSession,
} from '../js/state.js';

export function runStateTests() {
  const { test, assertEqual, assertDeep, assert } = makeRunner('state.js normalizers');
  const R = makeRunner('state.js normalizers');
  const t = R.test.bind(R);
  const eq = R.assertEqual.bind(R);
  const deep = R.assertDeep.bind(R);
  const ok = R.assert.bind(R);

  // ── clampInt ───────────────────────────────────────────────────────────
  t('clampInt clamps low', () => eq(clampInt(-5, 0, 100, 50), 0));
  t('clampInt clamps high', () => eq(clampInt(200, 0, 100, 50), 100));
  t('clampInt rounds', () => eq(clampInt(9.7, 0, 100, 50), 10));
  t('clampInt uses fallback for NaN', () => eq(clampInt('abc', 0, 100, 42), 42));
  t('clampInt passes through valid value', () => eq(clampInt(55, 0, 100, 0), 55));

  // ── fmt ───────────────────────────────────────────────────────────────
  t('fmt formats zero', () => eq(fmt(0), '00:00'));
  t('fmt formats 90 seconds', () => eq(fmt(90), '01:30'));
  t('fmt formats negative (clamps to 0)', () => eq(fmt(-10), '00:00'));
  t('fmt pads minutes', () => eq(fmt(65), '01:05'));
  t('fmt formats large value', () => eq(fmt(3600), '60:00'));

  // ── uid ───────────────────────────────────────────────────────────────
  t('uid returns string starting with b_', () => ok(uid().startsWith('b_')));
  t('uid produces unique values', () => ok(uid() !== uid()));
  t('uid has expected length', () => ok(uid().length >= 10));

  // ── normalizeBlock ────────────────────────────────────────────────────
  t('normalizeBlock preserves existing id', () => {
    const b = normalizeBlock({ id: 'my-id', type: 'text', label: 'A', start: 0, duration: 5 });
    eq(b.id, 'my-id');
  });
  t('normalizeBlock generates id when missing', () => {
    const b = normalizeBlock({ type: 'text' });
    ok(b.id && b.id.startsWith('b_'));
  });
  t('normalizeBlock clamps start to 0 minimum', () => {
    const b = normalizeBlock({ start: -5 });
    eq(b.start, 0);
  });
  t('normalizeBlock clamps duration to 1 minimum', () => {
    const b = normalizeBlock({ duration: 0 });
    eq(b.duration, 1);
  });
  t('normalizeBlock preserves content', () => {
    const b = normalizeBlock({ content: 'hello world' });
    eq(b.content, 'hello world');
  });
  t('normalizeBlock defaults type to text', () => {
    const b = normalizeBlock({});
    eq(b.type, 'text');
  });
  t('normalizeBlock defaults _position to center', () => {
    const b = normalizeBlock({});
    eq(b._position, 'center');
  });

  // ── normalizeAudioTrack ───────────────────────────────────────────────
  t('normalizeAudioTrack preserves existing id', () => {
    const t2 = normalizeAudioTrack({ id: 'au-1', name: 'test', dataUrl: '', volume: 0.5 });
    eq(t2.id, 'au-1');
  });
  t('normalizeAudioTrack generates id when missing', () => {
    const t2 = normalizeAudioTrack({ name: 'no-id' });
    ok(t2.id && t2.id.startsWith('b_'));
  });
  t('normalizeAudioTrack clamps volume 0–2', () => {
    eq(normalizeAudioTrack({ volume: -1 }).volume, 0);
    eq(normalizeAudioTrack({ volume: 10 }).volume, 2);
  });
  t('normalizeAudioTrack defaults _muted to false', () => {
    ok(normalizeAudioTrack({})._muted === false);
  });
  t('normalizeAudioTrack preserves _muted:true', () => {
    ok(normalizeAudioTrack({ _muted: true })._muted === true);
  });

  // ── normalizeVideoTrack ───────────────────────────────────────────────
  t('normalizeVideoTrack preserves existing id', () => {
    const t2 = normalizeVideoTrack({ id: 'vid-1', name: 'v' });
    eq(t2.id, 'vid-1');
  });
  t('normalizeVideoTrack generates id when missing', () => {
    ok(normalizeVideoTrack({ name: 'v' }).id.startsWith('b_'));
  });
  t('normalizeVideoTrack defaults mediaKind to video', () => {
    eq(normalizeVideoTrack({}).mediaKind, 'video');
  });
  t('normalizeVideoTrack accepts image mediaKind', () => {
    eq(normalizeVideoTrack({ mediaKind: 'image' }).mediaKind, 'image');
  });
  t('normalizeVideoTrack rejects unknown mediaKind', () => {
    eq(normalizeVideoTrack({ mediaKind: 'gif' }).mediaKind, 'video');
  });

  // ── normalizeFunscriptTrack ───────────────────────────────────────────
  t('normalizeFunscriptTrack generates id', () => {
    ok(normalizeFunscriptTrack({}).id.startsWith('b_'));
  });
  t('normalizeFunscriptTrack preserves id', () => {
    eq(normalizeFunscriptTrack({ id: 'fs-1' }).id, 'fs-1');
  });
  t('normalizeFunscriptTrack sorts actions by time', () => {
    const track = normalizeFunscriptTrack({ actions: [
      { at: 500, pos: 100 }, { at: 0, pos: 0 }, { at: 250, pos: 50 },
    ]});
    eq(track.actions[0].at, 0);
    eq(track.actions[1].at, 250);
    eq(track.actions[2].at, 500);
  });
  t('normalizeFunscriptTrack filters non-finite actions', () => {
    const track = normalizeFunscriptTrack({ actions: [
      { at: 0, pos: 0 }, { at: NaN, pos: 50 }, { at: 500, pos: 'x' },
    ]});
    eq(track.actions.length, 1);
  });
  t('normalizeFunscriptTrack clamps pos 0–100', () => {
    const track = normalizeFunscriptTrack({ actions: [
      { at: 0, pos: -10 }, { at: 500, pos: 200 },
    ]});
    eq(track.actions[0].pos, 0);
    eq(track.actions[1].pos, 100);
  });
  t('normalizeFunscriptTrack defaults _disabled to false', () => {
    ok(normalizeFunscriptTrack({})._disabled === false);
  });

  // ── normalizeSubtitleTrack ────────────────────────────────────────────
  t('normalizeSubtitleTrack generates stable id', () => {
    const t2 = normalizeSubtitleTrack({});
    ok(t2.id && t2.id.startsWith('b_'));
  });
  t('normalizeSubtitleTrack preserves existing id', () => {
    eq(normalizeSubtitleTrack({ id: 'sub-1' }).id, 'sub-1');
  });
  t('normalizeSubtitleTrack filters invalid events (end <= start)', () => {
    const t2 = normalizeSubtitleTrack({ events: [
      { start: 0, end: 5, text: 'ok' },
      { start: 10, end: 5, text: 'bad end' },
      { start: 3, end: 3, text: 'zero duration' },
    ]});
    eq(t2.events.length, 1);
    eq(t2.events[0].text, 'ok');
  });
  t('normalizeSubtitleTrack defaults _disabled to false', () => {
    ok(normalizeSubtitleTrack({})._disabled === false);
  });

  // ── normalizeMacro ────────────────────────────────────────────────────
  t('normalizeMacro generates id', () => {
    ok(normalizeMacro({}).id.startsWith('b_'));
  });
  t('normalizeMacro preserves id', () => {
    eq(normalizeMacro({ id: 'mac-1' }).id, 'mac-1');
  });
  t('normalizeMacro defaults name to Macro', () => {
    eq(normalizeMacro({}).name, 'Macro');
  });
  t('normalizeMacro sorts actions', () => {
    const m = normalizeMacro({ actions: [{ at: 200, pos: 100 }, { at: 0, pos: 0 }]});
    eq(m.actions[0].at, 0);
  });

  // ── normalizeSession — CRITICAL regression: empty blocks must be preserved ──
  // ── normalizeSession — scenes ─────────────────────────────────────────
  t('normalizeSession initialises scenes:[] when absent', () => {
    const s = normalizeSession({});
    ok(Array.isArray(s.scenes) && s.scenes.length === 0);
  });
  t('normalizeSession normalizes scene entries', () => {
    const s = normalizeSession({ scenes: [{ start: 10, end: 70, name: 'Act 1' }] });
    eq(s.scenes.length, 1);
    ok(s.scenes[0].id?.startsWith('b_'));
    eq(s.scenes[0].name, 'Act 1');
    eq(s.scenes[0].start, 10);
  });
  // ── normalizeSession — triggers ───────────────────────────────────────
  // ── normalizeBlock — macro fields ────────────────────────────────────
  t('normalizeBlock defaults macroSlot to null', () => {
    eq(normalizeBlock({}).macroSlot, null);
  });
  t('normalizeBlock preserves numeric macroSlot', () => {
    eq(normalizeBlock({ macroSlot: 3 }).macroSlot, 3);
  });
  t('normalizeBlock defaults macroId to empty string', () => {
    eq(normalizeBlock({}).macroId, '');
  });
  t('normalizeBlock preserves macroId string', () => {
    eq(normalizeBlock({ macroId: 'b_abc123' }).macroId, 'b_abc123');
  });
  t('normalizeBlock type macro is preserved', () => {
    eq(normalizeBlock({ type: 'macro' }).type, 'macro');
  });

  t('normalizeSession preserves null safetySettings', () => {
    eq(normalizeSession({ safetySettings: null }).safetySettings, null);
  });
  t('normalizeSession normalizes safetySettings fields', () => {
    const s = normalizeSession({ safetySettings: { maxIntensity: 1.5, maxSpeed: 2.5, warnAbove: 1.2, emergencyCooldownSec: 45 } });
    ok(s.safetySettings !== null);
    eq(s.safetySettings.maxIntensity, 1.5);
    eq(s.safetySettings.maxSpeed, 2.5);
    eq(s.safetySettings.emergencyCooldownSec, 45);
  });
  t('normalizeSession clamps safetySettings maxIntensity to 0-2', () => {
    const s = normalizeSession({ safetySettings: { maxIntensity: 5 } });
    eq(s.safetySettings.maxIntensity, 2);
  });

  t('normalizeSession initialises triggers:[] when absent', () => {
    ok(Array.isArray(normalizeSession({}).triggers));
    eq(normalizeSession({}).triggers.length, 0);
  });
  t('normalizeSession normalizes trigger entries', () => {
    const s = normalizeSession({ triggers: [{ atSec: 45, windowDurSec: 8, name: 'Check' }] });
    eq(s.triggers.length, 1);
    ok(s.triggers[0].id?.startsWith('b_'));
    eq(s.triggers[0].atSec, 45);
    eq(s.triggers[0].windowDurSec, 8);
  });
  t('normalizeSession clamps trigger cooldownSec min 0', () => {
    const s = normalizeSession({ triggers: [{ cooldownSec: -10 }] });
    eq(s.triggers[0].cooldownSec, 0);
  });

  // ── normalizeSession — rampSettings ──────────────────────────────────
  t('normalizeSession preserves null rampSettings', () => {
    eq(normalizeSession({ rampSettings: null }).rampSettings, null);
  });
  t('normalizeSession normalizes rampSettings fields', () => {
    const s = normalizeSession({ rampSettings: { enabled: true, mode: 'engagement', startVal: 0.3, endVal: 1.8, curve: 'sine', blendMode: 'replace', steps: [] } });
    ok(s.rampSettings !== null);
    eq(s.rampSettings.mode, 'engagement');
    eq(s.rampSettings.startVal, 0.3);
    eq(s.rampSettings.enabled, true);
  });
  t('normalizeSession rejects invalid rampSettings mode', () => {
    const s = normalizeSession({ rampSettings: { mode: 'invalid' } });
    eq(s.rampSettings.mode, 'time');
  });

  // ── normalizeSession — pacingSettings ─────────────────────────────────
  t('normalizeSession preserves null pacingSettings', () => {
    eq(normalizeSession({ pacingSettings: null }).pacingSettings, null);
  });
  t('normalizeSession normalizes pacingSettings fields', () => {
    const s = normalizeSession({ pacingSettings: { enabled: true, minSpeed: 0.75, maxSpeed: 3, smoothingSec: 5, curve: 'exponential', lockDuringSec: 2 } });
    ok(s.pacingSettings !== null);
    eq(s.pacingSettings.minSpeed, 0.75);
    eq(s.pacingSettings.maxSpeed, 3);
    eq(s.pacingSettings.enabled, true);
  });
  t('normalizeSession clamps pacingSettings minSpeed to 0.25', () => {
    const s = normalizeSession({ pacingSettings: { minSpeed: 0 } });
    eq(s.pacingSettings.minSpeed, 0.25);
  });

  t('normalizeSession preserves blocks:[] (does NOT replace with sample)', () => {
    const s = normalizeSession({ blocks: [] });
    ok(Array.isArray(s.blocks), 'blocks should be array');
    eq(s.blocks.length, 0, 'empty array must stay empty');
  });
  t('normalizeSession returns empty blocks[] when blocks field is absent', () => {
    // Correct behaviour: missing blocks → [], not sampleSession fallback
    const s = normalizeSession({});
    ok(Array.isArray(s.blocks), 'blocks should always be an array');
    eq(s.blocks.length, 0, 'absent blocks should normalise to []');
  });
  t('normalizeSession returns empty blocks[] when blocks is not an array', () => {
    // Correct behaviour: invalid blocks type → [], not sampleSession fallback
    const s = normalizeSession({ blocks: 'invalid' });
    ok(Array.isArray(s.blocks), 'blocks should always be an array');
    eq(s.blocks.length, 0, 'invalid blocks should normalise to []');
  });
  t('normalizeSession preserves _modeSource on rules through import round-trip', () => {
    // _modeSource lets applySessionMode clean up rules by metadata after export/import
    const s = normalizeSession({
      rules: [{
        name: '[Focus] Pause on break', enabled: true,
        condition: { metric: 'attention', op: '<', value: 0.3 },
        durationSec: 3, cooldownSec: 30,
        action: { type: 'pause', param: null },
        _modeSource: 'focus',
      }]
    });
    eq(s.rules.length, 1);
    eq(s.rules[0]._modeSource, 'focus', '_modeSource must survive normalizeSession');
  });

  // ── Session notes field ──────────────────────────────────────────────────
  t('defaultSession includes notes field as empty string', () => {
    eq(defaultSession().notes, '');
  });
  t('normalizeSession preserves a short notes string', () => {
    const s = normalizeSession({ notes: 'Mindfulness session for partner use.' });
    eq(s.notes, 'Mindfulness session for partner use.');
  });
  t('normalizeSession defaults notes to empty string when absent', () => {
    eq(normalizeSession({}).notes, '');
  });
  t('normalizeSession defaults notes to empty string when wrong type', () => {
    eq(normalizeSession({ notes: 42 }).notes, '');
  });
  t('normalizeSession caps notes at 10 000 characters', () => {
    const long = 'x'.repeat(15_000);
    eq(normalizeSession({ notes: long }).notes.length, 10_000);
  });

  // ── Scene nextSceneId (Phase 2 branching) ───────────────────────────────
  t('normalizeScene defaults nextSceneId to null', () => {
    const s = normalizeScene({ start: 0, end: 60 });
    eq(s.nextSceneId, null);
  });
  t('normalizeScene preserves a valid nextSceneId string', () => {
    const s = normalizeScene({ start: 0, end: 60, nextSceneId: 'b_abc123' });
    eq(s.nextSceneId, 'b_abc123');
  });
  t('normalizeScene rejects empty string nextSceneId → null', () => {
    eq(normalizeScene({ nextSceneId: '' }).nextSceneId, null);
  });
  t('normalizeScene rejects non-string nextSceneId → null', () => {
    eq(normalizeScene({ nextSceneId: 42 }).nextSceneId, null);
  });
  t('normalizeSession preserves nextSceneId through scenes normalisation', () => {
    const s = normalizeSession({
      scenes: [{ name: 'Intro', start: 0, end: 30, nextSceneId: 'b_xyz' }]
    });
    eq(s.scenes[0].nextSceneId, 'b_xyz');
  });
  t('normalizeSession normalizes nested audio tracks (assigns ids)', () => {
    const s = normalizeSession({
      playlists: { audio: [{ name: 'track', dataUrl: '', volume: 1 }] }
    });
    ok(s.playlists.audio[0].id && s.playlists.audio[0].id.startsWith('b_'));
  });
  t('normalizeSession normalizes nested subtitle tracks (assigns ids)', () => {
    const s = normalizeSession({
      subtitleTracks: [{ name: 'subs', events: [] }]
    });
    ok(s.subtitleTracks[0].id && s.subtitleTracks[0].id.startsWith('b_'));
  });
  t('normalizeSession merges advanced defaults', () => {
    const s = normalizeSession({ advanced: { stageBlur: 10 } });
    eq(s.advanced.stageBlur, 10);
    ok('crossfadeSeconds' in s.advanced, 'crossfadeSeconds should be merged from default');
  });
  t('normalizeSession preserves custom themes', () => {
    const s = normalizeSession({ customThemes: { myTheme: { name: 'My' } } });
    ok('myTheme' in s.customThemes);
  });
  t('defaultSession() does not include dead deviceConnected field', () => {
    // The field was removed from defaultSession. New sessions must not carry it.
    const s = normalizeSession({});
    ok(!('deviceConnected' in s.funscriptSettings),
      'fresh session must not have deviceConnected');
  });
  t('normalizeSession preserves funscriptSettings.speed from import', () => {
    // Unknown extra fields in funscriptSettings survive the spread (by design).
    // What matters is that known fields are correctly merged.
    const s = normalizeSession({ funscriptSettings: { speed: 2.5 } });
    eq(s.funscriptSettings.speed, 2.5, 'speed must be preserved from import');
  });

  // ── dataUrl security guard (normalizeAudioTrack / normalizeVideoTrack / normalizeBlock) ──
  // Imported sessions must not be able to inject non-data: URLs into src= attributes.

  t('normalizeAudioTrack accepts a valid data: URL', () => {
    const t2 = normalizeAudioTrack({ dataUrl: 'data:audio/mp3;base64,AAAA' });
    eq(t2.dataUrl, 'data:audio/mp3;base64,AAAA');
  });
  t('normalizeAudioTrack rejects http: URL and clears dataUrl', () => {
    const t2 = normalizeAudioTrack({ dataUrl: 'http://evil.example.com/audio.mp3' });
    eq(t2.dataUrl, '', 'http: URL must be rejected');
  });
  t('normalizeAudioTrack rejects javascript: URL and clears dataUrl', () => {
    const t2 = normalizeAudioTrack({ dataUrl: 'javascript:alert(1)' });
    eq(t2.dataUrl, '', 'javascript: URL must be rejected');
  });
  t('normalizeAudioTrack preserves empty dataUrl', () => {
    eq(normalizeAudioTrack({ dataUrl: '' }).dataUrl, '');
  });

  t('normalizeVideoTrack accepts a valid data: URL', () => {
    const t2 = normalizeVideoTrack({ dataUrl: 'data:video/mp4;base64,AAAA' });
    eq(t2.dataUrl, 'data:video/mp4;base64,AAAA');
  });
  t('normalizeVideoTrack rejects http: URL and clears dataUrl', () => {
    const t2 = normalizeVideoTrack({ dataUrl: 'https://example.com/video.mp4' });
    eq(t2.dataUrl, '', 'https: URL must be rejected');
  });
  t('normalizeVideoTrack rejects file: URL and clears dataUrl', () => {
    const t2 = normalizeVideoTrack({ dataUrl: 'file:///etc/passwd' });
    eq(t2.dataUrl, '', 'file: URL must be rejected');
  });

  t('normalizeBlock accepts a valid data: URL for media', () => {
    const b = normalizeBlock({ type: 'audio', dataUrl: 'data:audio/mp3;base64,BBBB' });
    eq(b.dataUrl, 'data:audio/mp3;base64,BBBB');
  });
  t('normalizeBlock rejects non-data: URL and clears dataUrl', () => {
    const b = normalizeBlock({ type: 'audio', dataUrl: 'http://evil.example.com/audio.mp3' });
    eq(b.dataUrl, '', 'non-data: URL must be rejected in blocks');
  });
  t('normalizeBlock accepts empty dataUrl (no media)', () => {
    eq(normalizeBlock({ type: 'text', dataUrl: '' }).dataUrl, '');
  });

  // ── sessionReady (IDB boot) ─────────────────────────────────────────────
  t('sessionReady is a Promise', () => {
    ok(sessionReady instanceof Promise, 'sessionReady must be a Promise');
  });

  t('sessionReady resolves (IDB loads without error in test environment)', async () => {
    await sessionReady; // should not throw
    ok(true, 'sessionReady resolved');
  });

  // ── persistState ───────────────────────────────────────────────────────
  t('persistState is an object with expected keys', () => {
    ok(typeof persistState === 'object' && persistState !== null);
    ok('dirty'     in persistState, 'dirty field');
    ok('error'     in persistState, 'error field');
    ok('lastSaved' in persistState, 'lastSaved field');
  });

  // ── defaultSession ─────────────────────────────────────────────────────
  t('defaultSession() returns a fresh object each call', () => {
    const a = defaultSession();
    const b = defaultSession();
    ok(a !== b, 'each call should return a new object');
  });

  t('defaultSession() includes required top-level fields', () => {
    const s = defaultSession();
    ok('name'      in s, 'name');
    ok('duration'  in s, 'duration');
    ok('loopMode'  in s, 'loopMode');
    ok('blocks'    in s, 'blocks');
    ok('scenes'    in s, 'scenes');
    ok('rules'     in s, 'rules');
    ok('notes'     in s, 'notes');
    ok('variables' in s, 'variables field must exist');
    ok('primaryUse' in s.playlists === false, 'primaryUse is on profile not session');
  });

  t('defaultSession() initialises variables as empty object', () => {
    const s = defaultSession();
    ok(typeof s.variables === 'object' && !Array.isArray(s.variables));
    ok(Object.keys(s.variables).length === 0);
  });

  // ── normalizeSession variable round-trips ──────────────────────────────
  t('normalizeSession preserves a valid number variable', () => {
    const s = normalizeSession({ variables: { score: { type: 'number', value: 42 } } });
    ok('score' in s.variables);
    eq(s.variables.score.type,  'number');
    eq(s.variables.score.value, 42);
  });

  t('normalizeSession strips variables with invalid names', () => {
    const s = normalizeSession({ variables: { 'BadName': { type: 'number', value: 1 } } });
    ok(!('BadName' in s.variables));
  });

  t('normalizeSession defaults variables to {} when absent', () => {
    const s = normalizeSession({});
    ok(typeof s.variables === 'object');
    ok(Object.keys(s.variables).length === 0);
  });

  t('normalizeSession coerces variable value to declared type', () => {
    const s = normalizeSession({ variables: { level: { type: 'number', value: '7' } } });
    eq(s.variables.level.value, 7);
  });

  // ── normalizeScene stateType (Phase 5.1) ──────────────────────────────
  t('normalizeScene initialises stateType to null by default', () => {
    eq(normalizeScene({}).stateType, null);
  });

  t('normalizeScene preserves all four valid stateType values', () => {
    for (const type of ['calm', 'build', 'peak', 'recovery']) {
      eq(normalizeScene({ stateType: type }).stateType, type);
    }
  });

  t('normalizeScene rejects unknown stateType', () => {
    eq(normalizeScene({ stateType: 'sprint' }).stateType, null);
    eq(normalizeScene({ stateType: 0        }).stateType, null);
  });

  // ── setVar round-trip through normalizeSession ──────────────────────────
  // Regression: state.js inline allowlists previously omitted 'setVar',
  // causing setVar rules/triggers to silently reset to pause/none on import.
  t('normalizeSession preserves setVar rule action type', () => {
    const s = normalizeSession({
      rules: [{
        id: 'r1', enabled: true, name: 'Set score',
        condition: { metric: 'attention', op: '<', value: 0.3 },
        durationSec: 5, cooldownSec: 30,
        action: { type: 'setVar', param: 'score=10' },
      }],
    });
    eq(s.rules[0].action.type,  'setVar',    'setVar must survive normalizeSession');
    eq(s.rules[0].action.param, 'score=10', 'param must survive normalizeSession');
  });

  t('normalizeSession preserves setVar trigger successAction', () => {
    const s = normalizeSession({
      triggers: [{
        id: 't1', enabled: true, name: 'Trigger',
        atSec: 10, windowDurSec: 5, cooldownSec: 60,
        condition: { metric: 'attention', op: '<', value: 0.3 },
        successAction: { type: 'setVar', param: 'level=5' },
        failureAction: { type: 'none',   param: null },
      }],
    });
    eq(s.triggers[0].successAction.type,  'setVar', 'setVar successAction must survive');
    eq(s.triggers[0].successAction.param, 'level=5');
  });

  t('normalizeSession preserves setVar trigger failureAction', () => {
    const s = normalizeSession({
      triggers: [{
        id: 't1', enabled: true, name: 'T',
        atSec: 5, windowDurSec: 5, cooldownSec: 30,
        condition: { metric: 'attention', op: '<', value: 0.3 },
        successAction: { type: 'pause',  param: null },
        failureAction: { type: 'setVar', param: 'phase=end' },
      }],
    });
    eq(s.triggers[0].failureAction.type,  'setVar', 'setVar failureAction must survive');
    eq(s.triggers[0].failureAction.param, 'phase=end');
  });

  t('normalizeSession double round-trip preserves setVar action', () => {
    const once = normalizeSession({
      rules: [{ id: 'r1', enabled: true, name: 'R',
        condition: { metric: 'attention', op: '<', value: 0.3 },
        durationSec: 3, cooldownSec: 20,
        action: { type: 'setVar', param: 'x=1' } }],
    });
    const twice = normalizeSession(once);
    eq(twice.rules[0].action.type,  'setVar');
    eq(twice.rules[0].action.param, 'x=1');
  });

  // ── normalizeBlock: viz block fields ──────────────────────────────────────
  t('normalizeBlock defaults vizType to spiral', () => {
    const b = normalizeBlock({ type: 'viz' });
    eq(b.vizType, 'spiral');
  });

  t('normalizeBlock preserves valid vizType', () => {
    for (const vt of ['spiral','pendulum','tunnel','pulse','vortex']) {
      eq(normalizeBlock({ type: 'viz', vizType: vt }).vizType, vt);
    }
  });

  t('normalizeBlock rejects unknown vizType → spiral', () => {
    eq(normalizeBlock({ type: 'viz', vizType: 'rainbow' }).vizType, 'spiral');
  });

  t('normalizeBlock defaults vizSpeed to 1.0', () => {
    eq(normalizeBlock({ type: 'viz' }).vizSpeed, 1.0);
  });

  t('normalizeBlock clamps vizSpeed min to 0.25', () => {
    ok(normalizeBlock({ type: 'viz', vizSpeed: 0.01 }).vizSpeed >= 0.25);
  });

  t('normalizeBlock clamps vizSpeed max to 4', () => {
    eq(normalizeBlock({ type: 'viz', vizSpeed: 99 }).vizSpeed, 4);
  });

  t('normalizeBlock preserves vizColor string', () => {
    eq(normalizeBlock({ type: 'viz', vizColor: '#7a1a2e' }).vizColor, '#7a1a2e');
  });

  t('normalizeBlock defaults vizColor to gold', () => {
    eq(normalizeBlock({ type: 'viz' }).vizColor, '#c49a3c');
  });

  t('normalizeBlock round-trips all viz fields', () => {
    const b = normalizeBlock({ type: 'viz', vizType: 'vortex', vizSpeed: 2.5, vizColor: '#ffffff' });
    eq(b.vizType, 'vortex');
    eq(b.vizSpeed, 2.5);
    eq(b.vizColor, '#ffffff');
  });

  // ── normalizeFunscriptTrack: variant field ─────────────────────────────────
  t('normalizeFunscriptTrack defaults variant to empty string', () => {
    eq(normalizeFunscriptTrack({}).variant, '');
  });

  t('normalizeFunscriptTrack preserves valid variant values', () => {
    for (const v of ['Soft','Standard','Intense','Custom']) {
      eq(normalizeFunscriptTrack({ variant: v }).variant, v, `variant ${v} should survive`);
    }
  });

  t('normalizeFunscriptTrack rejects unknown variant → empty string', () => {
    eq(normalizeFunscriptTrack({ variant: 'Ultra' }).variant, '');
  });

  t('normalizeFunscriptTrack preserves empty string variant', () => {
    eq(normalizeFunscriptTrack({ variant: '' }).variant, '');
  });

  t('normalizeFunscriptTrack round-trip preserves variant', () => {
    const once  = normalizeFunscriptTrack({ variant: 'Intense', actions: [{ at: 0, pos: 50 }] });
    const twice = normalizeFunscriptTrack(once);
    eq(twice.variant, 'Intense');
  });


  // ── defaultSession: hudOptions ────────────────────────────────────────────
  t('defaultSession has hudOptions object', () => {
    const s = normalizeSession(defaultSession());
    ok(s.hudOptions && typeof s.hudOptions === 'object');
  });

  t('hudOptions.showMetricBars defaults to true', () => {
    ok(normalizeSession(defaultSession()).hudOptions.showMetricBars === true);
  });

  t('hudOptions.showScene defaults to true', () => {
    ok(normalizeSession(defaultSession()).hudOptions.showScene === true);
  });

  t('hudOptions.showMacroSlots defaults to true', () => {
    ok(normalizeSession(defaultSession()).hudOptions.showMacroSlots === true);
  });

  t('hudOptions.showVariables defaults to true', () => {
    ok(normalizeSession(defaultSession()).hudOptions.showVariables === true);
  });

  t('hudOptions.showHint defaults to false', () => {
    ok(normalizeSession(defaultSession()).hudOptions.showHint === false);
  });

  t('hudOptions.hideAfterSec defaults to 2.5', () => {
    eq(normalizeSession(defaultSession()).hudOptions.hideAfterSec, 2.5);
  });

  t('hudOptions are merged (not replaced) on normalizeSession', () => {
    const s = normalizeSession({ hudOptions: { showHint: true, showScene: false } });
    ok(s.hudOptions.showHint   === true,  'explicit true preserved');
    ok(s.hudOptions.showScene  === false, 'explicit false preserved');
    ok(s.hudOptions.showMetricBars === true, 'default true filled in for unset field');
  });

  // ── defaultSession: displayOptions ───────────────────────────────────────
  t('defaultSession has displayOptions object', () => {
    ok(normalizeSession(defaultSession()).displayOptions && typeof normalizeSession(defaultSession()).displayOptions === 'object');
  });

  t('displayOptions.showFsHeatmap defaults to true', () => {
    ok(normalizeSession(defaultSession()).displayOptions.showFsHeatmap === true);
  });

  t('displayOptions.richIdleScreen defaults to true', () => {
    ok(normalizeSession(defaultSession()).displayOptions.richIdleScreen === true);
  });

  t('displayOptions.sensorBridgeUrl defaults to ws://localhost:8765', () => {
    eq(normalizeSession(defaultSession()).displayOptions.sensorBridgeUrl, 'ws://localhost:8765');
  });

  t('displayOptions.sensorBridgeAuto defaults to false', () => {
    ok(normalizeSession(defaultSession()).displayOptions.sensorBridgeAuto === false);
  });

  t('displayOptions merge preserves explicit false', () => {
    const s = normalizeSession({ displayOptions: { showFsHeatmap: false, richIdleScreen: false } });
    ok(s.displayOptions.showFsHeatmap  === false);
    ok(s.displayOptions.richIdleScreen === false);
  });

  t('normalizeSession round-trips hudOptions without corruption', () => {
    const original = normalizeSession({ hudOptions: { showHint: true, hideAfterSec: 5, showScene: false } });
    const twice    = normalizeSession(original);
    ok(twice.hudOptions.showHint   === true);
    ok(twice.hudOptions.hideAfterSec === 5);
    ok(twice.hudOptions.showScene  === false);
  });


  // ── session.mode field ────────────────────────────────────────────────────
  t('defaultSession includes mode:null', () => {
    const s = normalizeSession(defaultSession());
    ok('mode' in s, 'mode field should exist on normalised session');
    ok(s.mode === null, 'mode should default to null');
  });

  t('normalizeSession preserves a string mode value', () => {
    const s = normalizeSession({ mode: 'induction' });
    eq(s.mode, 'induction');
  });

  t('normalizeSession preserves mode:null from explicit null', () => {
    const s = normalizeSession({ mode: null });
    ok(s.mode === null);
  });

  t('normalizeSession round-trips mode through double normalisation', () => {
    const first  = normalizeSession({ mode: 'conditioning' });
    const second = normalizeSession(first);
    eq(second.mode, 'conditioning');
  });

  // ── variables field now in defaultSession ─────────────────────────────────
  t('defaultSession variables field is an empty object', () => {
    const s = normalizeSession(defaultSession());
    ok(typeof s.variables === 'object' && !Array.isArray(s.variables));
    eq(Object.keys(s.variables).length, 0);
  });


  // ── hudOptions.hideAfterSec clamping ─────────────────────────────────────
  t('normalizeSession clamps hideAfterSec below 0.5 to 0.5', () => {
    const s = normalizeSession({ hudOptions: { hideAfterSec: 0 } });
    ok(s.hudOptions.hideAfterSec >= 0.5, `got ${s.hudOptions.hideAfterSec}`);
  });

  t('normalizeSession clamps hideAfterSec above 30 to 30', () => {
    const s = normalizeSession({ hudOptions: { hideAfterSec: 9999 } });
    ok(s.hudOptions.hideAfterSec <= 30, `got ${s.hudOptions.hideAfterSec}`);
  });

  t('normalizeSession fixes non-finite hideAfterSec to default 2.5', () => {
    const s = normalizeSession({ hudOptions: { hideAfterSec: NaN } });
    eq(s.hudOptions.hideAfterSec, 2.5);
  });

  t('normalizeSession preserves valid hideAfterSec in range', () => {
    const s = normalizeSession({ hudOptions: { hideAfterSec: 7 } });
    eq(s.hudOptions.hideAfterSec, 7);
  });


  return R.summary();
}
